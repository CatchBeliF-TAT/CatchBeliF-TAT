#!/bin/bash
##############################################################################
# Example command to build the whole project with shell.
##############################################################################
# 
# This script shows how one can build scope with shell.

SCOPE_ROOT="$(cd "$(dirname "$0")/../" && pwd)"
SCOPE_BUILD_ROOT=$SCOPE_ROOT/build
EXT_CMAKE_BUILD_ARGS=""

######################### Building Scope #########################
echo "============================================================"
echo "Building Scope ... "
echo "Building directory $SCOPE_BUILD_ROOT"

for i in $(set | grep ^USE_ ); do \
    echo "${i}"
    EXT_CMAKE_BUILD_ARGS="${EXT_CMAKE_BUILD_ARGS} -D${i}" ; \
done

echo "EXT_CMAKE_BUILD_ARGS: ${EXT_CMAKE_BUILD_ARGS}"
echo "============================================================"
if ! [ -d $SCOPE_BUILD_ROOT ]; then
  mkdir $SCOPE_BUILD_ROOT
fi
cd $SCOPE_BUILD_ROOT
cmake .. -DCMAKE_INSTALL_PREFIX=$SCOPE_BUILD_ROOT \
         -DCMAKE_BUILD_TYPE=Release  \
         -DUSE_CUDA=ON \
         -DUSE_CUDNN=ON \
         -DUSE_OpenCV=ON \
         -DBUILD_SHARED_LIBS=ON \
         ${EXT_CMAKE_BUILD_ARGS}

make -j"$(nproc)" install
