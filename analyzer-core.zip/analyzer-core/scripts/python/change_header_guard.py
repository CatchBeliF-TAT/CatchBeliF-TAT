import argparse
import glob
import re


### This script should be called in the project root
### python scripts/python/change_header_guard.py -p 'analyzer/algorithm/**/*.hpp'

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='unify header protect macro')
    parser.add_argument('--patten', '-p', required=True, help='The patten used to find source file')
    args = parser.parse_args()

    for header in glob.glob(args.patten, recursive=True):
        macro = re.sub(r'[-./\s]', '_', header).upper() + '_'

        with open(header, 'r') as f:
            lines = f.readlines()

            for n, line in enumerate(lines):
                if '#ifndef' in line:
                    lines[n] = '#ifndef {}\n'.format(macro)
                    break

            for n, line in enumerate(lines):
                if '#define' in line:
                    lines[n] = '#define {}\n'.format(macro)
                    break

            for n, line in enumerate(lines[::-1]):
                if '#endif' in line:
                    lines[-(n + 1)] = '#endif  // {}\n'.format(macro)
                    break

        with open(header, 'w') as f:
            for line in lines:
                f.write(line)
