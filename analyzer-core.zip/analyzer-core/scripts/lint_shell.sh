#!/bin/bash

set -e

if [ -x "$(command -v clang-format)" ]; then
  CLANG_FORMAT_BIN="clang-format"
elif [ -x "$(command -v clang-format-6.0)" ]; then
  CLANG_FORMAT_BIN="clang-format-6.0"
else
  echo "Can not find clang-format executable"
  exit 1
fi

PROJECT_ROOT="$(cd "$(dirname "$0")/../" && pwd)"

filelist=$(find "$PROJECT_ROOT/analyzer/algorithm" \( -name "*.[ch]pp" -or -name "*.cu" \) -type f)

for f in $filelist; do
  ${CLANG_FORMAT_BIN} -style=file -i "$f"
  changed=$(git status --porcelain -- "$f" | grep '^ M' | cut -c4-)
  if [[ -n $changed ]]; then
    changelist+=("${changed}")
  fi
done

if [[ ${#changelist[@]} -gt 0 ]]; then
  echo "The following files have clang-format problems"
  for f in "${changelist[@]}"; do
    echo "$f"
  done
  exit 1
fi
