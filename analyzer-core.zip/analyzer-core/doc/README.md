## alg_events_engine

|算法模块|模型参数名|模型参数含义|参数类型|默认值|
|--|:--:|--|--|--|
|通用参数|gpu_id|GPU卡 ID|int|0|
|通用参数|detect_batch_size|检测batchSize|int|1|
|团雾检测|weather_model|模型路径|string|""|
|团雾检测|detect_interval|团雾检测间隔|int|25|
|抛洒物|traffic_det_model|抛洒物检测模型|string|“”|
|抛洒物|leftobject_classify_model|抛洒物分类模型|string|“”|
|抛洒物|bg_interval|背景建模的间隔|int|1|
|行人(非机动车)闯入|detect_last_|局部检测次数|int|5|
|行人(非机动车)闯入|detect_interval_global_|全局跳帧时间|int|25*60|
|行人(非机动车)闯入|detect_interval_local_|局部跳帧间隔|int|2|
|行人(非机动车)闯入|detect_last_|局部检测次数|int|5|
|交通灯异常|traffic_sign_model|交通灯异常检测模型路径|string|“”|
|交通灯异常|traffic_sign_detect_interval|交通灯异常检测间隔|int|50|
