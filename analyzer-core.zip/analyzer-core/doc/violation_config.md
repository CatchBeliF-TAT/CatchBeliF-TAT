- [违法行为布控配置说明](#违法行为布控配置说明)
  - [共通部分](#共通部分)
    - [流对应的字段](#流对应的字段)
    - [违章对应字段](#违章对应字段)
    - [conditions 过线配置](#conditions-过线配置)
    - [conditions 区域配置](#conditions-区域配置)
  - [违法行为布控过滤规则说明](#违法行为布控过滤规则说明)
    - [按车辆类型过滤](#按车辆类型过滤)
    - [按特种车辆类型过滤](#按特种车辆类型过滤)
    - [按非机动类型过滤](#按非机动类型过滤)
    - [按非机动车行为过滤](#按非机动车行为过滤)
    - [施工人员分类过滤](#施工人员分类过滤)
    - [车牌类别过滤](#车牌类别过滤)
- [机动车](#机动车)
  - [大弯小转](#大弯小转)
  - [实线变道](#实线变道)
  - [不按导向线行驶](#不按导向线行驶)
  - [机动车占用非机动车道](#机动车占用非机动车道)
  - [网格线停车](#网格线停车)
  - [不礼让行人](#不礼让行人)
  - [变更车道影响其他机动车](#变更车道影响其他机动车)
  - [连续变道(2111)](#连续变道2111)
  - [危险路段掉头](#危险路段掉头)
  - [闯禁令](#闯禁令)
  - [占用公交车道](#占用公交车道)
  - [禁止大货车](#禁止大货车)
  - [大型车占用小型车车道](#大型车占用小型车车道)
  - [客货分道](#客货分道)
  - [违法停车](#违法停车)
  - [车辆限时](#车辆限时)
  - [路口滞留](#路口滞留)
  - [越线停车](#越线停车)
  - [车道平均车速](#车道平均车速)
  - [车道占用率](#车道占用率)
  - [交通状态](#交通状态)
  - [排队长度v2](#排队长度v2)
  - [车辆碰线(2750)](#车辆碰线(2750))
  - [占用应急车道](#占用应急车道)
  - [穿越导流线](#穿越导流线)
  - [特种车辆抓拍](#特种车辆抓拍)
  - [特种车辆抓拍2](#特种车辆抓拍2)
  - [车辆倒车](#车辆倒车)
  - [车辆逆行](#车辆逆行)
  - [车辆逆行v2 (2454)](#车辆逆行v2-2454)
  - [车辆加塞 (2127)](#车辆加塞-2127)
  - [大货车右转停车时间不足 (2128)](#大货车右转停车时间不足-2128)
  - [蛇形行驶](#蛇形行驶)
  - [网格线停车v2](#网格线停车v2)
  - [左转不让直行(2134)](#左转不让直行2134)
  - [车辆排队长度(2740)](车辆排队长度(2740))
- [非机动车](#非机动车)
  - [非机动车占用人行道](#非机动车占用人行道)
  - [违反禁令标志](#违反禁令标志)
  - [在机动车道行驶](#在机动车道行驶)
  - [非机动车不戴头盔](#非机动车不戴头盔)
  - [非机动车越线停车](#非机动车越线停车)
  - [逆向行驶](#逆向行驶)
  - [闯红灯](#闯红灯)
- [交通事件](#交通事件)
  - [道路拥堵](#道路拥堵)
  - [车辆闯入](#车辆闯入)
  - [高速违法停车(2416)](#高速违法停车2416)
  - [超速行驶(2451)](#超速行驶2451)
  - [低速行驶(2452)](#低速行驶2452)
  - [违法停车v3](#违法停车v3)
  - [违法停车提示](#违法停车提示)
  - [占道经营(2463)](#占道经营2463)
  - [车辆驶入人行道(2464)](#车辆驶入人行道2464)
  - [非法运营非机动车聚集(2465)](#非法运营非机动车聚集2465)
  - [非机动车碰撞事故(2466)](#非机动车碰撞事故2466)
  - [人车混乱(2467)](#人车混乱2467)
  - [火焰烟雾检测](#火焰烟雾检测)
  - [红绿灯异常检测v2 (2440)](#红绿灯异常检测v2-2440)
  - [红绿灯异常检测(2441)](#红绿灯异常检测2441)
  - [高速异常停车](#高速异常停车)
  - [高速车辆逆行](#高速车辆逆行)
  - [高速实线变道](#高速实线变道)
  - [高速穿越导流线](#高速穿越导流线)
  - [高速占用应急车道](#高速占用应急车道)
  - [高速大型车占用主车道](#高速大型车占用主车道)
  - [高速大货车](#高速大货车)
  - [高速连续变道](#高速连续变道)
  - [高速抛洒物(2433)](#高速抛洒物2433)
  - [高速行人闯入(2434)](#高速行人闯入2434)
  - [高速团雾天气(2435)](#高速团雾天气2435)
  - [高速群体减速(2470)](#高速群体减速2470)
  - [高速群体变道(2471)](#高速群体变道2471)
  - [高速抛洒物v2 (2438)](#高速抛洒物v2-2438)
  - [疑似事故2416](#疑似事故2416)
  - [异常停车v2](异常停车v2-2455)
- [共享单车](#共享单车)
  - [共享单车乱停放(2462)](#共享单车乱停放2462)
- [施工监管](#施工监管)
  - [施工超时](#施工超时)
  - [施工超期](#施工超期)
  - [施工超区域](#施工超区域)
  - [施工超时第二版](#施工超时第二版)
  - [施工超期第二版](#施工超期第二版)
  - [施工超区域第二版](#施工超区域第二版)
  - [占道施工](#占道施工)
- [倒地](#倒地)
  - [人员倒地](#人员倒地)
- [安全帽](#安全帽)
  - [戴安全帽](#戴安全帽)
  - [未戴安全帽](#未戴安全帽)
- [客流](#客流)
  - [排队人数异常报警,定时上报](#排队人数异常报警定时上报)
  - [区域人数异常报警,定时上报](#区域人数异常报警定时上报)
  - [人流计数](#人流计数)
  - [越线识别](#越线识别)
  - [翻栏杆](#翻栏杆)
  - [人员逆行](#人员逆行)
  - [区域入侵](#区域入侵)
  - [行人聚集](#行人聚集)
  - [人员拉横幅](#人员拉横幅)
  - [打架](#打架)
  - [徘徊滞留](#徘徊滞留)
  - [截帧服务](#截帧服务)

## 违法行为布控配置说明

### 共通部分

布控配置用于表示判断违法行为时的一些关键的线和区域，用目标（人车非）和这些线、区域的关系，以及产生关系的先后顺序，来判断目标是否符合某种违法行为。
其中，一个布控任务可以对应多个子场景（机动车/非机动车）的布控配置。

布控配置的大体结构

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            // 公共字段
            "code": "2101",
            "name": "xxxxxxxxxxxx",  // 具体违法名称
            "on": true,              // 是否开启
            // 以下是具体违法类型的自定义字段，字段含义、格式等均不固定
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "stop_line",
                    "type": "multi_line",
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569] // 8个float表示两个线段
                },
                {
                    "name": "violate_box",
                    "type": "polygon",
                    "parking_second": 10,
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569] // >=6个float表示一个区域
                },
                {
                    "name": "violate_box_2",
                    "type": "multi_polygon",
                    "parking_second": 10,
                    "data_offset": [12, 24], // 每个面的数据偏移
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569] // >=6个float表示一个区域
                }
            ]
        },
        {
            ...
        }
    ]
}
```

#### 流对应的字段

| 字段名 | 类型 | 说明 |
|----|----|----|
| rois | [2*N]int | 事件感兴趣区域（不在区域内的发生的事件不关心，不进行检测跟踪） |
| enable_tracking_debug | bool | 是否开启跟踪调试框 |

#### 违章对应字段

| 字段名 | 类型 | 说明 |
|----|----|----|
| code | string | `code` 违章的事件代码 |
| name | string | `name` 违章的事件描述文字（暂时没有使用） |
| on | bool | 是否开启该违规（暂时没有使用？） |
| snapshotidx| int | 前端配置下来的特写用的图片序号|

#### conditions 过线配置

| 字段名 | 类型 | 说明 |
|----|----|----|
| type | string | `line`、`multi_line` 线或多线类型 |
| data | []float  | 线数组, 格式[x1,y1,x2,y2], 如果为多线则长度是4的整数倍 |
| mode_args.type | string | 过线模式`center_across`、`box_touch`, 不填默认为`box_touch` |
| mode_args.center.x | float | 模式`center_across`下, 中心点的位置x轴的比例, 默认不设置为0.5  |
| mode_args.center.y | float | 模式`center_across`下, 中心点的位置y轴的比例, 默认不设置为0.5  |

样例：
```json
{
    "violations": [
        {
            "conditions": [
                {
                    "name" : "start_line",
                    "type" : "line",
                    "data" : [0,0,100,200],
                    "mode_args": {
                        "type": "center_across",
                        "center": {
                            "x": 0.5,
                            "y": 1.0
                        }
                    }
                }
            ]
        }
    ]
}
```
#### conditions 区域配置

| 字段名 | 类型 | 说明 |
|----|----|----|
| type | string | `polygon`、`multi_polygon` 线或多线类型 |
| data | []float  | 线数组, 格式[x1,y1,x2,y2,x3,y3], 如果为多线则长度是2的整数倍且大于等于6 |
| mode_args.center.x | float | 中心点的位置x轴的比例, 默认不设置为0.5  |
| mode_args.center.y | float | 中心点的位置y轴的比例, 默认不设置为0.5  |

样例：
```json
{
    "violations": [
        {
            "conditions": [
                {
                    "name" : "violation_box",
                    "type" : "polygon",
                    "data" : [0,0,100,0,100,200,0,200],
                    "mode_args": {
                        "center": {
                            "x": 0.5,
                            "y": 1.0
                        }
                    }
                }
            ]
        }
    ]
}
```

### 违法行为布控过滤规则说明

#### 按车辆类型过滤

| 字段名 | 类型 | 说明 |
|----|----|----|
| sub_type | [N]string | 机动车细分类 |
| action | string | 黑白名单,默认 空: 白名单, "drop": 黑名单 |

[车辆类型](alg_biz_label.md#机动车细分类)

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "xxx",
            "name": "xxx",
            "on": true,
            "conditions": [
                {
                    "name" : "sub_type",
                    "sub_type" : [
                        "Car",
                        "Bus",
                        "Heavy_Truck"
                    ]
                }
            ]
        }
    ]
}
```

#### 按特种车辆类型过滤

| 字段名 | 类型 | 说明 |
|----|----|----|
| special_car_type | [N]string | 机动车特种车辆分类 |
| action | string | 黑白名单,默认 空: 白名单, "drop": 黑名单 |

[机动车特种车辆分类](alg_biz_label.md#机动车特种车辆分类)

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "xxx",
            "name": "xxx",
            "on": true,
            "conditions": [
                {
                    "name" : "special_car_type",
                    "special_car_type" : [
                        "Police_Car",
                        "Law_Car",
                        "Fire_Car"
                    ]
                }
            ]
        }
    ]
}
```

#### 按非机动类型过滤

| 字段名 | 类型 | 说明 |
|----|----|----|
| nonmotor_type | [N]string | 非机动车类型细分类 |
| action | string | 黑白名单,默认 空: 白名单, "drop": 黑名单 |

[非机动车类型细分类](alg_biz_label.md#非机动车类型细分类)

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "xxx",
            "name": "xxx",
            "on": true,
            "conditions": [
                {
                    "name" : "nonmotor_type",
                    "nonmotor_type" : [
                        "motor",
                        "ebike"
                    ]
                }
            ]
        }
    ]
}
```

#### 按非机动车行为过滤

| 字段名 | 类型 | 说明 |
|----|----|----|
| nonmotor_behaviour | [N]string | 非机动车行为细分类 |
| action | string | 黑白名单,默认 空: 白名单, "drop": 黑名单 |

[非机动车行为细分类](alg_biz_label.md#非机动车行为细分类)

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "xxx",
            "name": "xxx",
            "on": true,
            "conditions": [
                {
                    "name" : "nonmotor_behaviour",
                    "nonmotor_behaviour" : [
                        "no_helmet",
                        "manned"
                    ]
                }
            ]
        }
    ]
}
```

#### 施工人员分类过滤

| 字段名 | 类型 | 说明 |
|----|----|----|
| person_type | [N]string | 施工人员分类 |
| action | string | 黑白名单,默认 空: 白名单, "drop": 黑名单 |

[施工人员分类](alg_biz_label.md#施工人员分类)

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "xxx",
            "name": "xxx",
            "on": true,
            "conditions": [
                {
                    "name" : "person_type",
                    "person_type" : [
                        "NonWorker"
                    ]
                }
            ]
        }
    ]
}
```

#### 车牌类别过滤

| 字段名 | 类型 | 说明 |
|----|----|----|
| plate_type | [N]string | 车牌细分类 |
| action | string | 黑白名单,默认 空: 白名单, "drop": 黑名单 |

[车牌细分类](alg_biz_label.md#车牌细分类)

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "xxx",
            "name": "xxx",
            "on": true,
            "conditions": [
                {
                    "name" : "plate_type",
                    "plate_type" : [
                        "d_yellow"
                    ]
                }
            ]
        }
    ]
}
```

## 机动车

### 大弯小转

| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | |
| violate_line | [4]int | 指车辆左转时压到的实线 |
| stop_line | [4]int | 1条线，表示左转完成之后的结束线，用于第三张取证 |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2101",
            "name": "大弯小转",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569] // 8个float表示两个线段
                }
            ]
        }
    ]
}
```

### 实线变道

判定规则:
1. 过`start_line` 线，取第一张取证图，进入步骤2;
2. 过`violate_line` 线，取第二张取证图,进入步骤3;
3. 过`stop_line`线，取第三张取证图，出事件

| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 指车辆跨越的实线 |
| stop_line | [N*4]int | 表示左转完成之后的结束线，用于第三张取证 |

### 不按导向线行驶

| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 车辆经过路口的线 |
| stop_line | [N*4]int | 未按导向线行驶之后经过的路口线 |

### 机动车占用非机动车道

| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 车辆经过路口的线 |
| stop_line | [N*4]int | 未按导向线行驶之后经过的路口线 |

### 网格线停车

| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的网格线区域 |
| parking_second | int | 可选，默认10，表示判断网格线停车的事件阈值 |
| cooling_second | int | 冷却时间 |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2101",
            "name": "网格线停车",
            "on": true,
            "cooling_second" : 30,
            "conditions": [
                {
                    "name": "violate_box",
                    "type": "polygon",
                    "parking_second": 10,
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569] // >=6个float表示一个区域
                }
            ]
        }
    ]
}
```

### 不礼让行人

| 字段名 | 类型 | 说明 |
|----|----|----|
| person_detect_roi| [N*2*4]int | 行人检测区 |
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 车辆经过路口的线 |
| stop_line | [4]int | 车辆驶离的结束线 |
| person_box | [N*2, N>2]int | 行人判定区域,多边形 |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "person_detect_roi": [x1, y1, x2, y2, x3, y3, x4, y4],
    "violations": [
        {
            "code": "0000",
            "name": "不礼让行人",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "person_box",
                    "type": "polygon",
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 变更车道影响其他机动车
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |

### 连续变道(2111)
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |
| cross_angle | float | 车辆穿过车道线的最小夹角[0,90] (废弃, 效果不好)|
| direction_angle_min | float | 车辆朝向与车道线的最小夹角[0,90], 只存在于某一条车道线上, 越大过滤的数据越多 |
| direction_angle_span | float | 夹角计算的时间间隔, 只存在于某一条车道线上, 单位秒, 默认1s不需要调节 |

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "2111",
            "name": "连续变道",
            "on": true,
            "cross_angle_删除": 40,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569],
                    "direction_angle_min": 15
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 危险路段掉头
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |

### 闯禁令
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |

### 占用公交车道
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |

### 禁止大货车
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |

### 大型车占用小型车车道
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |

### 客货分道
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |

### 违法停车
同网格线停车

### 车辆限时
| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_line | [4]int | 违法(中间)线 |
| start_date | int64  | 施工结束时间，1970年1月1日0点0分0秒开始到现在的毫秒数 |
| end_date   | int64  | 施工结束时间，1970年1月1日0点0分0秒开始到现在的毫秒数 |
| available_times*  | [2*N]int | 表示多个可以施工的时间段，每个时间点的表示为 HH 小时 * 100 + MM 分钟，例如 1200，表示 12:00 |
| week_pattern*     | string   | 正则表达式, 如星期一或星期二:`1|2`, 星期日或星期六:`0|6`, 默认匹配所有
| plate_pattern*    | string   | 正则表达式, 沪C和非沪牌:`^((沪C)|(?!沪)).*$`, 默认匹配所有
注:
如`available_times_XXXX, week_pattern_XXXX, plate_pattern_XXXX` 相同后缀名为一组条件, 可以包含任意组条件
没有后缀也是合法的组合`available_times, week_pattern, plate_pattern`

样例：

```json
{
  "violations" : [
    {
      "name" : "车辆限时",
      "code" : "2119",
      "on" : true,
      "roi" : [1579.0, 1325.0, 2284.0, 1330.0, 2687.0, 1972.0, 1643.0, 1945.0],
      "conditions" : [
          {
            "name" : "violate_line",
            "type" : "line",
            "data" : [1590.0, 1182.0, 2221.0, 1203.0]
          },
          {
            "name" : "start_date",
            "type": "int64",
            "data_number": 1561627786000,
            "commnet1": "2019-06-27 17:31:19+08:00",
            "commnet2": "date '+%s'"
          },
          {
            "name" : "end_date",
            "type": "int64",
            "data_number": 1561627786000
          },
          {
            "name" : "available_times",
            "type" : "span",
            "data" : [800, 1000, 1700, 1900]
          },
          {
            "name" : "week_pattern",
            "type": "regex",
            "data_string": "1|2|3|4|5"
          },
          {
            "name" : "plate_pattern",
            "type": "regex",
            "data_string": "^((沪C)|(?!沪)).*$"
          },
          {
            "name" : "available_times_test1",
            "type" : "span",
            "data" : [800, 1000, 1700, 1900]
          },
          {
            "name" : "week_pattern_test1",
            "type": "regex",
            "data_string": "1|2|3|4|5"
          },
          {
            "name" : "plate_pattern_test1",
            "type": "regex",
            "data_string": "^((沪C)|(?!沪)).*$"
          }
      ]
    }
  ]
}
```

### 路口滞留
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 开始线 |
| violate_box | [2*N]int | 停车区域 |
| parking_second | int | 停车区域内滞留时长(秒) |
| car_count | int | 停车区域内滞留时最少的车数 |
| traffic_light_box | [2*n]int | 红绿等框 |

样例：
```json
{
  "violations" : [
    {
      "name" : "路口滞留",
      "code" : "2120",
      "on" : true,
      "roi": [930,1200,2360,1180,2810,1910,190,1910],
      "traffic_light_box": [2005, 390, 2020, 450],
      "conditions" : [
        {
          "name" : "start_line",
          "type" : "line",
          "data" : [
              1850.0,
              1800.0,
              2550.0,
              1800.0
          ]
        },
        {
          "name" : "violate_box",
          "type" : "polygon",
          "data" : [
              1880.0,
              1170.0,
              2200.0,
              1170.0,
              2200.0,
              1380.0,
              1880.0,
              1380.0
          ],
          "parking_second" : 10,
          "car_count": 2
        }
      ]
    }
  ]
}
```
### 越线停车
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 开始线 |
| violate_box | [2*N]int | 停车区域 |
| parking_second | int | 停车区域内滞留时长(秒) |
| traffic_light_box | [2*N]int | 红绿等框 |

样例：
```json
{
  "violations" : [
    {
      "name" : "越线停车",
      "code" : "2107",
      "on" : true,
      "roi": [930,1200,2360,1180,2810,1910,190,1910],
      "traffic_light_box": [2005, 390, 2020, 450],
      "conditions" : [
        {
          "name" : "start_line",
          "type" : "line",
          "data" : [
              1850.0,
              1800.0,
              2550.0,
              1800.0
          ]
        },
        {
          "name" : "violate_box",
          "type" : "polygon",
          "data" : [
              1880.0,
              1170.0,
              2200.0,
              1170.0,
              2200.0,
              1380.0,
              1880.0,
              1380.0
          ],
          "parking_second" : 10
        }
      ]
    }
  ]
}
```
### 车道平均车速
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 开始线 |
| stop_line | [4]int | 终止线 |
| distance | float | 两条线之间的距离 |

样例：
```json
{
  "violations" : [
    {
      "name" : "车道平均速度",
      "code" : "2710",
      "on" : true,
      "roi": [930,1200,2360,1180,2810,1910,190,1910],
      "conditions" : [
        {
          "name" : "start_line",
          "type" : "line",
          "data" : [
              1850.0,
              1800.0,
              2550.0,
              1800.0
          ]
        },
        {
          "name" : "stop_line",
          "type" : "line",
          "data" : [
              1850.0,
              1800.0,
              2550.0,
              1800.0
          ],
          "distance" : 10.0
        }
      ]
    }
  ]
}
```

### 车道占用率
| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 检测区域 |

样例：
```json
{
  "violations" : [
    {
      "name" : "车道占用率",
      "code" : "2720",
      "on" : true,
      "roi": [930,1200,2360,1180,2810,1910,190,1910],
      "conditions" : [
        {
          "name" : "violate_box",
          "type" : "polygon",
          "data" : [
              1880.0,
              1170.0,
              2200.0,
              1170.0,
              2200.0,
              1380.0,
              1880.0,
              1380.0
          ]
        }
      ]
    }
  ]
}
```

### 交通状态
| 字段名 | 类型 | 说明 |
|----|----|----|
| data | [16] float | 8个点表示4条线 |
| standard_speed | float | 自由流速度，用于判断交通状态，默认为30.0 |
| car_count | int | 最小车流，车流较小时不计算，默认为3 |
| multi_distance | [3] float  | 四条线之间的三段实际距离 |
| time_ratio | string | "line"、"box"，选择用线或框的方式计算时间占有率，默认为box |

样例：
```json
{
  "violations" : [
    {
      "name" : "交通状态",
      "code" : "2730",
      "on" : true,
      "roi": [930,1200,2360,1180,2810,1910,190,1910],
      "conditions" : [
        {
          "name" : "traffic_status",
          "data" : [
              966.0,
              963.0,
              1893.0,
              969.0,
              1005.0,
              801.0,
              1833.0,
              794.0,
              1026.0,
              641.0,
              1742.0,
              626.0,
              1062.0,
              454.0,
              1616.0,
              451.0
          ],
          "standard_speed" : 35.0,
          "car_count" : 3,
          "multi_distance" : [
              6,
              6,
              6
          ],
          "time_ratio" : "line"
        }
      ]
    }
  ]
}
```

### 车辆碰线(2750)

判定逻辑: 车过`start_line`和`end_line`都会出一个事件

| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| stop_line  | [4]int | 终止线  |
| mode_args.type | string | 过线模式`center_across`、`box_touch`, 不填默认为`box_touch` |
| mode_args.center.x | float | 模式`center_across`下, 中心点的位置x轴的比例, 默认不设置为0.5  |
| mode_args.center.y | float | 模式`center_across`下, 中心点的位置y轴的比例, 默认不设置为0.5  |

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "2750",
            "name": "车辆碰线",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569],
                    "mode_args": {
                        "type": "center_across",
                        "center": {
                            "x": 0.5,
                            "y": 1.0
                        }
                    }
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569],
                    "mode_args": {
                        "type": "center_across",
                        "center": {
                            "x": 0.5,
                            "y": 1.0
                        }
                    }
                }
            ]
        }
    ]
}
```
### 排队长度v2

判定逻辑， 选取`violate_box`的所有车辆，每秒输出一个事件。

| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 违停区域 |
| mode_args.type | string | 过线模式`center_across`、`box_touch`, 不填默认为`box_touch` |
| mode_args.center.x | float | 模式`center_across`下, 中心点的位置x轴的比例, 默认不设置为0.5  |
| mode_args.center.y | float | 模式`center_across`下, 中心点的位置y轴的比例, 默认不设置为0.5  |

样例：
```json
{
  "violations" : [
    {
      "name" : "排队长度v2",
      "code" : "2760",
      "on" : true,
      "roi": [930,1200,2360,1180,2810,1910,190,1910],
      "conditions" : [
        {
          "name" : "violate_box",
          "type" : "polygon",
          "data" : [
              1880.0,
              1170.0,
              2200.0,
              1170.0,
              2200.0,
              1380.0,
              1880.0,
              1380.0
          ],
          "mode_args": {
                "type": "center_across",
                "center": {
                    "x": 0.5,
                    "y": 1.0
                }
            }
        }
      ]
    }
  ]
}
```


### 占用应急车道
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "2125",
            "name": "占用应急车道",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 穿越导流线
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "2126",
            "name": "穿越导流线",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 特种车辆抓拍
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线+碰线模式 |
| violate_line | [4]int | 违法(中间)线+碰线模式 |
| stop_line | [4]int | 终止线+碰线模式 |
| available_times*  | [2*N]int | 表示多个抓拍的时间段，每个时间点的表示为 HH 小时 * 100 + MM 分钟，例如 1200，表示 12:00 |
| filter_line | [4]int | 屏蔽线 |
| special_car_type | [N]string | 车型配置，为弹框的形式 |

[特种车辆类型](alg_biz_label.md#机动车特种车辆分类)

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "2140",
            "name": "特种车辆抓拍",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name" : "filter_line",
                    "type" : "line",
                    "data" : [1668, 553, 2435, 569]
                },
                {
                    "name" : "available_times",
                    "data" : [1200, 1300]
                },
                {
                    "name" : "special_car_type",
                    "special_car_type" : [
                        "Police_Car",
                        "Law_Car",
                        "Fire_Car"
                    ]
                }
            ]
        }
    ]
}
```

### 特种车辆抓拍2

同特种车辆抓拍
特种车辆抓拍2 code:2141


### 车辆倒车
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |
| direction | string | 过线时的车头方向(Rear \ Front \ No_Direction) |

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "2443",
            "name": "车辆倒车",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name" : "direction",
                    "direction" : [
                        "Rear"
                    ]
                }
            ]
        }
    ]
}
```

### 车辆逆行

判定规则:
1. 过`start_line`，取第一张取证图,进入步骤2;
2. 过`violate_line` ， 取第二张取证图，进步骤3;
3. 过`stop_line` ，取第三张取证图，出事件;

| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |
| direction | string | 过线时的车头方向(Rear \ Front \ No_Direction) |

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "2411",
            "name": "车辆逆行",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                   "name" : "direction",
                   "direction" : [
                       "Front"
                   ]
                }
            ]
        }
    ]
}
```

### 车辆逆行v2 (2454)
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| stop_line | [4]int | 终止线 |
| threshold | float | 倒车灵敏度,默认0.5(即倒车距离与线距的比值) |

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "2454",
            "name": "车辆逆行v2",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569],
                    "threshold": 0.2,
                }
            ]
        }
    ]
}
```

### 车辆加塞 (2127)
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法线, 默认中心点过线 |
| violate_box | [N*2]int | 排队车道框 |
| stop_line | [4]int | 终止线 |

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "2127",
            "name": "车辆加塞",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "center_across": true,
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name" : "violate_box",
                    "type" : "polygon",
                    "data" : [
                        1880.0,
                        1170.0,
                        2200.0,
                        1170.0,
                        2200.0,
                        1380.0,
                        1880.0,
                        1380.0
                    ]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569],
                }
            ]
        }
    ]
}
```

### 大货车右转停车时间不足 (2128)
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法线 |
| parking_second | float | 最小停车时长 |
| stop_line | [4]int | 终止线 |


样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "2128",
            "name": "大货车右转停车时间不足",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name" : "violate_box",
                    "type" : "polygon",
                    "data" : [
                        1880.0,
                        1170.0,
                        2200.0,
                        1170.0,
                        2200.0,
                        1380.0,
                        1880.0,
                        1380.0
                    ],
                    "parking_second" : 3
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569],
                }
            ]
        }
    ]
}
```
### 蛇形行驶
| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_line | [4]int | 违法线 |
| violate_box | [2*N]int | 蛇形驾驶判定区域 |

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "2472",
            "name": "蛇形驾驶",
            "on": true,
            "conditions": [
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name" : "violate_box",
                    "type" : "polygon",
                    "data" : [
                        1880.0,
                        1170.0,
                        2200.0,
                        1170.0,
                        2200.0,
                        1380.0,
                        1880.0,
                        1380.0
                    ]
                }
            ]
        }
    ]
}
```

### 网格线停车v2
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 开始线 |
| violate_box | [2*N]int | 停车区域 |
| parking_second | int | 停车区域内滞留时长(秒) |
| traffic_light_box | [2*N]int | 红绿等框 |

样例：
```json
{
  "violations" : [
    {
      "name" : "网格线停车v2",
      "code" : "2130",
      "on" : true,
      "roi": [930,1200,2360,1180,2810,1910,190,1910],
      "traffic_light_box": [2005, 390, 2020, 450],
      "conditions" : [
        {
          "name" : "start_line",
          "type" : "line",
          "data" : [
              1850.0,
              1800.0,
              2550.0,
              1800.0
          ]
        },
        {
          "name" : "violate_box",
          "type" : "polygon",
          "data" : [
              1880.0,
              1170.0,
              2200.0,
              1170.0,
              2200.0,
              1380.0,
              1880.0,
              1380.0
          ],
          "parking_second" : 10
        }
      ]
    }
  ]
}
```

### 左转不让直行(2134)
| 字段名 | 类型 | 说明 |
|----|----|----|
| zuo_start_line | [4]int | 左转开始线 |
| zuo_end_line   | [4]int | 左转结束线 |
| zhi_start_line | [4]int | 直行开始线 |
| zhi_end_line   | [4]int | 直行结束线 |

样例：
```json
{
  "violations" : [
    {
      "name" : "左转不让直行",
      "code" : "2134",
      "on" : true,
      "conditions": [
            {
                "name": "zuo_start_line",
                "type": "line",
                "data": [
                    431.0,
                    265.0,
                    590.0,
                    265.0
                ]
            },
            {
                "name": "zuo_end_line",
                "type": "line",
                "data": [
                    130.0,
                    150.0,
                    110.0,
                    216.0
                ]
            },
            {
                "name": "zhi_start_line",
                "type": "line",
                "data": [
                    385.0,
                    127.0,
                    450.0,
                    127.0
                ]
            },
            {
                "name": "zhi_end_line",
                "type": "line",
                "data": [
                    295.0,
                    274.0,
                    425.0,
                    274.0
                ]
            }
        ]
    }
  ]
}
```

### 车辆排队长度(2740)

判定逻辑: 
相邻2跟线组成一个roi区域的集合A,  判定车的选定点在A的哪个roi内部， 在里面的话选取组成roi区域的远的线距离为`vehicle_queue`， 若车在由第一根线或者最后一根线组成的roi区域，会判定选定点以及上下边框中点， 只要由一个点在区域就算在区域内。 然后对每个车都做这个操作。 每分钟取停够`parking_second`的车中`vehicle_queue`最长的为事件的`vehicle_queue`,出事件。

| 字段名 | 类型 | 说明 |
|----|----|----|
| data | [4*N] float | 8个点表示4条线,N与multi_distance的长度对应 | 
| parking_second | int | 停留时间，默认为3s|
| multi_distance | [N] float  | 排队线,最多为10 |
| type | string | 类型为isoline |
| mode_args.type | string | 过线模式`center_across`、`box_touch`, 不填默认为`box_touch` |
| mode_args.center.x | float | 模式`center_across`下, 中心点的位置x轴的比例, 默认不设置为0.5  |
| mode_args.center.y | float | 模式`center_across`下, 中心点的位置y轴的比例, 默认不设置为0.5  |

样例：
```json
{
  "violations": [
    {
      "name": "车道占用率",
      "code": "2740",
      "on": true,
      "conditions": [
        {
          "name": "isoline",
          "type": "isoline",
          "parking_second": 10,
          "data": [
            1880,
            1170,
            2200,
            1170,
            2200,
            1380,
            1880,
            1380
          ],
          "multi_distance": [
            6,
            12
          ],
          "mode_args": {
                "type": "center_across",
                "center": {
                    "x": 0.5,
                    "y": 1.0
                }
            }
        }
      ]
    }
  ]
}
        
```

## 非机动车

### 非机动车占用人行道

| 字段名 | 类型 | 说明 |
|----|----|----|
| roi | [2*N]int | 可选，N个点围成的区域, [x0, y0, x1, y1, ...] |
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |

样例：

```json
{
    // "rois": [[...], [...]],         // 通过 violations[].roi 合并而成，前端不需要关心，由后端完成合并
    "violations": [
        {
            "code": "2205",
            "name": "在人行道行驶",
            "on": true,
            "condition_order": false,		//三条配置线没有触碰顺序限制，默认为true
            "roi": [200,200,1017,200,1838,427,1653,1002,1017,1079,0,1079,0,1059,0,900],
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "enable_draw": true,	//触碰此线渲染流开始画框，默认为false
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569] // 8个float表示两个线段
                }
            ]
        },
        {
            // ...
        }
    ]
}
```

### 违反禁令标志

样例：

```json
{
    "violations": [
        {
            "code": "2206",
            "name": "违反禁令标志",
            "on": true,
            //其他同上
        }
    ]
}
```

### 在机动车道行驶

样例：

```json
{
    "violations": [
        {
            "code": "2204",
            "name": "占用机动车道",
            "on": true,
            //其他同上
        }
    ]
}
```

### 非机动车不戴头盔
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |

样例：
```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],
    "violations": [
        {
            "code": "2209",
            "name": "非机动车不戴头盔",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 非机动车越线停车
| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 开始线 |
| violate_box | [2*N]int | 停车区域 |
| parking_second | int | 停车区域内滞留时长(秒) |
| traffic_light_box | [2*N]int | 红绿等框 |

样例：
```json
{
  "violations" : [
    {
      "name" : "非机动车越线停车",
      "code" : "2208",
      "on" : true,
      "roi": [930,1200,2360,1180,2810,1910,190,1910],
      "traffic_light_box": [2005, 390, 2020, 450],
      "conditions" : [
        {
          "name" : "start_line",
          "type" : "line",
          "data" : [
              1850.0,
              1800.0,
              2550.0,
              1800.0
          ]
        },
        {
          "name" : "violate_box",
          "type" : "polygon",
          "data" : [
              1880.0,
              1170.0,
              2200.0,
              1170.0,
              2200.0,
              1380.0,
              1880.0,
              1380.0
          ],
          "parking_second" : 10
        }
      ]
    }
  ]
}
```

### 逆向行驶

| 字段名 | 类型 | 说明 |
|----|----|----|
| roi | [2*N]int | 可选，N个点围成的区域, [x0, y0, x1, y1, ...] |
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |

样例：

```json
{
    "violations": [
        {
            "code": "2202",
            "name": "逆向行驶",
            "on": true,
            "condition_order": true,		//三条配置线触碰有顺序限制
            "roi": [200,200,1017,200,1838,427,1653,1002,1017,1079,0,1079,0,1059,0,900],
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "enable_draw": true,	//触碰此线渲染流开始画框，默认为false
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569] // 8个float表示两个线段
                }
            ]
        },
        {
            // ...
        }
    ]
}
```

### 闯红灯

| 字段名 | 类型 | 说明 |
|----|----|----|
| roi | [2*N]int | 可选，N个点围成的区域, [x0, y0, x1, y1, ...] |
| traffic_light_box | [2*N]int | 信号灯区域，N个点的多边形 |
| start_line | [4]int | 起始线 |
| violate_line | [4]int | 违法(中间)线 |
| stop_line | [4]int | 终止线 |
⚠️:如没有配置红绿灯,则不会产生任何事件
样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "traffic_light_box": [12,23,34,45,56,67,78,89],
    "violations": [
        {
            "code": "xxxxxx",
            "name": "闯红灯",
            "on": true,
            "conditions": [
                {
                    "name": "start_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "violate_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "stop_line",
                    "type": "multi_line",
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569] // 8个float表示两个线段
                }
            ]
        }
    ]
}
```

### 违法停车v3
| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 违停区域 |
| pre_parking_second | int | 停车区域内车辆预停留时间 |
| parking_second | int | 停车区域内滞留时长(秒) |
| max_car_count  | int | 违停区域内车辆数上限 |

样例：
```json
{
  "violations" : [
    {
      "name" : "违法停车(移动版)",
      "code" : "2133",
      "on" : true,
      "roi": [930,1200,2360,1180,2810,1910,190,1910],
      "conditions" : [
        {
          "name" : "violate_box",
          "type" : "polygon",
          "data" : [
              1880.0,
              1170.0,
              2200.0,
              1170.0,
              2200.0,
              1380.0,
              1880.0,
              1380.0
          ],
          "parking_second" : 10,
          "max_car_count"  : 1
        }
      ]
    }
  ]
}
```
### 违法停车提示
code 2142
同违法停车v3
## 交通事件
### 道路拥堵

判定规则 : 
1. 在`violate_box`区域区域内，如果未设置`cover_ratio`，则`violate_box`区域内的车数量大于等于
最小停车数量，如果设置了`cover_ratio`，还需要满足`violate_box`内车辆覆盖区域的比例不小于`cover_ratio`，满足前面条件取第一张证据图并进入步骤2;
2. 在`violate_box`区域区域内，如果未设置`cover_ratio`，持续`parking_second`的时间，`violate_box`内部车的数量都大于`car_count`，如果设置了`cover_ratio`，则同时还要满足内车辆覆盖区域的比例不大于`cover_ratio`，满足取第二张取证图出事件，进入步骤3, 如果出现`violate_box`内车辆的覆盖率小于等于`cover_rati`或者车的数量小于`car_count`,清掉取证图，重新进入步骤1；
3. 在持续时间达到`cooling_second`后， 清除所有取证图，重新进入步骤1.

| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| parking_second | int | 可选，默认10，表示判断网格线停车的事件阈值 |
| cooling_second | int | 冷却时间 |
| car_count      | int | 车辆的数目 | 负数不检测, 正数区域内没有离开的车辆必须大于car_count |
| cover_ratio    | float | 车辆覆盖区域的比例 | 负数不检测, 正数区域内覆盖比必须大于该值 |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2431",
            "name": "交通拥堵",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
                {
                    "name": "violate_box",
                    "type": "polygon",
                    "parking_second": 10,
                    "car_count": -1,
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569] // >=6个float表示一个区域
                }
            ]
        }
    ]
}
```

### 车辆闯入

判定规则:
1. 车辆框在整个图的合适位置并且第一条线在车辆框的缩小框内,取第一张取证图,进入步骤2;
2. 车辆框的中心点在`violate_box`内, 取第二张取证图, 进入步骤3;
3. 车辆框的中心点在`violate_box`内, 并且当前时间减去取第二张取证图的时间的差大于`parking_second`,取第三张取证图，出事件，结束。

| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [4]int | 起始线 |
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| parking_second | int | 可选，默认10，表示判断车辆闯入的事件阈值 |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2442",
            "name": "车辆闯入",
            "on": true,
            "conditions": [
            	{
                    "name": "start_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "violate_box",
                    "type": "polygon",
                    "parking_second": 10,
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569] // >=6个float表示一个区域
                }
            ]
        }
    ]
}
```

### 高速违法停车(2416)

判定规则:
https://cf.supremind.info/pages/viewpage.action?pageId=73204049

| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| parking_second | int | 可选，默认10，表示判断网格线停车的事件阈值 |
| cooling_second | int | 冷却时间 |
| car_count      | int | 车辆的数目 | 负数不检测, 区域内没有离开的车辆须<=car_count
| person_count   | int | 行人的数目 | 负数不检测, 区域内的最小行人数字须>=person_count

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2416", // old 2124
            "name": "高速违法停车",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
                {
                    "name": "violate_box",
                    "type": "polygon",
                    "parking_second": 10,
                    "car_count": -1,
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569] // >=6个float表示一个区域
                }
            ]
        }
    ]
}
```

### 超速行驶(2451)

判定规则:
1. 车框过第一条线`start_line`, 取第一张取证图,取证图数据存入时间`t1`，进入步骤2;
2. 如果车框过第二条线`end_line`, 当前时间`t2` ，算出speed = `distance`\(t2-t1)，如果speed > `max_speed`,取第二张图，出事件。

| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [2*2]int | 起始线 |
| stop_line | [2*2]int | 结束线 |
| distance | float | 两条线中间的距离(米) |
| max_speed | float | 最大车速限制(km/hs) |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2451",
            "name": "超速行驶",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
            	{
                    "name": "start_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "distance": 10.1,
                    "max_speed": 40,
                    "data": [1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 低速行驶(2452)

判定规则:
1. 车框过第一条线`start_line`, 取第一张取证图,取证图数据存入时间`t1`，进入步骤2;
2. 如果车框过第二条线`end_line`, 当前时间`t2` ，算出speed = `distance`\(t2-t1)，如果speed < `min_speed`,取第二张图，出事件。

| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [2*2]int | 起始线 |
| stop_line | [2*2]int | 结束线 |
| distance | float | 两条线中间的距离(米) |
| min_speed | float | 最大车速限制 |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2452",
            "name": "低速行驶",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
            	{
                    "name": "start_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "parking_second": 10,
                    "data": [1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 占道经营(2463)

判定规则: 
1. 目标车辆框的中心在`violate_box`内, 并且在距离车辆中心以`distance`(默认为0.1*max(img.width,img.height))为半径的圆内, 人、车、飞机动车的数据分别大于`person_count`、`car_count`、`nonmotor_count`，记录下这些目标为map_pre，取第一张取证图并记录当前时间t1，进入步骤2;
2. 目标车辆框的中心在`violate_box`内, 并且在距离车辆中心以`distance`(默认为0.1*max(img.width,img.height))为半径的圆内, 人、车、飞机动车在这个区域内并且在之前的map_pre中，并分别大于`person_count`、`car_count`、`nonmotor_count`，取当前时间t2，否则重新清除取证图，重新进入步骤1。然后如果t2-t1>`parking_second`，取第二张取证图，并出事件,进入步骤3; 
3. 从t2时间开始，等待 `cooling_second`后，清除取证图，重新进入步骤1。

| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| cooling_second | int | 冷却时间,秒单位 |
| parking_second | int | 可选，默认60s，表示判断人和车停留的时间阈值 |
| car_count | int | 可选， 默认1个，表示车的数量|
| nonmotor_count | int | 可选 ,默认1个， 表示非机动车的数量|
｜ person_count ｜ int | 可选, 默认1个，表示人的数量｜
| distance | float | 距离车的判定距离范围 |

样例：

```json
{
    "violations": [
        {
            "code": "2463",
            "name": "占道经营",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
            	{
                    "name": "violate_box",
                    "type": "polygon",
                    "parking_second": 60,
                    "data": [2062, 650, 2422, 1307, 1668, 553, 2435, 569],
                    "car_count" : 1,
                    "person_count" : 2,
                    "nonmotor_count": 2,
                    "distance": 100.1
                }
            ]
        }
    ]
}
```

### 车辆驶入人行道(2464)

判定规则:
1. 车框刚进入`violate_box` , 按配置确定是哪个点在框中,记下时间t1，取第一张取证图，然后进入步骤2;
2. 车框在框从进入时间t1，如果持续`parking_second`在`violate_box`内，取第二张证据图，并且出事件，进入步骤3；
3. 等待`cooling_second`后，清空取证图，重新进入步骤1.

| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| cooling_second | int | 冷却时间,秒单位 |
| parking_second | int | 可选，默认60s，表示判断人和车停留的时间阈值 |

样例：

```json
{
    "violations": [
        {
            "code": "2464",
            "name": "车辆驶入人行道",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
            	{
                    "name": "violate_box",
                    "type": "polygon",
                    "parking_second": 60,
                    "data": [2062, 650, 2422, 1307, 1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 非法运营非机动车聚集(2465)

判定规则:
1. 将图中`violate_box`里非机动车按相距小于`distance`的作为一个group，对每个group进行有人的非机动车进行计数为`count_zairen_nonmotor`,如果`count_zairen_nonmotor` >= `nonmotor_count`，记录在图中的非机动车pre_obj,取一张取证图，进入步骤2；
2. 将图中非机动车按相距小于‘distance’的作为一个group, 到`parking_second`时间后，找出在`violate_box`并且在上个步骤的pre_obj中，再进行group， ，对每个group进行有人的非机动车进行计数为`count_zairen_nonmotor`,如果`count_zairen_nonmotor` >= `nonmotor_count`，取一张取证图，出事件，进入步骤3;
3. `cooling_second` 时间满足后，清空取证图，回到步骤1；

| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| cooling_second | int | 冷却时间,秒单位 |
| parking_second | int | 可选，默认60s，表示判断人和车停留的时间阈值 |
| nonmotor_count | int | 停车区域内滞留时最少的车数 |
| distance | float | distance为-1， 取全图的范围，距离车的判定距离范围 |

样例：

```json
{
    "violations": [
        {
            "code": "2465",
            "name": "非法运营非机动车聚集",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
            	{
                    "name": "violate_box",
                    "type": "polygon",
                    "parking_second": 60,
                    "nonmotor_count": 5,
                    "data": [2062, 650, 2422, 1307, 1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 非机动车碰撞事故(2466)

判定规则: 同code 2465

| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| cooling_second | int | 冷却时间,秒单位 |
| parking_second | int | 可选，默认60s，表示判断人和车停留的时间阈值 |
| nonmotor_count | int | 停车区域内最少的非机动车车数 |
| person_count   | int | 停车区域内最少的人数 |

样例：

```json
{
    "violations": [
        {
            "code": "2466",
            "name": "非机动车碰撞事故",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
            	{
                    "name": "violate_box",
                    "type": "polygon",
                    "parking_second": 60,
                    "nonmotor_count": 5,
                    "person_count": 6,
                    "data": [2062, 650, 2422, 1307, 1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 人车混乱(2467)

判定逻辑 : 同code 2465

| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| cooling_second | int | 冷却时间,秒单位 |
| parking_second | int | 可选，默认60s，表示判断人和车停留的时间阈值 |
| car_count | int | 停车区域内最少的车数 |
| nonmotor_count | int | 停车区域内最少的车数 |
| person_count | int | 停车区域内最少的人数 |

样例：

```json
{
    "violations": [
        {
            "code": "2467",
            "name": "人车混乱",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
            	{
                    "name": "violate_box",
                    "type": "polygon",
                    "parking_second": 60,
                    "car_count": 5,
                    "nonmotor_count": 6,
                    "person_count": 7,
                    "data": [2062, 650, 2422, 1307, 1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 火焰烟雾检测

判定规则:
1. 如果距离上个取证图片时间大于`cooling_second`,模型检测图片中火焰分数大于`threshold` 或者 烟雾分数大于等于 `threshold`,将这张图片做取证图，并且出事件.

| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| threshold | float | 分类置信度阈值, 默认 0.6f |
| parking_second | int | 持续时长,秒单位 |
| cooling_second | int | 冷却时间,秒单位 |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2437",
            "name": "火焰烟雾检测",
            "on": true,
            "cooling_second" : 10,
            "conditions": [
                {
                    "name": "violate_box",
                    "type": "polygon",
                    "threshold" : 0.9,
                    "parking_second": 3,
                    "data": [0.0,0.0,1920.0,0.0,1920.0,1080.0,0.0,1080.0]
                }
            ]
        }
    ]
}
```

### 红绿灯异常检测v2 (2440)
| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| threshold | float | 灵敏度, 统计周期内黑色的占比, 默认值1 |
| parking_second | int | 统计周期, 同period_second, 后面废弃 |
| period_second | int | 统计周期, 红绿灯等为黑的持续时间 |
| period_second2 | int | 统计周期2, 红绿灯不变的持续时间 |
| cooling_second | int | 冷却时间,秒单位 |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2440",
            "name": "红绿灯异常检测v2",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
                {
                    "name": "violate_box",
                    "type": "polygon",
                    "threshold" : 0.8,
                    "period_second" : 600,
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 红绿灯异常检测(2441)
| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| threshold | float | 红绿灯检测阈值 |
| parking_second | int | 统计周期 |
| cooling_second | int | 冷却时间,秒单位 |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2441",
            "name": "红绿灯异常检测",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
                {
                    "name": "violate_box",
                    "type": "polygon",
                    "threshold" : 0.8,
                    "parking_second" : 30,
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 高速异常停车

判定规则: 
1. 车框进入`violate_box`内, 取第一张取证图，进入步骤2;
2. 若车框在移动，回到步骤1；若车框在`violate_box`内停够`cooling_second`/3~`cooling_second`/6 ,取第二张取证图，进入步骤3;
3. 时间够`parking_second`后，若车框动了，回到步骤1， 在图中车框不动并且`violate_box`内的车框数量大于`goasu_yongdu_count`前提下，如果开出去的车数量少于`goasu_yongdu_count`，回到步骤1，如果停在区域内的车数量大于`goasu_yongdu_count`并且停留时间大于 2*`parking_second`, 回到步骤1, 如果停在区域内的车数量大于`goasu_yongdu_count`并且停留时间小于 2*`parking_second`，保持步骤2；如果`violate_box` 里面的人数量少于`person_count`，回到步骤1， 否则取第三张图，出事件，结束。

| 字段名 | 类型 | 说明 |
|----|----|----
| cooling_second | int | 冷却时长(秒) | 600 ｜
| violate_box | [2*N]int | 停车区域 |
| parking_second | int | 停车区域内滞留时长(秒) |
｜ goasu_yongdu_count｜ int | 默认为4 |
| person_count | int | 默认-1， 表示不限制 |

样例：
```json
{
  "violations" : [
    {
      "name" : "高速异常停车",
      "code" : "2432",
      "on" : true,
      "roi": [930,1200,2360,1180,2810,1910,190,1910],
      "cooling_second": 600,
      "conditions" : [
        {
          "name" : "violate_box",
          "type" : "polygon",
          "data" : [
              1880.0,
              1170.0,
              2200.0,
              1170.0,
              2200.0,
              1380.0,
              1880.0,
              1380.0
          ],
          "parking_second" : 10
        }
      ]
    }
  ]
}
```

### 高速车辆逆行

判定规则:
同 车辆逆行

| 字段名 | 类型 | 说明 |
|----|----|----|

 同 车辆逆行
 code: 2411

### 高速实线变道

判定规则:
同 实线变道

| 字段名 | 类型 | 说明 |
|----|----|----|

 同 实线变道
 code: 2412 // old 原：2151

### 高速穿越导流线

判定规则:
同 实线变道

| 字段名 | 类型 | 说明 |
|----|----|----|

同 实线变道
 code: 2413 // old 原：2154

### 高速占用应急车道

判定规则:
1. 过`start_line` 线，取第一张取证图，进入步骤2;
2. 过`violate_line` 线，取第二张取证图,进入步骤3;
3. 过`stop_line`线，取第三张取证图，出事件.

| 字段名 | 类型 | 说明 |
|----|----|----|

 同 占用公交车道
 code: 2414

### 高速大型车占用主车道

判定逻辑:
1. 过`start_line` 线，取第一张取证图，车辆属性属性是大型车(几个车辆属性的集合)，进入步骤2;
2. 过`violate_line` 线，取第二张取证图,进入步骤3;
3. 过`stop_line`线，取第三张取证图，出事件.

| 字段名 | 类型 | 说明 |
|----|----|----|

 同 占用公交车道
 code: 2415

### 高速大货车

判定规则:
1. 过`start_line` 线，取第一张取证图，属性是大货车(几种车辆属性的集合)，进入步骤2;
2. 过`violate_line` 线，取第二张取证图,进入步骤3;
3. 过`stop_line`线，取第三张取证图，出事件.

| 字段名 | 类型 | 说明 |
|----|----|----|

 同 禁止大货车
 code: 2417 // old 2153

### 高速连续变道

判定规则:
1. 车辆中心点通过车道线1
2. 车辆中心点通过车道线2
3. 车辆中心点通结束线, 上报事件

| 字段名 | 类型 | 说明 |
|----|----|----|

code: 2444 // old 2111


### 高速抛洒物(2433)

判定规则:
1. 区域中对别出现图像变化的区域
2. 检测区域中的车辆, 用车辆过滤掉变化的区域, 剩余的区域即为抛洒物, 则上报事件, 并开始冷却

| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| threshold | float | 分类置信度阈值, 默认 0.5f |
| cooling_second | int | 冷却时间,秒单位 |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2433",
            "name": "高速抛洒物",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
                {
                    "name": "violate_box",
                    "type": "polygon",
                    "threshold" : 0.5,
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 高速行人闯入(2434)

判定规则:
1. 区域内出现行人,并且行人数目大于阈值, 并开始冷却

| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| person_count | int | 行人闯入的数量, 默认值2 |
| cooling_second | int | 冷却时间,秒单位 |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2434",
            "name": "高速行人闯入",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
                {
                    "name": "violate_box",
                    "type": "polygon",
                    "person_count" : 2,
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569]
                }
            ]
        }
    ]
}
```

### 高速团雾天气(2435)

判定规则:
1. 视频图片的fog分类大于设定的阈值,则上报事件,并开始冷却

| 字段名 | 类型 | 说明 |
|----|----|----|
| threshold | float | 分类置信度阈值, 默认 0.5f |
| cooling_second | int | 冷却时间,秒单位, 默认 600s |

样例：

```json
{
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2435",
            "name": "高速团雾天气",
            "on": true,
            "cooling_second" : 600,
            "conditions": [
                {
                    "name": "violate_box",
                    "threshold" : 0.5,
                }
            ]
        }
    ]
}
```

### 高速群体减速(2470)

判定规则:
1. 通过`开始线`,`结束线`,`线距(distance)`, 以分钟为周期计算平均速度
2. 当有车辆的速度小于上个周期的平均速度*down_scale, 则记车辆数加一
3. 当减速的车辆数大于设定的`car_count`, 则上报事件, 然后开始冷却

| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [2*2]int | 起始线 |
| stop_line | [2*2]int | 结束线 |
| distance | float | 两条线之间的距离, 默认 0.0f |
| car_count | int | 最小车辆数,默认3 | 
| max_speed | float | 上个周的最大有效速度, 默认 250.0f |
| min_speed | float | 上个周的最小有效速度, 默认 2.5f |
| down_scale | float | 减速(致)比例, 默认 0.25f |

样例：

```json
{
    "violations": [
        {
            "code": "2470",
            "name": "高速群体减速",
            "on": true,
            "conditions": [
            	{
                    "name": "start_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569],
                    "distance": 10.1,
                    "max_speed": 40,
                    "max_speed": 400,
                    "car_count" : 5,
                    "down_scale": 0.5
                }
            ]
        }
    ]
}
```

### 高速群体变道(2471)

判定规则:
1. 当车辆依次通过车道1,车道2,则记变道车辆数加一
2. 当统计周期内变道车辆数大于设定的`car_count`, 则上报事件, 然后开始冷却

| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [2*2]int | 起始线 |
| stop_line | [4*N]int | 结束线 |
| car_count | int | 最小车辆数,默认3 | 

样例：

```json
{
    "violations": [
        {
            "code": "2471",
            "name": "高速群体变道",
            "on": true,
            "conditions": [
            	{
                    "name": "start_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },,
                {
                    "name": "stop_line",
                    "type": "multi_line",
                    "data": [1668, 553, 2435, 569, 1668, 553, 2435, 569], // 8个float表示两个线段
                    "car_count" : 5
                }
            ]
        }
    ]
}
```
### 高速抛洒物v2 (2438)

判定规则:
1. 区域中检测出现抛洒物, 并且阈值大于设置
2. 若干秒内, 区域内相同位置上仍然有大于阈值的抛洒物, 则上报事件, 并开始冷却

同 2433

### 疑似事故2416

判定规则:
https://cf.supremind.info/pages/viewpage.action?pageId=73204049

| 字段名 | 类型 | 说明 |
|----|----|----
| cooling_second | int | 冷却时长(秒) | 600
| violate_box | [2*N]int | 停车区域 |
| parking_second | int | 停车区域内滞留时长(秒) |

样例：
```json
{
  "violations" : [
    {
      "name" : "疑似事故",
      "code" : "2416",
      "on" : true,
      "roi": [930,1200,2360,1180,2810,1910,190,1910],
      "cooling_second": 600,
      "conditions" : [
        {
          "name" : "violate_box",
          "type" : "polygon",
          "data" : [
              1880.0,
              1170.0,
              2200.0,
              1170.0,
              2200.0,
              1380.0,
              1880.0,
              1380.0
          ],
          "parking_second" : 10
        }
      ]
    }
  ]
}
```
### 异常停车v2

判定规则:
https://cf.supremind.info/pages/viewpage.action?pageId=69633921

| 字段名 | 类型 | 说明 |
|----|----|----|
| start_line | [2*2]int | 起始线 |
| stop_line | [2*2]int | 结束线 |
| violate_box | [2*N]int | 停车区域 |
| car_count | int | 最小车辆数 | 
| person_count | int | 最小人数 |
| cooling_second | int | 冷却时间 |
| parking_second ｜ int | 停车时间 |

样例：

```json
{
    "violations": [
        {
            "code": "2455",
            "name": "异常停车v2",
            "on": true,
            "conditions": [
            	{
                    "name": "start_line",
                    "type": "line",
                    "data": [2062, 650, 2422, 1307]
                },
                {
                    "name": "stop_line",
                    "type": "line",
                    "data": [1668, 553, 2435, 569],
                }
                {
                    "name" : "violate_box",
                    "type" : "polygon",
                    "data" : [
                        1880.0,
                        1170.0,
                        2200.0,
                        1170.0,
                        2200.0,
                        1380.0,
                        1880.0,
                        1380.0
                    ],
                    "parking_second" : 10,
                    "cooling_second" : 300
                },
            ]
}
```
## 共享单车

### 共享单车乱停放(2462)

| 字段名 | 类型 | 说明 |
|----|----|----|
| cooling_second | int | 冷却时长(秒) | 600
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域 |
| nonmotor_count | int | 停留的共享单车数量 | 1
| parking_second | int | 统计的停留时长 | 60
样例：

```json
{
    "violations": [
    {
        "code" : "2462",
        "name" : "sharedbike",
        "on" : true,
        "cooling_second":60,
        "conditions" : [
            {
                "parking_second": 10,
                "nonmotor_count": 3,
                "name" : "violate_box",
                "type" : "polygon",
                "data" : [
                    1310,400,1420,400,1420,535,1310,535
                ]
            }
        ]
    }
    ]
}
```

## 施工监管

待定

### 施工超时

| 字段名 | 类型 | 说明 |
|----|----|----|
| alarm_frequency | int | 统计的周期(秒) |
| min_passing_vehicle_count | float | 假设该路段平均最少通过xxx辆车 | 1
| ratio | float | 目标区域车密度／背景区域车密度 < ratio1时，表示施工 |
| shigong_areas | [2*N]int | 多边形表示目标施工区域 |
| non_shigong_areas | [2*N]int | 多边形表示非工区域 |
| available_times | [2*N]int | 表示多个可以施工的时间段，每个时间点的表示为 HH 小时 * 100 + MM 分钟，例如 1200，表示 12:00 |
样例：

```json
{
    "detect_interval": 100,
    "rois": [[x1, y1, x2, y2, x3, y3, x4, y4, ...], [...], ...],        // 目标跟踪开始的识别多边形区域
    "violations": [
        {
            "code": "2301",
            "name": "施工超时",
            "on": true,
            "conditions": [
                {
                    "name": "alarm_frequency",
                    "type": "int",
                    "data_number": 100
                },
                {
                    "name": "min_passing_vehicle_count",
                    "type": "int",
                    "data_number": 5
                },
                {
                    "name": "ratio",
                    "type": "float",
                    "data_number": 0.5
                },
                {
                    "name": "shigong_areas",
                    "type": "polygon",
                    "data": [x,y,x1,y1,x2,y2]
                },
                {
                    "name": "non_shigong_areas",
                    "type": "polygon",
                    "data": [x,y,x1,y1,x2,y2]
                },
                {
                    "name": "available_times",
                    "type": "polygon",
                    "data": [800,1600]
                }
            ]
        }
    ]
}
```

### 施工超期

| 字段名 | 类型 | 说明 |
|----|----|----|
| alarm_frequency | int | 统计的周期(秒) |
| min_passing_vehicle_count | float | 假设该路段平均最少通过xxx辆车 |
| ratio | float | 目标区域车密度／背景区域车密度 < ratio1时，表示施工 |
| shigong_areas | [2*N]int | 多边形表示目标施工区域 |
| nonshigong_areas | [2*N]int | 多边形表示非工区域 |
| end_time | int64 | 施工结束时间，1970年1月1日0点0分0秒开始到现在的毫秒数 |

### 施工超区域
| 字段名 | 类型 | 说明 |
|----|----|----|
| alarm_frequency | int | 统计的周期(秒) |
| min_passing_vehicle_count | float | 假设该路段平均最少通过xxx辆车 |
| ratio | float | 目标区域车密度／背景区域车密度 < ratio1时，表示施工 |
| shigong_out_areas | [2*N]int | 多边形表示超出施工区域 |
| nonshigong_areas | [2*N]int | 多边形表示非工区域 |

### 施工超时第二版

| 字段名 | 类型 | 说明 |
|----|----|----|
| shigong_areas | [2*N]int | 多边形表示目标施工区域, threshold代表该区域内施工判断阀值(默认值300), weight代表不同目标权重(默认值1)，weight_label检测目标名|
| available_times | [2*N]int | 表示多个可以施工的时间段，每个时间点的表示为 HH 小时 * 100 + MM 分钟，例如 1200，表示 12:00 |
| cooling_second | int | 冷却时间(秒), 默认值10 |
| report_interval | int | 表示事件定期上报的时间间隔(秒), 如果为0则不上报, 默认值0 |
| period_second | float | 统计周期(秒), 默认值30 |
| cover_ratio | float | 施工时长占比, 范围0-1, 默认0.5 |

样例：

```json
{
        "violations" : [ 
            {
                "on" : true,
                "name" : "施工超时",
                "cooling_second" : 100,
                "conditions" : [ 
                    {
                        "period_second": 30,
                        "cover_ratio": 0.5,
                        "data" : [ 
                            668.0, 
                            521.0, 
                            1330.0, 
                            1047.0, 
                            1896.0, 
                            1050.0, 
                            1884.0, 
                            436.0, 
                            671.0, 
                            515.0
                        ],
                        "name" : "violate_box",
                        "type" : "multi_polygon",
                        "weight" : [ 
                            10, 
                            10, 
                            10, 
                            10, 
                            10, 
                            10, 
                            10, 
                            10, 
                            10, 
                            10
                        ],
                        "threshold" : 1000,
                        "weight_label" : [ 
                            "Worker", 
                            "NonWorker", 
                            "Crowd_Control_Barrier", 
                            "Warning_Sign", 
                            "Reflective_Road_Cone", 
                            "Watersafety_Barrier", 
                            "Paver", 
                            "Road_Roller", 
                            "Excavator", 
                            "Long_Arm_car"
                        ]
                    }, 
                    {
                        "data" : [ 
                            1010,
                            2355
                        ],
                        "name" : "available_times",
                        "type" : "array"
                    }, 
                    {
                        "name" : "report_interval",
                        "type" : "number",
                        "data_number" : 30
                    }
                ],
                "code" : "2306"
            }
        ]
}
```

### 施工超期第二版

| 字段名 | 类型 | 说明 |
|----|----|----|
| shigong_areas | [2*N]int | 多边形表示目标施工区域, threshold代表该区域内施工判断阀值(默认值300), weight代表不同目标权重(默认值1)，weight_label检测目标名|
| start_time | int64 | 施工开始时间，1970年1月1日0点0分0秒开始到现在的毫秒数 |
| end_time | int64 | 施工结束时间，1970年1月1日0点0分0秒开始到现在的毫秒数 |
| cooling_second | int | 冷却时间(秒), 默认值10 |
| report_interval | int | 表示事件定期上报的时间间隔(秒), 如果为0则不上报, 默认值0 |
| period_second | float | 统计周期(秒), 默认值30 |
| cover_ratio | float | 施工时长占比, 范围0-1, 默认0.5 |

### 施工超区域第二版
| 字段名 | 类型 | 说明 |
|----|----|----|
| shigong_out_areas | [2*N]int | 多边形表示超出施工区域, threshold代表该区域内施工判断阀值(默认值300), weight代表不同目标权重(默认值1)，weight_label检测目标名|
| cooling_second | int | 冷却时间(秒), 默认值10 |
| report_interval | int | 表示事件定期上报的时间间隔(秒), 如果为0则不上报, 默认值0 |
| period_second | float | 统计周期(秒), 默认值30 |
| cover_ratio | float | 施工时长占比, 范围0-1, 默认0.5 |
### 占道施工
| 字段名 | 类型 | 说明 |
|----|----|----|
| shigong_zhandao_areas | [2*N]int | 多边形表示占道施工区域, threshold代表该区域内施工判断阀值(默认值300), weight代表不同目标权重(默认值1)，weight_label检测目标名|
| cooling_second | int | 冷却时间(秒), 默认值10 |
| report_interval | int | 表示事件定期上报的时间间隔(秒), 如果为0则不上报, 默认值0 |

## 倒地
### 人员倒地
| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域|
| threshold | float | 检测阈值, 默认值0.9 |
| fall_thresh | float | 分类用阈值(目前为横纵比), 默认值2.0 |
| cooling_second | int | 冷却时间(秒), 默认值0 |

样例：
```json
{
    "violations": [
        {
            "code" : "6003",
            "name" : "fall",
            "on" : true,
            "render": true,
            "conditions" : [
                {
                    "name" : "violate_box",
                    "type" : "polygon",
                    "data" : [
                        0.0,
                        0.0,
                        1920.0,
                        0.0,
                        1920.0,
                        1080.0,
                        0.0,
                        1080.0
                    ],
                    "threshold": 0.9,
                    "fall_thresh": 2.0
                }
            ],
            "cooling_second":1
        }
    ]
}
```
## 安全帽
### 戴安全帽
| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域|
| cooling_second | int | 冷却时间(秒), 默认值1 |

样例：
```json
{
    "violations": [
        {
            "code" : "27",
            "name" : "safehelmet",
            "on" : true,
            "render": true,
            "conditions" : [
                {
                    "name" : "violate_box",
                    "type" : "polygon",
                    "data" : [
                        0.0,
                        0.0,
                        1920.0,
                        0.0,
                        1920.0,
                        1080.0,
                        0.0,
                        1080.0
                    ]
                }
            ],
            "cooling_second":1
        }
    ]
}
```

### 未戴安全帽
| 字段名 | 类型 | 说明 |
|----|----|----|
| violate_box | [2*N]int | 表示有N个点围成的封闭线区域|
| cooling_second | int | 冷却时间(秒), 默认值1 |


## 客流
### 排队人数异常报警,定时上报
| 字段名 | 类型 | 说明 |
|----|----|----|
| cooling_second | int | 排队人数超限上报冷却时间(秒)， 为-1时不上报 |
| min_num_threshold | int | 排队人数超限上报阈值 |
| report_span | int | 排队人数定时上报时间间隔(秒)， 为-1时不上报|
样例：
```json
    "analyze_config" : {
        "violations" : [ 
            {
                "name" : "排队人数",
                "on" : true,
                "roi" : [ 
                    {
                        "data" : [ 
                            117.0, 
                            84.0, 
                            120.0, 
                            849.0, 
                            1857.0, 
                            1017.0, 
                            1881.0, 
                            63.0
                        ]
                    }
                ],
                "code" : "15",
                "cooling_second" : 10.0,
                "report_span": 10.0,
                "min_num_threshold" : 15.0,
            }
        ]
    }
```
### 区域人数异常报警,定时上报
和排队人数一致，换一下code和name
### 人流计数
| report_span | int | 人流计数定时上报时间间隔(秒)|
| headcount_scene | int | 场景  0 1 2 ，分别为小场景、大场景、高密度|
```json
    "analyze_config" : {
        "violations" : [ 
            {
                "code" : "11",
                "on" : true,
                "lines" : [ 
                    {
                        "type" : 1.0,
                        "line" : [ 
                            593.0, 
                            214.0, 
                            1445.0, 
                            831.0
                        ]
                    }
                ],
                "report_span": 10.0,
                "headcount_scene": 1
            }
        ]
    }
```
### 越线识别
| cooling_second | int | 越线识别报警冷却时间(秒)|
```json
    "analyze_config" : {
        "violations" : [ 
            {
                "code" : "8",
                "on" : true,
                "lines" : [ 
                    {
                        "type" : 1.0,
                        "line" : [ 
                            593.0, 
                            214.0, 
                            1445.0, 
                            831.0
                        ]
                    }
                ],
                "cooling_second": 10.0,
                "headcount_scene": 1
            }
        ]
    }
```
### 翻栏杆
和越线识别一样，code换一下
### 人员逆行
和越线识别一样，code换一下
### 区域入侵
```json
    "analyze_config" : {
        "rois" : [],
        "violations" : [ 
            {
                "on" : true,
                "roi" : [ 
                    {
                        "data" : [ 
                            27.0, 
                            42.0, 
                            21.0, 
                            1038.0, 
                            1878.0, 
                            1038.0, 
                            1893.0, 
                            39.0
                        ]
                    }
                ],
                "cooling_second" : 300.0,
                "code" : "19",
                "enable_vehicle_detect": false
            }
        ]
    }
```
### 行人聚集
```json
    "analyze_config" : {
        "violations" : [ 
            {
                "min_time_threshold" : 10.0,
                "cooling_second" : 300.0,
                "code" : "1",
                "on" : true,
                "roi" : [ 
                    {
                        "id" : 1.0,
                        "data" : [ 
                            54.0, 
                            24.0, 
                            48.0, 
                            1056.0, 
                            1863.0, 
                            1059.0, 
                            1854.0, 
                            33.0
                        ]
                    }
                ],
                "min_num_threshold" : 5.0
            }
        ]
    }
```
### 人员拉横幅
```json
    "analyze_config" : {
        "violations" : [ 
            {
                "code" : "2",
                "on" : true,
                "roi" : [ 
                    {
                        "data" : [ 
                            605.0, 
                            253.0, 
                            518.0, 
                            704.0, 
                            1384.0, 
                            731.0, 
                            1523.0, 
                            202.0
                        ],
                        "id" : 1.0
                    }
                ],
                "cooling_second" : 300.0,
                "id" : 0.0
            }
        ]
    }
```
### 打架
```json
    "analyze_config" : {
        "rois" : [],
        "violations" : [ 
            {
                "code" : "3",
                "on" : true,
                "cooling_second" : 300.0,
                "times":[
                    {
                        "day" : 1,
                        "periods" :[
                            1.0, 
                            102.0, 
                            200.0, 
                            500.0
                        ]
                    },
                    {
                        "day" : 2,
                        "periods" :[
                            1807.0, 
                            2259.0, 
                            1102.0, 
                            1200.0
                        ]
                    }                   
                ]
            }
        ]
    }
```
### 徘徊滞留
```json
    "analyze_config" : {
        "violations" : [ 
            {
                "code" : "6",
                "on" : true,
                "roi" : [ 
                    {
                        "data" : [ 
                            605.0, 
                            253.0, 
                            518.0, 
                            704.0, 
                            1384.0, 
                            731.0, 
                            1523.0, 
                            202.0
                        ],
                        "id" : 1.0
                    }
                ],
                "cooling_second" : 300.0,
                "id" : 0.0,
                "wander_retention_buffer_time" : 300.0,
                "wander_retention_report_time" : 60.0
            }
        ]
    }
```
### 截帧服务
```json
    "analyze_config" : {
        "violations" : [ 
            {
                "code" : "59",
                "on" : true,
                "cooling_second" : 900.0,
                "id" : 0.0,
                "callback" : "http://xxx"
            }
        ]
    }
```