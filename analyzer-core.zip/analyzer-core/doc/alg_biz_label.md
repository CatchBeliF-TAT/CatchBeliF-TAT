## 算法标签列表

### 机动车细分类
| 算法返回字符串 | 说明 |
|----|----|
| Car / 257 | 普通汽车 |
| Pick_Up / 258 | 皮卡 |
| Light_Bus / 259 | 普通小巴 |
| Bus / 260 | 公交车 |
| Light_Truck / 261 | 小型卡车 |
| Middle_Truck / 262 | 中型卡车 |
| Heavy_Truck / 263 | 重型卡车 |
| Van_Truck / 264 | 厢式货车 |


### 机动车特种车辆分类

| 算法返回字符串 | 说明 |
|----|----|
| Taxi / 1025 | 出租车 |
| Police_Car / 1026 | 警车 |
| Engineer_Truck / 1027 | 工程车 |
| Emergency_Car / 1028 | 公路抢险车 |
| Ambulance / 1029 | 救护车 |
| Fire_Car / 1030 | 消防车 |
| Garbage_Car / 1031 | 垃圾车 |
| Sweeper_Car / 1032 | 清扫车 |
| Watering_Car / 1033 | 洒水车 |
| CementMix_Car / 1034 | 搅拌车 |
| Cash_Car / 1035 | 运钞车 |
| Muck_Truck / 1036 | 渣土车 |
| Tank_Truck / 1037 | 危险用品车 |
| Bus_Spechial / 1038 | 公交车 |
| NoSpechialCar / 1039 | 非特种小车 |
| NoSpechialTruck / 1040 | 非特种货车 |
| Others / 1041 | 其他 |

### 非机动车细分类

| 算法返回字符串 | 说明 |
|----|----|
| Meituan / 513 | 美团 |
| Ele / 514 | 饿了么 |
| Nonmotor_Suspect/ 519 | 疑似外卖 |
| Nonmotor_Other / 515 | 普通非机动车 |
| Person / 516 | 行人 |
| Shunfeng / 517 | 顺丰 |
| Jingdong / 518 | 京东 |

### 非机动车类型细分类

| 算法返回字符串 | 说明 |
|----|----|
| bike / 1281 | 自行车 |
| ebike / 1282 | 电瓶车 |
| motor/ 1283 | 摩托车 |
| tricycle / 1284 | 三轮车 |
| others / 1285 | 其他 |

### 非机动车行为细分类

| 算法返回字符串 | 说明 |
|----|----|
| no_helmet / 1297 | 没带头盔 |
| manned / 1314 | 载人 |
| promoting / 1330 | 推行 |

### 车辆朝向分类

| 算法返回字符串 | 说明 |
|----|----|
| Front / 770 | 车头 |
| Rear / 771 | 车尾 |
| No_Direction / 772 | 无朝向 |

### 机动车车牌细分类

| 算法返回字符串 | 说明 |
|----|----|
| s_blue / 1 | 单层蓝牌 |
| s_yellow / 2 | 单层黄牌 |
| s_green / 3 | 单层新能源牌 |
| d_yellow / 4 | 双层黄牌 |
| s_white / 5 | 单层白牌 |
| d_white / 6 | 双层白牌 |
| d_blue / 7 | 双层蓝牌 |

### 非机动车车牌细分类
| 算法返回字符串 | 说明 |
|----|----|
| d_yellow / 17 | 双层黄牌 |
| d_blue / 18 | 双层蓝牌 |
| d_white / 19 | 双层白牌 |
| d_green / 20 | 双层绿牌 |
### 人员分类
| 算法返回字符串 | 说明 |
|----|----|
| Worker | 施工人员 |
| NonWorker | 非施工人员 |
| Other | 其他 |
| LEOWorker | 执法人员 |