//
// Created by 赵之健 on 2020/3/17.
//

#include <algorithm/detect/detect.hpp>
#include <opencv2/opencv.hpp>
#include <vector>
#include "common/io.hpp"
#include "common/util.hpp"
#include "common/json.hpp"
#include "common/pbjson.hpp"
#include "core/alg_engine/alg_safehelmet_engine.hpp"
#include "serving/violation_event.pb.h"
#include "core/stream/stream_manager.hpp"
#include "algorithm/traffic_light/traffic_light_recog.hpp"
#include "algorithm/vehicleattribute/vehicle_attr.hpp"
#include "algorithm/vehicleattribute/vehicle_attr.hpp"
#include "violation/violation_event.hpp"
#include "violation/violation_manager.hpp"
#include "core/flow_dispatch.hpp"
#include "serving/config.pb.h"
#include "core/helper.hpp"
//#define TEST_TWO_STREAM

using namespace FLOW;
using namespace std;

void DrawViolateion(cv::Mat &im, string config) {
  const std::string FIELD = "violations";
  const auto &document = get_document(config);
  const auto &data = document["violations"];
  for (int i = 0; i < data.Size(); i++) {
    const auto &flag_on = get_bool(data[i], "on", "");
    if (!flag_on) continue;

    const auto &violation_name = get_string(data[i], "name", "");
    const auto &temp = data[i]["conditions"];
    for (int k = 0; k < temp.Size(); k++) {
      const auto &line_type_name = get_string(temp[k], "name", "");
      stringstream ss;
      ss << violation_name.c_str() << "-" << i << "--"
         << line_type_name.c_str();
      if (line_type_name == "person_box" || line_type_name == "violate_box") {
        auto points = get_array<float>(temp[k], "data");
        int idx;
        for (idx = 0; idx < points.size() / 2 - 1; idx++) {
          cv::line(im, cv::Point(points[idx * 2], points[idx * 2 + 1]),
                   cv::Point(points[idx * 2 + 2], points[idx * 2 + 3]), cv::Scalar(0, 255, 0), 2);
        }
        cv::line(im, cv::Point(points[idx * 2], points[idx * 2 + 1]),
                 cv::Point(points[0], points[1]), cv::Scalar(0, 255, 0), 2);
      }else {
        auto lines = get_array<float>(temp[k], "data");
        CHECK_EQ(lines.size() % 4, 0);
        for (int j = 0; j < j / 4 + 1; j++) {
          cv::putText(im, ss.str(),
                      cv::Point(lines[j * 4], lines[j * 4 + 1] - 10),
                      cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(255, 0, 255), 2);
          cv::line(im, cv::Point(lines[j * 4], lines[j * 4 + 1]),
                   cv::Point(lines[j * 4 + 2], lines[j * 4 + 3]),
                   cv::Scalar(0, 0, 255), 2);
        }
      }


    }
  }
}

std::vector<std::string> parse_violations(const std::string &config) {
  std::vector<std::string> retv;
  auto doc = get_document(config);
  const auto &value = get_value(doc, "violations");
  if (value.IsArray()) {
    const auto &violations = value.GetArray();
    for (int i = 0; i < violations.Size(); i++) {
      rapidjson::StringBuffer s;
      rapidjson::Writer<rapidjson::StringBuffer> writer(s);
      violations[i].Accept(writer);
      retv.push_back(s.GetString());
    }
  }
  return retv;
}




struct uid_info{
  string stream_id;
  int obj_id;
  int64 start;
  int64 end;
};

//uid_info parse_uid_eventid(const std::string &config) {
//  uid_info info;
//  std::vector<std::string> retv;
//  auto doc = get_document(config);
//  std::vector<string> return_res;
//  inference::ViolationEvent event;
//  string error ;
//  json2pb(config, &event,&error);
//  info.stream_id = event.stream_id();
//  info.obj_id = event.obj_id();
//  info.start = event.snapshots(0).pts();
//  info.end = event.snapshots(2).pts();
//
//
////    auto snapshots = get_value(doc, "snapshots");
//
//
//
//  return info;
//}


int main(int argc, char const *argv[]) {
  // const auto &im_mat =
  // cv::imread("/home/atlab/Downloads/IMG_20190604_182916.jpg");
  // const auto &im_mat = make_shared<cv::Mat>(cv::imread("data/test_plate.png"));
  auto alg_engine_ = std::make_shared<CAlgSafehelmetEngine>();
  std::unordered_map<int, string> id_obj_map;

  //const string config_file = "config/config_bulirang_putuo.json";
  // const string config_file = "configs/weifaceshi/model_configs/test_config_dawanxiaozhuan.json";
//  const string config_file = "/home/shanma/Workspace/zhaozhijian/localtest/analyzer-flow/config/config_v1.1.json";
    const string config_file = "/home/shanma/Workspace/hourz/code/code_analyze-flow/0924/analyzer-core/config/config_safehelmet.json";
#ifdef TEST_TWO_STREAM
  const string config_file_2 = "video/weifaceshi/2019-09-17/shixianbiandao/07/Bukong2.json";
#endif
  //const string config_file = "xuhuivideo/test/test_config_wanggexian.json";
  //const string violation_config_file = "video/weifaceshi/2019-09-17/shixianbiandao/07/bukong_nonmotor.json";

  // const string violation_config_file = "/home/shanma/Workspace/zhaozhijian/localtest/video/dahuoche/miss_dahuoche/task.json";
  // const string violation_config_file_3 = "configs/bulirang_putuo_1008.json";
  //const string violation_config_file_3 = "configs/weifaceshi/bukong_configs/dawanxiaozhuan-0930.json";
  // const string violation_config_file_3 = "video/weifaceshi/2019-09-17/shixianbiandao/07/model.json";
//  const string violation_config_file_3 = "/home/shanma/Workspace/zhaozhijian/localtest/analyzer-flow/config/fight.json";
    const string violation_config_file_3 = "/home/shanma/Workspace/hourz/code/code_analyze-flow/0924/analyzer-core/config/safehelmet.json";
#ifdef  TEST_TWO_STREAM
  const string violation_config_file_4 = "video/weifaceshi/2019-09-17/shixianbiandao/07/hongdeng2.json";
#endif

  Profiler profiler;
  int code;
  string config = FLOW::Util::read_text_from_file(config_file);
#ifdef  TEST_TWO_STREAM
  string config_2 = TAD::Util::read_text_from_file(config_file_2);
#endif
  // string config_violation =
  //     FLOW::Util::read_text_from_file(violation_config_file);
  string config_violation_3 =
      FLOW::Util::read_text_from_file(violation_config_file_3);
#ifdef  TEST_TWO_STREAM
  string config_violation_4 =
            TAD::Util::read_text_from_file(violation_config_file_4);
#endif
  //std::string video_file = "/home/shanma/Workspace/zhaozhijian/localtest/Alg-VideoAlgorithm/project/tad/video/cases/交通/机动车/实线变道/case1/shixianbiandao1.mp4";
  //std::string video_file = "rtmp://localhost:11935/9527/buandaoxiang2.mp4";
//    std::string video_file = "/home/shanma/Workspace/hourz/code/code_gitlab_20200812_wander_safehelmet/Alg-VideoAlgorithm/demos/alg_module/safehelmet_detect/01000000244C166CE7E5EF150700000000000000_20200423_160005-12min-30min.mp4";
    std::string video_file = "/home/shanma/Workspace/hourz/data/safehelmet1.mp4";
    std::string stream_id = "101";

  //std::string video_file = "/home/shanma/Workspace/zhaozhijian/localtest/video/dahuoche/miss_dahuoche/S339省道常胜路路口西车尾_40秒4分20秒.mp4";
  // std::string video_file = "/home/shanma/Workspace/zhaozhijian/localtest/video/2019-07-02-08-14.mp4";
#ifdef  TEST_TWO_STREAM
  std::string video_file_2 = "video/weifaceshi/2019-09-17/shixianbiandao/07/宾虹东路栖凤街东口1-2.mp4";
#endif
  std::vector<FLOW::ImageObjectsInfo> image_infoes;
  FLOW::VecImage image_map;
  FLOW::ImageObjectsInfo objInfo;
  inference::AnalyzerConfig  cfg;
  std::string err;
  json2pb(config, &cfg, &err);
  alg_engine_->Init(cfg.engine_config(), code);
  FLOW::CStreamManager stream_manager_;

  spViolationEventProcesser violation_event_manager_(make_shared<ViolationEventProcesser>(alg_engine_, nullptr, 1));

  //spViolationEventProcesser violation_event_manager_(new ViolationEventProcesser(alg_engine_, &stream_manager_));
  //FLOW::CViolationManager violationManager(wpViolationEventProcesser(violation_event_manager_));

  FLOW::CViolationManager violationManager(violation_event_manager_);

  if (code == 0 || code == 200) {
    // auto cofnig = alg_engine_->GetConfig();
    // stream_manager_.AddStream(video_file, stream_id, 0, alg_engine_->GetConfig().detect_input_shapes);
#ifndef USE_MEDIA_UTILS

    stream_manager_.AddStream(video_file, stream_id, cfg.stream_config());
#ifdef  TEST_TWO_STREAM
    stream_manager_.AddStream(video_file_2,video_file_2, cfg->stream_config());
#endif
    alg_engine_->AddStream(stream_id, config);
#ifdef  TEST_TWO_STREAM
    alg_engine_->AddStream(video_file_2, config_2);
#endif

#endif
    int violation_id = 100;
    auto violations = parse_violations(config_violation_3);
    for (const auto &violation : violations) {
      const auto &document = get_document(violation);
      const auto &flag_on = get_bool(document, "on", "");
      if (!flag_on) continue;
      LOG(INFO) << "Add violation " << violation_id << " " << violation;
      alg_engine_->AddViolation(stream_id, std::to_string(violation_id), violation);
      violationManager.AddViolation(stream_id, std::to_string(violation_id), violation);
      // alg_engine_->AddStreamTrackingType(stream_id, "100", violation);
      violation_id++;
    }
#ifdef  TEST_TWO_STREAM
    violations = parse_violations(config_violation_4);
        for (const auto &violation : violations) {
            const auto &document = get_document(violation);
            const auto &flag_on = get_bool(document, "on", "");
            if (!flag_on) continue;
            LOG(INFO)<< "Add violation "<< violation_id<<" "<<violation;
            violationManager.AddViolation(video_file_2, std::to_string(violation_id), violation);
            alg_engine_->AddStreamTrackingType(video_file_2, "100", violation);
            violation_id++;
        }
#endif
  } else {
    LOG(INFO) << "error creat alg-engine with " << stream_id;
    return 0;
  }

  cv::VideoCapture capture;
  CFlowDispatch dsp;
  CFlowDispatch::spNode chin, chout, root;

  if (capture.open(video_file)) {
    auto rate = static_cast<float>(capture.get(cv::CAP_PROP_FPS));
    auto width = static_cast<int>(capture.get(cv::CAP_PROP_FRAME_WIDTH));
    auto height = static_cast<int>(capture.get(cv::CAP_PROP_FRAME_HEIGHT));

    cv::VideoWriter writer;
//    const auto &out_file = Util::change_extension(video_file, "-result.mp4");
//    writer.open(out_file, CV_FOURCC('H', '2', '6', '4'), rate,
//                cv::Size(width, height));

    //       cv::namedWindow("image", cv::WINDOW_NORMAL);

    //std::ofstream outfile("tracking_result.txt");
    int frame_id = 1;
    //while (capture.read(*im_mat) && !im_mat->empty()) {
    cv::Mat im_mat;
    capture.read(im_mat);
    auto im_mat_ptr = make_shared<cv::Mat>(im_mat);
    bool init_flag = false;
    bool break_flag = false;
    auto root = dsp.root();
    while (!im_mat_ptr->empty()) {
      if (!chin) {
        chin = dsp.add_node(stream_id, "in", 255);
        chin->task(false);
        chout = dsp.add_node(stream_id, "out", 255);
        root->next(chin);
        chout->process([&image_infoes, &stream_id, &writer, &init_flag, &break_flag, &stream_manager_, &violationManager, &violation_event_manager_] (VecImage& in)
                         {
                           //do{
                             VecImage &image_map_out = in;
                             if (image_map_out.size() > 0) {
                               image_infoes.clear();
                               for (auto image_info_temp : image_map_out) {
                                 if (image_info_temp.get()->channel_id == stream_id) {
                                   image_infoes.push_back(*image_info_temp);
                                   LOG(INFO) << "OUT channle id = " << image_info_temp->channel_id
                                              << "pts = " << image_info_temp->pts;
                                 }
                               }
                             } else {
                               if (!init_flag) {
                                 init_flag = !init_flag;
                                 sleep(2);
                               }else{
                                 map<string, int> stream_status;
                                 stream_manager_.GetStatus(stream_status);
                                 break_flag = false;
                                 for (auto status : stream_status){
                                   if (status.first == stream_id){
                                     std::cout<< status.second<<std::endl;
                                     if (status.second == 255){
                                       sleep(1);
                                       std::string event;
                                       // violation_event_manager_->Pop(-1, event);
                                       if (!event.empty()) {
                                         // std::os<<event<<std::endl;
                                         LOG(INFO) << "Event:" << event;
                                       }
                                       break_flag = true;
                                     }
                                   }
                                 }
                                 //if (break_flag) break;
                                 usleep(40 * 1000);
                               }
                             }
                             FLOW::spEventProto event;
                             violationManager.Process(image_map_out);
                             violation_event_manager_->Pop(-1, event);
                             if (!event.get()) {
                               LOG(INFO) << "Event:" << event->ShortDebugString();
                             }
                             //if (image_info.img_ptr.get() == NULL) {
                             //  return ;
                             //}

                             for (auto image_info : image_infoes){
                             auto im_clone = image_info.sframe->getMat()->clone();
                             auto pts_now = image_info.pts;
                             //tracker_ptr->DrawTrackingROI(im_clone);
                             //DrawViolateion(im_clone, config_violation_3);

                             std::map<int, std::string> ssmap_traffic_light = {
                                 {TrafficLight::kColorGreen,  "Green"},
                                 {TrafficLight::kColorRed,    "Red"},
                                 {TrafficLight::kColorYellow, "Yellow"},
                             };
                            /*
                             if (image_info.tlc == TrafficLight::kColorRed) {
                               static int idx = 0;
                               idx++;
                               LOG(INFO) << "out_pts =" << image_info.pts;
                             }

                             if (image_info.tlc >= TrafficLight::kColorGreen) {
                               cv::putText(im_clone, ssmap_traffic_light.find(image_info.tlc)->second,
                                           cv::Point(20, 20),
                                           cv::FONT_HERSHEY_SCRIPT_COMPLEX, 1, cv::Scalar(255, 0, 0),
                                           2);
                             }
                              */
                             for (const auto &box : image_info.highways.traffic_sign_event.traffic_signs) {
                               // std::cout << "box No." << offset << std::endl;
                               if (box.delete_flag) continue;
                               auto box_type = box.attr_type.type;
                               cv::rectangle(im_clone, cv::Point2f(box.xmin, box.ymin),
                                             cv::Point2f(box.xmax, box.ymax), cv::Scalar(255, 0, 0),
                                             2);
                               float percent = 0.75;
                               const auto dx = (1.0f - percent) / 2.0f * (box.xmax - box.xmin);
                               const auto dy = (1.0f - percent) / 2.0f * (box.ymax - box.ymin);
                               cv::line(im_clone, cv::Point2f(box.xmax - dx, box.ymax - dy),
                                        cv::Point2f(box.xmin + dx, box.ymax - dy), cv::Scalar(255, 0, 0),
                                        2);

                               stringstream ss;
                               ss << box.uid;

                               cv::putText(im_clone, ss.str(), cv::Point(box.xmax, box.ymax),
                                           cv::FONT_HERSHEY_PLAIN, 2, cv::Scalar(255, 0, 255),
                                           2);


                               if (box.label == 2) {
                                 if (box_type != -1) {
                                   cv::putText(im_clone, Attribute::helperGetStringVehicleType((Attribute::VehicleType)box_type),
                                               cv::Point(box.xmax, box.ymin),
                                               cv::FONT_HERSHEY_PLAIN, 1, cv::Scalar(255, 0, 0),
                                               2);
                                 }

                               } else if (box.label == 3) {
                                 cv::putText(im_clone, "nonmotor", cv::Point(box.xmax, box.ymin),
                                             cv::FONT_HERSHEY_PLAIN, 1, cv::Scalar(0, 255, 0),
                                             2);
                               } else {
                                 cv::putText(im_clone, "Person", cv::Point(box.xmax, box.ymin),
                                             cv::FONT_HERSHEY_PLAIN, 1,
                                             cv::Scalar(255, 255, 0), 2);
                               }

                               //offset++;
                             }

//                             if (writer.isOpened()) {
//                               LOG(INFO)<<"writing pts = "<<pts_now;
//                               writer.write(im_clone);
//                             }

                             cv::Mat im_show;
                             cv::resize(im_clone, im_show, cv::Size(1920, 1080));

                             // cv::imshow("image", im_show);
                             if (cv::waitKey(1) % 256 == 32) {
                               if ((cv::waitKey(0) % 256) == 27) break_flag = true ;
                             }
                           in.clear();
                               }
                         }); // process
      } // chout

      bool push_data = false;
      auto pQueue = stream_manager_.GetFrameQueue(stream_id);
      if (!pQueue->empty() && !chin->full(root.get())){
        if (chin->full(root.get())) {
          //LOG(INFO)<< "chin is full";
        }
        root->in().clear();
        while (!pQueue->empty() && root->in().size() < 12) {
          auto frame = pQueue->pop();
          auto newImage = std::make_shared<ImageObjectsInfo>();
          newImage->channel_id = frame.channel_id;
          if(frame.sframe == nullptr){
            continue;
          }
          newImage->sframe = frame.sframe;
          newImage->pts = frame.pts;
          LOG(INFO)<< "sent image pts = "<< frame.pts;
          newImage->count = frame.count;
          root->in().push_back(newImage);
          push_data = true;
        }
        if (root->in().empty()) continue;
        root->ts(root->in().back()->count);
        root->push(chin);
      }

      alg_engine_->Process(dsp);
      dsp.dispatch();
      // dsp.print_topo(root,0);
      if (!push_data)  usleep(5);
      map<string, int> stream_status;
      stream_manager_.GetStatus(stream_status);
      break_flag = false;
      for (auto status : stream_status){
        if (status.first == stream_id){
          //std::cout<< status.second<<std::endl;
          if (status.second == 255){
            auto res = dsp.checknode(dsp.root());
            if(dsp.is_clear() == false )
              break;
            LOG(INFO)<<"Break";
            sleep(1);
            break_flag = true;
          }
        }
      }
      if (break_flag) break;
       usleep(5);
    }


    //  }
    // outfile.close();
  }
  stream_manager_.GetFrameQueue(stream_id).get()->cancel_pops();
  stream_manager_.StopStream(video_file);


  LOG(INFO) << profiler.get_stats_str();


  return 0;
}
