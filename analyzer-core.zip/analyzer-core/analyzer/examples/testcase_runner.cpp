//
// Created by zyj on 2022/5/30.
//

#include <algorithm>
#include <atomic>
#include <chrono>
#include <mutex>
#include <opencv2/opencv.hpp>
#include <sstream>

#include "analyzer.h"
#include "common/io.hpp"
#include "common/json.hpp"
#include "common/pbjson.hpp"
#include "serving/input_arguments.pb.h"
#include "serving/violation_event.pb.h"

const char* getCmdOption(const char** begin, const char** end, const std::string& option, std::string& value) {
    const char** itr = std::find(begin, end, option);
    if (itr != end && ++itr != end) {
        value = *itr;
        return *itr;
    }
    return 0;
}

bool cmdOptionExists(const char** begin, const char** end, const std::string& option) {
    return std::find(begin, end, option) != end;
}

std::string dirname(std::string file) {
    auto s = file.find_last_of("/\\");
    if (s != std::string::npos) {
        return file.substr(0, s);
    }
    return "";
}

std::string filename(std::string file) {
    auto s = file.find_last_of("/\\");
    if (s != std::string::npos) {
        return file.substr(s + 1);
    }
    return file;
}

struct _task {
    std::thread thread;
    bool event_out_detial;
    bool enable_traking_debug;
    std::string stream_id;
    std::string stream_url;
    std::string event_out_file;
    std::string stream_out_url;
    std::string violation_config;
    std::vector<std::string> events;
    std::string error;
};
int process_task(void* p_engine, const _task& task);

/**
 * @brief
 * 使用方式:
 *  1. 单文件模式 ./testcase_runner --engine engine_config.json --stream_url xxx/xxx.mp4
 *  2. batch模式 ./testcase_runner --engine engine_config.json --stream_url files.list
 *                                  [--stream_out_all] [--event_out_detial]
 *
 * @param argc
 * @param argv
 * @return int
 */
int main(int argc, char const* argv[]) {
    if (cmdOptionExists(argv, argv + argc, "-h") || cmdOptionExists(argv, argv + argc, "--help")) {
        std::cout << "testcase_runner" << std::endl
                  << "\t--engine engine_config.json" << std::endl
                  << "\t--stream_url rtsp://stream_url or xxxx.list" << std::endl
                  << "\t[--violation_config violation_config.json]" << std::endl
                  << "\t[--event_out_file event.txt, enable record event json in file]" << std::endl
                  << "\t[--event_out_detial], output jpg" << std::endl
                  << "\t[--stream_out_url rtsp://stream_out_url]" << std::endl
                  << "\t[--stream_out_all, enable all out stream with name *_out.flv]" << std::endl
                  << "\t[--conunt 10], max run task count" << std::endl;
        return 0;
    }

    std::string engine_config;
    if (getCmdOption(argv, argv + argc, "--engine", engine_config)) {
        engine_config = FLOW::Util::read_text_from_file(engine_config);
    } else {
        std::cerr << "--engine not found" << std::endl;
        return -1;
    }

    std::string violation_config;
    if (!getCmdOption(argv, argv + argc, "--violation_config", violation_config)) {
        std::cerr << "--violation_config not found, guess metadata.json or violation.json" << std::endl;
    }

    std::string stream_url;
    if (!getCmdOption(argv, argv + argc, "--stream_url", stream_url)) {
        std::cerr << "--stream_url not found" << std::endl;
        return -1;
    }
    std::string stream_out_url;
    bool stream_out_all = false;
    if (cmdOptionExists(argv, argv + argc, "--stream_out_all")) {
        stream_out_all = true;
    } else if (!getCmdOption(argv, argv + argc, "--stream_out_url", stream_out_url)) {
        std::cerr << "--stream_out_url not found, close output stream" << std::endl;
    }

    bool enable_traking_debug = false;
    if (cmdOptionExists(argv, argv + argc, "--enable_traking_debug")) {
        enable_traking_debug = true;
    }

    std::string event_out_file;
    if (!getCmdOption(argv, argv + argc, "--event_out_file", event_out_file)) {
        std::cerr << "--event_out_file not found, output std output" << std::endl;
    }

    bool event_out_detial = false;
    if (cmdOptionExists(argv, argv + argc, "--event_out_detial")) {
        event_out_detial = true;
    }

    std::string count_str;
    std::atomic<int> count(10);
    if (getCmdOption(argv, argv + argc, "--count", count_str)) {
        const int icount = atoi(count_str.c_str());
        if (icount > 0) {
            count.store(icount);
        }
    }

    // flow_create
    void* p_engine = nullptr;
    std::shared_ptr<void> sp_engine;
    {
        std::string flow_arg;
        inference::InptArguments arguments;
        arguments.set_engine_config(engine_config);
        FLOW::pb2json(&arguments, &flow_arg);
        int code = 0;
        flow_create(&p_engine, flow_arg.data(), flow_arg.size(), &code);
        if (code != flow_status_ok) {
            std::cerr << "flow_create failed, check engine_config" << std::endl;
            return -1;
        }
        sp_engine = std::shared_ptr<void>(p_engine, [](void* engine) { flow_release(&engine); });
    }

    std::map<std::string, _task> userdata;
    std::string list_suffix(".list");
    bool is_list = stream_url.size() > list_suffix.size() &&
                   stream_url.substr(stream_url.size() - list_suffix.size()).find(list_suffix) != std::string::npos;

    std::set<std::string> files;
    if (!is_list) {
        files.insert(stream_url);
    } else {
        std::ifstream list_file(stream_url);
        std::string file;
        while (std::getline(list_file, file)) {
            files.insert(file);
        }
    }

    // init all task
    size_t i = 0;
    const int bits = std::to_string(files.size()).size();
    for (auto&& file : files) {
        std::stringstream ss;
        ss << std::setw(bits) << std::setfill('0') << i++;
        auto stream_id = ss.str() + "_" + filename(file);
        auto& task = userdata[stream_id];
        task.event_out_detial = event_out_detial;
        task.enable_traking_debug = enable_traking_debug;
        task.stream_id = stream_id;
        task.stream_url = file;
        task.event_out_file = event_out_file;
        if (stream_out_all) {
            task.stream_out_url = file + "_out.flv";
        } else if (!stream_out_url.empty()) {
            task.stream_out_url = dirname(stream_out_url) + ss.str() + "_" + filename(stream_out_url);
        }
        if (violation_config.empty()) {
            auto v1 = dirname(file) + "/" + "violation.json";
            auto v2 = dirname(file) + "/" + "metadata.json";
            if (std::ifstream(v1).is_open()) {
                task.violation_config = v1;
            } else if (std::ifstream(v2).is_open()) {
                task.violation_config = v2;
            } else {
                std::cerr << "violation_config not found, " << std::endl;
                std::cerr << v1 << std::endl;
                std::cerr << v2 << std::endl;
                exit(0);
            }
        } else {
            auto violation_config_name = filename(violation_config);
            task.violation_config = dirname(file) + "/" + violation_config_name;
        }
        auto violation_config_content = FLOW::Util::read_text_from_file(task.violation_config);
        if (violation_config_content.empty()) {
            std::cerr << "violation_config empty, " << task.violation_config << std::endl;
            exit(0);
        }
        task.violation_config = violation_config_content;
        task.event_out_detial = event_out_detial;
    }

    // flow_add_event_callback
    if (p_engine) {
        // typedef int (*flow_event_callback)(void *user_data, const void *event, const int event_size);
        auto call_back = [](void* userdata, const void* event, const int event_size) -> int {
            auto& tasks = *((std::map<std::string, _task>*)(userdata));
            inference::Event pb_event;
            pb_event.ParseFromString(std::string((const char*)(event), event_size));
            const auto stream_id = pb_event.traffic_event().stream_id();
            const auto violation_id = pb_event.traffic_event().violation_id();
            std::cout << stream_id << ", " << violation_id << " got event" << std::endl;
            if (tasks.count(stream_id) == 0) {
                std::cerr << stream_id << "not found";
                exit(1);
            }
            auto& task = tasks.at(stream_id);
            auto event_out_file = task.event_out_file;
            if (stream_id != task.stream_id) {
                std::cerr << stream_id << "!=" << task.stream_id << std::endl;
                exit(1);
            }

            // result
            std::string event_str;
            FLOW::pb2json(&pb_event, &event_str);
            task.events.push_back(violation_id);
            // event
            if (!event_out_file.empty()) {
                const auto event_str_log = task.event_out_detial ? event_str : "got_1";
                std::ofstream of(event_out_file, std::ios::app);
                of << stream_id << "\t" << violation_id << "\t" << event_str_log << std::endl;
            }
            // event jpg
            if (task.event_out_detial) {
                int i = 0;
                for (auto&& sn : pb_event.traffic_event().snapshots()) {
                    auto basedir = dirname(task.stream_url);
                    std::string filename = basedir + "/" + stream_id + "_" + std::to_string(i++) + ".jpg";
                    if (sn.objects_size() > 0) {
                        auto scalar = cv::Scalar(0, 0, 255);
                        std::vector<uint8_t> vectordata(sn.image().begin(), sn.image().end());
                        auto image = cv::imdecode(vectordata, cv::IMREAD_COLOR);
                        for (auto object : sn.objects()) {
                            cv::rectangle(image, cv::Point(object.box(0), object.box(1)),
                                          cv::Point(object.box(2), object.box(3)), scalar, 2);
                        }
                        cv::imwrite(filename, image);
                    } else {
                        std::ofstream imagefs(filename, std::ios::trunc);
                        imagefs.write(sn.image().data(), sn.image().size());
                    }
                }
            }
            return 0;
        };
        int code = 0;
        flow_add_event_callback(p_engine, (flow_event_callback)call_back, &userdata, &code);
        if (code != flow_status_ok) {
            std::cerr << "flow_add_event_callback failed" << std::endl;
            return -1;
        }
    }

    for (auto& t : userdata) {
        while (count.load() <= 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        }
        count.fetch_sub(1);
        t.second.thread = std::thread([&]() {
            std::shared_ptr<void> add_counter(nullptr, [&](void*) { count.fetch_add(1); });
            auto retv = process_task(p_engine, t.second);
            t.second.error = std::to_string(retv);
        });
    }

    for (auto& t : userdata) {
        t.second.thread.join();
    }

    for (auto& t : userdata) {
        std::cout << t.first << "\t" << t.second.events.size() << "\t" << t.second.error << std::endl;
    }

    return 0;
}

int process_task(void* p_engine, const _task& task) {
    if (p_engine == nullptr) {
        return -1;
    }

    // flow_add_stream
    if (p_engine) {
        std::string flow_arg;
        inference::InptArguments arguments;
        arguments.set_stream_url(task.stream_url);
        arguments.set_stream_id(task.stream_id);
        arguments.set_engine_config(R"~({"stream_config":{"enable_tracking_debug": true}})~");
        FLOW::pb2json(&arguments, &flow_arg);
        int code = 0;
        flow_add_stream(p_engine, flow_arg.data(), flow_arg.size(), &code);
        if (code != flow_status_ok) {
            std::cerr << "flow_add_stream failed, check stream_url" << std::endl;
            return -1;
        }
    }

    // flow_add_violation
    if (p_engine) {
        std::vector<std::string> violations;
        auto doc = FLOW::get_document(task.violation_config);
        if (doc.IsArray()) {
            const auto& value = doc.GetArray();
            for (int i = 0; i < value.Size(); i++) {
                violations.push_back(FLOW::value_as_string(value[i]));
            }
        } else if (doc.HasMember("event") && doc["event"].HasMember("task_config") &&
                   doc["event"]["task_config"].HasMember("violations") &&
                   doc["event"]["task_config"]["violations"].IsArray()) {
            const auto& value = doc["event"]["task_config"]["violations"].GetArray();
            for (int i = 0; i < value.Size(); i++) {
                violations.push_back(FLOW::value_as_string(value[i]));
            }
        } else {
            violations.push_back(task.violation_config);
        }

        for (size_t i = 0; i < violations.size(); i++) {
            std::string flow_arg;
            inference::InptArguments arguments;
            arguments.set_stream_id(task.stream_id);
            arguments.set_violation_type(std::string("violation_") + std::to_string(i));
            arguments.set_violation_config(violations[i]);
            FLOW::pb2json(&arguments, &flow_arg);
            int code = 0;
            flow_add_violation(p_engine, flow_arg.data(), flow_arg.size(), &code);
            if (code != flow_status_ok) {
                std::cerr << "flow_add_stream failed, check stream_url" << std::endl;
                return -1;
            }
        }
    }

    // flow_add_push_stream
    if (p_engine && !task.stream_out_url.empty()) {
        std::string flow_arg;
        inference::InptArguments arguments;
        arguments.set_stream_url(task.stream_out_url);
        arguments.set_stream_id(task.stream_id);
        FLOW::pb2json(&arguments, &flow_arg);
        int code = 0;
        flow_add_push_stream(p_engine, flow_arg.data(), flow_arg.size(), &code);
        if (code != flow_status_ok) {
            std::cerr << "flow_add_push_stream failed, check stream_out_url" << std::endl;
            return -1;
        }
    }

    while (p_engine) {
        flow_msg* msg = nullptr;
        flow_msg_create(&msg);
        std::shared_ptr<flow_msg> _(msg, [](flow_msg* p) { flow_msg_release(p); });
        int code = 0;
        flow_get_stream_status(p_engine, msg, &code);
        if (code != flow_status_ok) {
            std::cerr << "flow_get_stream_status failed" << std::endl;
            return -1;
        }
        const void* pdata = nullptr;
        int length = 0;
        flow_msg_data(msg, &pdata);
        flow_msg_size(msg, &length);

        auto doc = FLOW::get_document(std::string((const char*)pdata, length));
        auto value = FLOW::json_get<int>(doc, task.stream_id, -255);
        if (value > 1) {
            std::cout << "stream_id status=" << value << std::endl;
            break;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }

    // flow_stop_stream
    if (p_engine) {
        std::string flow_arg;
        inference::InptArguments arguments;
        arguments.set_stream_id(task.stream_id);
        FLOW::pb2json(&arguments, &flow_arg);
        int code = 0;
        flow_stop_stream(p_engine, flow_arg.data(), flow_arg.size(), &code);
        if (code != flow_status_ok) {
            std::cerr << "flow_stop_stream failed" << std::endl;
        }
    }
    return 0;
}