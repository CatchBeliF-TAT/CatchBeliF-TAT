//
// Created by 赵之健 on 2020/3/17.
//

#include <algorithm/detect/detect.hpp>
#include <opencv2/opencv.hpp>
#include <vector>
#include "algorithm/traffic_light/traffic_light_recog.hpp"
#include "algorithm/vehicleattribute/vehicle_attr.hpp"
#include "common/io.hpp"
#include "common/json.hpp"
#include "common/pbjson.hpp"
#include "common/util.hpp"
#include "core/alg_engine/alg_fall_engine.hpp"
#include "core/alg_engine/alg_vehicle_engine.hpp"
#include "core/flow_dispatch.hpp"
#include "core/flow_engine.hpp"
#include "core/stream/stream_manager.hpp"
#include "serving/violation_event.pb.h"
#include "violation/violation_event.hpp"

//#define TEST_TWO_STREAM

using namespace FLOW;
using namespace std;

void DrawViolateion(cv::Mat& im, string config) {
  const std::string FIELD = "violations";
  const auto& document = get_document(config);
  const auto& data = document["violations"];
  for (int i = 0; i < data.Size(); i++) {
    const auto& flag_on = get_bool(data[i], "on", "");
    if (!flag_on) continue;

    const auto& violation_name = get_string(data[i], "name", "");
    const auto& temp = data[i]["conditions"];
    for (int k = 0; k < temp.Size(); k++) {
      const auto& line_type_name = get_string(temp[k], "name", "");
      stringstream ss;
      ss << violation_name.c_str() << "-" << i << "--"
         << line_type_name.c_str();
      if (line_type_name == "person_box" || line_type_name == "violate_box") {
        auto points = get_array<float>(temp[k], "data");
        int idx;
        for (idx = 0; idx < points.size() / 2 - 1; idx++) {
          cv::line(im, cv::Point(points[idx * 2], points[idx * 2 + 1]),
                   cv::Point(points[idx * 2 + 2], points[idx * 2 + 3]),
                   cv::Scalar(0, 255, 0), 2);
        }
        cv::line(im, cv::Point(points[idx * 2], points[idx * 2 + 1]),
                 cv::Point(points[0], points[1]), cv::Scalar(0, 255, 0), 2);
      } else {
        auto lines = get_array<float>(temp[k], "data");
        CHECK_EQ(lines.size() % 4, 0);
        for (int j = 0; j < j / 4 + 1; j++) {
          cv::putText(im, ss.str(),
                      cv::Point(lines[j * 4], lines[j * 4 + 1] - 10),
                      cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(255, 0, 255), 2);
          cv::line(im, cv::Point(lines[j * 4], lines[j * 4 + 1]),
                   cv::Point(lines[j * 4 + 2], lines[j * 4 + 3]),
                   cv::Scalar(0, 0, 255), 2);
        }
      }
    }
  }
}

std::vector<std::string> parse_violations(const std::string& config) {
  std::vector<std::string> retv;
  auto doc = get_document(config);
  const auto& value = get_value(doc, "violations");
  if (value.IsArray()) {
    const auto& violations = value.GetArray();
    for (int i = 0; i < violations.Size(); i++) {
      rapidjson::StringBuffer s;
      rapidjson::Writer<rapidjson::StringBuffer> writer(s);
      violations[i].Accept(writer);
      retv.push_back(s.GetString());
    }
  }
  return retv;
}

int main(int argc, char const* argv[]) {
  const string config_file =
      "/home/shanma/Workspace/hdk/analyzer-core/config/config_cloud.json";
  const string violation_config_file_3 =
      "/home/shanma/Workspace/hdk/analyzer-core/config/"
      "config_cloud_vilation.json";

  Profiler profiler;
  int code = 0;
  string config = FLOW::Util::read_text_from_file(config_file);
  string config_violation_3 =
      FLOW::Util::read_text_from_file(violation_config_file_3);

  std::string video_file = "/home/shanma/Workspace/hourz/data/safehelmet1.mp4";
  std::string stream_id = "101-";
  auto alg_engine_ = std::make_shared<CFlowEngine>(config);
  alg_engine_->Init();
  for (int i = 0; i < 1; i++) {
    LOG(INFO) << "Add Stream " << video_file << " " << stream_id + to_string(i);
    alg_engine_->AddStream(video_file, stream_id + to_string(i), "{}");
  }

  if (code == 0 || code == 200) {
    int violation_id = 100;
    auto violations = parse_violations(config_violation_3);
    for (const auto& violation : violations) {
      const auto& document = get_document(violation);
      const auto& flag_on = get_bool(document, "on", "");
      if (!flag_on) continue;
      LOG(INFO) << "Add violation " << violation_id << " " << violation;
      for (int i = 0; i < 1; i++) {
        alg_engine_->AddViolation(stream_id + to_string(i),
                                  std::to_string(violation_id), violation);
      }

      // alg_engine_->AddStreamTrackingType(stream_id, "100", violation);
      violation_id++;
    }
    // output
    //
    alg_engine_->AddPushStream("out.flv", stream_id + to_string(0));
  } else {
    LOG(INFO) << "error creat alg-engine with " << stream_id;
    return 0;
  }

  cv::VideoCapture capture;
  CFlowDispatch dsp;

  if (capture.open(video_file)) {
    cv::Mat im_mat;
    capture.read(im_mat);
    auto im_mat_ptr = make_shared<cv::Mat>(im_mat);
    while (!im_mat_ptr->empty()) {
      alg_engine_->Process();
    }
  }

  LOG(INFO) << profiler.get_stats_str();

  return 0;
}
