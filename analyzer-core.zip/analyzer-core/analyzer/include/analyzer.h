#ifndef ANALYZER_H
#define ANALYZER_H


#ifdef __cplusplus
extern "C" {
#endif

enum flow_status {
    flow_status_ok = 0,
    flow_status_failed_unknown = 1,
    flow_status_argument_parse_error = 2,
    flow_status_out_of_buffer = 3,
};

typedef int (*flow_event_callback)(void *user_data, const void *event, const int event_size);

struct flow_msg;

void flow_version           (int *major, int *minor, int *patch);
void flow_create            (void **ctx, const void *params, const int params_size, int *code);
void flow_release           (void **ctx);

void flow_add_stream        (void *ctx, const void *request, const int request_size, int *code);
void flow_stop_stream       (void *ctx, const void *request, const int request_size, int *code);
void flow_add_push_stream   (void *ctx, const void *request, const int request_size, int *code);
void flow_stop_push_stream  (void *ctx, const void *request, const int request_size, int *code);
void flow_add_violation     (void *ctx, const void *request, const int request_size, int *code);
void flow_remove_violation  (void *ctx, const void *request, const int request_size, int *code);
void flow_add_stream_2_task (void *ctx, const void *request, const int request_size, int *code);
void flow_add_event_callback(void *ctx, flow_event_callback fn, void *user_data, int *code);
void flow_image_process     (void *ctx, const void *image, const int image_size,
                                        const void *request, const int request_size,
                                        flow_msg *buffer, int *code);
void flow_get_stream_status (void *ctx, flow_msg *out_msg, int *code);
void flow_get_metrics       (void *ctx, flow_msg *out_msg, int *code);

void flow_msg_create        (flow_msg **msg);
void flow_msg_release       (flow_msg *msg);
void flow_msg_size          (const flow_msg *msg, int *size);
void flow_msg_data          (const flow_msg *msg, const void **data);

#ifdef __cplusplus
}
#endif

#endif //ANALYZER_H
