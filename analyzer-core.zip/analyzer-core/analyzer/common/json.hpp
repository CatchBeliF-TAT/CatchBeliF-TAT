#ifndef SCOPE_COMMON_JSON_HPP
#define SCOPE_COMMON_JSON_HPP

#include "document.h"
#include "stringbuffer.h"
#include "writer.h"

#include <vector>

#include "common/log.hpp"
#include "common/util.hpp"

namespace FLOW {

inline rapidjson::Document get_document(const std::string &json_text) {
  rapidjson::Document document;
  if (json_text.empty()) {
    document.Parse("{}");
  } else if( !document.Parse(json_text.c_str()).HasParseError() ) {
    // nop
  } else if ( Path(json_text).is_file() &&
    ! document.Parse(Util::read_text_from_file(json_text).c_str()).HasParseError() ) {
    // nop
  } else {
    LOG(ERROR) << "prase json error" << json_text.c_str();
    document.Parse("{}");
  }
  return document;
}

inline std::string value_as_string(const rapidjson::Value &value) {
    rapidjson::StringBuffer buffer;
    rapidjson::Writer<rapidjson::StringBuffer> writer(buffer);
    value.Accept(writer);
    return buffer.GetString();
}

inline const rapidjson::Value &get_value(const rapidjson::Value &root,
                                         const std::string &name) {
  CHECK(root.HasMember(name.c_str()));
  return root[name.c_str()];
}

inline bool get_bool(const rapidjson::Value &root, const std::string &name,
                     const bool &def) {
  if (root.HasMember(name.c_str())) {
    const auto &value = root[name.c_str()];
    CHECK(value.IsBool());
    return value.GetBool();
  } else {
    return def;
  }
}

inline int get_int(const rapidjson::Value &root, const std::string &name,
                   const int &def) {
  if (root.HasMember(name.c_str())) {
    const auto &value = root[name.c_str()];
    CHECK(value.IsNumber());
    return value.GetInt();
  } else {
    return def;
  }
}

inline float get_float(const rapidjson::Value &root, const std::string &name,
                       const float &def) {
  if (root.HasMember(name.c_str())) {
    const auto &value = root[name.c_str()];
    CHECK(value.IsNumber());
    return value.GetFloat();
  } else {
    return def;
  }
}

inline int64_t get_int64(const rapidjson::Value &root, const std::string &name,
                       const int64_t def) {
  if (root.HasMember(name.c_str())) {
    const auto &value = root[name.c_str()];
    CHECK(value.IsNumber());
    return value.GetInt64();
  } else {
    return def;
  }
}

template <typename T>
inline T json_get(const rapidjson::Value &root, const std::string &name,
                       const T def) {
  if (root.HasMember(name.c_str())) {
    const auto &value = root[name.c_str()];
    return value.Get<T>();
  } else {
    return def;
  }
}

inline std::string get_string(const rapidjson::Value &root,
                              const std::string &name, const std::string &def) {
  if (root.HasMember(name.c_str())) {
    const auto &value = root[name.c_str()];
    assert(value.IsString());
    return value.GetString();
  } else {
    return def;
  }
}

template <typename T, size_t SIZE>
inline bool try_get_array(const rapidjson::Value &root, const std::string &name, T (&out)[SIZE]) {
  if (root.HasMember(name.c_str()) && root[name.c_str()].IsArray()) {
    const auto &value = root[name.c_str()].GetArray();
    if (value.Size() >= SIZE ) {
        for(int i=0; i<SIZE; i++) {
            out[i]=(value[i].Get<T>());
        }
        return true;
    }
  }
  return false;
}

template <typename T, size_t SIZE>
inline std::vector<T> get_array(const rapidjson::Value &root, const std::string &name, T def) {
  std::vector<T> retv(SIZE, def);
  if (root.HasMember(name.c_str()) && root[name.c_str()].IsArray()) {
    const auto &value = root[name.c_str()].GetArray();
    if (value.Size() >= SIZE ) {
        for(int i=0; i<SIZE; i++) {
            retv[i]=(value[i].Get<T>());
        }
    }
  }
  return retv;
}

template <typename T>
inline std::vector<T> get_array(const rapidjson::Value &root, const std::string &name) {
  std::vector<T> retv;
  if (root.HasMember(name.c_str()) && root[name.c_str()].IsArray()) {
    const auto &value = root[name.c_str()].GetArray();
    for(int i=0; i<value.Size(); i++) {
      retv.push_back(value[i].Get<T>());
    }
  }
  return retv;
}

inline std::vector<std::vector<int>> get_array(const rapidjson::Value &root, const std::string &name,std::vector<std::vector<int>> &def) {
  std::vector<std::vector<int>> retv;
  if (root.HasMember(name.c_str()) && root[name.c_str()].IsArray()) {
    const auto &value = root[name.c_str()].GetArray();
    for(int i=0; i<value.Size(); i++) {
      const auto polygon = value[i].GetArray();
      std::vector<int> polygon_vec;
      for (int j=0;j<polygon.Size();j++){
        polygon_vec.push_back(polygon[j].GetInt());
      }
      retv.push_back(polygon_vec);
    }
  }
  else{
    return def;
  }
  return retv;
}

}  // namespace FLOW

#endif  // SCOPE_COMMON_JSON_HPP
