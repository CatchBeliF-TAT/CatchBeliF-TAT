#include "file_server.hpp"

#include "common/log.hpp"

namespace FLOW {
namespace FileServer {

UploadClient::UploadClient(std::string address) {
#if defined(USE_GRPC)
  const auto channel =
      grpc::CreateChannel(address, grpc::InsecureChannelCredentials());
  stub_ = fileserver::ObjectStorageService::NewStub(channel);
#else
  LOG(FATAL) << "Unsupported UploadClient, recompiled with USE_GRPC=ON";
#endif
  server_address_ = address;
}

UploadClient::UploadClient(const UploadClient& upload_client) {
  server_address_ = upload_client.server_address_;
#if defined(USE_GRPC)
  const auto channel =
      grpc::CreateChannel(server_address_, grpc::InsecureChannelCredentials());
  stub_ = fileserver::ObjectStorageService::NewStub(channel);
#else
  LOG(FATAL) << "Unsupported UploadClient, recompiled with USE_GRPC=ON";
#endif
}

std::string UploadClient::UploadFile(
    fileserver::StoreRequest& request,
    fileserver::StorageObject& response) const {
#if defined(USE_GRPC)
  grpc::ClientContext context;
  const auto& status = stub_->Store(&context, request, &response);
#endif
  const auto& uri = response.uri();
  return uri;
}
}  // namespace FileServer
}  // namespace FLOW
