#ifndef SRC_COMMON_HELPER_HPP
#define SRC_COMMON_HELPER_HPP

#include "type.hpp"

#include <opencv2/opencv.hpp>
#if CV_MAJOR_VERSION >= 4
#define CV_FOURCC cv::VideoWriter::fourcc
#define CV_CAP_PROP_FPS cv::CAP_PROP_FPS
#define CV_CAP_PROP_FRAME_WIDTH cv::CAP_PROP_FRAME_WIDTH
#define CV_CAP_PROP_FRAME_HEIGHT cv::CAP_PROP_FRAME_HEIGHT
#endif

namespace FLOW {

typedef struct PosInfo_ PosInfo;

namespace Helper {

cv::Mat PerspectiveAlignment(const cv::Mat& im_mat,
                             const std::vector<cv::Point2f>& points, int dst_h,
                             int dst_w);

std::string get_pic(const cv::Mat &img);
std::string get_pic_base64(const cv::Mat &img);

bool is_same_postion(const PosInfo& location_x,const PosInfo& location_y);

inline int utf8_first_length(const char* s, size_t length) {
    if (length == 0) {
        return 0;
    }
    int cplen = 1;
    // https://en.wikipedia.org/wiki/UTF-8#Description
    if ((s[0] & 0xf8) == 0xf0)      // 11111000, 11110000
        cplen = 4;
    else if ((s[0] & 0xf0) == 0xe0) // 11100000
        cplen = 3;
    else if ((s[0] & 0xe0) == 0xc0) // 11000000
        cplen = 2;
    if ((cplen) > length)
        cplen = 1;
    return cplen;
}

inline int utf8_length(const char* s, size_t length) {
    int len = 0;
    int i=0;
    while (i<length && s[i]) {
        int cplen = utf8_first_length(s+i, length-i);
        i += cplen;
        len++;
    }
    return len;
}

}  // namespace Helper

}  // namespace FLOW

#endif  // SRC_COMMON_HELPER_HPP
