#ifndef SRC_COMMON_MAKE_TRAFFIC_LIGHT_MORE_LIGHT_HPP
#define SRC_COMMON_MAKE_TRAFFIC_LIGHT_MORE_LIGHT_HPP

#include <opencv2/opencv.hpp>

#include "tad_internal.hpp"

namespace FLOW {
    void make_traffic_light_more_red(cv::Mat mat, BoxF traffic_box);
    bool get_traffic_light_box_config(const std::vector<float> &traffic_light_roi, BoxF *box);
} 
#endif //SRC_COMMON_MAKE_TRAFFIC_LIGHT_MORE_LIGHT_HPP