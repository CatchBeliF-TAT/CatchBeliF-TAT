#include "helper.hpp"

#include "base64.hpp"
#include "tad_internal.hpp"

namespace FLOW {

namespace Helper {

cv::Mat PerspectiveAlignment(const cv::Mat& im_mat,
                             const std::vector<cv::Point2f>& points, int dst_h,
                             int dst_w) {
  CHECK_EQ(points.size(), 4);

  std::vector<cv::Point2f> dst_points{
      {0.f, 0.f},
      {static_cast<float>(dst_w), 0.f},
      {static_cast<float>(dst_w), static_cast<float>(dst_h)},
      {0.f, static_cast<float>(dst_h)}};

  const auto& transform = cv::getPerspectiveTransform(points, dst_points);

  cv::Mat aligned_mat;
  cv::warpPerspective(im_mat, aligned_mat, transform, cv::Size(dst_w, dst_h));

  return aligned_mat;
}

inline void get_pic(const cv::Mat &img, std::vector<unsigned char> *im_data) {
  auto param = std::vector<int>(2);
  param[0] = cv::IMWRITE_JPEG_QUALITY;
  param[1] = 95;
  im_data->clear();
  cv::imencode(".jpg", img, *im_data, param);
  return;
}

std::string get_pic(const cv::Mat &img) {
    std::vector<unsigned char> im_data;
    get_pic(img, &im_data);
    return std::string((const char*)(im_data.data()), im_data.size());
}

std::string get_pic_base64(const cv::Mat &img) {
  std::vector<unsigned char> im_data;
  get_pic(img, &im_data);
  return base64_encode((&(im_data[0])), im_data.size());
}

bool is_same_postion(const PosInfo& location_x,const PosInfo& location_y) {
    const float threshold_scale = 1;
    const float threshold_angle_x = 5;
    const float threshold_angle_y = 5;

    if (fabs(location_x.scale - location_y.scale) > threshold_scale){
        return false;
    }
    if (fabs(location_x.angle_x - location_y.angle_x) > threshold_angle_x){
        return false;
    }
    if (fabs(location_x.angle_y - location_y.angle_y) > threshold_angle_y){
        return false;
    }
    return true;
}

}  // namespace Helper

}  // namespace FLOW
