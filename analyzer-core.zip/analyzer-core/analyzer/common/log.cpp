#include "log.hpp"

#include <iostream>
#include <memory>
#include <stdexcept>
#include <vector>

#if defined(__linux__) || defined(__APPLE__)
#include <cxxabi.h>
#include <execinfo.h>
#endif

#if defined(USE_SPDLOG)
#include "spdlog/cfg/env.h"
#include "spdlog/sinks/stdout_color_sinks.h"
#include "spdlog/spdlog.h"
#endif

namespace FLOW {

LogMessage::LogMessage(const std::string& severity, const char* file, int line)
    : severity_(severity) {
  std::string file_str(file);
  std::string file_name = file_str.substr(file_str.find_last_of("/\\") + 1);
#if defined(USE_SPDLOG)
  static auto logger = []() {
    spdlog::cfg::load_env_levels();
    auto logger = spdlog::stdout_color_mt("analyzer");
    logger->set_pattern("[%m/%d/%Y %H:%M:%S.%e] [%n] [%^%L%$] %v");
    return logger;
  }();
  stream_ << "[" << file_name << ":" << line << "] ";
#else
  stream_ << "[" << severity << "] [" << file_name << ":" << line << "] ";
#endif
}

LogMessage::~LogMessage() noexcept(false) {
  const auto& msg = stream_.str();
#if defined(USE_SPDLOG)
  if (severity_ == "DEBUG") {
    spdlog::get("analyzer")->debug(msg);
  } else if (severity_ == "INFO") {
    spdlog::get("analyzer")->info(msg);
  } else if (severity_ == "WARNING") {
    spdlog::get("analyzer")->warn(msg);
  } else if (severity_ == "ERROR") {
    spdlog::get("analyzer")->error(msg);
  } else if (severity_ == "FATAL") {
    spdlog::get("analyzer")->critical(msg);
  }
#else
  if (severity_ == "DEBUG" || severity_ == "INFO") {
    std::cout << msg << std::endl;
  } else {
    std::cerr << msg << std::endl;
  }
#endif
  if (severity_ == "FATAL") {
    const auto& trace = stack_trace(0);
    if (!trace.empty()) {
      std::cerr << trace;
    }
    throw std::runtime_error(msg);
  }
}

std::string LogMessage::demangle(const char* symbol) {
  std::string symbol_str(symbol);
#if defined(__linux__) || defined(__APPLE__)
  auto func_start = symbol_str.find("_Z");
  if (func_start != std::string::npos) {
    auto func_end = symbol_str.find_first_of(" +", func_start);
    const auto& func_symbol =
        symbol_str.substr(func_start, func_end - func_start);
    int status = 0;
    size_t length = 0;
    auto demangle_func_symbol =
        abi::__cxa_demangle(func_symbol.c_str(), nullptr, &length, &status);
    if (demangle_func_symbol != nullptr && status == 0 && length > 0) {
      symbol_str = symbol_str.substr(0, func_start) + demangle_func_symbol +
                   symbol_str.substr(func_end);
    }
    free(demangle_func_symbol);
  }
#endif
  return symbol_str;
}

std::string LogMessage::stack_trace(int start_frame, int stack_size) {
  std::stringstream ss;
#if defined(__linux__) || defined(__APPLE__)
  std::vector<void*> stack(stack_size, nullptr);
  stack_size = backtrace(stack.data(), stack_size);
  ss << "Stack trace:" << std::endl;
  auto symbols = backtrace_symbols(stack.data(), stack_size);
  if (symbols != nullptr) {
    for (int n = start_frame; n < stack_size; ++n) {
      const auto& demangle_symbol = demangle(symbols[n]);
      if (demangle_symbol.find("LogMessage") == std::string::npos) {
        ss << "  [bt] " << demangle_symbol << std::endl;
      }
    }
  }
  free(symbols);
#endif
  return ss.str();
}

}  // namespace FLOW
