#ifndef TAD_TAD_INTERNAL_HPP
#define TAD_TAD_INTERNAL_HPP

#include <atomic>
#include <functional>
#include <memory>
#include <opencv2/opencv.hpp>
#include <queue>
#include <string>
#include <vector>

#include "common/boxes.hpp"
#include "common/util.hpp"
#include "common/type.hpp"


#ifdef USE_MEDIA_UTILS
#include "frame_reader.h"
#else
namespace media_utils
{
class vframe;
}
#endif

namespace FLOW
{

struct BreakIn_Event {
  VecBoxF persons;
  VecBoxF non_motors;
};

struct QueueCount_Event {
  VecBoxF persons;
};

struct LeftObject_Event {
  VecBoxF left_objects;
  bool need_detect_flag;
};

struct ThrowObject_Event {
  VecBoxF throw_objects;
  VecBoxF vehicle_objects;
  bool need_detect_flag;
};

struct Fight_Event {
  float predict_score = 0.f;
  bool if_predicted = false;
  bool is_bk_fighting = false;
};

struct TrafficSign_Event {
  VecBoxF traffic_signs;
};

struct TrafficLight_Event {
  bool processed = false;
  std::map<std::string, VecBoxF> traffic_lights;
};

struct Construction_Event {
    VecBoxF objs;//mapped
    VecBoxF objs_traffic;
    //只是为了给数据层用方便。
    VecBoxF objs_vehicle;
    VecBoxF objs_nomotor;
    VecBoxF objs_person;
    VecBoxF objs_sign;
    bool processed = false;
};

struct SharedBike_Event {
  VecBoxF objs;
};

struct Weather_Event {
  float predict_foggy_score = 0.f;
  std::string predict_foggy_name;
  float predict_suspected_score = 0.f;
  std::string predict_suspected_name;
};

struct Fire_Event {
  bool processed = false;
  float predict_fire_score = 0.f;
  std::string predict_fire_name;
  float predict_smoke_score = 0.f;
  std::string predict_smoke_name;
};

struct Fall_Event {
  VecBoxF fall;
  std::string predict_fall_name;
};

struct SafeHelmet_Event {
  VecBoxF safe_helmets;
  std::vector<std::shared_ptr<cv::Mat>> safehelmets_mat;
};

struct Guardrail_Event {
  std::map<std::string, VecBoxF> guardrails;
};

struct Highway_Event {
  Weather_Event weather_event;
  BreakIn_Event break_in_event;
  LeftObject_Event left_object_event;
  ThrowObject_Event throw_object_event;
  TrafficSign_Event traffic_sign_event;
  Fire_Event fire_event;
  TrafficLight_Event traffic_light_event;
};

struct Cloud_Event {
  SafeHelmet_Event safe_helmet_event;
  Fall_Event fall_event;
};

enum ModuleStatus {
  module_status_success = 200,
  module_status_skip = 201,
  module_status_method_nullptr = 550,
  module_status_parse_model_error = 551,
  module_status_infer_error = 552,
};

enum StreamStatus {
  STREAM_STATUS_UNKNOW = 0,
  STREAM_STATUS_SUCCESS = 1,
  STREAM_STATUS_FAIL = 255,
};

enum AlgEngineType {
  ENGINE_TYPE_VEHICLE = 0,
  ENGINE_TYPE_BANNER = 1,
  ENGINE_TYPE_HEAD = 2,
  ENGINE_TYPE_CROWD = 3,
  ENGINE_TYPE_FIGHT = 4,
};

enum ObjectType {
  OBJECT_TYPE_NONE = 0,
  OBJECT_TYPE_PERSON = 1,
  OBJECT_TYPE_VEHICLE = 2,
  OBJECT_TYPE_NONMOTOR = 3,
  OBJECT_TYPE_TRICYCLE = 4,
  OBJECT_TYPE_HEAD = 6,
  OBJECT_TYPE_BANNER = 7,
  //OBJECT_TYPE_PARADE = 8,
};

static const int DUCHA_DETECT_TYPE = 0x1;
static const int DUCHA_FIGHT_TYPE = 0x2;
static const int GANGWEI_DETECT_TYPE = 0x4;

typedef std::shared_ptr<cv::Mat> Mat_Ptr;
typedef std::vector<Mat_Ptr> VecMat;

typedef struct DensityInfo_ {
  std::vector<int> crowd_count_;
  cv::Mat density_map;
  std::vector<cv::Rect> crowd_rect;
  std::vector<int> crowd_num;
  cv::Mat foreground_mask;
  int score;
} DensityInfo;

typedef struct _POINT_ {
    float x;
    float y;
} POINT;
typedef struct HeadCountInfo_ {
  std::vector<int> head_count_;
  std::vector<std::vector<int>> DrawHeadLines_;
  std::vector<std::vector<int>> arrows_;
  VecBoxF in_persons_;
  VecBoxF out_persons_;
  std::vector<std::pair<POINT, POINT> > inHeadTrace_; //每个过线的head的移动路径
  std::vector<std::pair<POINT, POINT> > outHeadTrace_;
  std::string startCountTime_; //开始计数时间
} HeadCountInfo;

typedef struct ZoneGuardInfo_ {
  VecBoxF heads_;//触发入侵上报的目标
  VecBoxF tracked_heads_;//所有正在跟踪的目标
} ZoneGuardInfo;

typedef struct RetrogradeInfo_ {
  VecBoxF persons_;
  std::vector<std::vector<int>> rois_;
  std::vector<std::vector<int>> arrows_;
  std::vector<std::vector<int>> lines_;
} RetrogradeInfo;

typedef struct BannerInfo_ {
  VecBoxF bannerobjects_;
} BannerInfo;

typedef struct ValidRois_ {
  std::vector<VecPointF> rois_;
  int head_counts_;
  //keliu_debug
  //int have_head_seconds_;
  //int not_have_head_seconds_;
} ValidRoisInfo;

typedef struct WanderRetentionInfo_ {
  VecBoxF retentionobjects_;
} WanderRetentionInfo;

typedef struct ParadeInfo_ {
  VecBoxF red_flag_detect_objs_;//举旗算法检测目标，仅用作过滤
  VecBoxF red_flag_objs_;//举旗目标
  VecBoxF white_flag_objs_;//举牌目标
} ParadeInfo;

typedef struct flow_info_ {
  Fight_Event fight_event_;
  HeadCountInfo headcountinfo_;
  ZoneGuardInfo zoneguardinfo_;
  DensityInfo densityinfo_;
  BannerInfo bannerinfo_;
  RetrogradeInfo retrogradeinfo_;
  ValidRoisInfo roisinfo_;
  WanderRetentionInfo retentioninfo_;
} FlowInfo;

typedef std::shared_ptr<media_utils::vframe> Vframe_Ptr;

typedef std::vector<Vframe_Ptr> VecVframe;

class ShellFrame {
 public:
  ShellFrame(Mat_Ptr input_ptr) {
    mat_ = input_ptr;
  }
  ~ShellFrame() { getValue().fetch_sub(frameSize); }

  static std::atomic<std::int64_t>& getValue() {
    static std::atomic<std::int64_t> totalVframeUsed(0);
    return totalVframeUsed;
  }

  Mat_Ptr getMat() const{
    return mat_;
  }

  void addVframe(Vframe_Ptr input_ptr) {
    vframe_ = input_ptr;
    if (input_ptr) {
#ifdef USE_MEDIA_UTILS
      frameSize = 12 * input_ptr->w * input_ptr->h;
#else
      frameSize = 1;
#endif
    } else {
      frameSize = 0;
    }
    getValue().fetch_add(frameSize);
  }

  Vframe_Ptr getVframe() const {
    return vframe_;
  }

  void clearVframe() {
    vframe_.reset();
  }

  int width() const {
    return mat_->cols;
  }

  int height() const {
    return mat_->rows;
  }

 private:
  Mat_Ptr mat_;
  Vframe_Ptr vframe_;
  std::int64_t frameSize = 0;
};

typedef std::shared_ptr<ShellFrame> ShellFrame_Ptr;

typedef std::vector<ShellFrame_Ptr> VecShellFrame;

typedef struct PosInfo_ {
  float angle_x = -1;
  float angle_y = -1;
  float scale = -1;
  bool changed = false;
} PosInfo;

typedef struct ImageObjectsInfo_ {
  std::string channel_id;
  ShellFrame_Ptr sframe;
  Highway_Event highways;
  VecBoxF objects;
  //keliu_head
  VecBoxF keliu_objects;
  VecBoxF safehelmet_v3_objects;
  std::unordered_map<std::string, BoxF> tlc;
  bool fake_objects = false;
  int64_t pts = -1;
  int64_t count = -1;
  int64_t ntp_time_stamp=-1;
  PosInfo ptz_pos;
  float pts_interval=0;
  float time_interval=0;
  uint64_t type = 0;
  int jitter_status = 0;

  // ducha
  VecBoxF ducha_objects;
  Fight_Event ducha_fight_event;
  // gangwei
  VecBoxF gangwei_objects;

  Construction_Event shigong_objects;
  VecBoxF face_objects;
  VecBoxF person_objects;
  bool skip_crowd_status = false;

  // shared_bike
  SharedBike_Event sharedbike_objs;

  // clouds
  Cloud_Event clouds;
  VecBoxF fall_objects;
  VecBoxF safehelmet_objects;
  Guardrail_Event guardrails;

  mutable FlowInfo flow_info;
  mutable ParadeInfo parade_info;
  bool bool_head_exception = false;  // control head streaming

  mutable std::map<std::string, VecPointF> avg_path_map;
  mutable std::map<std::string, VecPointF> voilation_path_map;
  mutable std::map<std::string, VecPointF> current_path_map;
  mutable VecBoxF vest_objects;
} ImageObjectsInfo;

typedef std::shared_ptr<ImageObjectsInfo> spImageObjectsInfo;
typedef std::vector<spImageObjectsInfo> VecImage;
typedef std::function<void(const ImageObjectsInfo&, Mat_Ptr, bool)> AlgRender;

inline spImageObjectsInfo CloneWithoutImage(spImageObjectsInfo in) {
  auto retv = std::make_shared<ImageObjectsInfo>(*in);
  retv->sframe.reset();
  return retv;
}

}  // namespace FLOW

#endif  // TAD_TAD_INTERNAL_HPP
