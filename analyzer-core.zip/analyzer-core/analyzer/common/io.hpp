#ifndef SCOPE_COMMON_IO_HPP
#define SCOPE_COMMON_IO_HPP

#include <google/protobuf/message.h>

#if GOOGLE_PROTOBUF_VERSION >= 3003000
#define SUPPORT_JSON
#endif

namespace FLOW {

namespace IO {

using google::protobuf::Message;

bool ReadProtoFromBinaryFile(const std::string &proto_file, Message *proto);

bool ReadProtoFromArray(const void *proto_data, int proto_size,
                        google::protobuf::Message *proto);

bool WriteProtoToJsonText(const Message &proto, std::string *json_text,
                          bool compact = false);

bool ReadBinaryFile(const std::string& binary_file,
                    std::vector<char>* binary_data);

}  // namespace IO

}  // namespace FLOW

#endif  // SCOPE_COMMON_IO_HPP
