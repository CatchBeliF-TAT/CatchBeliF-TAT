#ifndef ANALYZER_COMMON_LOG_HPP_
#define ANALYZER_COMMON_LOG_HPP_

#include <cstdlib>
#include <sstream>
#include <string>

namespace FLOW {

#define SLOG_DEBUG LogMessage("DEBUG", __FILE__, __LINE__)
#define SLOG_INFO LogMessage("INFO", __FILE__, __LINE__)
#define SLOG_WARNING LogMessage("WARNING", __FILE__, __LINE__)
#define SLOG_ERROR LogMessage("ERROR", __FILE__, __LINE__)
#define SLOG_FATAL LogMessage("FATAL", __FILE__, __LINE__)

#define LOG(severity) SLOG_##severity.stream()
#define LOG_IF(severity, condition) \
  if ((condition)) LOG(severity)

#define CHECK_NOTNULL(condition) \
  if ((condition) == nullptr)    \
  LOG(FATAL) << "Check Failed: '" #condition << "' Must be non NULL "

#define CHECK(condition) \
  if (!(condition)) LOG(FATAL) << "Check Failed: " #condition << " "

#define CHECK_OP(condition, val1, val2)                                        \
  if (!((val1)condition(val2)))                                                \
  LOG(FATAL) << "Check Failed: " #val1 " " #condition " " #val2 " (" << (val1) \
             << " vs " << (val2) << ") "

#define CHECK_EQ(val1, val2) CHECK_OP(==, val1, val2)
#define CHECK_NE(val1, val2) CHECK_OP(!=, val1, val2)
#define CHECK_LE(val1, val2) CHECK_OP(<=, val1, val2)
#define CHECK_LT(val1, val2) CHECK_OP(<, val1, val2)
#define CHECK_GE(val1, val2) CHECK_OP(>=, val1, val2)
#define CHECK_GT(val1, val2) CHECK_OP(>, val1, val2)

#if defined(NDEBUG)
#define DLOG(severity) \
  while (false) LOG(severity)
#define DLOG_IF(severity, condition) \
  while (false) LOG_IF(severity, condition)

#define DCHECK(condition) \
  while (false) CHECK(condition)
#define DCHECK_EQ(val1, val2) \
  while (false) CHECK_EQ(val1, val2)
#define DCHECK_NE(val1, val2) \
  while (false) CHECK_NE(val1, val2)
#define DCHECK_LE(val1, val2) \
  while (false) CHECK_LE(val1, val2)
#define DCHECK_LT(val1, val2) \
  while (false) CHECK_LT(val1, val2)
#define DCHECK_GE(val1, val2) \
  while (false) CHECK_GE(val1, val2)
#define DCHECK_GT(val1, val2) \
  while (false) CHECK_GT(val1, val2)

#else
#define DLOG(severity) LOG(severity)
#define DLOG_IF(severity, condition) LOG_IF(severity, condition)

#define DCHECK(condition) CHECK(condition)
#define DCHECK_EQ(val1, val2) CHECK_EQ(val1, val2)
#define DCHECK_NE(val1, val2) CHECK_NE(val1, val2)
#define DCHECK_LE(val1, val2) CHECK_LE(val1, val2)
#define DCHECK_LT(val1, val2) CHECK_LT(val1, val2)
#define DCHECK_GE(val1, val2) CHECK_GE(val1, val2)
#define DCHECK_GT(val1, val2) CHECK_GT(val1, val2)
#endif

class LogMessage {
 public:
  LogMessage(const std::string& severity, const char* file, int line);
  ~LogMessage() noexcept(false);

  std::stringstream& stream() { return stream_; }

  LogMessage(const LogMessage&) = delete;
  void operator=(const LogMessage&) = delete;

 private:
  static std::string demangle(const char* symbol);
  static std::string stack_trace(int start_frame, int stack_size = 20);

  std::string severity_;
  std::stringstream stream_;
};

class LogFunInOut {
  const std::string severity_;
  const char* file_;
  const int line_;
  const std::string fun_name_;
  public:
    LogFunInOut(const std::string& severity, const char* file, int line, const std::string& fun_name)
      : severity_(severity)
      , file_(file)
      , line_(line)
      , fun_name_(fun_name){
      LogMessage(severity_, file_, line_).stream() <<"->["<< fun_name_<<"]";
    }
    ~LogFunInOut() noexcept(false){
      LogMessage(severity_, file_, line_).stream() <<"<-["<< fun_name_<<"]";
    }
};

#define SLOG_FUN_IN_OUT_DEBUG LogFunInOut("DEBUG", __FILE__, __LINE__, __PRETTY_FUNCTION__)
#define SLOG_FUN_IN_OUT_INFO LogFunInOut("INFO", __FILE__, __LINE__, __PRETTY_FUNCTION__)
#define LOG_FUN_IN_OUT(severity) SLOG_FUN_IN_OUT_##severity

}  // namespace FLOW

#endif  // ANALYZER_COMMON_LOG_HPP_
