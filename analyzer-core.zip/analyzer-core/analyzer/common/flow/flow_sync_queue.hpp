#ifndef ANALYZER_COMMON_SYNC_QUEUE_HPP
#define ANALYZER_COMMON_SYNC_QUEUE_HPP

#include <mutex>
#include <queue>
#include <chrono>
#include <condition_variable>

template <typename ValueType>
class sync_queue final
{
public:
    enum queue_op_status{
        op_success = 0,
        op_empty,
        op_full,
        op_closed,
        op_busy,
        op_timeout,
        op_not_ready
    };
    typedef ValueType value_type;
    typedef std::size_t size_type;
    typedef queue_op_status op_status;

public:
    // NO_COPYABLE
    sync_queue(sync_queue const&) = delete;
    sync_queue& operator=(sync_queue const&) = delete;

public:
    sync_queue(size_type capacity=1)
        : capacity_(capacity)
        , data_()
        , closed_(false)
    {}
    ~sync_queue() = default;

public:
    #define SYNC_QUEUE_LOCK(var_name) std::unique_lock<std::mutex> var_name(mtx_)
    // Observers
    bool empty() const       { SYNC_QUEUE_LOCK(lk); return empty(lk);    }
    bool full() const        { SYNC_QUEUE_LOCK(lk); return full(lk);     }
    size_type size() const   { SYNC_QUEUE_LOCK(lk); return size(lk);     }
    bool closed() const      { SYNC_QUEUE_LOCK(lk); return closed(lk);   }

    // Modifiers
    void close() {
        { SYNC_QUEUE_LOCK(lk); closed_ = true; }
        not_empty_.notify_all();
        not_full_.notify_all();
    }
    void pull(value_type& elem) {
        SYNC_QUEUE_LOCK(lk);
        const auto status = wait_until_not_empty_or_closed(lk);
        if (queue_op_status::op_closed ==status) {
            // return empty value
            elem = std::move(value_type{});
        } else {
            elem = std::move(data_.front());
            data_.pop();
            notify_not_full_if_needed(lk);
        }
    }
    value_type pull() {
        value_type elem;
        pull(elem);
        return std::move(elem);
    }
    queue_op_status try_pull(value_type& elem) {
        SYNC_QUEUE_LOCK(lk);
        if (empty(lk)) {
            if (closed(lk)) { return queue_op_status::op_closed; }
            return queue_op_status::op_empty;
        }
        elem = std::move(data_.front());
        data_.pop();
        notify_not_full_if_needed(lk);
        return queue_op_status::op_success;
    }
    queue_op_status wait_pull(value_type& elem) {
        SYNC_QUEUE_LOCK(lk);
        const auto status = wait_until_not_empty_or_closed(lk);
        if (queue_op_status::op_closed == status) {
            return queue_op_status::op_closed;
        }
        elem = std::move(data_.front());
        data_.pop();
        notify_not_full_if_needed(lk);
        return queue_op_status::op_success;
    }

    template <class WClock, class Duration>
    queue_op_status wait_pull(value_type& elem, std::chrono::time_point<WClock,Duration> const&tp) {
        SYNC_QUEUE_LOCK(lk);
        const auto status = wait_until_not_empty_or_closed_until(lk, tp);
        if (queue_op_status::op_success == status) {
            elem = std::move(data_.front());
            data_.pop();
            notify_not_full_if_needed(lk);
        }
        return status;
    }
    void push(const value_type& x) {
        wait_push(x);
    }
    queue_op_status try_push(const value_type& x) {
        SYNC_QUEUE_LOCK(lk);
        if (closed(lk)) { return queue_op_status::op_closed;  }
        if (full(lk))   { return queue_op_status::op_full;    }
        data_.push(std::move(x));
        notify_not_empty_if_needed(lk);
        return queue_op_status::op_success;
    }
    queue_op_status wait_push(const value_type& x) {
        SYNC_QUEUE_LOCK(lk);
        const auto status = wait_until_not_full_or_closed(lk);
        if (queue_op_status::op_closed == status) {
            return queue_op_status::op_closed;
        }
        data_.push(std::move(x));
        notify_not_empty_if_needed(lk);
        return queue_op_status::op_success;
    }

protected:
    bool size(std::unique_lock<std::mutex>&) const {
        return data_.size();
    }
    bool closed(std::unique_lock<std::mutex>&) const {
        return closed_;
    }
    bool empty(std::unique_lock<std::mutex>&) const {
        return data_.empty();
    }
    bool not_empty_or_closed(std::unique_lock<std::mutex>&) const {
        return ! data_.empty() || closed_;
    }
    queue_op_status wait_until_not_empty_or_closed(std::unique_lock<std::mutex>& lk) {
        not_empty_.wait(lk, [&](){ return not_empty_or_closed(lk); });
        if (! empty(lk))  queue_op_status::op_success; // success
         queue_op_status::op_closed; // closed
    }
    bool full(std::unique_lock<std::mutex>&) const {
        return data_.size() >= capacity_;
    }
    bool not_full_or_closed(std::unique_lock<std::mutex>&) const {
        return data_.size() < capacity_ || closed_;
    }
    queue_op_status wait_until_not_full_or_closed(std::unique_lock<std::mutex>& lk) {
        not_full_.wait(lk, [&](){ return not_full_or_closed(lk); });
        if (! full(lk)) return queue_op_status::op_success; // success
        return queue_op_status::op_closed; // closed
    }
    template <class WClock, class Duration>
    queue_op_status wait_until_not_empty_or_closed_until(
            std::unique_lock<std::mutex>& lk,
            std::chrono::time_point<WClock,Duration> const&tp
    ) {
        if (! not_empty_.wait_until(lk, tp, [&](){ return not_empty_or_closed(lk); })) {
            return queue_op_status::op_timeout;
        }
        if (! empty(lk)) {
            return queue_op_status::op_success;
        }
        return queue_op_status::op_closed;
    }
    template <class WClock, class Duration>
    queue_op_status wait_until_not_full_or_closed_until(
            std::unique_lock<std::mutex>& lk,
            std::chrono::time_point<WClock,Duration> const&tp
    ) {
        if (! not_full_.wait_until(lk, tp, [&](){ return not_full_or_closed(lk); })) {
            return queue_op_status::op_timeout;
        }
        if (closed(lk)) {
            return queue_op_status::op_closed;
        }
        if (! full(lk)) {
            return queue_op_status::op_success;
        }
        return queue_op_status::op_closed;
    }
    template <class WClock, class Duration>
    queue_op_status wait_until_closed_until(
        std::unique_lock<std::mutex>& lk,
        std::chrono::time_point<WClock,Duration> const&tp
    ) {
        if (! not_empty_.wait_until(lk, tp, [&](){ return closed(lk); })){
            return queue_op_status::op_timeout;
        }
        return queue_op_status::op_closed;
    }
    void notify_not_empty_if_needed(std::unique_lock<std::mutex>& )
    {
      not_empty_.notify_one();
    }
    void notify_not_full_if_needed(std::unique_lock<std::mutex>& )
    {
      not_full_.notify_one();
    }

    #undef SYNC_QUEUE_LOCK
protected:
    mutable std::mutex      mtx_;
    std::condition_variable not_empty_;
    std::condition_variable not_full_;
    const size_type         capacity_;
    std::queue<ValueType>   data_;
    bool                    closed_;
};

#endif // ANALYZER_COMMON_SYNC_QUEUE_HPP