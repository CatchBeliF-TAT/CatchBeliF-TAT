#ifndef ANALYZER_COMMON_PROCESSS_HPP
#define ANALYZER_COMMON_PROCESSS_HPP

#include <tuple>
#include <vector>
#include <memory>
#include <thread>
#include <future>
#include <functional>
#include <sstream>
#include <opencv2/opencv.hpp>

#include "flow_sync_queue.hpp"
#include "common/log.hpp"
#include "common/util.hpp"
#include "core/metric.hpp"
#include "serving/input_arguments.pb.h"

namespace FLOW{
class flow_process_base
    : public std::enable_shared_from_this<flow_process_base>
{
public:
    virtual ~flow_process_base()=default;
};
typedef std::shared_ptr<flow_process_base> sp_flow_process_base;


class flow_process_inference : public flow_process_base {
public:
    typedef std::function<void(void)>       call_back_type;
public:
    virtual void inference(cv::Mat mat, const inference::PictureReq& req, inference::PictureResp* resp, call_back_type done) =0;
};

template <typename Engine>
class flow_process_sync
    : public flow_process_inference
{
public:
    typedef std::function<void(void)>       call_back_type;
    typedef typename Engine::input_type     input_type;
    typedef typename Engine::output_type    output_type;

    typedef flow_process_sync<Engine>       processer_type;
    typedef std::shared_ptr<processer_type> sync_handle;
private:
    typedef struct {
        input_type  input;
        output_type* output;
        call_back_type done;
    } request_type;
    typedef sync_queue<request_type> sync_queue_type;

private:
    const std::string   name_;
    Engine              processer_;
    sync_queue_type     sync_queue_;
    std::thread         thread_;
    ProfileMetric       profile_metric_;
    prometheus::Counter*req_counter_;
    prometheus::Counter*resp_counter_;

public:
    // NO_COPYABLE
    flow_process_sync(flow_process_sync const&) = delete;
    flow_process_sync& operator=(flow_process_sync const&) = delete;

public:
    flow_process_sync(const std::string& name="FP_UNDFINE")
        : name_(name)
        , processer_()
        , sync_queue_(std::max<size_t>(processer_.MaxBatchSize(), 1)*2)
        , profile_metric_(ProfileMetric::LablesType{{"engine", "shared"}, {"model", name}})
    {

        std::stringstream address; address<<this;
        req_counter_ = &Metric::Instance().algorithm_req_count->Add({
                        {"model", name},
                        {"uuid", address.str()},
                    });
        resp_counter_ = &Metric::Instance().algorithm_resp_count->Add({
                        {"model", name},
                        {"uuid", address.str()},
                    });
    }
    virtual ~flow_process_sync(){
        sync_queue_.close();
        thread_.join();
    }
    template<typename... Types>
    void set_up(Types&... args) {
        processer_.Setup(args...);
        if (! thread_.joinable()) {
            thread_ = std::thread([this](){
                this->Run();
            });
        }
    }
    Engine* base(){
        return &processer_;
    }
    sync_handle Handle() {
        return std::dynamic_pointer_cast<processer_type>(shared_from_this());
    }

    // thread safe
    void inference(cv::Mat mat, const inference::PictureReq& req, inference::PictureResp* resp, call_back_type done) override {
        input_type in = Engine::ConvertInput(mat, req);
        auto output = std::make_shared<output_type>();
        call_back_type warp_done = [output, resp, done](void){
            *resp = Engine::ConvertOutput(*output);
            done();
        };
        sync_process(in, output.get(), warp_done);
    }

    // thread safe
    void process(const input_type& in, output_type* out) {
        std::promise<void> barrier;
        call_back_type done = [&barrier](){ barrier.set_value(); };
        sync_process(in, out, done);
        barrier.get_future().wait();
    }

    // thread safe
    void process(const std::vector<input_type>& in, const std::vector<output_type*>* const out) {
        std::vector<std::promise<void>> vec_barrier(in.size());
        for (size_t i = 0; i < in.size(); i++) {
            auto& barrier = vec_barrier[i];
            call_back_type done = [&barrier](){ barrier.set_value(); };
            sync_process(in[i], (*out)[i], done);
        }
        for (auto itr=vec_barrier.rbegin(); itr!=vec_barrier.rend(); itr++) {
            itr->get_future().wait();
        }
    }

    // thread safe
    void sync_process(const input_type& in, output_type* out, call_back_type done) {
        req_counter_->Increment();
        sync_queue_.push(request_type{in, out, done});
    }

protected:
    void Run(void) {
        LOG(INFO) << "Start thread "<< typeid(this).name();
        SET_THREAD_NAME(name_);
        const auto max_batch_size = std::max<size_t>(processer_.MaxBatchSize(), 1);
        request_type req;
        while(1) {
            auto end_time = std::chrono::steady_clock::now();
            end_time += std::chrono::milliseconds(10);
            auto code = sync_queue_.wait_pull(req, end_time);
            if (sync_queue_type::op_timeout == code) {
                continue;
            }
            if (sync_queue_type::op_success != code) {
                break;
            }
            // TODO need batch
            std::vector<input_type> inputs{req.input};
            std::vector<output_type*> outputs{req.output};
            std::vector<call_back_type> call_backs{req.done};
            while(inputs.size() < max_batch_size) {
                code = sync_queue_.wait_pull(req, end_time);
                if (sync_queue_type::op_success != code) {
                    break;
                }
                inputs.push_back(req.input);
                outputs.push_back(req.output);
                call_backs.push_back(req.done);
            }
            {
                ProfileMetric::Helper _metric_helper(profile_metric_);
                processer_.ProcessBatch(inputs, &outputs);
            }
            LOG(INFO) << "Runing thread "<< typeid(this).name()
                    <<", process req:" << inputs.size();
            for (auto&& done : call_backs) {
                resp_counter_->Increment();
                if (done) { done(); } 
            }
        }
        LOG(INFO) << "Exit thread "<< typeid(this).name();
    }
};

} // namespace FLOW

#endif // ANALYZER_COMMON_PROCESSS_HPP