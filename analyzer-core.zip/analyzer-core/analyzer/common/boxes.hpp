#ifndef SRC_COMMON_BOXES_HPP
#define SRC_COMMON_BOXES_HPP

#include "type.hpp"

namespace FLOW {

namespace TrafficLight {

  enum TrafficLightColor {
    kColorEmpty = 0,
    kColorGreen = 1,
    kColorRed = 2,
    kColorYellow = 3,
    kColorBlack = 4,
    kColorDouble = 5
  };
}
struct Attr{
  int   type  = -1;
  float score =  0;
};

template <class Dtype>
struct PlateInfo{
  typedef Point<Dtype> PointT;
  typedef std::vector<PointT>    VecPointT;
  VecPointT points;
  int   label = -1;
  float score =  0;
  VecFloat score_by_character;
  std::string content;

  PlateInfo()=default;
  explicit PlateInfo(const VecPointT &vp): points(vp),label(-1),score(0){}
};
template <class Dtype>

struct FacePoint{
    Dtype x1 = 0,y1 = 0, x2 = 0,y2 = 0,x3 = 0,y3 = 0,x4 = 0,y4 = 0,x5 = 0,y5 = 0;
    Dtype occ1 = 0,occ2 = 0,occ3 = 0,occ4 = 0,occ5 = 0;
    FacePoint()=default;
};

struct mergedBoxInfo {
  int lable = -1;
  int uid = -1;
};

template <class Dtype>
class Box {
 public:
  Box() = default;
  Box(Dtype xmin_t, Dtype ymin_t, Dtype xmax_t, Dtype ymax_t)
      : xmin(xmin_t), ymin(ymin_t), xmax(xmax_t), ymax(ymax_t), delete_flag(0) {}

    Rect<int> RectInt() const {
    return Rect<int>(xmin, ymin, xmax - xmin, ymax - ymin);
  }
    Rect<float> RectFloat() const {
    return Rect<float>(xmin, ymin, xmax - xmin, ymax - ymin);
  }
    Point<float> CenterFloat() const {
    return Point<float>((xmin+xmax)/2, (ymin+ymax)/2);
  }
    bool IsCover(const Point<float> point) const {
    return  point.x >= xmin && 
          point.x <= xmax &&
          point.y >= ymin && 
          point.y <= ymax;
  }

  Dtype xmin = 0, ymin = 0, xmax = 0, ymax = 0;
  float score = 0;
  float ave_score = 0;
  float lowest_score = 0;
  int label = -1, uid = -1, violate_type = 0;
  mutable int violate_state = 0;
  mutable bool  keliu_head_in_roi = false;//记录head是否在roi内，选择性渲染
  mutable float  auto_center_x=-1,auto_center_y=-1;// 自动中心点位置
  
  std::vector<PlateInfo<Dtype>>  plates;
  Attr                           attr_type;
  Attr                           attr_direction;
  Attr                           special_car_type;
  Attr                           shigong_attr;
  Attr                           nonmotor_type;
  Attr                           traffic_person_type;
  Attr                           ducha_colour;// add for ducha
  Attr                           ducha_action;
  Attr                           ducha_sex;
  Attr                           ducha_mask;
  std::vector<Attr>              behaviour_types;
  int                            create_flag=0;
  int                            delete_flag=0;
  FacePoint<Dtype>               face_point;
  VecFloat                       face_feature;
  Attr                           face_quality;
  std::vector<Attr>              face_attr;

  VecFloat                       person_feature;
  std::vector<Attr>              person_attr;
  std::vector<Attr>              person_quality;
  std::vector<Attr>              attr;
  Attr                           no_vest_attr;
  mutable int64_t                park_ms=-1;//停了多少毫秒
  TrafficLight::TrafficLightColor color=TrafficLight::kColorEmpty;
  std::vector<mergedBoxInfo>     mergedBoxes;
};

using BoxI = Box<int>;
using BoxF = Box<float>;

using VecBoxI = std::vector<BoxI>;
using VecBoxF = std::vector<BoxF>;

template <typename T>
class Polygon {
 public:
  Polygon() = default;
  explicit Polygon(const std::vector<Point<T>>& points_t) : points(points_t) {}
  Polygon(const std::vector<T>& x_t, const std::vector<T>& y_t) {
    for (int n = 0; n < std::min(x_t.size(), y_t.size()); ++n) {
      points.emplace_back(x_t[n], y_t[n]);
    }
  }

  Box<T> box() const {
    Box<T> box;
    if (!points.empty()) {
      box.xmin = points[0].x, box.ymin = points[0].y;
      box.xmax = points[0].x, box.ymax = points[0].y;
      for (const auto& point : points) {
        box.xmin = std::min(box.xmin, point.x);
        box.ymin = std::min(box.ymin, point.y);
        box.xmax = std::max(box.xmax, point.x);
        box.ymax = std::max(box.ymax, point.y);
      }
      box.score = score;
    }
    return box;
  }
  std::vector<Point<T>> points;
  float score = 0;
};

using PolygonF = Polygon<float>;

namespace Boxes {

template <typename Dtype>
void Clip(const Box<Dtype> &box, Box<Dtype> *clip_box, Dtype min, Dtype max);

template <typename Dtype>
Dtype Size(const Box<Dtype> &box);

template <typename Dtype>
float Intersection(const Box<Dtype> &box_a, const Box<Dtype> &box_b);

template <typename Dtype>
float Union(const Box<Dtype> &box_a, const Box<Dtype> &box_b);

template <typename Dtype>
float IoU(const Box<Dtype> &box_a, const Box<Dtype> &box_b);

template <typename Dtype>
std::vector<Box<Dtype>> NMS(const std::vector<Box<Dtype>> &boxes,
                            float iou_threshold);
template <typename Dtype>
std::vector<Box<Dtype>> NMS(const std::vector<std::vector<Box<Dtype>>> &Gboxes,
                            float iou_threshold);

template <typename Dtype>
void Smooth(const Box<Dtype> &old_box, Box<Dtype> *new_box, float smooth);
template <typename Dtype>
void Smooth(const std::vector<Box<Dtype>> &old_boxes,
            std::vector<Box<Dtype>> *new_boxes, float smooth);

template <typename Dtype>
void Amend(std::vector<std::vector<Box<Dtype>>> *Gboxes, const VecRectF &crops,
           int height = 1, int width = 1);

}  // namespace Boxes

}  // namespace FLOW

#endif  // SRC_COMMON_BOXES_HPP
