#ifndef THREAD_POOL_H
#define THREAD_POOL_H

#include <vector>
#include <queue>
#include <memory>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <future>
#include <functional>
#include <stdexcept>
#include <string>
#include <iostream>

#include "util.hpp"

namespace FLOW
{
class ThreadPool {
public:
    ThreadPool(size_t size=0, const std::string& name="");
    template<class F, class... Args>
    void enqueue(F&& f, Args&&... args);
    template<class F, class... Args>
    auto enqueue_with_future(F&& f, Args&&... args) 
        -> std::future<typename std::result_of<F(Args...)>::type>;
    ~ThreadPool();
private:
    // need to keep track of threads so we can join them
    std::vector< std::thread > workers;
    // the task queue
    std::queue< std::function<void()> > tasks;
    
    // synchronization
    std::mutex queue_mutex;
    std::condition_variable condition;
    bool stop;
    const std::string name;
};
 
// the constructor just launches some amount of workers
inline ThreadPool::ThreadPool(size_t size, const std::string& name)
    :   stop(false)
    ,   name(name.empty()?"UNDEFINE":name)
{
    for(size_t i = 0;i<size;++i)
        workers.emplace_back(
            [=]
            {
                std::string tt_name = name.substr(0,11) + "/" + std::to_string(i);
                SET_THREAD_NAME(tt_name);
                for(;;)
                {
                    std::function<void()> task;

                    {
                        std::unique_lock<std::mutex> lock(this->queue_mutex);
                        this->condition.wait(lock,
                            [this]{ return this->stop || !this->tasks.empty(); });
                        if(this->stop && this->tasks.empty())
                            return;
                        task = std::move(this->tasks.front());
                        this->tasks.pop();
                    }
                    task();
                }
            }
        );
}

// add new work item to the pool
template<class F, class... Args>
auto ThreadPool::enqueue_with_future(F&& f, Args&&... args) 
    -> std::future<typename std::result_of<F(Args...)>::type>
{
    using return_type = typename std::result_of<F(Args...)>::type;

    auto task = std::make_shared< std::packaged_task<return_type()> >(
            std::bind(std::forward<F>(f), std::forward<Args>(args)...)
        );
        
    std::future<return_type> res = task->get_future();
    {
        std::unique_lock<std::mutex> lock(queue_mutex);

        // don't allow enqueueing after stopping the pool
        if(stop)
            throw std::runtime_error("enqueue on stopped ThreadPool");

        tasks.emplace([task](){ (*task)(); });
    }
    condition.notify_one();
    return res;
}

// add new work item to the pool
template<class F, class... Args>
void ThreadPool::enqueue(F&& f, Args&&... args)
{
    using return_type = typename std::result_of<F(Args...)>::type;

    auto task = std::make_shared< std::packaged_task<return_type()> >(
            std::bind(std::forward<F>(f), std::forward<Args>(args)...)
        );
    {
        std::unique_lock<std::mutex> lock(queue_mutex);

        // don't allow enqueueing after stopping the pool
        if(stop)
            throw std::runtime_error("enqueue on stopped ThreadPool");

        tasks.emplace([task, this](){
            std::future<return_type> res = task->get_future();
            (*task)();
            res.get();
            // try{
            // }
            // catch (const std::exception &ex){
            //     std::cerr << "Thread <"
            //             << this->name <<"> caught with exception: "
            //             << ex.what() << "\n";
            //     exit(1);
            // }
            // catch (...){
            //     auto ex = std::current_exception();
            //     std::cerr << "Thread <"
            //             << this->name <<"> caught with unknow exception: "
            //             << ex.__cxa_exception_type()->name() << "\n";
            //     exit(1);
            // }
        });
    }
    condition.notify_one();
    return;
}

// the destructor joins all threads
inline ThreadPool::~ThreadPool()
{
    {
        std::unique_lock<std::mutex> lock(queue_mutex);
        stop = true;
    }
    condition.notify_all();
    for(std::thread &worker: workers)
        worker.join();
}
} // namespace FLOW
#endif
