#ifndef SCOPE_COMMON_UTIL_SCALE_HPP
#define SCOPE_COMMON_UTIL_SCALE_HPP

#include <opencv2/opencv.hpp>

namespace FLOW {

    static inline
    cv::Rect operator * (const cv::Rect& p, const cv::Matx22f& scale) {
        cv::Matx22f tmp = cv::Matx22f(p.x, p.y, p.width, p.height) * scale;
        return cv::Rect(tmp.val[0], tmp.val[1], tmp.val[2], tmp.val[3]);
    }
    static inline
    cv::Point operator * (const cv::Point& p, const cv::Matx22f& scale) {
        cv::Matx12f tmp = cv::Matx12f(p.x, p.y) * scale;
        return cv::Point(tmp.val[0], tmp.val[1]);
    }

}

#endif  // SCOPE_COMMON_UTIL_HPP
