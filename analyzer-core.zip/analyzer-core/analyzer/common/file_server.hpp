#ifndef ANALYZER_COMMON_FILE_SERVER_HPP_
#define ANALYZER_COMMON_FILE_SERVER_HPP_

#include <fstream>
#include <iostream>
#include <memory>

#include "serving/file_server.pb.h"

#if defined(USE_GRPC)
#include <grpc++/grpc++.h>
#include "serving/file_server.grpc.pb.h"
#endif

namespace FLOW {
namespace FileServer {
class UploadClient {
 public:
  explicit UploadClient(std::string address);

  UploadClient(const UploadClient& upload_client);

  std::string UploadFile(fileserver::StoreRequest& request,
                         fileserver::StorageObject& response) const;

  ~UploadClient() = default;

 private:
#if defined(USE_GRPC)
  std::unique_ptr<fileserver::ObjectStorageService::Stub> stub_;
#endif

  std::string server_address_;
};
}  // namespace FileServer

}  // namespace FLOW
#endif  // ANALYZER_COMMON_FILE_SERVER_HPP_
