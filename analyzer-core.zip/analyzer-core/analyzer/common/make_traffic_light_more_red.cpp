#include "make_traffic_light_more_red.hpp"

namespace FLOW {
    void make_traffic_light_more_red(cv::Mat mat, BoxF traffic_box)  {
    cv::Rect traffic_roi(traffic_box.xmin, traffic_box.ymin, traffic_box.xmax-traffic_box.xmin+1, traffic_box.ymax-traffic_box.ymin+1 );
    cv::Mat light_mat = cv::Mat(mat, traffic_roi);
    cv::Mat light_hsv_mat;
    cv::Mat retval_v;
    cv::cvtColor(light_mat, light_hsv_mat, cv::COLOR_BGR2HSV);
    std::vector<cv::Mat> hsv;
    cv::split(light_hsv_mat, hsv);
    auto v = hsv[2]; 

    cv::threshold( v, retval_v, 0, 255, cv::THRESH_OTSU);
    auto dark = retval_v.clone();
    
    for ( int i = 0; i < v.rows; ++i) {
        for ( int j = 0; j < v.cols; ++j) {
            dark.ptr<uchar>(i)[j]= ( v.ptr<uchar>(i,j) <=  retval_v.ptr<uchar>(i,j));
        }
    }

    int left = 0, right = dark.cols - 1, upper = 0, bottom = dark.rows - 1;
    
    //去除红绿灯黑框后的上边框
    for (  ; upper < bottom; ++upper) {
        double sum= 0;
        for ( int j = 0; j < dark.cols; ++j) {
            sum += dark.ptr<uchar>(upper)[j];
        }
        if ( sum/(dark.cols) > 0.5 ) {
            break;
        }
    } 
    //去除红绿灯黑框后的下边框
    for (  ; bottom > upper; --bottom ) {
        double sum = 0;
        for ( int j = 0; j < dark.cols; ++j) {
            sum += dark.ptr<uchar>(bottom)[j];
        }
        if ( sum/(dark.cols) > 0.5 ) {
            break;
        }
    } 
    //去除红绿灯黑框后的左边框
    for (  ; left < right; ++left) {
        double sum = 0;
        for ( int j = 0; j < dark.rows; ++j) {
            sum += dark.ptr<uchar>(j)[left];
        }
        if ( sum/(dark.rows) > 0.5 ) {
            break;
        }
    } 
    //去除红绿灯黑框后的右边框
    for (  ; left < right; --right ) {
        double sum = 0;
        for ( int j = 0; j < dark.rows; ++j) {
            sum += dark.ptr<uchar>(j)[right];
        }
        if ( sum/(dark.rows) > 0.5 ) {
            break;
        }
    }
    if ( left >= right || upper >= bottom) return;
    cv::Mat mat_after_crop(light_mat, cv::Rect(left, upper, right - left+1,bottom-upper+1));
    cv::Mat mat_hsv_crop;
    cv::cvtColor(mat_after_crop, mat_hsv_crop, cv::COLOR_BGR2HSV);

    std::vector<cv::Mat> hsv_crop;
    cv::split(mat_hsv_crop, hsv_crop);
    
    cv::Mat h_val, s_val, v_val;
    
    cv::threshold( hsv_crop[0], h_val, 0, 255, cv::THRESH_OTSU);
    cv::threshold( hsv_crop[1], s_val, 0, 255, cv::THRESH_OTSU);
    cv::threshold( hsv_crop[2], v_val, 0, 255, cv::THRESH_OTSU);

    double H=0.0,S=0.0,V =0.0; 

    for ( int i = 0; i < mat_hsv_crop.rows; ++i) {
        auto img_ptr_h = hsv_crop[0].ptr<uchar>(i);
        auto img_ptr_s = hsv_crop[1].ptr<uchar>(i);
        auto img_ptr_v = hsv_crop[2].ptr<uchar>(i);
        for ( int j = 0; j < mat_hsv_crop.cols; j++) {
            H = img_ptr_h[j];
            S = img_ptr_s[j];
            V = img_ptr_v[j];
            if ( H <= 40 && V >= v_val.ptr<uchar>(i)[j]) {
                mat_hsv_crop.ptr<uchar>(i)[3*j+0] /= 10;
            }
            if ( (H >=40 || H >= 160) && V >= V >= v_val.ptr<uchar>(i)[j]) {
                if ( S < 192 ) {
                    auto tmp = S + 128;
                    if ( tmp > 255) {
                        mat_hsv_crop.ptr<uchar>(i)[3*j+1] = 255;
                    } else {
                        mat_hsv_crop.ptr<uchar>(i)[3*j+1] += 128;
                    }
                }
            }
        }
    }
    cv::cvtColor(mat_hsv_crop, mat_after_crop, cv::COLOR_HSV2BGR);
}

bool get_traffic_light_box_config(const std::vector<float> &traffic_light_roi,BoxF *box) {

    CHECK_GE(traffic_light_roi.size(), 2 * 2);
    CHECK_EQ(traffic_light_roi.size() % 2, 0);

    box->xmin = traffic_light_roi[0];
    box->xmax = traffic_light_roi[0];
    box->ymin = traffic_light_roi[1];
    box->ymax = traffic_light_roi[1];
    for (int i = 1; i < traffic_light_roi.size() / 2; i++) {
        box->xmin = std::min(box->xmin, traffic_light_roi[i * 2]);
        box->xmax = std::max(box->xmax, traffic_light_roi[i * 2]);
        box->ymin = std::min(box->ymin, traffic_light_roi[i * 2 + 1]);
        box->ymax = std::max(box->ymax, traffic_light_roi[i * 2 + 1]);
    }
    return true;
}

}