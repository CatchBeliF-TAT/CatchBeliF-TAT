#ifndef VSS_VIOLATION_PATCHES_HPP
#define VSS_VIOLATION_PATCHES_HPP

#include <map>
#include <vector>
#include <string>

#include "common/json.hpp"
#include "common/log.hpp"

namespace FLOW {

std::map<std::string, std::string> get_static_voilation_patches() {
static const std::vector<std::string> static_voilation_patches=
{
    R"({
        "code" : "2101",
        "conditions" : [
            {"name" : "violate_line",   "zuozhuan_across" : true}
        ]
    })",
    R"({
        "code" : "2115",
        "conditions" : [
            {"name" : "sub_type",   "sub_type" : ["Middle_Truck", "Heavy_Truck", "Van_Truck"]}
        ]
    })",
    R"({
        "code" : "2116",
        "conditions" : [
            {"name" : "sub_type",   "sub_type" : ["Middle_Truck", "Heavy_Truck", "Bus"]}
        ]
    })",
    R"({
        "code" : "2117",
        "conditions" : [
            {"name" : "sub_type",   "sub_type" : ["Middle_Truck", "Heavy_Truck", "Van_Truck"]}
        ]
    })",
    R"({
        "code" : "2153",
        "conditions" : [
            {"name" : "start_line",     "gaosu_across" : true},
            {"name" : "violate_line",   "gaosu_across" : true},
            {"name" : "stop_line",      "gaosu_across" : true},
            {"name" : "sub_type",       "sub_type" : ["Middle_Truck", "Heavy_Truck", "Van_Truck"]}
        ]
    })",
    R"({
        "code" : "2201",
        "conditions" : [
            {"name" : "violate_line", "center_across" : true, "cross_angle" : 30},
            {"name" : "stop_line",    "center_across" : true, "cross_angle" : 30}
        ]
    })",
    R"({
        "code" : "2209",
        "conditions" : [
            {"name" : "nonmotor_behaviour", "nonmotor_behaviour": ["no_helmet"]},
            {"name" : "nonmotor_type",      "nonmotor_type":      ["ebike", "motor"]}
        ]
    })",
    R"({
        "code" : "2210",
        "conditions" : [
            {"name" : "nonmotor_behaviour", "nonmotor_behaviour": ["manned"], "data_number": 3},
            {"name" : "nonmotor_type",      "nonmotor_type":      ["ebike", "motor"]}
        ]
    })",
    R"({
        "code" : "2221",
        "conditions" : [
            {"name" : "nonmotor_type",      "nonmotor_type":      ["motor"]}
        ]
    })",
    R"({
        "code" : "2222",
        "conditions" : [
            {"name" : "nonmotor_type",      "nonmotor_type":      ["motor"]}
        ]
    })",
    R"({
        "code" : "2223",
        "conditions" : [
            {"name" : "nonmotor_behaviour", "nonmotor_behaviour": ["no_helmet"]},
            {"name" : "nonmotor_type",      "nonmotor_type":      ["motor"]}
        ]
    })",
    R"({
        "code" : "2224",
        "conditions" : [
            {"name" : "nonmotor_type",      "nonmotor_type":      ["motor"]}
        ]
    })",
    R"({
        "code" : "2225",
        "conditions" : [
            {"name" : "nonmotor_type",      "nonmotor_type":      ["motor"]}
        ]
    })",
    R"({
        "code" : "2226",
        "conditions" : [
            {"name" : "nonmotor_type",      "nonmotor_type":      ["motor"]}
        ]
    })",
    R"({
        "code" : "2227",
        "conditions" : [
            {"name" : "nonmotor_type",      "nonmotor_type":      ["motor"]}
        ]
    })",
    R"({
        "code" : "2228",
        "conditions" : [
            {"name" : "nonmotor_type",      "nonmotor_type":      ["motor"]}
        ]
    })",
    R"({
        "code" : "2415",
        "conditions" : [
            {"name" : "sub_type",   "sub_type" : ["Middle_Truck", "Heavy_Truck", "Van_Truck"]}
        ]
    })",
    R"({
        "code" : "2417",
        "conditions" : [
            {"name" : "sub_type",   "sub_type" : ["Middle_Truck", "Heavy_Truck"]}
        ]
    })",
    R"({
        "code" : "2418",
        "conditions" : [
            {"name" : "violate_box", "polygon_action": "enter-in"}
        ]
    })",
    R"({
        "code" : "2453",
        "conditions" : [
            {"name" : "special_car_type", "special_car_type": ["Tank_Truck"]}
        ]
    })",
    R"({
        "code" : "2464",
        "conditions" : [
            {"name" : "violate_box", "polygon_action": "in"}
        ]
    })",   
    R"({
        "code" : "2128",
        "enable_valid_box_check" : false,
        "conditions" : [
            {"name" : "violate_box", "polygon_action": "enter_duration_not_reached"}
        ]
    })",
    R"({
        "code" : "2750",
        "enable_output_picture":false
    })"
};

std::map<std::string, std::string> retv;
for(auto voilation_patch : static_voilation_patches) {
    auto root = get_document(voilation_patch);
    auto code = get_string(root, "code", "");
    if (code == "" ) {
        LOG(FATAL) << "parse code error, index=" << retv.size() << ", "
                   << "voilation_patch"<< voilation_patch;
        continue;
    }
    if (retv.count(code)) {
        LOG(FATAL) << "code="<<code<<" repeated, index=" << retv.size() << ", "
                   << "voilation_patch"<< voilation_patch;
        continue;

    }
    retv[code] = voilation_patch;
}
return retv;

}
} // namespace FLOW
#endif // VSS_VIOLATION_PATCHES_HPP
