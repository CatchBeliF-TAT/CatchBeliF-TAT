#ifndef VSS_VIOLATION_PARADE_HPP
#define VSS_VIOLATION_PARADE_HPP

#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"


namespace FLOW {

 class ViolationParadeFactory : public IViolationFactory
 {
    public:
        ViolationParadeFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationParadeFactory()=default;

    public:
        virtual const std::string& id()const;
        virtual spIViolation CreateIViolation(const BoxF& obj);

    protected:
        std::string                              id_;
        spViolationMassiveflowCommonConfig      cfg_;
 };

} // namespace FLOW
#endif

