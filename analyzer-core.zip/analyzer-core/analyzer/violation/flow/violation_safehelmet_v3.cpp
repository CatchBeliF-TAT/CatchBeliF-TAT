#include <unordered_map>
#include <memory>

#include "common/log.hpp"
#include "common/helper.hpp"
#include "common/pbjson.hpp"    
#include "common/tad_internal.hpp"          

#include "serving/violation_event.pb.h"  
#include "violation_flow_base.hpp"
#include "violation_flow_code.hpp"                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
#include "violation/violation_util.hpp"
#include "violation_safehelmet_v3.hpp" 

namespace FLOW {

    using namespace std;

    class ViolationSafeHelmetV3 : public ViolationFlowBase{
    public:
        ViolationSafeHelmetV3(int object_id, const std::string& violation_id, const spViolationMassiveflowCommonConfig cfg)
        : ViolationFlowBase(object_id, violation_id, cfg->data_){

            last_report_time_for_people_exceed_ = 0;
            //parse roi
            for (int i = 0; i < mf_violation_cfg_->roi_size(); i++){
                VecPointF tmp;
                for (int j = 0; j < mf_violation_cfg_->roi(i).data_size(); )
                {
                    PointF point;
                    point.x = mf_violation_cfg_->roi(i).data(j);
                    point.y = mf_violation_cfg_->roi(i).data(j+1);//j+1要是正好等于data_size应该就崩掉
                    tmp.push_back(point);
                    j += 2;
                }
                validRois.push_back(tmp);
            }
            //parse two threshold
            head_threshold_ = mf_violation_cfg_->threshold();
            body_threshold_ = mf_violation_cfg_->body_threshold();
        }
        virtual ~ViolationSafeHelmetV3()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
        virtual result_list_t get_people_exceed_results() const; //获取人数超限类事件
        result_list_t         try_get_alarm(const ImageObjectsInfo& objs);

    protected:
        vector<VecPointF>                           validRois;
        time_t                                      last_report_time_for_people_exceed_;
        VecBoxF                                     valid_boxes_;
        float                                       head_threshold_;
        float                                       body_threshold_;
    };

    class ICAlgEngine;

    result_list_t ViolationSafeHelmetV3::get_people_exceed_results()const{
        result_list_t retv;
        const auto stream_id = snapshots_[0].image->channel_id;
        const auto violation_code = mf_violation_cfg_->code();
        const auto violation_name = mf_violation_cfg_->name();
        const auto violation_id = violation_id_;
        const auto snapshots = snapshots_;
        const auto enable_output_picture = mf_violation_cfg_->enable_output_picture();
        const auto enable_save_picture = mf_violation_cfg_->enable_save_debug_picture();
        const auto valid_boxes = valid_boxes_;
        const auto is_violation = is_violation_;

        auto action = [=](ICAlgEngine* engine) -> spEventProto {
            auto retv = std::make_shared<inference::Event>();
            inference::Event& event = *retv;

            event.set_event_type(EventTypeMassiveflow);
            inference::MassiveFlowEvent * mass_event = event.mutable_massive_flow_event();
            mass_event->set_stream_id(stream_id);
            mass_event->set_task_id(stream_id);
            mass_event->set_event_type(atoi(violation_code.c_str()));
            for(int i=0;i<snapshots.size();i++){
                auto& image = snapshots[i].image;
                auto snap1 = mass_event->add_snapshots();
                snap1->set_now(snapshots[i].now.time_since_epoch().count());
                if (enable_output_picture){
                    snap1->set_image(Helper::get_pic_base64(*(image->sframe->getMat())));
                }
                for(auto iter1=valid_boxes.begin() ;iter1!= valid_boxes.end();iter1++){
                    auto obj1 = snap1->add_objects();
                    obj1->add_box((*iter1).xmin);
                    obj1->add_box((*iter1).ymin);
                    obj1->add_box((*iter1).xmax);
                    obj1->add_box((*iter1).ymax);
                }
            }

            //std::string result_json;
            //pb2json(&event, &result_json);
            //LOG(INFO) <<"head count exceed==>json result, violation_id="<<violation_id<<", len(result_json)="<<result_json.size();
            return retv;
        };
        retv.push_back(action);
        return retv;
    }



    result_list_t ViolationSafeHelmetV3::check(BoxF& box, const ImageObjectsInfo& objs){
        result_list_t retv;
        if(!check_time_valid()){
            return retv;
        }
        valid_boxes_.clear();

        time_t now;
        time(&now);

        for(const auto tmp_point : validRois) {
            for (auto &box : objs.safehelmet_v3_objects) {
                if (!interior_polygon(box, tmp_point))
                    continue;
                if(box.label == OBJECT_TYPE_HEAD && box.score>=head_threshold_){
                    valid_boxes_.push_back(box);
                    box.keliu_head_in_roi = true;
                }else if(box.label == OBJECT_TYPE_PERSON && box.score>=body_threshold_){
                    valid_boxes_.push_back(box);
                    box.keliu_head_in_roi = true;
                }
            } 
        }
        /*
        //3s或人头数变化大于5时更新渲染数值
        if(now-last_render_time_>=0 || head_counts_ >= valid_boxes_.size()+5 || valid_boxes_.size()>=head_counts_+5){
            head_counts_        = valid_boxes_.size();
            last_render_time_   = now;
        }
        auto &roisinfo      = objs.flow_info.roisinfo_;
        roisinfo.rois_        = validRois;
        roisinfo.head_counts_ = head_counts_;

        //keliu_debug
        if(valid_boxes_.size()>0){
            if_have_head_in_this_count_ = true;
        }
        if(now-last_count_time_>=1){
            last_count_time_ = now;
            if(if_have_head_in_this_count_){
                have_head_seconds_++;
            }else{
                not_have_head_seconds_++;
            }
            if_have_head_in_this_count_ = false;
        }
        roisinfo.have_head_seconds_ = have_head_seconds_;
        roisinfo.not_have_head_seconds_ = not_have_head_seconds_;
        //debug end*/

        if (now - last_report_time_for_people_exceed_ >= mf_violation_cfg_->cooling_second() && mf_violation_cfg_->cooling_second()>0){
            if (valid_boxes_.size() >= 1){
                last_report_time_for_people_exceed_ = now;
                this->clear_snapshot();
                this->add_snapshot(BoxF(), objs);
                retv.push_back(get_people_exceed_results().back());
            }
        }
        return retv;
    }

    //ViolationSafeHelmetV3Factory
    ViolationSafeHelmetV3Factory::ViolationSafeHelmetV3Factory(const std::string& id, const std::string& cfg)
    : IViolationFactory(), id_(id), cfg_(std::make_shared<ViolationMassiveflowCommonConfig>(cfg))
    {

    }
    

    const std::string& ViolationSafeHelmetV3Factory::id()const
    {
        return id_;
    }

    spIViolation ViolationSafeHelmetV3Factory::CreateIViolation(const BoxF& obj)
    {
        if (obj.uid == -1)
        {
            return std::make_shared<ViolationSafeHelmetV3>(obj.uid, id_, cfg_);
        }
        else
        {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(BUILDING_HEAD_BODY_DETECT_CODE, SafeHelmetV3);
    REGISTER_VIOLATION(BUILDING_HEAD_BODY_DETECT_PATTERN_CODE, SafeHelmetV3);

} // namespace FLOW

