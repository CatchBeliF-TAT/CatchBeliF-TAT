#ifndef VSS_VIOLATION_FLOW_HEARTBEAT_HPP
#define VSS_VIOLATION_FLOW_HEARTBEAT_HPP

#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"


namespace FLOW {

 class ViolationHeartBeatFactory : public IViolationFactory
 {
    public:
        ViolationHeartBeatFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationHeartBeatFactory()=default;

    public:
        virtual const std::string& id()const;
        virtual spIViolation CreateIViolation(const BoxF& obj);

    protected:
        std::string                                 id_;
        spViolationMassiveflowCommonConfig          cfg_;
 };

} // namespace FLOW
#endif