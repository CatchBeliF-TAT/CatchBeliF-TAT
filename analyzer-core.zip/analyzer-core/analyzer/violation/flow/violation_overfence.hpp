//
// Created by wuzhenzhou on 2019-12-18.
//

#ifndef ANALYZER_FLOW_VIOLATION_OVERFENCE_HPP
#define ANALYZER_FLOW_VIOLATION_OVERFENCE_HPP

#include <vector>
#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"

namespace FLOW {

    class ViolationOverfenceFactory : public IViolationFactory
    {
    public:
        ViolationOverfenceFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationOverfenceFactory()=default;

    public:
        virtual const std::string&  id()const;
        virtual spIViolation        CreateIViolation(const BoxF& obj);

    protected:
        std::string                             id_;
        spViolationMassiveflowCommonConfig      cfg_;
    };

} // namespace FLOW



#endif //ANALYZER_FLOW_VIOLATION_OVERFENCE_HPP
