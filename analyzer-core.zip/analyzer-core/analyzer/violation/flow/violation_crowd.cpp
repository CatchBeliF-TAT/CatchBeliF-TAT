//
// Created by wuzhenzhou on 2019-12-18.
//
#include <numeric>
#include <iterator>
#include <fstream>
#include <time.h>
#include <string>
#include <stdlib.h>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/util.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation_flow_base.hpp"
#include "violation_crowd.hpp"

#include "violation/flow/crowd/mot.hpp"

namespace FLOW
{

using namespace std;

typedef char uuid_string_t[37];

//
// ViolationCrowd
//
class ViolationCrowd : public ViolationFlowBase
{
public:
    ViolationCrowd(int object_id, const std::string &violation_id, const spViolationMassiveflowCommonConfig cfg);
    virtual ~ViolationCrowd() = default;

public:
    virtual result_list_t check(BoxF &box, const ImageObjectsInfo &objs);
    virtual result_list_t get_results() const;
    void log_info(const ImageObjectsInfo &objs) const;
    result_list_t try_get_alarm(const ImageObjectsInfo &objs);

protected:
    const spViolationMassiveflowCommonConfig cfg_;


    bool is_violation_;
    time_t last_report_time_;
    // std::shared_ptr<Crowdcount::crowdregion> crowdregion_ = nullptr;
    vector<DST_LIST> in_dst_list;

    TRACK_RES res_person_list[MAX_NUM_PERSON];
    TRACK_LIST person_list[MAX_NUM_PERSON];

    uuid_string_t uu_ed[10];
    int uu_num = 0;
    int track_id[10] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // std::vector<std::vector<float>> validRois;
    // std::vector<std::vector<float>> removeRois;
    float min_crowd_num_throd = 1;

    float skip_crowd = 1.0;
    float skip_crowd_count = 1;
    long pts_prev = 0;
    long pts_cur = 0;
};

ViolationCrowd::ViolationCrowd(int object_id, const std::string &violation_id, const spViolationMassiveflowCommonConfig cfg)
    : ViolationFlowBase(object_id, violation_id, cfg->data_), cfg_(cfg), is_violation_(false), last_report_time_(0)
{
    min_crowd_num_throd = float(cfg_->data_->min_num_threshold());
}

result_list_t ViolationCrowd::check(BoxF &box, const ImageObjectsInfo &objs)
{
    result_list_t retv;
    if(!check_time_valid()){
        return retv;
    }
    if (objs.skip_crowd_status) {
        return retv;
    }
    //todo
    if (objs.flow_info.densityinfo_.score/100  > min_crowd_num_throd)
    {
        time_t now = std::time(NULL);
        bool skip = (now - last_report_time_) < cfg_->data_->cooling_second();
        LOG(INFO)<< "(now - last_report_time_)" << (now - last_report_time_);
        if (!skip)
        {
            last_report_time_ = now;
            return try_get_alarm(objs);
        }
        LOG(INFO) << " cooling time, skip  ";
    }
    // result_list_t retv;

    return retv;
}

void ViolationCrowd::log_info(const ImageObjectsInfo &objs) const
{
    LOG(INFO) << "crowd ==> violation_id: " << this->violation_id_
              << ", stream_id: " << objs.channel_id;
}

result_list_t ViolationCrowd::try_get_alarm(const ImageObjectsInfo &objs)
{
    this->clear_snapshot();
    this->add_snapshot(BoxF(), objs);
    return get_results();
}

class ICAlgEngine;

result_list_t ViolationCrowd::get_results() const
{
    result_list_t retv;
    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = mf_violation_cfg_->code();
    const auto violation_name = mf_violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;
    const auto enable_output_picture = mf_violation_cfg_->enable_output_picture();
    const auto enable_save_picture = mf_violation_cfg_->enable_save_debug_picture();

    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event = *retv;
        event.set_event_type(EventTypeMassiveflow);

        inference::MassiveFlowEvent *mass_event = event.mutable_massive_flow_event();
        mass_event->set_stream_id(stream_id);
        mass_event->set_task_id(stream_id);
        mass_event->set_event_type(atoi(violation_code.c_str()));
        // mass_event->set_roi_num(roi_num);
        for (int i = 0; i < snapshots.size(); i++)
        {
            auto &image = snapshots[i].image;
            auto snap1 = mass_event->add_snapshots();
            snap1->set_now(snapshots[i].now.time_since_epoch().count());
            if (enable_output_picture){
                snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
            }

            if (enable_save_picture)
            {
                std::stringstream buff;
                buff << stream_id << "/pic_" << violation_id << "_"
                     << "_" << i << ".jpg";
                auto fname = buff.str();
                std::ofstream of;
                mkdir(stream_id.c_str(), 0755);
                of.open(fname);
                std::vector<unsigned char> im_data;
                cv::imencode(".jpg", *(image->sframe->getMat()), im_data);
                of.write((const char *)im_data.data(), im_data.size());
                LOG(INFO) << "==>pic result " << fname << "," << of.is_open() << "," << of.tellp();
                of.close();
            }
        }

        return retv;
    };
    retv.push_back(action);
    return retv;
}

//
// ViolationCrowdFactory
//
ViolationCrowdFactory::ViolationCrowdFactory(const std::string &id, const std::string &cfg)
    : IViolationFactory(), id_(id), cfg_(std::make_shared<ViolationMassiveflowCommonConfig>(cfg))
{
}

const std::string &ViolationCrowdFactory::id() const
{
    return id_;
}

spIViolation ViolationCrowdFactory::CreateIViolation(const BoxF &obj)
{
    if (obj.label == -1)
    {
        return std::make_shared<ViolationCrowd>(obj.uid, id_, cfg_);
    }
    else
    {
        return nullptr;
    }
}

REGISTER_VIOLATION(FLOW_CROWD_REGION_EXCEED_CODE, Crowd);
REGISTER_VIOLATION(BUILDING_CROWD_REGION_EXCEED_CODE, Crowd);
} // namespace FLOW
