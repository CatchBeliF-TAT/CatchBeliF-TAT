#ifndef VSS_VIOLATION_FLOW_TIMER_HPP
#define VSS_VIOLATION_FLOW_TIMER_HPP

#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"


namespace FLOW {

 class ViolationTimerFactory : public IViolationFactory
 {
    public:
        ViolationTimerFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationTimerFactory()=default;

    public:
        virtual const std::string& id()const;
        virtual spIViolation CreateIViolation(const BoxF& obj);

    protected:
        std::string                                 id_;
        spViolationMassiveflowCommonConfig          cfg_;
 };

} // namespace FLOW
#endif