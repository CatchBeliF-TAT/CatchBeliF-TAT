//
// Created by wuzhenzhou on 2019-12-11.
//
#include <math.h>
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "serving/violation_config.pb.h"
#include "violation_flow_common.hpp"
namespace FLOW {

    ViolationMassiveflowCommonConfig::ViolationMassiveflowCommonConfig(const std::string& json)
    {
        auto result = this->ParseJson(json);
        CHECK(result);
    }

    bool ViolationMassiveflowCommonConfig::ParseJson(const std::string& json) {
        std::string err;
        data_ = std::make_shared<inference::MassiveflowViolationConfig>();
        json2pb(json, data_.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< json;
            return false;
        }
        return true;
    }
    
    //为布控线向量标出人流检测方向
    std::vector<int> calculateTheArrowForDeployLine(int x1, int y1, int x2, int y2){

        int x_ini = (int)(x1 + x2) / 2;
        int y_ini = (int)(y1 + y2) / 2;

        //布控线归一化向量
        float x_o_d = x2 - x1;
        float y_o_d = y2 - y1;
        float norm_o_d = sqrt(x_o_d * x_o_d + y_o_d * y_o_d) > 0 ? sqrt(x_o_d * x_o_d + y_o_d * y_o_d) : 1;
        x_o_d = x_o_d / norm_o_d;
        y_o_d = y_o_d / norm_o_d;

        //人流方向向量是布控线向量逆时针旋转90度
        /*
        * 按照和前端布控的约定，人流方向是布控线向量逆时针旋转90度，
        * 但由于opencv中图像坐标系的关系，实际坐标需要按照顺时针90度旋转来计算
        */
        float x_v_d = y_o_d;
        float y_v_d = -x_o_d;

        //采集箭头的四个点的坐标
        std::vector<int> coordinate_4p;
        coordinate_4p.push_back(x_ini);//箭头根部坐标
        coordinate_4p.push_back(y_ini);
        float scale1 = 80;
        float scale2 = 30;
        int x_dst = int(x_ini + x_v_d * scale1);
        int y_dst = int(y_ini + y_v_d * scale1);
        coordinate_4p.push_back(x_dst);
        coordinate_4p.push_back(y_dst);//箭头顶点坐标

        //人流方向向量旋转正负135度，作为箭头的两根短线
        float x_arrow_d, y_arrow_d;
        x_arrow_d = (-x_v_d) * 0.7071 - (-y_v_d) * 0.7071;
        y_arrow_d = (-x_v_d) * 0.7071 + (-y_v_d) * 0.7071;
        coordinate_4p.push_back(int(x_dst + scale2 * x_arrow_d));
        coordinate_4p.push_back(int(y_dst + scale2 * y_arrow_d));
        x_arrow_d = (-x_v_d) * 0.7071 + (-y_v_d) * 0.7071;
        y_arrow_d = -(-x_v_d) * 0.7071 + (-y_v_d) * 0.7071;
        coordinate_4p.push_back(int(x_dst + scale2 * x_arrow_d));
        coordinate_4p.push_back(int(y_dst + scale2 * y_arrow_d));

        return coordinate_4p;
    }

} // namespace FLOW

