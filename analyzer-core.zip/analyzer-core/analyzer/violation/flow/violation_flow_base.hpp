#ifndef VSS_VIOLATION_FLOW_BASE_HPP
#define VSS_VIOLATION_FLOW_BASE_HPP

#include <memory>
#include <chrono>
#include <vector>

#include "serving/violation_config.pb.h"
#include "violation/violation_interface.hpp"
#include "violation/violation_registry.hpp"
#include "violation_flow_code.hpp"
#include "violation/conditions/time_condition.hpp"

namespace FLOW {

typedef std::shared_ptr<inference::MassiveflowViolationConfig> spMassiveflowViolationConfig;
typedef std::pair<int, int> period;
class ViolationFlowBase : public IViolation, public std::enable_shared_from_this<ViolationFlowBase>
{
public:
    ViolationFlowBase(int object_id, const std::string& violation_id, const spMassiveflowViolationConfig& violation_cfg)
        : snapshots_()
        , object_id_(object_id)
        , violation_id_(violation_id)
        , mf_violation_cfg_(violation_cfg)
        , is_violation_(false)
        , time_condition_map_(CreateTimeConditionMap(*mf_violation_cfg_))
    {
        /*
        for(int i=0; i<mf_violation_cfg_->times_size(); i++){
            int day = mf_violation_cfg_->times(i).day();
            if(day>7 || day<1){
                continue;
            }
            if(mf_violation_cfg_->times(i).time_size()%2 != 0){
                continue;
            }
            for(int i=0; i<mf_violation_cfg_->times(i).time_size(); i+=2){
                time_periods[day].push_back(period(mf_violation_cfg_->times(i).time(i), mf_violation_cfg_->times(i).time(i+1)));
            }
        }*/
    }

    virtual ~ViolationFlowBase()=default;

public:
    virtual const std::string&  id()const { return violation_id_; }
    virtual result_list_t       check(BoxF& box, const ImageObjectsInfo& objs)=0;


protected:
    typedef std::shared_ptr<ImageObjectsInfo> spImageObjectsInfo;
    typedef std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds> sys_milliseconds;
    struct ViolationSnapshot{
        BoxF                box;
        spImageObjectsInfo  image;
        sys_milliseconds    now;
    };

protected:
    virtual size_t          add_snapshot(const BoxF& box, const ImageObjectsInfo& objs) { 
                                const auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
                                snapshots_.push_back(ViolationSnapshot{box, std::make_shared<ImageObjectsInfo>(objs), now});
                                return snapshots_.size();
                            }
    virtual void            clear_snapshot() { snapshots_.clear(); }

    /*
    virtual bool  check_time_valid(){
        
        if(mf_violation_cfg_->times_size()==0){
            //没配置时间段默认valid
            return true;
        }
        std::chrono::time_point<std::chrono::system_clock> now = std::chrono::system_clock::now();
        auto tt = std::chrono::system_clock::to_time_t(now);
        auto ptm = std::localtime(&tt);
    
        int time = 100*ptm->tm_hour+ptm->tm_min;
        for(auto time_period: time_periods[ptm->tm_wday]){
            if(time>=time_period.first && time<=time_period.second){
                return true;
            }
        }
        return false;
    }*/

    virtual bool  check_time_valid(){
        auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
        if(time_condition_map_.empty()){
            return true;
        }
        for(auto time_condition: time_condition_map_){
            if(time_condition.second.TimeMatch(now)){
                return true;
            }
        }
        return false;
    }
protected:
    const int                             object_id_;
    const std::string                     violation_id_;
    const spMassiveflowViolationConfig    mf_violation_cfg_;
    std::vector<ViolationSnapshot>        snapshots_;
    bool                                  is_violation_;
    //std::vector<period>                 time_periods[7];//一星期内每天的生效时间段
    TimeConditionMap                      time_condition_map_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_FLOW_BASE_HPP
