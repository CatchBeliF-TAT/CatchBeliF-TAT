//
// Created by wuzhenzhou on 2020-01-06.
//

#include <iterator>
#include <string>
#include <fstream>
#include <time.h>
#include <stdlib.h>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation_flow_base.hpp"
#include "violation_retrograde.hpp"
#include "head_line/headline.hpp"

namespace FLOW
{

using namespace std;

//
// ViolationRetrograde
//
class ViolationRetrograde : public ViolationFlowBase
{
public:
    ViolationRetrograde(int object_id, const std::string &violation_id, const spViolationMassiveflowCommonConfig cfg);
    virtual ~ViolationRetrograde() = default;

public:
    virtual result_list_t check(BoxF &box, const ImageObjectsInfo &objs);
    virtual result_list_t get_results() const;
    void log_info(const ImageObjectsInfo &objs) const;
    result_list_t try_get_alarm(const ImageObjectsInfo &objs);

protected:
    const spViolationMassiveflowCommonConfig cfg_;
    VecBoxF pre_data_;
    bool is_violation_;
    time_t last_report_time_;
    VecBoxF in_persons_;
    vector<vector<int>> rois_;
	vector< vector<int> > arrows_;

    vector<vector<int>> crossinglines;
    Headline::CrossingLine crossingline_;
};

ViolationRetrograde::ViolationRetrograde(int object_id, const std::string &violation_id, const spViolationMassiveflowCommonConfig cfg)
    : ViolationFlowBase(object_id, violation_id, cfg->data_), cfg_(cfg), pre_data_(), is_violation_(false), last_report_time_(0)

{
    LOG(INFO) << "retrograde violation init... ";

    for (int i = 0; i < cfg_->data_->lines_size(); i++)
    {
        vector<int> tmp;
        for (int j = 0; j < cfg_->data_->lines(i).line_size(); j++)
        {
            tmp.push_back(cfg_->data_->lines(i).line(j));
        }

        if (tmp.size() != 4)
        {
            LOG(ERROR) << "invalid line point num";
            continue;
        }
        crossinglines.push_back(tmp);
    }

    for (int i = 0; i < cfg_->data_->roi_size(); i++)
    {
        vector<int> tmp;
        for (int j = 0; j < cfg_->data_->roi(i).data_size(); j++)
        {
            tmp.push_back(int(cfg_->data_->roi(i).data(j)));
        }
        rois_.push_back(tmp);
    }

    //set arrow
    // vector<vector<int>> arrows;
    int pix_len = 200;

    for (int i = 0; i < crossinglines.size(); i++)
    {        
        auto arrow = calculateTheArrowForDeployLine(crossinglines[i][0], crossinglines[i][1], crossinglines[i][2], crossinglines[i][3]);
        arrows_.push_back(arrow);
    }

    crossingline_.Init(crossinglines);
} // namespace FLOW

result_list_t ViolationRetrograde::check(BoxF &box, const ImageObjectsInfo &objs)
{
    result_list_t retv;
    //log_info(objs);
    if(!check_time_valid()){
        return retv;
    }
    crossingline_.Update(objs);

    auto &retrogradeinfo = objs.flow_info.retrogradeinfo_;
    retrogradeinfo.rois_ = rois_;
    retrogradeinfo.persons_ = crossingline_.in_persons;
    // set arrows
    retrogradeinfo.arrows_ = arrows_;
    retrogradeinfo.lines_ = crossinglines;

    if (crossingline_.in_persons.size() == 0)
    {
        return retv;
    }
    in_persons_ = crossingline_.in_persons;

    time_t now;
    time(&now);

    if ((now - last_report_time_) > cfg_->data_->cooling_second())
    {
        retv = try_get_alarm(objs);
        last_report_time_ = now;
    }
    else
    {
        LOG(INFO) << "time is not up , skip";
    }

    return retv;
}

void ViolationRetrograde::log_info(const ImageObjectsInfo &objs) const
{
    LOG(INFO) << "==> violation_id: " << this->violation_id_
              << ", stream_id: " << objs.channel_id;
}

result_list_t ViolationRetrograde::try_get_alarm(const ImageObjectsInfo &objs)
{
    this->clear_snapshot();
    this->add_snapshot(BoxF(), objs);

    return get_results();
}

result_list_t ViolationRetrograde::get_results() const
{
    result_list_t retv;

    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = mf_violation_cfg_->code();
    const auto violation_name = mf_violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;
    const auto enable_output_picture = mf_violation_cfg_->enable_output_picture();
    const auto enable_save_picture = mf_violation_cfg_->enable_save_debug_picture();
    const auto in_persons = in_persons_;

    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event = *retv;
        event.set_event_type(EventTypeMassiveflow);

        auto *mass_event = event.mutable_massive_flow_event();
        mass_event->set_stream_id(stream_id);
        mass_event->set_task_id(stream_id);
        mass_event->set_event_type(atoi(violation_code.c_str()));
        mass_event->set_roi_num(in_persons.size());

        for (int si = 0; si < snapshots.size(); si++)
        {
            auto &image = snapshots[si].image;
            auto snap1 = mass_event->add_snapshots();
            snap1->set_now(snapshots[si].now.time_since_epoch().count());
            if (enable_output_picture)
            {
                snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
                for (auto iter1 = in_persons.begin(); iter1 != in_persons.end(); iter1++)
                {
                    auto obj1 = snap1->add_objects();
                    obj1->add_box((*iter1).xmin);
                    obj1->add_box((*iter1).ymin);
                    obj1->add_box((*iter1).xmax);
                    obj1->add_box((*iter1).ymax);
                }
            }

            if (enable_save_picture)
            {
                std::stringstream buff;
                buff << stream_id << "/pic_" << violation_id << "_"
                     << "_" << si << ".jpg";
                auto fname = buff.str();
                std::ofstream of;
                mkdir(stream_id.c_str(), 0755);
                of.open(fname);
                std::vector<unsigned char> im_data;
                cv::imencode(".jpg", *(image->sframe->getMat()), im_data);
                of.write((const char *)im_data.data(), im_data.size());
                LOG(INFO) << "==>pic result " << fname << "," << of.is_open() << "," << of.tellp();
                of.close();
            }
        }

        return retv;
    };
    retv.push_back(action);

    return retv;
}

//
// ViolationRetrogradeFactory
//
ViolationRetrogradeFactory::ViolationRetrogradeFactory(const std::string &id, const std::string &cfg)
    : IViolationFactory(), id_(id), cfg_(std::make_shared<ViolationMassiveflowCommonConfig>(cfg))
{
}

const std::string &ViolationRetrogradeFactory::id() const
{
    return id_;
}

spIViolation ViolationRetrogradeFactory::CreateIViolation(const BoxF &obj)
{

    if (obj.uid == -1)
    {
        return std::make_shared<ViolationRetrograde>(obj.uid, id_, cfg_);
    }
    else
    {
        return nullptr;
    }
}

REGISTER_VIOLATION(FLOW_RETROGRADE_CODE, Retrograde);

} // namespace FLOW
