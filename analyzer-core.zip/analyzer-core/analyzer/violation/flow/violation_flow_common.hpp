//
// Created by wuzhenzhou on 2019-12-11.
//

#ifndef VIOLATION_FLOW_COMMON_HPP
#define VIOLATION_FLOW_COMMON_HPP

#include <string>

namespace FLOW {

    class ViolationMassiveflowCommonConfig {
    public:
        ViolationMassiveflowCommonConfig(const std::string& json);
        bool ParseJson(const std::string& json);

    public:
        std::shared_ptr<inference::MassiveflowViolationConfig> data_;
    };
    typedef std::shared_ptr<ViolationMassiveflowCommonConfig> spViolationMassiveflowCommonConfig;

    std::vector<int> calculateTheArrowForDeployLine(int x1, int y1, int x2, int y2);//为布控线向量标出人流检测方向

} // namespace FLOW

#endif //VIOLATION_FLOW_COMMON_HPP

