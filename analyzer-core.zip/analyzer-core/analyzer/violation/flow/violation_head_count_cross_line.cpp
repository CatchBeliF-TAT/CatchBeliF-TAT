//
// Created by wuzhenzhou on 2019-12-18.
//

#include <numeric>
#include <iterator>
#include <fstream>
#include <string>
#include <time.h>
#include <stdlib.h>
#include <algorithm>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation_flow_base.hpp"
#include "violation_head_count_cross_line.hpp"
#include "head_line/headline.hpp"

namespace FLOW
{

class ViolationHeadCount : public ViolationFlowBase
{
public:
    ViolationHeadCount(int object_id, const std::string &violation_id, const spViolationMassiveflowCommonConfig cfg);
    virtual ~ViolationHeadCount() = default;

public:
    virtual result_list_t check(BoxF &box, const ImageObjectsInfo &objs);
    virtual result_list_t get_results() const;
    result_list_t try_get_alarm(const ImageObjectsInfo &objs);

protected:
    time_t last_report_time_;
    std::vector<int> last_count_arr_;
    std::vector<int> current_count_arr_;

    std::vector<std::vector<int>> crossinglines;
    Headline::CrossingLine crossingline_;
    std::vector<std::vector<int>> arrows;
    std::string reset_time_;
};

ViolationHeadCount::ViolationHeadCount(int object_id, const std::string &violation_id, const spViolationMassiveflowCommonConfig cfg)
    : ViolationFlowBase(object_id, violation_id, cfg->data_)
{
    time(&last_report_time_);
    
    {
        struct tm stm;
        localtime_r(&last_report_time_, &stm);
        char time_str[18];
        if ( strftime(time_str, sizeof(time_str), "%Y%m%d %H:%M:%S", &stm) == 0 ) {
            LOG(FATAL) << " get time fail ";
        }
        time_str[17] = '\0';
        reset_time_ = time_str;
    }
        
    for (int i = 0; i < mf_violation_cfg_->lines_size(); i++){
        std::vector<int> tmp;
        for (int j = 0; j < mf_violation_cfg_->lines(i).line_size(); j++){
            tmp.push_back(mf_violation_cfg_->lines(i).line(j));
        }
        if (tmp.size() != 4){
            LOG(ERROR) << "invalid line point num";
            continue;
        }
        crossinglines.push_back(tmp);
    }
    // make arrow
    int line_num = crossinglines.size();
    for (int i = 0; i < line_num; i++){
        auto arrow = calculateTheArrowForDeployLine(crossinglines[i][0], crossinglines[i][1], crossinglines[i][2], crossinglines[i][3]);
        arrows.push_back(arrow);
    }

    crossingline_.Init(crossinglines);
}

class ICAlgEngine;

result_list_t ViolationHeadCount::check(BoxF &box, const ImageObjectsInfo &objs)
{
    result_list_t retv;
    crossingline_.Update(objs);
    if(!check_time_valid()){
        return retv;
    }
    time_t now;
    time(&now);
    
    auto &headcountinfo = objs.flow_info.headcountinfo_;
    headcountinfo.DrawHeadLines_ = crossinglines;
    headcountinfo.arrows_ = arrows;
    headcountinfo.head_count_.assign(crossingline_.res_human_count.begin(), crossingline_.res_human_count.end());
    headcountinfo.in_persons_ = crossingline_.in_persons;
    headcountinfo.out_persons_ = crossingline_.out_persons;
    headcountinfo.inHeadTrace_ = crossingline_.inHeadTrace;
    headcountinfo.outHeadTrace_ = crossingline_.outHeadTrace;

    if ( mf_violation_cfg_->resetplan().has_on() &&
        mf_violation_cfg_->resetplan().on() ) {
        std::vector<int> reset_day;
        auto reset_type = mf_violation_cfg_->resetplan().resettype();
        if ( "day" == reset_type) {
            reset_day = {0,1,2,3,4,5,6};
        } else if ( "week" == reset_type ) {
            reset_day = std::vector<int> (mf_violation_cfg_->resetplan().weekdays().begin(),mf_violation_cfg_->resetplan().weekdays().end());
        }
        int wday = 0;
        std::string hms_time;
        {
            struct tm stm;
            localtime_r(&now, &stm);
            wday = stm.tm_wday;
            char time_str[18];
            if ( strftime(time_str, sizeof(time_str), "%Y%m%d %H:%M:%S", &stm) == 0 ) {
                LOG(FATAL) << " get time fail ";
            }
            time_str[17] = '\0';
            hms_time = time_str;
        }
        auto it = find(reset_day.begin(), reset_day.end(), wday);
        if ( it != reset_day.end() ) {
            if ( mf_violation_cfg_->resetplan().has_resettime() &&
                    hms_time.substr(9) ==  mf_violation_cfg_->resetplan().resettime()) {
                LOG(INFO) << "flow head count reset at " << hms_time;
                //std::vector<int> tmp_vec = std::vector<int>();
                fill(last_count_arr_.begin(), last_count_arr_.end(), 0);
                fill(headcountinfo.head_count_.begin(), headcountinfo.head_count_.end(), 0);
                reset_time_ = hms_time;
                fill(crossingline_.res_human_count.begin(), crossingline_.res_human_count.end(), 0);
            }
        }
    }

    headcountinfo.startCountTime_ = reset_time_;
    
    if (mf_violation_cfg_->code() == FLOW_HEADCOUNT_CODE){

        if (now - last_report_time_ >= mf_violation_cfg_->report_span()&& mf_violation_cfg_->report_span()>0){
            current_count_arr_.assign(crossingline_.res_human_count.begin(), crossingline_.res_human_count.end());
            while (last_count_arr_.size() < current_count_arr_.size()){ //第一个report_span两个数组size不等
                last_count_arr_.push_back(0);
            }
            retv = try_get_alarm(objs);
            last_count_arr_.swap(current_count_arr_);
            last_report_time_ = now;
        }
    }else if(mf_violation_cfg_->code() == FLOW_CROSS_LINE_CODE){
        if(crossingline_.intersect_persons.size()!=0){
            if(now - last_report_time_ >= mf_violation_cfg_->cooling_second()){
                retv = try_get_alarm(objs);
                last_report_time_ = now;
            }
        }
    }
    return retv;
}

result_list_t ViolationHeadCount::try_get_alarm(const ImageObjectsInfo &objs)
{
    this->clear_snapshot();
    this->add_snapshot(BoxF(), objs);
    return get_results();
}

result_list_t ViolationHeadCount::get_results() const
{
    result_list_t retv;

    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = mf_violation_cfg_->code();
    const auto violation_name = mf_violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;
    const auto enable_output_picture = mf_violation_cfg_->enable_output_picture();
    const auto enable_save_picture = mf_violation_cfg_->enable_save_debug_picture();
    const auto valid_boxes = crossingline_.intersect_persons;

    if (mf_violation_cfg_->code() == FLOW_HEADCOUNT_CODE){
        for (int i = 0; i < current_count_arr_.size() / 2; i++){
            //  先出后进
            const auto violation_id = violation_id_;
            int out_num = current_count_arr_[2 * i] - last_count_arr_[2 * i];
            int in_num = current_count_arr_[2 * i + 1] - last_count_arr_[2 * i + 1];

            LOG(INFO) << "out num: " << out_num << " ,in num:" << in_num;

            std::vector<int> line;
            for (int j = 0; j < mf_violation_cfg_->lines(i).line_size(); j++)
            {
                line.push_back(mf_violation_cfg_->lines(i).line(j));
            }
            auto action = [=](ICAlgEngine* engine) -> spEventProto {
                auto retv = std::make_shared<inference::Event>();
                inference::Event& event = *retv;
                event.set_event_type(EventTypeMassiveflowCount);

                auto *mass_event = event.mutable_count_event();
                mass_event->set_task_id(stream_id);
                mass_event->set_event_type(atoi(violation_code.c_str()));
                mass_event->set_in_count(abs(in_num));
                mass_event->set_out_count(abs(out_num));
                mass_event->set_violation_id(violation_id);

                for (int j = 0; j < line.size(); j++)
                {
                    mass_event->add_line_points(line[j]);
                }

                for (int si = 0; si < snapshots.size(); si++)
                {
                    auto &image = snapshots[si].image;
                    auto snap1 = mass_event->add_snapshots();
                    snap1->set_now(snapshots[si].now.time_since_epoch().count());
                    //定时上报类的事件上报现在不要图片了
                    //if (enable_output_picture){ //todo
                    //    snap1->set_image(Helper::get_pic(*(image->img_ptr)));
                    //}

                    if (enable_save_picture){
                        std::stringstream buff;
                        buff << stream_id << "/pic_" << violation_id << "_"
                            << "_" << si << ".jpg";
                        auto fname = buff.str();
                        std::ofstream of;
                        mkdir(stream_id.c_str(), 0755);
                        of.open(fname);
                        std::vector<unsigned char> im_data;
                        cv::imencode(".jpg", *(image->sframe->getMat()), im_data);
                        of.write((const char *)im_data.data(), im_data.size());
                        LOG(INFO) << "==>pic result " << fname << "," << of.is_open() << "," << of.tellp();
                        of.close();
                    }
                }

                return retv;
            };
            retv.push_back(action);
        }
    }else if(mf_violation_cfg_->code() == FLOW_CROSS_LINE_CODE){
            auto action = [=](ICAlgEngine* engine) -> spEventProto {
                auto retv = std::make_shared<inference::Event>();
                inference::Event& event = *retv;
                event.set_event_type(EventTypeMassiveflow);

                auto *mass_event = event.mutable_massive_flow_event();
                mass_event->set_task_id(stream_id);
                mass_event->set_event_type(atoi(violation_code.c_str()));

                for (int si = 0; si < snapshots.size(); si++)
                {
                    auto &image = snapshots[si].image;
                    auto snap1 = mass_event->add_snapshots();
                    snap1->set_now(snapshots[si].now.time_since_epoch().count());

                    if (enable_output_picture){ //todo
                        snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
                        for(auto iter1=valid_boxes.begin() ;iter1!= valid_boxes.end();iter1++){
                            auto obj1 = snap1->add_objects();
                            obj1->add_box((*iter1).xmin);
                            obj1->add_box((*iter1).ymin);
                            obj1->add_box((*iter1).xmax);
                            obj1->add_box((*iter1).ymax);
                        }
                    }

                    if (enable_save_picture){
                        std::stringstream buff;
                        buff << stream_id << "/pic_" << violation_id << "_"
                            << "_" << si << ".jpg";
                        auto fname = buff.str();
                        std::ofstream of;
                        mkdir(stream_id.c_str(), 0755);
                        of.open(fname);
                        std::vector<unsigned char> im_data;
                        cv::imencode(".jpg", *(image->sframe->getMat()), im_data);
                        of.write((const char *)im_data.data(), im_data.size());
                        LOG(INFO) << "==>pic result " << fname << "," << of.is_open() << "," << of.tellp();
                        of.close();
                    }
                }

                return retv;
            };
            retv.push_back(action);
    }
    return retv;
}

//
// ViolationHeadCountFactory
//
ViolationHeadCountFactory::ViolationHeadCountFactory(const std::string &id, const std::string &cfg)
    : IViolationFactory(), id_(id), cfg_(std::make_shared<ViolationMassiveflowCommonConfig>(cfg))
{
}

const std::string &ViolationHeadCountFactory::id() const
{
    return id_;
}

spIViolation ViolationHeadCountFactory::CreateIViolation(const BoxF &obj)
{

    if (obj.uid == -1)
    {
        return std::make_shared<ViolationHeadCount>(obj.uid, id_, cfg_);
    }
    else
    {
        return nullptr;
    }
}

REGISTER_VIOLATION(FLOW_HEADCOUNT_CODE, HeadCount);
REGISTER_VIOLATION(FLOW_CROSS_LINE_CODE, HeadCount);

} // namespace FLOW
