//
// Created by qiushuang on 2020-12-03.
//

	
#include <numeric>
#include <string>
#include <iterator>
#include <fstream>
#include <time.h>
#include <stdlib.h>
#include <list>
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation_flow_base.hpp"
#include "violation_wander_retention.hpp"
#include "violation/violation_util.hpp"


namespace FLOW {
//
// ViolationWanderRetention
//
    class ViolationWanderRetention : public ViolationFlowBase
    {
    public:
        ViolationWanderRetention(int object_id, const std::string& violation_id, const spViolationMassiveflowCommonConfig cfg);
        virtual ~ViolationWanderRetention()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
        virtual result_list_t get_results() const;
        void                  log_info(const ImageObjectsInfo& objs) const;
        // result_list_t         try_get_alarm(const ImageObjectsInfo& objs);

        std::vector<VecPointF> validRois;
        // std::vector<std::vector<float> > removeRois;

    protected:
        const spViolationMassiveflowCommonConfig     cfg_;
        VecBoxF                                 pre_data_;
        VecBoxF                                 objects_vec_; //检测目标
        time_t                                  last_report_time_;
    private:
        //std::vector<VecInt> person_id_buffer_list;
        std::list<std::pair<time_t, VecInt>> person_id_buffer_list;
        int wander_retention_buffer_time;
        int wander_retention_report_time;
    };

    ViolationWanderRetention::ViolationWanderRetention(int object_id, const std::string& violation_id, const spViolationMassiveflowCommonConfig cfg)
            : ViolationFlowBase(object_id, violation_id, cfg->data_)
            , cfg_(cfg)
            , pre_data_()
            , last_report_time_(0)
    {
        LOG(INFO) << "wander retention violation registered" ;
        wander_retention_buffer_time = cfg_->data_->wander_retention_buffer_time();
        wander_retention_report_time = cfg_->data_->wander_retention_report_time();
        for (int i = 0; i < cfg_->data_->roi_size(); i++){
            VecPointF tmp;
            for (int j = 0; j < cfg_->data_->roi(i).data_size(); )
            {
                PointF point;
                point.x = cfg_->data_->roi(i).data(j);
                point.y = cfg_->data_->roi(i).data(j+1);//j+1要是正好等于data_size应该就崩掉
                tmp.push_back(point);
                j += 2;
            }
            validRois.push_back(tmp);
        }
    }

class ICAlgEngine;

    std::set<int> is_wander_occur(std::list<std::pair<time_t, VecInt>> person_id_buffer_list, int threshold) {
        std::map<int, int> person_id_map;
        std::set<int> wander_ids;
        int max = 0;
        for (auto person_ids : person_id_buffer_list) {
            for (auto person_id : person_ids.second) {
                if (person_id == 0) {
                    continue;
                }
                if (person_id_map.find(person_id) == person_id_map.end()) {
                    person_id_map[person_id] = 1;
                } else {
                    person_id_map[person_id]++;
                    if (person_id_map[person_id] > threshold) {
                        wander_ids.insert(person_id);
                    }
                }
            }
        }
        return wander_ids;
    }

    result_list_t ViolationWanderRetention::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        //log_info(objs);
        //LOG(INFO) << "wander retention check" ;
        if(!check_time_valid()){
            result_list_t retv;
            return retv;
        }
        std::pair<time_t, VecInt> person_id_buffer;

        person_id_buffer.first = std::time(NULL);

        for (const auto& retention_box : objs.flow_info.retentioninfo_.retentionobjects_) {
            for(const auto tmp_point : validRois) {
                if (!interior_polygon(retention_box, tmp_point)){
                    //box not in this roi, process next roi
                    continue;
                }else{
                    //box in the roi, process next box
                    person_id_buffer.second.push_back(retention_box.uid);
                    break;
                }
            }
        }
        person_id_buffer_list.push_back(person_id_buffer);

        VecBoxF wander_retention_vecs_valid;

        // int FPS = 5;

        if(person_id_buffer.first - person_id_buffer_list.front().first < wander_retention_buffer_time){
            //未达到buffer time
            result_list_t retv;
            return retv;
        }else{
            //超过buffer time的帧删去
            while(!person_id_buffer_list.empty()){
                if(person_id_buffer.first - person_id_buffer_list.front().first > wander_retention_buffer_time){
                    person_id_buffer_list.pop_front();
                }else{
                    //遇到第一个未超出范围的帧，跳出循环
                    break;
                }
            }
        }

        //Mat_Ptr img_ptr = objs.img_ptr;
        double threshold = (double)wander_retention_report_time/(double)wander_retention_buffer_time * (double)person_id_buffer_list.size();
        auto wander_ids = is_wander_occur(person_id_buffer_list, (int)threshold);
        if (!wander_ids.empty()) {
            for (auto &box : objs.flow_info.retentioninfo_.retentionobjects_) {
                if (box.xmin ==0 && box.xmax ==0 && box.ymin ==0 && box.ymax ==0 ){
                    continue;
                }
                auto i = wander_ids.find(box.uid);
                if(i!=wander_ids.end()){
                    wander_retention_vecs_valid.push_back(box);
                }
            }
            // std::cout << "徘徊滞留报警" << std::endl;
            // for (auto &box : wander_retention_vecs_valid){
            //     cv::rectangle(*img_ptr, cvRect(box.xmin * (*img_ptr).cols, box.ymin * (*img_ptr).rows, (box.xmax-box.xmin)*(*img_ptr).cols, (box.ymax-box.ymin)*(*img_ptr).rows), cv::Scalar( 0, 0, 255 ), 2, 8, 0 );
            // }
            // std::stringstream ssa;
            // ssa << "/home/shanma/Workspace/qiushuang/analyzer-core-qs/analyzer-flow/101-0/snapshot_" <<  objs.count << ".jpg";
            // cv::imwrite(ssa.str(), *img_ptr);
        }

        objects_vec_.clear();
        objects_vec_.assign(wander_retention_vecs_valid.begin(), wander_retention_vecs_valid.end());

        if (objects_vec_.size() > 0){
            time_t now=  std::time(NULL);
            bool skip  = (now-last_report_time_) < cfg_->data_->cooling_second();
            if (!skip){
                last_report_time_ = now;
                this->clear_snapshot();
                this->add_snapshot(BoxF(), objs);
                this->snapshots_.back().image->objects = objects_vec_;
                return get_results();
            }
        }

        result_list_t retv;
        return retv;
    }

    void ViolationWanderRetention::log_info(const ImageObjectsInfo& objs) const{
        LOG(INFO) <<"wander retention ==> violation_id: " << this->violation_id_
                  << ", stream_id: " << objs.channel_id;

    }

    // result_list_t ViolationWanderRetention::try_get_alarm(const ImageObjectsInfo& objs) {

    //     LOG(INFO) << "enter_alarm";

    //     this->clear_snapshot();
    //     this->add_snapshot(BoxF(), objs);
    //     return get_results();
    // }


    result_list_t ViolationWanderRetention::get_results()const{
        result_list_t retv;
        const auto stream_id = snapshots_[0].image->channel_id;
        const auto violation_code = cfg_->data_->code();
        const auto violation_name = cfg_->data_->name();
        const auto violation_id = violation_id_;
        const auto snapshots = snapshots_;
        const auto enable_output_picture = cfg_->data_->enable_output_picture();
        const auto enable_save_picture = cfg_->data_->enable_save_debug_picture();
        // const auto enable_save_picture = true;
        const auto objects_vec = objects_vec_;

        auto action = [=](ICAlgEngine* engine) -> spEventProto {
            auto retv = std::make_shared<inference::Event>();
            inference::Event& event = *retv;
            event.set_event_type(EventTypeMassiveflow);
            inference::MassiveFlowEvent * mass_event = event.mutable_massive_flow_event();
            mass_event->set_stream_id(stream_id);
            mass_event->set_task_id(stream_id);
            mass_event->set_event_type(atoi(violation_code.c_str()));

            LOG(INFO) << "snapshots size : " << snapshots.size();

            for(int i=0;i<snapshots.size();i++){
                auto& image = snapshots[i].image;
                auto snap1 = mass_event->add_snapshots();
                snap1->set_now(snapshots[i].now.time_since_epoch().count());
                if (enable_output_picture){
                    snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
                    for(auto iter1=objects_vec.begin() ;iter1!= objects_vec.end();iter1++){
                        auto obj1 = snap1->add_objects();
                        obj1->add_box((*iter1).xmin);
                        obj1->add_box((*iter1).ymin);
                        obj1->add_box((*iter1).xmax);
                        obj1->add_box((*iter1).ymax);
                    }
                }

                if (enable_save_picture){
                    std::stringstream buff;
                    buff << stream_id <<"/pic_" << violation_id << "_"  <<"_" << i <<".jpg";
                    auto fname = buff.str();
                    std::ofstream of;
                    mkdir(stream_id.c_str(),0755);
                    of.open(fname);
                    std::vector<unsigned char> im_data;
                    cv::imencode(".jpg", *(image->sframe->getMat()), im_data);
                    of.write((const char*)im_data.data(),im_data.size());
                    LOG(INFO)<<"==>pic result "<<fname <<","<<of.is_open()<<","<<of.tellp();
                    of.close();
                }
            }

            return retv;
        };
        retv.push_back(action);
        return retv;
    }

//
// ViolationWanderRetentionFactory
//
    ViolationWanderRetentionFactory::ViolationWanderRetentionFactory(const std::string& id, const std::string& cfg)
            : IViolationFactory()
            , id_(id)
            , cfg_(std::make_shared<ViolationMassiveflowCommonConfig>(cfg))
    {
    }

    const std::string& ViolationWanderRetentionFactory::id()const
    {
        return id_;
    }

    spIViolation ViolationWanderRetentionFactory::CreateIViolation(const BoxF& obj)
    {
        if (obj.uid == -1){
            return std::make_shared<ViolationWanderRetention>(obj.uid, id_, cfg_);
        }
        else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(FLOW_RETENTION_CODE, WanderRetention);

} // namespace FLOW

