//
// Created by wuzhenzhou on 2019-12-18.
//

#ifndef ANALYZER_FLOW_VIOLATION_HEAD_COUNT_HPP
#define ANALYZER_FLOW_VIOLATION_HEAD_COUNT_HPP

#include <vector>
#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"

namespace FLOW {

    class ViolationHeadCountFactory : public IViolationFactory
    {
    public:
        ViolationHeadCountFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationHeadCountFactory()=default;

    public:
        virtual const std::string&  id()const;
        virtual spIViolation        CreateIViolation(const BoxF& obj);

    protected:
        std::string                             id_;
        spViolationMassiveflowCommonConfig      cfg_;
    };

} // namespace FLOW



#endif //ANALYZER_FLOW_VIOLATION_HEAD_COUNT_HPP

