//
// Created by wuzhenzhou on 2019-12-18.
//

#ifndef ANALYZER_FLOW_VIOLATION_CROWD_HPP
#define ANALYZER_FLOW_VIOLATION_CROWD_HPP



#include <vector>
#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"
// #include "crowd/crowdregion.hpp"

namespace FLOW {

    class ViolationCrowdFactory : public IViolationFactory
    {
    public:
        ViolationCrowdFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationCrowdFactory()=default;

    public:
        virtual const std::string&  id()const;
        virtual spIViolation        CreateIViolation(const BoxF& obj);

    protected:
        std::string                             id_;
        spViolationMassiveflowCommonConfig      cfg_;

    };

} // namespace FLOW


#endif //ANALYZER_FLOW_VIOLATION_CROWD_HPP

