#include <unordered_map>
#include <memory>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_event.pb.h"
#include "violation_flow_base.hpp"
#include "violation_heartbeat.hpp"

namespace FLOW {

    using namespace std;

    class ViolationHeartBeat : public ViolationFlowBase
    {
    public:
        ViolationHeartBeat(int object_id, const std::string& violation_id, const spViolationMassiveflowCommonConfig cfg)
                : ViolationFlowBase(object_id, violation_id, cfg->data_)
                , cfg_(cfg){
            std::string heartbeat_time = cfg->data_->heartbeat_time();
            std::regex split_douhao(",");
            std::regex split_maohao(":");
            std::vector<std::string> times(std::sregex_token_iterator(heartbeat_time.begin(), heartbeat_time.end(), split_douhao, -1),
                                        std::sregex_token_iterator());
            for(auto& time: times){
                int hour, min;
                std::vector<std::string> hour_and_min(std::sregex_token_iterator(time.begin(), time.end(), split_maohao, -1),
                                            std::sregex_token_iterator());
                if(hour_and_min.size()!=2){
                    LOG(ERROR) << "Parse time: hour_and_min.size()!=2 ";
                    continue;
                }
                hour_and_min[0].erase(0, hour_and_min[0].find_first_not_of("0"));
                hour_and_min[1].erase(0, hour_and_min[1].find_first_not_of("0"));
                //考虑00和0的情况
                if(hour_and_min[0]==""){
                    hour_and_min[0] = "0";
                }
                if(hour_and_min[1]==""){
                    hour_and_min[1] = "0";
                }

                try {
                    hour = std::stoi(hour_and_min[0]);
                }
                catch (std::invalid_argument&){
                    // If no conversion could be performed, an invalid_argument exception is thrown.
                    LOG(ERROR)<< "Parse Hour: Invalid_argument";
                    continue;
                }
                catch (std::out_of_range&){
                    // If the value read is out of the range of representable values by an int, an out_of_range exception is thrown.
                    LOG(ERROR) << "Parse Hour: Out of range";
                    continue;
                }
                catch (...) {
                    // everything else
                    LOG(ERROR)<< "Parse Hour: Something else";
                    continue;
                }

                try {
                    min = std::stoi(hour_and_min[1]);
                }
                catch (std::invalid_argument&){
                    // If no conversion could be performed, an invalid_argument exception is thrown.
                    LOG(ERROR)<< "Parse Min: Invalid_argument";
                    continue;
                }
                catch (std::out_of_range&){
                    // If the value read is out of the range of representable values by an int, an out_of_range exception is thrown.
                    LOG(ERROR) << "Parse Min: Out of range";
                    continue;
                }
                catch (...) {
                    // everything else
                    LOG(ERROR)<< "Parse Min: Something else";
                    continue;
                }
                LOG(INFO)<<"time: "<<hour<<":"<<min;
                time_to_report.push_back(std::pair<int, int>(hour, min));
            }
    
        }

        virtual ~ViolationHeartBeat()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
        virtual result_list_t get_results() const;
        result_list_t         try_get_alarm(const ImageObjectsInfo& objs);

    protected:
        const spViolationMassiveflowCommonConfig cfg_;
        int last_report_day_ = 0;
        int last_report_hour_ = 0;
        int last_report_min_ = 0;
        std::vector<std::pair<int, int>> time_to_report;
    };

class ICAlgEngine;

    result_list_t ViolationHeartBeat::get_results()const{
        result_list_t retv;
        const auto stream_id = snapshots_[0].image->channel_id;
        const auto violation_code = cfg_->data_->code();
        const auto violation_id = violation_id_;
        const auto snapshots = snapshots_;
        const auto enable_output_picture = cfg_->data_->enable_output_picture();

        auto action = [=](ICAlgEngine* engine) -> spEventProto{
            auto retv = std::make_shared<inference::Event>();
            inference::Event& event = *retv;

            event.set_event_type(EventTypeMassiveflow);

            inference::MassiveFlowEvent * mass_event = event.mutable_massive_flow_event();
            mass_event->set_stream_id(stream_id);
            mass_event->set_task_id(stream_id);
            mass_event->set_event_type(atoi(violation_code.c_str()));

            for(int i=0;i<snapshots.size();i++){
                auto& image = snapshots[i].image;
                auto snap1 = mass_event->add_snapshots();
                snap1->set_now(snapshots[i].now.time_since_epoch().count());
                if (enable_output_picture){
                    snap1->set_image(Helper::get_pic_base64(*(image->sframe->getMat())));
                }
            }

            //std::string result_json;
            //pb2json(&event, &result_json);
            //LOG(INFO) <<"fight==>json result, violation_id="<<violation_id<<", len(result_json)="<<result_json.size();
            return retv;
        };
        retv.push_back(action);
        return retv;
    }

    result_list_t ViolationHeartBeat::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        if(!check_time_valid()){
            return retv;
        }

        time_t now = std::time(NULL);
        struct tm *p;
        p = localtime(&now);

        for(auto& e:time_to_report){
            if(p->tm_hour==e.first && p->tm_min==e.second){
                if(last_report_day_!=p->tm_mday || last_report_hour_!=p->tm_hour || last_report_min_!=p->tm_min){
                    //report
                    last_report_day_ = p->tm_mday;
                    last_report_hour_ = p->tm_hour;
                    last_report_min_ = p->tm_min;
                    this->clear_snapshot();
                    this->add_snapshot(BoxF(), objs);
                    return get_results();
                }
                break;
            }
        }
        return retv;
    }

    ViolationHeartBeatFactory::ViolationHeartBeatFactory(const std::string& id, const std::string& cfg)
            :IViolationFactory(),
             id_(id),
             cfg_(std::make_shared<ViolationMassiveflowCommonConfig>(cfg)){}

    const std::string& ViolationHeartBeatFactory::id()const
    {
        return id_;
    }

    spIViolation ViolationHeartBeatFactory::CreateIViolation(const BoxF& obj)
    {
        if (obj.label == -1)
        {
            return std::make_shared<ViolationHeartBeat>(obj.uid, id_, cfg_);
        }
        else
        {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(BUILDING_HEARTBEAT_CODE, HeartBeat);

} // namespace FLOW

