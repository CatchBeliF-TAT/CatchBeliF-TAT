//
// Created by wuzhenzhou on 2019-12-18.
//

#include <iterator>
#include <string>
#include <fstream>
#include <time.h>
#include <stdlib.h>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation_flow_base.hpp"
#include "violation_overfence.hpp"
#include "head_line/headline.hpp"

namespace FLOW
{

// static const std::string FLOW_OVERFENCE_CODE("4");
//
// ViolationOverfence
//
class ViolationOverfence : public ViolationFlowBase
{
public:
    ViolationOverfence(int object_id, const std::string &violation_id, const spViolationMassiveflowCommonConfig cfg);
    virtual ~ViolationOverfence() = default;

public:
    virtual result_list_t check(BoxF &box, const ImageObjectsInfo &objs);
    virtual result_list_t get_results() const;
    void log_info(const ImageObjectsInfo &objs) const;
    result_list_t try_get_alarm(const ImageObjectsInfo &objs);

protected:
    const spViolationMassiveflowCommonConfig cfg_;
    time_t last_report_time_;
    VecBoxF intersect_persons_;

    std::vector<std::vector<int>> crossinglines;
    Headline::CrossingLine crossingline_;
};

ViolationOverfence::ViolationOverfence(int object_id, const std::string &violation_id, const spViolationMassiveflowCommonConfig cfg)
    : ViolationFlowBase(object_id, violation_id, cfg->data_), cfg_(cfg), last_report_time_(0)

{
    LOG(INFO) << "overfence violation init... ";

    for (int i = 0; i < cfg_->data_->lines_size(); i++)
    {
        std::vector<int> tmp;
        for (int j = 0; j < cfg_->data_->lines(i).line_size(); j++)
        {
            tmp.push_back(cfg_->data_->lines(i).line(j));
        }

        if (tmp.size() != 4)
        {
            LOG(ERROR) << "invalid line point num";
            continue;
        }

        crossinglines.push_back(tmp);
    }
    crossingline_.Init(crossinglines);
}

result_list_t ViolationOverfence::check(BoxF &box, const ImageObjectsInfo &objs)
{
    result_list_t retv;

    //log_info(objs);

    crossingline_.Update(objs);
    if(!check_time_valid()){
        return retv;
    }
    if (crossingline_.intersect_persons.size() == 0)
    {
        return retv;
    }
    intersect_persons_ = crossingline_.intersect_persons;

    time_t now;
    time(&now);

    if (now - last_report_time_ >= cfg_->data_->cooling_second())
    {

        retv = try_get_alarm(objs);
        last_report_time_ = now;
    }
    else
    {
        LOG(INFO) << "time is not up , skip";
    }

    return retv;
}

void ViolationOverfence::log_info(const ImageObjectsInfo &objs) const
{
    LOG(INFO) << "==> violation_id: " << this->violation_id_
              << ", stream_id: " << objs.channel_id;
}

result_list_t ViolationOverfence::try_get_alarm(const ImageObjectsInfo &objs)
{
    this->clear_snapshot();
    this->add_snapshot(BoxF(), objs);

    return get_results();
}

result_list_t ViolationOverfence::get_results() const
{
    result_list_t retv;

    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = mf_violation_cfg_->code();
    const auto violation_name = mf_violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;
    const auto enable_output_picture = mf_violation_cfg_->enable_output_picture();
    const auto enable_save_picture = mf_violation_cfg_->enable_save_debug_picture();
    const auto intersect_persons = intersect_persons_;

    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event = *retv;
        event.set_event_type(EventTypeMassiveflow);

        auto *mass_event = event.mutable_massive_flow_event();
        mass_event->set_stream_id(stream_id);
        mass_event->set_task_id(stream_id);
        mass_event->set_event_type(atoi(violation_code.c_str()));
        mass_event->set_roi_num(intersect_persons.size());

        for (int si = 0; si < snapshots.size(); si++)
        {
            auto &image = snapshots[si].image;
            auto snap1 = mass_event->add_snapshots();
            snap1->set_now(snapshots[si].now.time_since_epoch().count());
            if (enable_output_picture)
            {
                snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));

                for(auto iter1=intersect_persons.begin() ;iter1!= intersect_persons.end();iter1++){
                    auto obj1 = snap1->add_objects();
                    obj1->add_box((*iter1).xmin);
                    obj1->add_box((*iter1).ymin);
                    obj1->add_box((*iter1).xmax);
                    obj1->add_box((*iter1).ymax);
                }
            }

            if (enable_save_picture)
            {
                std::stringstream buff;
                buff << stream_id << "/pic_" << violation_id << "_"
                     << "_" << si << ".jpg";
                auto fname = buff.str();
                std::ofstream of;
                mkdir(stream_id.c_str(), 0755);
                of.open(fname);
                std::vector<unsigned char> im_data;
                cv::imencode(".jpg", *(image->sframe->getMat()), im_data);
                of.write((const char *)im_data.data(), im_data.size());
                LOG(INFO) << "==>pic result " << fname << "," << of.is_open() << "," << of.tellp();
                of.close();
            }
        }

        return retv;
    };
    retv.push_back(action);

    return retv;
}

//
// ViolationOverfenceFactory
//
ViolationOverfenceFactory::ViolationOverfenceFactory(const std::string &id, const std::string &cfg)
    : IViolationFactory(), id_(id), cfg_(std::make_shared<ViolationMassiveflowCommonConfig>(cfg))
{
}

const std::string &ViolationOverfenceFactory::id() const
{
    return id_;
}

spIViolation ViolationOverfenceFactory::CreateIViolation(const BoxF &obj)
{

    if (obj.uid == -1)
    {
        return std::make_shared<ViolationOverfence>(obj.uid, id_, cfg_);
    }
    else
    {
        return nullptr;
    }
}

REGISTER_VIOLATION(FLOW_OVERFENCE_CODE, Overfence);

} // namespace FLOW

