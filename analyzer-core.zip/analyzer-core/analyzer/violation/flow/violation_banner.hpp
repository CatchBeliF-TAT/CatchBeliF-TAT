//
// Created by wuzhenzhou on 2019-12-11.
//

#ifndef ANALYZER_FLOW_VIOLATION_BANNER_HPP
#define ANALYZER_FLOW_VIOLATION_BANNER_HPP


#include <vector>
#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"

namespace FLOW {

    class ViolationBannerFactory : public IViolationFactory
    {
    public:
        ViolationBannerFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationBannerFactory()=default;

    public:
        virtual const std::string&  id()const;
        virtual spIViolation        CreateIViolation(const BoxF& obj);

    protected:
        std::string                             id_;
        spViolationMassiveflowCommonConfig      cfg_;
    };

} // namespace FLOW

#endif //ANALYZER_FLOW_VIOLATION_BANNER_HPP

