/*
 * @Author: qiushuang
 * @Date: 2020-11-26 15:16:07
 * @LastEditTime: 2020-12-03 15:18:19
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /analyzer-flow/analyzer/violation/flow/violation_wander_retention.hpp
 */
//
// Created by wuzhenzhou on 2019-12-11.
//

#ifndef ANALYZER_FLOW_VIOLATION_WANDER_RETENTION_HPP
#define ANALYZER_FLOW_VIOLATION_WANDER_RETENTION_HPP


#include <vector>
#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"

namespace FLOW {

    class ViolationWanderRetentionFactory : public IViolationFactory
    {
    public:
        ViolationWanderRetentionFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationWanderRetentionFactory()=default;

    public:
        virtual const std::string&  id()const;
        virtual spIViolation        CreateIViolation(const BoxF& obj);

    protected:
        std::string                             id_;
        spViolationMassiveflowCommonConfig      cfg_;
    };


} // namespace FLOW

#endif //ANALYZER_FLOW_VIOLATION_WANDER_RETENTION_HPP

