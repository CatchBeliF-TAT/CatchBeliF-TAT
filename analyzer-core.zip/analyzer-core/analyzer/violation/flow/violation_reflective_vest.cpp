#include <unordered_map>
#include <memory>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_event.pb.h"
#include "violation_flow_base.hpp"
#include "violation_reflective_vest.hpp"
#include "core/alg_engine/alg_reflective_vest_engine.hpp"
namespace FLOW {

    using namespace std;

    class ViolationVest : public ViolationFlowBase
    {
    public:
        ViolationVest(int object_id, const std::string& violation_id, const spViolationMassiveflowCommonConfig cfg)
                : ViolationFlowBase(object_id, violation_id, cfg->data_)
                , cfg_(cfg)
                ,last_report_time_(0)
                {}

        virtual ~ViolationVest()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
        result_list_t         get_results(const ImageObjectsInfo& objs) const;
        void                  log_info(const ImageObjectsInfo& objs) const;
        result_list_t         try_get_alarm(const ImageObjectsInfo& objs);

    protected:
        const spViolationMassiveflowCommonConfig cfg_;
        time_t  last_report_time_;
        //
        VecBoxF vest_objects_to_report_;
    };

class ICAlgEngine;

    result_list_t ViolationVest::get_results(const ImageObjectsInfo& objs)const{
        result_list_t retv;

        const auto stream_id = snapshots_[0].image->channel_id;
        const auto violation_code = cfg_->data_->code();
        const auto violation_id = violation_id_;
        const auto snapshots = snapshots_;
        const auto enable_output_picture = cfg_->data_->enable_output_picture();
        bool wear_vest_is_violate = cfg_->data_->wear_vest_alert(); //穿了反光背心作为事件上报还是没穿的时候上报
        VecBoxF vest_objects_to_report = vest_objects_to_report_;
        auto action = [=](ICAlgEngine* engine) -> spEventProto {
            auto retv = std::make_shared<inference::Event>();
            inference::Event& event = *retv;
            event.set_event_type(EventTypeMassiveflow);

            inference::MassiveFlowEvent * mass_event = event.mutable_massive_flow_event();
            mass_event->set_stream_id(stream_id);
            mass_event->set_task_id(stream_id);
            mass_event->set_event_type(atoi(violation_code.c_str()));

            for(int i=0;i<snapshots.size();i++){
                auto& image = snapshots[i].image;
                auto snap1 = mass_event->add_snapshots();
                snap1->set_now(snapshots[i].now.time_since_epoch().count());
                if (enable_output_picture){
                    snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
                }
                if(violation_code==BUILDING_REFLECTIVE_VEST_CODE){
                    if(wear_vest_is_violate){
                        for(auto& obj: vest_objects_to_report){
                            auto obj1 = snap1->add_objects();
                            obj1->add_box(obj.xmin);
                            obj1->add_box(obj.ymin);
                            obj1->add_box(obj.xmax);
                            obj1->add_box(obj.ymax);
                            obj1->set_score(obj.score);
                            obj1->set_zone_guard_lowest_score(float(obj.label));
                        }
                    }else{
                        for(auto& obj: vest_objects_to_report){
                            auto obj1 = snap1->add_objects();
                            obj1->add_box(obj.xmin);
                            obj1->add_box(obj.ymin);
                            obj1->add_box(obj.xmax);
                            obj1->add_box(obj.ymax);
                            obj1->set_score(obj.no_vest_attr.score);
                            obj1->set_zone_guard_lowest_score(float(obj.no_vest_attr.type));
                        }
                    }
                }
            }

            return retv;
        };
        retv.push_back(action);
        return retv;
    }

    result_list_t ViolationVest::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        if(!check_time_valid()){
            return retv;
        }
        const auto violation_code = cfg_->data_->code();
        bool wear_vest_is_violate = cfg_->data_->wear_vest_alert(); //穿了反光背心作为事件上报还是没穿的时候上报
        float threshold = cfg_->data_->has_threshold()?cfg_->data_->threshold():0.0;

        vest_objects_to_report_.clear(); //占用内存不会回收, 一直是用过最大的一次
        if(violation_code==BUILDING_REFLECTIVE_VEST_CODE){
            if(wear_vest_is_violate){
                for(auto& obj :objs.vest_objects){
                    if(obj.label!=-1&&obj.score>=threshold){
                        vest_objects_to_report_.push_back(obj);
                    }
                }
            }else{
                for(auto& obj :objs.vest_objects){
                    if(obj.no_vest_attr.type!=-1&&obj.no_vest_attr.score>=threshold){
                        vest_objects_to_report_.push_back(obj);
                    }
                }
            }
        }
        if (!vest_objects_to_report_.empty()){
            time_t now = std::time(NULL);
            bool skip  = (now-last_report_time_) < cfg_->data_->cooling_second();
            if (!skip){
                last_report_time_ = now;
                this->clear_snapshot();
                this->add_snapshot(BoxF(), objs);
                return get_results(objs);
            }else{
                //LOG(INFO) <<"vest: cooling time, skip" ;
            }
        }

        return retv;
    }

    ViolationVestFactory::ViolationVestFactory(const std::string& id, const std::string& cfg)
            :IViolationFactory(),
             id_(id),
             cfg_(std::make_shared<ViolationMassiveflowCommonConfig>(cfg)){}

    const std::string& ViolationVestFactory::id()const
    {
        return id_;
    }

    spIViolation ViolationVestFactory::CreateIViolation(const BoxF& obj)
    {
        if (obj.label == -1)
        {
            return std::make_shared<ViolationVest>(obj.uid, id_, cfg_);
        }
        else
        {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(BUILDING_REFLECTIVE_VEST_CODE, Vest);
} // namespace FLOW

