#include <unordered_map>
#include <memory>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_event.pb.h"
#include "violation_flow_base.hpp"
#include "violation_parade.hpp"

namespace FLOW {

    using namespace std;

    class ViolationParade : public ViolationFlowBase
    {
    public:
        ViolationParade(int object_id, const std::string& violation_id, const spViolationMassiveflowCommonConfig cfg)
                : ViolationFlowBase(object_id, violation_id, cfg->data_)
                , cfg_(cfg)
                ,last_report_time_(0)
                {}

        virtual ~ViolationParade()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
        result_list_t         get_results(const ImageObjectsInfo& objs) const;
        void                  log_info(const ImageObjectsInfo& objs) const;
        result_list_t         try_get_alarm(const ImageObjectsInfo& objs);

    protected:
        const spViolationMassiveflowCommonConfig cfg_;
        time_t  last_report_time_;

    };

class ICAlgEngine;

    result_list_t ViolationParade::get_results(const ImageObjectsInfo& objs)const{
        result_list_t retv;

        const auto stream_id = snapshots_[0].image->channel_id;
        const auto violation_code = cfg_->data_->code();
        const auto violation_id = violation_id_;
        const auto snapshots = snapshots_;
        const auto enable_output_picture = cfg_->data_->enable_output_picture();
        auto action = [=](ICAlgEngine* engine) -> spEventProto {
            auto retv = std::make_shared<inference::Event>();
            inference::Event& event = *retv;
            event.set_event_type(EventTypeMassiveflow);

            inference::MassiveFlowEvent * mass_event = event.mutable_massive_flow_event();
            mass_event->set_stream_id(stream_id);
            mass_event->set_task_id(stream_id);
            mass_event->set_event_type(atoi(violation_code.c_str()));

            for(int i=0;i<snapshots.size();i++){
                auto& image = snapshots[i].image;
                auto snap1 = mass_event->add_snapshots();
                snap1->set_now(snapshots[i].now.time_since_epoch().count());
                if (enable_output_picture){
                    snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
                }
                if(violation_code==FLOW_PARADE_JUPAI_CODE){
                    for(auto& obj: objs.parade_info.white_flag_objs_){
                        auto obj1 = snap1->add_objects();
                        obj1->add_box(obj.xmin);
                        obj1->add_box(obj.ymin);
                        obj1->add_box(obj.xmax);
                        obj1->add_box(obj.ymax);
                    }
                }else if(violation_code==FLOW_PARADE_JUQI_CODE){
                    for(auto& obj: objs.parade_info.red_flag_objs_){
                        auto obj1 = snap1->add_objects();
                        obj1->add_box(obj.xmin);
                        obj1->add_box(obj.ymin);
                        obj1->add_box(obj.xmax);
                        obj1->add_box(obj.ymax);
                    }
                }
            }

            return retv;
        };
        retv.push_back(action);
        return retv;
    }

    result_list_t ViolationParade::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        if(!check_time_valid()){
            return retv;
        }
        const auto violation_code = cfg_->data_->code();
        bool violate = false;
        if(violation_code==FLOW_PARADE_JUPAI_CODE){
            if(!objs.parade_info.white_flag_objs_.empty()){
                violate = true;
            }
        }else if(violation_code==FLOW_PARADE_JUQI_CODE){
            if(!objs.parade_info.red_flag_objs_.empty()){
                violate = true;
            }
        }
        if (violate){
            time_t now = std::time(NULL);
            bool skip  = (now-last_report_time_) < cfg_->data_->cooling_second();
            if (!skip){
                last_report_time_ = now;
                this->clear_snapshot();
                this->add_snapshot(BoxF(), objs);
                return get_results(objs);
            }else{
                //LOG(INFO) <<"parade: cooling time, skip" ;
            }
        }

        return retv;
    }

    ViolationParadeFactory::ViolationParadeFactory(const std::string& id, const std::string& cfg)
            :IViolationFactory(),
             id_(id),
             cfg_(std::make_shared<ViolationMassiveflowCommonConfig>(cfg)){}

    const std::string& ViolationParadeFactory::id()const
    {
        return id_;
    }

    spIViolation ViolationParadeFactory::CreateIViolation(const BoxF& obj)
    {
        if (obj.label == -1)
        {
            return std::make_shared<ViolationParade>(obj.uid, id_, cfg_);
        }
        else
        {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(FLOW_PARADE_JUPAI_CODE, Parade);
    REGISTER_VIOLATION(FLOW_PARADE_JUQI_CODE, Parade);
} // namespace FLOW

