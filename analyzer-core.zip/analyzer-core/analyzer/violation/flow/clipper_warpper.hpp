#include <algorithm>
#include "common/clipper.hpp"
#include "common/boxes.hpp"
#include "common/tad_internal.hpp"
namespace FLOW{

namespace cl = ClipperLib;

    float paths_area(const cl::Paths &ps) {
        float area = 0;
        for (auto &&p: ps)
            area += cl::Area(p);
        return area;
    }



    float poly_iou(const cl::Path &a, const cl::Path &b) {
        cl::Clipper clpr;
        clpr.AddPath(a, cl::ptSubject, true);
        clpr.AddPath(b, cl::ptClip, true);

        cl::Paths inter, uni;
        clpr.Execute(cl::ctIntersection, inter, cl::pftEvenOdd);
        clpr.Execute(cl::ctUnion, uni, cl::pftEvenOdd);

        auto inter_area = paths_area(inter);
        return std::abs(inter_area) / cl::Area(b);
    }



    bool CheckPolygonIntersectWithBox(BoxF ba, BoxF bb) {
        using cInt = cl::cInt;

        cl::Path poly_text{{cInt(ba.xmin), cInt(ba.ymin)},
                       {cInt(ba.xmax), cInt(ba.ymin)},
                       {cInt(ba.xmax), cInt(ba.ymax)},
                       {cInt(ba.xmin), cInt(ba.ymax)},};

        cl::Path poly_object{{cInt(bb.xmin), cInt(bb.ymin)},
                       {cInt(bb.xmax), cInt(bb.ymin)},
                       {cInt(bb.xmax), cInt(bb.ymax)},
                       {cInt(bb.xmin), cInt(bb.ymax)},};

        if(poly_iou(poly_object, poly_text)>0.8) {
            return true;
        }else {
             return false;
        }

    }


    bool CheckBoxInRois(BoxF ba, std::vector<std::vector<float>> rois, float threshold_intersect) {
        using cInt = cl::cInt;
        bool inside = false;

        cl::Path poly_object{{cInt(ba.xmin), cInt(ba.ymin)},
                       {cInt(ba.xmax), cInt(ba.ymin)},
                       {cInt(ba.xmax), cInt(ba.ymax)},
                       {cInt(ba.xmin), cInt(ba.ymax)},};

	for (int i=0;i<rois.size();i++){
            cl::Path poly_roi;
	    if (rois[i].size()/2 < 2){
		    // wrong roi
		    continue;
	    }

	    for (int j=0;j<rois[i].size()/2;j++){
	        poly_roi.push_back(cl::IntPoint(cInt(rois[i][2*j]), cInt(rois[i][2*j+1])));
	    }
	    
	    // here params order matters
	    if (poly_iou(poly_roi, poly_object)>threshold_intersect){
		    inside = true;
		    break;
	    }
	}
        return inside;
    }


bool Pix_In_Poly(POINT pix, std::vector<float> zpoly){

    POINT p1, p2;
    int ncross = 0;
    double x;

    for (int i = 0; i < zpoly.size()/2; ++i){
        p1.x = zpoly[2*i];
        p1.y = zpoly[2*i+1];
        p2.x = zpoly[(2*i+2)%zpoly.size()];
        p2.y = zpoly[(2*i+3)%zpoly.size()];
        if (p1.y == p2.y)
        {
            continue;
        }
        if (pix.y >= std::max(p1.y, p2.y))
        {
            continue;
        }
        if (pix.y < std::min(p1.y, p2.y))
        {
            continue;
        }

        x = (double)(pix.y-p1.y) * ((double)(p2.x-p1.x)/(p2.y-p1.y)) + p1.x;
        if (x>pix.x)
        {
             ncross++;
        }
    }
    return (ncross % 2 == 1);
}


bool Pix_In_Polys(POINT pix, std::vector< std::vector<float> > polys){
    for (int i=0;i<polys.size();++i){
        if (Pix_In_Poly(pix, polys[i]))
            return true;
    }
    return false;
}




bool CheckBoxCenterInRois(BoxF ba, std::vector<std::vector<float>> rois) {
    POINT center;
    center.x = int((ba.xmin+ba.xmax)/2);
    center.y = int((ba.ymin+ba.ymax)/2);
    return Pix_In_Polys(center, rois);
}


}
