#ifndef SRC_HEADLINE_HPP
#define SRC_HEADLINE_HPP

#include <vector>
#include "common/type.hpp"
#include "common/log.hpp"
#include "common/tad_internal.hpp"

// #include "mot.hpp"

#define MAX_NUM_PERSON 50
#define TRACK_J_NUM 32
#define MAX_LINE_NUM 10

namespace FLOW
{
namespace Headline
{

typedef struct _TRACK_RES_ {
    int idd = -1;
    float xl = 0.0;
    float yt = 0.0;
    float xr = 0.0;
    float yb = 0.0;

    int track_j_num = 0;
    POINT track_j[TRACK_J_NUM];
    int lost_counter = 0;
    //0:目标未过线 1:目标已正向过线 2:目标已反向过线, 记录每个跟踪目标相对每个线的状态
    int event_1_ed[MAX_LINE_NUM];
} TRACK_RES;

class CrossingLine
{
public:
    CrossingLine() = default;
    ~CrossingLine() = default;

public:
    void Init(const std::vector<std::vector<int>> &crossinglines);
    void Update(const ImageObjectsInfo &objs);
    void GetTrackedObj(const ImageObjectsInfo &objs);

    float cross(POINT p1, POINT p2, POINT p3);
    int IsIntersec(POINT p1, POINT p2, POINT p3, POINT p4);
    void event_1_process(TRACK_RES person_list[MAX_NUM_PERSON]);

public:
    std::vector<std::vector<int>> crossinglines_;
    std::vector<int> res_human_count;
    VecBoxF intersect_persons;
    VecBoxF in_persons;
    VecBoxF out_persons;
    TRACK_RES res_person_list[MAX_NUM_PERSON];
    std::vector<std::pair<POINT, POINT> > inHeadTrace; //每个过线的head的移动路径
    std::vector<std::pair<POINT, POINT> > outHeadTrace;
public:
    const static int point_dis = 5;
    const static int track_tolerence = 4;
};

} // namespace Headline
} // namespace FLOW

#endif
