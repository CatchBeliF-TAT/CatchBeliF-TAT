#include "headline.hpp"
#include "common/log.hpp"

namespace FLOW
{

namespace Headline
{

using namespace std;

void CrossingLine::Init(const std::vector<std::vector<int>> &crossinglines)
{
  crossinglines_ = crossinglines;
  res_human_count.clear();
  res_human_count.resize(crossinglines_.size() * 2, 0);
}

void CrossingLine::Update(const ImageObjectsInfo &objs)
{
  GetTrackedObj(objs);
  event_1_process(res_person_list);
}


void CrossingLine::GetTrackedObj(const ImageObjectsInfo &objs)
{
  for (const auto &obj : objs.keliu_objects)
  {
    bool if_new_obj_insert = true;
    for (int j = 0; j < MAX_NUM_PERSON; ++j)
    {
      // if already tracked
      if (res_person_list[j].idd == obj.uid)
      {
        if_new_obj_insert = false;
        res_person_list[j].xl = obj.xmin;
        res_person_list[j].xr = obj.xmax;
        res_person_list[j].yt = obj.ymin;
        res_person_list[j].yb = obj.ymax;
        if (res_person_list[j].track_j_num < TRACK_J_NUM)
        {
          res_person_list[j].track_j[res_person_list[j].track_j_num].x =
              (res_person_list[j].xl + res_person_list[j].xr) / 2.0;
          res_person_list[j].track_j[res_person_list[j].track_j_num].y =
              (res_person_list[j].yt + res_person_list[j].yb) / 2.0;
          res_person_list[j].track_j_num++;
        }
        else if (res_person_list[j].track_j_num == TRACK_J_NUM)
        {
          memcpy(&res_person_list[j].track_j[0], &res_person_list[j].track_j[1],
                 (TRACK_J_NUM - 1) * sizeof(POINT));
          res_person_list[j].track_j[TRACK_J_NUM - 1].x =
              (res_person_list[j].xl + res_person_list[j].xr) / 2.0;
          res_person_list[j].track_j[TRACK_J_NUM - 1].y =
              (res_person_list[j].yt + res_person_list[j].yb) / 2.0;
        }
        break;
      }
    }
    // if not yet tracked
    if (if_new_obj_insert == true)
    {
      for (int i = 0; i < MAX_NUM_PERSON; ++i)
      {
        if (res_person_list[i].idd == -1)
        {
          res_person_list[i].idd = obj.uid;
          res_person_list[i].xl = obj.xmin;
          res_person_list[i].xr = obj.xmax;
          res_person_list[i].yt = obj.ymin;
          res_person_list[i].yb = obj.ymax;
          res_person_list[i].track_j_num = 0;
          res_person_list[i].track_j[0].x = (res_person_list[i].xl + res_person_list[i].xr) / 2.0;
          res_person_list[i].track_j[0].y = (res_person_list[i].yt + res_person_list[i].yb) / 2.0;
          res_person_list[i].track_j_num++;
          break;
        }
      }
    }
  }

  std::vector<int> remove_index;
  remove_index.clear();
  // if long time not tracked, remove
  for (int j = 0; j < MAX_NUM_PERSON; ++j)
  {
    int pre_idd = res_person_list[j].idd;
    bool if_old_tracked = false;
    for (auto &obj : objs.keliu_objects)
    {
      if (obj.uid == pre_idd)
      {
        if_old_tracked = true;
        break;
      }
    }
    // maybe break to here
    if (if_old_tracked == false)
    {
      res_person_list[j].lost_counter++;
    }
    else
    {
      res_person_list[j].lost_counter = 0;
    }

    // remove obj, set to default
    if (res_person_list[j].lost_counter > track_tolerence)
    {
      memset(&res_person_list[j], 0, sizeof(TRACK_RES));
      res_person_list[j].idd = -1;
    }
  }
}

float CrossingLine::cross(POINT p1, POINT p2, POINT p3)
{
  float x1 = float(p2.x - p1.x);
  float y1 = float(p2.y - p1.y);
  float x2 = float(p3.x - p1.x);
  float y2 = float(p3.y - p1.y);
  return (float(x1 * y2) - float(x2 * y1));
}

//线段相交
int CrossingLine::IsIntersec(POINT p1, POINT p2, POINT p3, POINT p4)
{
  int D;
  if (max(p1.x, p2.x) >= min(p3.x, p4.x) && max(p3.x, p4.x) >= min(p1.x, p2.x) && max(p1.y, p2.y) >= min(p3.y, p4.y) && max(p3.y, p4.y) >= min(p1.y, p2.y))
  {
    if (cross(p1, p2, p3) * cross(p1, p2, p4) <= 0 && cross(p3, p4, p1) * cross(p3, p4, p2) <= 0)
    {
      D = 1;
    }
    else
    {
      D = 0;
    }
  }
  else
  {
    D = 0;
  }

  return D;
}

void CrossingLine::event_1_process(TRACK_RES person_list[MAX_NUM_PERSON])
{
  set<int> person_intersect_idx;
  set<int> person_in_idx;
  set<int> person_out_idx;

  inHeadTrace.clear();
  outHeadTrace.clear();
  if(crossinglines_.size()>MAX_LINE_NUM){
    LOG(FATAL)<<"too much lines!!";
  }
  for (int i = 0; i < crossinglines_.size(); i++)
  {
    POINT p1 = {(float)crossinglines_[i][0], (float)crossinglines_[i][1]};
    POINT p2 = {(float)crossinglines_[i][2], (float)crossinglines_[i][3]};

    for (int j = 0; j < MAX_NUM_PERSON; j++)
    {
      int traj_num = person_list[j].track_j_num;
      if (traj_num >= point_dis && person_list[j].lost_counter == 0){
        POINT p4 = {person_list[j].track_j[traj_num - 1].x, person_list[j].track_j[traj_num - 1].y};                         //new
        POINT p3 = {person_list[j].track_j[traj_num - 1 - point_dis +1].x, person_list[j].track_j[traj_num - 1 - point_dis +1].y}; //old 
        if (IsIntersec(p1, p2, p3, p4) == 1){

          int &event_1_ed = person_list[j].event_1_ed[i];

          //布控线向量
          float x_o_d = p2.x - p1.x;
          float y_o_d = p2.y - p1.y;

          //人流判断方向向量
          /*
          * 按照和前端布控的约定，人流方向是布控线向量逆时针旋转90度，
          * 但由于opencv中图像坐标系的关系，实际坐标需要按照顺时针90度旋转来计算
          */
          float x_v_d = y_o_d;
          float y_v_d = -x_o_d;

          //行人轨迹向量
          float x_a_d = p4.x - p3.x;
          float y_a_d = p4.y - p3.y;

          //点乘 判断过线方向
          float dot = x_a_d * x_v_d + y_a_d * y_v_d;
          if(dot >0){//正过线
            if(event_1_ed==1){//目标已经正向过线了
              continue;
            }
            event_1_ed = 1;
          }else if(dot < 0){//反过线
            if(event_1_ed==2){//目标已经反向过线了
              continue;
            }
            event_1_ed = 2;
          }
          person_intersect_idx.insert(j);
          pair<POINT, POINT> traceLine(p3, p4);
          if (event_1_ed == 1){//in
            inHeadTrace.push_back(traceLine);
            person_in_idx.insert(j);
            res_human_count[2 * i + 1]++;
          }else if (event_1_ed == 2){ //out
            outHeadTrace.push_back(traceLine);
            person_out_idx.insert(j);
            res_human_count[2 * i]++;
          }else{
            LOG(WARNING)<<"some error happen";
          }
          //考虑了同一个人反复进出一条线，以及一个人同时过多条线的情况，但是不能频率太快，在线的一边至少停留10帧
        }
      }
    }//end of each obj
  }//end of each line

  intersect_persons.clear();
  for (auto iter = person_intersect_idx.begin(); iter != person_intersect_idx.end(); iter++)
  {
    BoxF box(person_list[*iter].xl, person_list[*iter].yt, person_list[*iter].xr, person_list[*iter].yb);
    intersect_persons.push_back(box);
  }

  out_persons.clear();
  for (auto iter = person_out_idx.begin(); iter != person_out_idx.end(); iter++)
  {
    BoxF box(person_list[*iter].xl, person_list[*iter].yt, person_list[*iter].xr, person_list[*iter].yb);
    out_persons.push_back(box);
  }

  in_persons.clear();
  for (auto iter = person_in_idx.begin(); iter != person_in_idx.end(); iter++)
  {
    BoxF box(person_list[*iter].xl, person_list[*iter].yt, person_list[*iter].xr, person_list[*iter].yb);
    in_persons.push_back(box);
  }
}

} // namespace Headline
} // namespace FLOW
