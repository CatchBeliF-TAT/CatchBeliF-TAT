//
// Created by wuzhenzhou on 2020-01-06.
//

#ifndef ANALYZER_FLOW_VIOLATION_ZONE_GUARD_HPP
#define ANALYZER_FLOW_VIOLATION_ZONE_GUARD_HPP

#include <vector>
#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"
#include "zone_guard/zone_guard.hpp"

namespace FLOW {

    class ViolationZoneGuardFactory : public IViolationFactory
    {
    public:
        ViolationZoneGuardFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationZoneGuardFactory()=default;

    public:
        virtual const std::string&  id()const;
        virtual spIViolation        CreateIViolation(const BoxF& obj);

    protected:
        std::string                             id_;
        spViolationMassiveflowCommonConfig      cfg_;
    };

} // namespace FLOW



#endif //ANALYZER_FLOW_VIOLATION_ZONE_GUARD_HPP
