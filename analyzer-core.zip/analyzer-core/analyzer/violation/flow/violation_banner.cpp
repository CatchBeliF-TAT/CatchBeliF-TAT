//
// Created by wuzhenzhou on 2019-12-11.
//

	
#include <numeric>
#include <string>
#include <iterator>
#include <fstream>
#include <time.h>
#include <stdlib.h>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation_flow_base.hpp"
#include "violation_banner.hpp"
#include "clipper_warpper.hpp"



namespace FLOW {

    // static const std::string FLOW_BANNER_CODE("2");

//
// ViolationBanner
//
    class ViolationBanner : public ViolationFlowBase
    {
    public:
        ViolationBanner(int object_id, const std::string& violation_id, const spViolationMassiveflowCommonConfig cfg);
        virtual ~ViolationBanner()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
        virtual result_list_t get_results() const;
        void                  log_info(const ImageObjectsInfo& objs) const;
        result_list_t         try_get_alarm(const ImageObjectsInfo& objs);

        std::vector<std::vector<float> > validRois;
        std::vector<std::vector<float> > removeRois;

    protected:
        const spViolationMassiveflowCommonConfig     cfg_;
        VecBoxF                                 pre_data_;
        VecBoxF                                 objects_vec_; //检测目标
        time_t                                  last_report_time_;
    };

    ViolationBanner::ViolationBanner(int object_id, const std::string& violation_id, const spViolationMassiveflowCommonConfig cfg)
            : ViolationFlowBase(object_id, violation_id, cfg->data_)
            , cfg_(cfg)
            , pre_data_()
            , last_report_time_(0)
    {
        LOG(INFO) << "banner violation registered" ;

        for(int i= 0;i< cfg_->data_->roi_size(); i++){
            std::vector<float> tmp;
            for (int j=0;j<cfg_->data_->roi(i).data_size();j++){
    		tmp.push_back(cfg_->data_->roi(i).data(j));
            }
            validRois.push_back(tmp);
        }

        for(int i= 0;i< cfg_->data_->remove_roi_size(); i++){
            std::vector<float> tmp;
            for (int j=0;j<cfg_->data_->remove_roi(i).data_size();j++){
                tmp.push_back(cfg_->data_->remove_roi(i).data(j));
            }
            removeRois.push_back(tmp);
        }

	if (validRois.size() == 0){
	    std::vector<float> tmp = {0,0,3000,0,3000,3000,0,3000}; // default
	    validRois.push_back(tmp);
	}
    }

class ICAlgEngine;

    result_list_t ViolationBanner::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        if(!check_time_valid()){
            return retv;
        }
        //log_info(objs);
        //LOG(INFO) << "banner check" ;
        VecBoxF banner_vecs;
        VecBoxF person_vecs;
        VecBoxF vehicle_vecs;

        for (const auto& obj : objs.flow_info.bannerinfo_.bannerobjects_) {
            // valid roi and remove roi check
            // box need IOU 0.75 larger with valid region
            // box need IOU 0.25 smaller with remove region
            if (CheckBoxInRois(obj, validRois, 0.75) && !CheckBoxInRois(obj, removeRois, 0.25)){
                banner_vecs.push_back(obj);
            }
        }
        for(const auto& obj : objs.objects){
            if (obj.label == OBJECT_TYPE_PERSON) {
                person_vecs.push_back(obj);

            }
            if (obj.label == OBJECT_TYPE_VEHICLE) {
                vehicle_vecs.push_back(obj);
            }
        }

        VecBoxF banner_vecs_valid;
        // todo check if text box valid
        // first step, check if text interact with
        for (const auto & banner_obj : banner_vecs){
            bool valid = true;
            // person intersect
            for (const auto & person_obj : person_vecs){
                if(CheckPolygonIntersectWithBox(banner_obj, person_obj)){
                    valid = false;
                    break;
                }
            }   

            // vehicle 
            for (const auto & vehicle_obj : vehicle_vecs){
                if (vehicle_obj.xmin < banner_obj.xmin 
                        && vehicle_obj.xmax > banner_obj.xmax
                        && vehicle_obj.ymin < banner_obj.ymin 
                        && vehicle_obj.ymax > banner_obj.ymax) 
                    {
                        valid = false;
                        break;
                    }
            }
            // remove certain text box
            if (valid)
                banner_vecs_valid.push_back(banner_obj);
        }

        objects_vec_.clear();
        objects_vec_.assign(banner_vecs_valid.begin(), banner_vecs_valid.end());

        if (objects_vec_.size()>0){
            time_t now=  std::time(NULL);
            bool skip  = (now-last_report_time_) < cfg_->data_->cooling_second();
            if (!skip){
                last_report_time_ = now;
                return try_get_alarm(objs);
            }
            LOG(INFO) <<"banner cooling time, skip  " ;
        }

        return retv;
    }

    void ViolationBanner::log_info(const ImageObjectsInfo& objs) const{
        LOG(INFO) <<"banner ==> violation_id: " << this->violation_id_
                  << ", stream_id: " << objs.channel_id;

    }

    result_list_t ViolationBanner::try_get_alarm(const ImageObjectsInfo& objs) {

        LOG(INFO) << "enter_alarm";

        this->clear_snapshot();
        this->add_snapshot(BoxF(), objs);
        return get_results();
    }


    result_list_t ViolationBanner::get_results()const{
        result_list_t retv;
        const auto stream_id = snapshots_[0].image->channel_id;
        const auto violation_code = mf_violation_cfg_->code();
        const auto violation_name = mf_violation_cfg_->name();
        const auto violation_id = violation_id_;
        const auto snapshots = snapshots_;
        const auto enable_output_picture = mf_violation_cfg_->enable_output_picture();
        const auto enable_save_picture = mf_violation_cfg_->enable_save_debug_picture();
        const auto objects_vec = objects_vec_;

        auto action = [=](ICAlgEngine* engine) -> spEventProto {
            auto retv = std::make_shared<inference::Event>();
            inference::Event& event = *retv;
            event.set_event_type(EventTypeMassiveflow);
            inference::MassiveFlowEvent * mass_event = event.mutable_massive_flow_event();
            mass_event->set_stream_id(stream_id);
            mass_event->set_task_id(stream_id);
            mass_event->set_event_type(atoi(violation_code.c_str()));

            LOG(INFO) << "snapshots size : " << snapshots.size();

            for(int i=0;i<snapshots.size();i++){
                auto& image = snapshots[i].image;
                auto snap1 = mass_event->add_snapshots();
                snap1->set_now(snapshots[i].now.time_since_epoch().count());
                if (enable_output_picture){
                    snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
                    for(auto iter1=objects_vec.begin() ;iter1!= objects_vec.end();iter1++){
                        auto obj1 = snap1->add_objects();
                        obj1->add_box((*iter1).xmin);
                        obj1->add_box((*iter1).ymin);
                        obj1->add_box((*iter1).xmax);
                        obj1->add_box((*iter1).ymax);
                    }
                }

                if (enable_save_picture){
                    std::stringstream buff;
                    buff <<stream_id <<"/pic_" << violation_id << "_"  <<"_" << i <<".jpg";
                    auto fname = buff.str();
                    std::ofstream of;
                    mkdir(stream_id.c_str(),0755);
                    of.open(fname);
                    std::vector<unsigned char> im_data;
                    cv::imencode(".jpg", *(image->sframe->getMat()), im_data);
                    of.write((const char*)im_data.data(),im_data.size());
                    LOG(INFO)<<"==>pic result "<<fname <<","<<of.is_open()<<","<<of.tellp();
                    of.close();
                }
            }

            return retv;
        };
        retv.push_back(action);
        return retv;
    }

//
// ViolationBannerFactory
//
    ViolationBannerFactory::ViolationBannerFactory(const std::string& id, const std::string& cfg)
            : IViolationFactory()
            , id_(id)
            , cfg_(std::make_shared<ViolationMassiveflowCommonConfig>(cfg))
    {
    }

    const std::string& ViolationBannerFactory::id()const
    {
        return id_;
    }

    spIViolation ViolationBannerFactory::CreateIViolation(const BoxF& obj)
    {
        if (obj.uid == -1){
            return std::make_shared<ViolationBanner>(obj.uid, id_, cfg_);
        }
        else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(FLOW_BANNER_CODE, Banner);

} // namespace FLOW

