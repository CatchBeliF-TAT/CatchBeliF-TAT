

#include "zone_guard.hpp"
#include "common/log.hpp"

namespace FLOW
{
namespace ZoneGuard
{

using namespace std;

static int PixInPoly(std::vector<int> point,
                     std::vector<int> polys)
{
    POINT pp;
    pp.x = point[0];
    pp.y = point[1];

    POINT p1, p2;
    int ncross;
    double x;
    int i;

    ncross = 0;

    for (i = 0; i < polys.size() / 2; i++)
    {
        p1.x = polys[2 * i];
        p1.y = polys[2 * i + 1];

        p2.x = polys[2 * (i + 1) % polys.size()];
        p2.y = polys[(2 * (i + 1) + 1) % polys.size()];

        if (p1.y == p2.y)
        {
            continue;
        }
        if (pp.y >= max(p1.y, p2.y))
        {
            continue;
        }
        if (pp.y < min(p1.y, p2.y))
        {
            continue;
        }

        x = (double)(pp.y - p1.y) * ((double)(p2.x - p1.x) / (p2.y - p1.y)) + p1.x;

        if (x > pp.x)
        {
            ncross++;
        }
    }
    return (ncross % 2 == 1);
}

// void ZoneGuard::Init(const std::vector<std::vector<int>> &rois)
// {
//     rois_ = rois;
// }

void ZoneGuard::Update(const ImageObjectsInfo &objs)
{
    updateTrackObjs(objs);
    process();
}

void ZoneGuard::updateTrackObjs(const ImageObjectsInfo &objs)
{

    for (const auto &obj : objs.keliu_objects)
    {
        int cur_uid = obj.uid;
        bool if_new_obj_insert = true;
        for (int j = 0; j < MAX_NUM_PERSON; ++j)
        {
            // if already tracked
            if (cur_uid == res_person_list[j].uid)
            {
                if_new_obj_insert = false;
                //记录所有跟踪到的obj中score最小的, 以及平均score
                if(obj.score < res_person_list[j].lowest_obj_score){
                    res_person_list[j].lowest_obj_score = obj.score;
                }
                res_person_list[j].ave_obj_score = (res_person_list[j].ave_obj_score * res_person_list[j].track_j_num + obj.score)/(res_person_list[j].track_j_num +1);
                res_person_list[j].xl = obj.xmin;
                res_person_list[j].xr = obj.xmax;
                res_person_list[j].yt = obj.ymin;
                res_person_list[j].yb = obj.ymax;
                if (res_person_list[j].track_j_num < TRACK_J_NUM)
                {
                    res_person_list[j].track_j[res_person_list[j].track_j_num].x =
                        (res_person_list[j].xl + res_person_list[j].xr) / 2.0;
                    res_person_list[j].track_j[res_person_list[j].track_j_num].y =
                        (res_person_list[j].yt + res_person_list[j].yb) / 2.0;
                    //res_person_list[j].track_j[res_person_list[j].track_j_num].framesid = objs.count;
                    res_person_list[j].track_j_num++;
                }
                else if (res_person_list[j].track_j_num == TRACK_J_NUM)
                {
                    memcpy(&res_person_list[j].track_j[0], &res_person_list[j].track_j[1],
                           (TRACK_J_NUM - 1) * sizeof(POINT));
                    res_person_list[j].track_j[TRACK_J_NUM - 1].x =
                        (res_person_list[j].xl + res_person_list[j].xr) / 2.0;
                    res_person_list[j].track_j[TRACK_J_NUM - 1].y =
                        (res_person_list[j].yt + res_person_list[j].yb) / 2.0;
                    //res_person_list[j].track_j[TRACK_J_NUM - 1].framesid = objs.count;
                }
                break;
            }
        }
        // if not yet tracked
        if (if_new_obj_insert == true)
        {
            for (int i = 0; i < MAX_NUM_PERSON; ++i)
            {
                if (res_person_list[i].uid == -1)
                {
                    res_person_list[i].uid = obj.uid;
                    res_person_list[i].xl = obj.xmin;
                    res_person_list[i].xr = obj.xmax;
                    res_person_list[i].yt = obj.ymin;
                    res_person_list[i].yb = obj.ymax;
                    res_person_list[i].track_j_num = 0;
                    res_person_list[i].track_j[0].x = (res_person_list[i].xl + res_person_list[i].xr) / 2.0;
                    res_person_list[i].track_j[0].y = (res_person_list[i].yt + res_person_list[i].yb) / 2.0;
                    res_person_list[i].track_j_num++;
                    res_person_list[i].ave_obj_score = res_person_list[i].lowest_obj_score = obj.score;
                    break;
                }
            }
        }
    }

    std::vector<int> remove_index;
    remove_index.clear();
    // if long time not tracked, remove
    for (int j = 0; j < MAX_NUM_PERSON; ++j)
    {
        int pre_uid = res_person_list[j].uid;
        if(pre_uid==-1){
            continue;
        }
        bool if_old_tracked = false;
        for (auto &obj : objs.keliu_objects)
        {
            if (obj.uid == pre_uid)
            {
                if_old_tracked = true;
                break;
            }
        }
        // maybe break to here
        if (if_old_tracked == false)
        {
            res_person_list[j].lost_counter++;
        }
        else
        {
            res_person_list[j].lost_counter = 0;
        }

        // remove obj, set to default
        if (res_person_list[j].lost_counter > TRACK_TOLERENCE)
        {
            //LOG(WARNING)<<"stop track obj "<<res_person_list[j].uid;
            memset(&res_person_list[j], 0, sizeof(TRACK_RES));
            res_person_list[j].uid = -1;
            res_person_list[j].track_j_num=0;
            // res_person_list[j].event_1_ed = 8;
        }
    }
}

float ZoneGuard::cross(POINT p1, POINT p2, POINT p3)
{
    float x1 = float(p2.x - p1.x);
    float y1 = float(p2.y - p1.y);
    float x2 = float(p3.x - p1.x);
    float y2 = float(p3.y - p1.y);
    return (float(x1 * y2) - float(x2 * y1));
}

int ZoneGuard::isIntersec(POINT p1, POINT p2, POINT p3, POINT p4)
{
    int D;
    if (max(p1.x, p2.x) >= min(p3.x, p4.x) && max(p3.x, p4.x) >= min(p1.x, p2.x) && max(p1.y, p2.y) >= min(p3.y, p4.y) && max(p3.y, p4.y) >= min(p1.y, p2.y))
    {
        if (cross(p1, p2, p3) * cross(p1, p2, p4) <= 0 && cross(p3, p4, p1) * cross(p3, p4, p2) <= 0)
        {
            D = 1;
        }
        else
        {
            D = 0;
        }
    }
    else
    {
        D = 0;
    }

    return D;
}

void ZoneGuard::process()
{
    //set<int> person_entry_idx;
    set<int> person_in_idx;

    for (int i = 0; i < rois_.size(); i++)
    {
        if (rois_[i].size() % 2 != 0 || rois_[i].size() <= 4)
        {
            LOG(ERROR) << "invalid rois_";
            continue;
        }
        //if in rois
        for (int j = 0; j < MAX_NUM_PERSON; j++)
        {
            int traj_num = res_person_list[j].track_j_num;
            if (res_person_list[j].valid == 0 && traj_num >= point_dis + 2)
            {
                // POINT point = {res_person_list[j].track_j[traj_num - 1].x, res_person_list[j].track_j[traj_num - 1].y}; //new
                std::vector<int> point;
                point.push_back(res_person_list[j].track_j[traj_num - 1].x);
                point.push_back(res_person_list[j].track_j[traj_num - 1].y);
                if (PixInPoly(point, rois_[i]))
                {
                    person_in_idx.insert(j);
                }
            }

            //if intersect
            /*因为目标在区域内就已经会上报，目标进入区域的前提是目标现在在区域内，所以不需要再判断目标是否进入区域
            for (int j = 0; j < rois_[i].size() / 2; j++)
            {
                POINT p1 = {(float)rois_[i][j], (float)rois_[i][j + 1]};
                POINT p2;
                if (j == rois_[i].size() / 2 - 1)
                {
                    p2 = POINT{(float)rois_[i][0], (float)rois_[i][1]};
                }
                else
                {
                    p2 = POINT{(float)rois_[i][j + 2], (float)rois_[i][j * 2 + 1]};
                }

                for (int k = 0; k < MAX_NUM_PERSON; k++)
                {
                    int traj_num = res_person_list[k].track_j_num;
                    if (res_person_list[k].valid == 0 && traj_num >= point_dis + 2)
                    {
                        POINT p4 = {res_person_list[k].track_j[traj_num - 1].x, res_person_list[k].track_j[traj_num - 1].y};                         //new
                        POINT p3 = {res_person_list[k].track_j[traj_num - 1 - point_dis].x, res_person_list[k].track_j[traj_num - 1 - point_dis].y}; //old
                        if (isIntersec(p1, p2, p3, p4) == 1 && person_in_idx.count(k))
                        {
                            person_entry_idx.insert(k);
                        }
                    }
                }
            }
            */
        }
    }
    /*
    entry_persons.clear();
    for (auto iter = person_entry_idx.begin(); iter != person_entry_idx.end(); iter++)
    {
        BoxF box(res_person_list[*iter].xl, res_person_list[*iter].yt, res_person_list[*iter].xr, res_person_list[*iter].yb);
        entry_persons.push_back(box);
    }
    */
    inside_persons.clear();
    for (auto iter = person_in_idx.begin(); iter != person_in_idx.end(); iter++)
    {
        BoxF box(res_person_list[*iter].xl, res_person_list[*iter].yt, res_person_list[*iter].xr, res_person_list[*iter].yb);
        box.ave_score = res_person_list[*iter].ave_obj_score;
        box.lowest_score = res_person_list[*iter].lowest_obj_score;
        inside_persons.push_back(box);
    }
    
    persons_tracked.clear();
    for (int j = 0; j < MAX_NUM_PERSON; j++){
        //if(res_person_list[j].uid == -1){
        //    continue;
        //}
        if(res_person_list[j].track_j_num==0){
            continue;
        }
        BoxF box(res_person_list[j].xl, res_person_list[j].yt, res_person_list[j].xr, res_person_list[j].yb);
        box.uid     = res_person_list[j].lost_counter;//临时用uid记录跟丢的帧数
        box.label   = res_person_list[j].track_j_num;//临时用label记录跟踪的帧数
        persons_tracked.push_back(box);
    }
}
} // namespace ZoneGuard
} // namespace FLOW
