#ifndef SRC_ZONE_GUARD_HPP
#define SRC_ZONE_GUARD_HPP

#include <vector>
#include "common/type.hpp"
#include "common/tad_internal.hpp"
#include "common/log.hpp"

namespace FLOW
{
namespace ZoneGuard
{

#define MAX_NUM_PERSON 50
#define TRACK_J_NUM 32
#define TRACK_TOLERENCE 4

typedef struct _POINT_
{
    float x =0.0;
    float y =0.0;
    int64_t framesid = 0;
} POINT;

typedef struct _TRACK_RES_
{
    int uid = -1;
    int dis = 0;
    int valid = 0;
    int crossed = 0;
    float xl = 0.0;
    float yt = 0.0;
    float xr = 0.0;
    float yb = 0.0;
    float lowest_obj_score = 1.0;
    float ave_obj_score = 0.0;
    int track_j_num = 0;
    POINT track_j[TRACK_J_NUM];
    int lost_counter = 0;

} TRACK_RES;

class ZoneGuard
{
public:
    ZoneGuard(const std::vector<std::vector<int>> &rois) : rois_(rois){
        inside_persons.clear();
        entry_persons.clear();
    };
    ~ZoneGuard() = default;

    // void Init(const std::vector<std::vector<int> >& rois);
    void Update(const ImageObjectsInfo &objs);

    VecBoxF GetPersonsInside(){
        return inside_persons;
    };
    VecBoxF GetPersonsEntry(){
        return entry_persons;
    };

    VecBoxF GetPersonsTracked(){
        return persons_tracked;
    };
private:
    void updateTrackObjs(const ImageObjectsInfo &objs);
    void process();

    float cross(POINT p1, POINT p2, POINT p3);
    int isIntersec(POINT p1, POINT p2, POINT p3, POINT p4);

    std::vector<int> tracked_id;

    std::vector<std::vector<int>> rois_;

    int point_dis = 10;

    VecBoxF entry_persons;//暂时不判断进入了，有需求再加回来
    VecBoxF inside_persons;
    VecBoxF persons_tracked; //正在跟踪的目标
    TRACK_RES res_person_list[MAX_NUM_PERSON];
    std::vector<int> res_uid_list;
};

} // namespace ZoneGuard
} // namespace FLOW

#endif
