#ifndef ANALYZER_FLOW_VIOLATION_CROWD_GATHERED_HPP
#define ANALYZER_FLOW_VIOLATION_CROWD_GATHERED_HPP



#include <vector>
#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"
// #include "crowd/crowdregion.hpp"

namespace FLOW {

    class ViolationCrowdGatheredFactory : public IViolationFactory
    {
    public:
        ViolationCrowdGatheredFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationCrowdGatheredFactory()=default;

    public:
        virtual const std::string&  id()const;
        virtual spIViolation        CreateIViolation(const BoxF& obj);

    protected:
        std::string                             id_;
        spViolationMassiveflowCommonConfig      cfg_;

    };

} // namespace FLOW


#endif //ANALYZER_FLOW_VIOLATION_CROWD_GATHERED_HPP

