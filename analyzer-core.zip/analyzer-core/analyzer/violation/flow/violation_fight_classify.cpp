#include <unordered_map>
#include <memory>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_event.pb.h"
#include "violation_flow_base.hpp"
#include "violation_fight_classify.hpp"

namespace FLOW {

    using namespace std;
    // static const std::string FLOW_FIGHT_CODE("3");


    class ViolationFightClassify : public ViolationFlowBase
    {
    public:
        ViolationFightClassify(int object_id, const std::string& violation_id, const spViolationMassiveflowCommonConfig cfg)
                : ViolationFlowBase(object_id, violation_id, cfg->data_)
                , cfg_(cfg)
                ,last_report_time_(0)
                {
                }
                

        virtual ~ViolationFightClassify()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
        virtual result_list_t get_results() const;
        void                  log_info(const ImageObjectsInfo& objs) const;
        result_list_t         try_get_alarm(const ImageObjectsInfo& objs);

    protected:
        const spViolationMassiveflowCommonConfig cfg_;
        time_t  last_report_time_;

    };

class ICAlgEngine;

    result_list_t ViolationFightClassify::get_results()const{
        result_list_t retv;
        // const auto obj_id = object_id_;
        const auto stream_id = snapshots_[0].image->channel_id;
        const auto violation_code = cfg_->data_->code();
        //const auto violation_name = cfg_->data_->name();
        const auto violation_id = violation_id_;
        const auto snapshots = snapshots_;
        const auto enable_output_picture = cfg_->data_->enable_output_picture();
        //const auto enable_save_picture = cfg_->data_->enable_save_debug_picture();
        auto action = [=](ICAlgEngine* engine) -> spEventProto {
            auto retv = std::make_shared<inference::Event>();
            inference::Event& event = *retv;
            event.set_event_type(EventTypeMassiveflow);

            inference::MassiveFlowEvent * mass_event = event.mutable_massive_flow_event();
            mass_event->set_stream_id(stream_id);
            mass_event->set_task_id(stream_id);
            mass_event->set_event_type(atoi(violation_code.c_str()));

            for(int i=0;i<snapshots.size();i++){
                auto& image = snapshots[i].image;
                auto snap1 = mass_event->add_snapshots();
                snap1->set_now(snapshots[i].now.time_since_epoch().count());
                if (enable_output_picture){
                    snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
                }
            }

            return retv;
        };
        retv.push_back(action);
        return retv;
    }

    result_list_t ViolationFightClassify::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        // if (objs.flow_info.fight_event_.predict_score > cfg_->fight_classify_score_thresh_
            // && objs.flow_info.fight_event_.is_bk_fighting){
        result_list_t retv;
        if(!check_time_valid()){
            return retv;
        }
        if (objs.flow_info.fight_event_.is_bk_fighting){
            time_t now = std::time(NULL);
            bool skip  = (now-last_report_time_) < cfg_->data_->cooling_second();
            if (!skip){
                last_report_time_ = now;
                this->clear_snapshot();
                this->add_snapshot(BoxF(), objs);
                return get_results();
            }else{
                LOG(INFO) <<"banner cooling time, skip  " ;
            }
        }
        return retv;
    }

    ViolationFightClassifyFactory::ViolationFightClassifyFactory(const std::string& id, const std::string& cfg)
            :IViolationFactory(),
             id_(id),
             cfg_(std::make_shared<ViolationMassiveflowCommonConfig>(cfg)){}

    const std::string& ViolationFightClassifyFactory::id()const
    {
        return id_;
    }

    spIViolation ViolationFightClassifyFactory::CreateIViolation(const BoxF& obj)
    {
        if (obj.label == -1)
        {
            return std::make_shared<ViolationFightClassify>(obj.uid, id_, cfg_);
        }
        else
        {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(FLOW_FIGHT_CODE, FightClassify);

} // namespace FLOW

