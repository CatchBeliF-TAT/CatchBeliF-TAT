#ifndef VSS_VIOLATION_CODE_HPP
#define VSS_VIOLATION_CODE_HPP

#include <string>
#include <regex>
namespace FLOW {
    const std::string EventTypeMassiveflow      = "massiveflow";
    const std::string EventTypeMassiveflowCount = "massiveflow_count";
    //=================> 客流code <==================
        //1.区域内人头超过一定范围上报或者定时上报
        static const std::string FLOW_QUEUE_COUNT_EXCEED_CODE("15");//排队人数超长报警
        static const std::string FLOW_CROWD_REGION_EXCEED_CODE("18");//区域人数报警
        static const std::string FLOW_QUEUE_COUNT_CODE("16");//排队人数上报，定时上报, 合并到15中
        static const std::string FLOW_CROWD_REGION_CODE("17");//区域人数，定时上报，合并到18中
        //2.人头跟踪过线类型
        static const std::string FLOW_HEADCOUNT_CODE("11");
        static const std::string FLOW_CROSS_LINE_CODE("8"); 
        static const std::string FLOW_OVERFENCE_CODE("4");
        static const std::string FLOW_RETROGRADE_CODE("14");//人员逆行
        //3.其他检人头类型
        static const std::string FLOW_ZONE_GUARD_CODE("19");
        //4.密度图
        static const std::string FLOW_CROWD_CODE("1");
        //5.其他类型客流code
        static const std::string FLOW_BANNER_CODE("2");
        static const std::string FLOW_FIGHT_CODE("3");
        static const std::string FLOW_RETENTION_CODE("6");
        //6.客流特殊需求
        static const std::string FLOW_PARADE_JUPAI_CODE("39");//黄埔举牌游行
        static const std::string FLOW_PARADE_JUQI_CODE("49");//黄埔举旗游行(小红旗)
    //=================> 公有云建筑平台code <==================
        //0.暂时没用到的code
        static const std::string FLOW_SAFEHELMET_CODE("26");//戴安全帽
        //1.原属客流的功能
        static const std::string BUILDING_ZONE_GUARD_CODE("7001");  //same to 19
        static const std::string BUILDING_CROWD_REGION_EXCEED_CODE("7002");//same to 18
        //2.工地系列code
        static const std::string BUILDING_NOSAFEHELMET_CODE("7003");//没戴安全帽
        static const std::string BUILDING_FALL_CODE("7004");//倒地
        static const std::string BUILDING_TEZHONGCHELIANGZHUAPAI("7005");//特种车辆抓拍
        static const std::string BUILDING_REFLECTIVE_VEST_CODE("7006");//反光背心
        static const std::string BUILDING_YICHANGTINGCHE("7010");//异常停车
        //3.截帧系列
        static const std::string BUILDING_TIMER_CODE("7007");//通用巡检	
        static const std::string BUILDING_TIMER_PATTERN("^7007[0-9]{2}$");//通用巡检
        static const std::string BUILDING_HEARTBEAT_CODE("7008");//心跳服务
        static const std::string BUILDING_HEAD_BODY_DETECT_CODE("7009");
        static const std::string BUILDING_HEAD_BODY_DETECT_PATTERN_CODE("^7009[0-9]{2}$");
    //=================> end <==================

    static const std::set<std::string> all_keliu_and_gongdi_code{\
        FLOW_QUEUE_COUNT_EXCEED_CODE,\
        FLOW_CROWD_REGION_EXCEED_CODE,\
        FLOW_QUEUE_COUNT_CODE,\
        FLOW_CROWD_REGION_CODE,\
        FLOW_HEADCOUNT_CODE,\
        FLOW_CROSS_LINE_CODE,\
        FLOW_OVERFENCE_CODE,\
        FLOW_RETROGRADE_CODE,\
        FLOW_ZONE_GUARD_CODE,\
        FLOW_CROWD_CODE,\
        FLOW_BANNER_CODE,\
        FLOW_FIGHT_CODE,\
        FLOW_RETENTION_CODE,\
        FLOW_PARADE_JUPAI_CODE,\
        FLOW_PARADE_JUQI_CODE,\
        FLOW_SAFEHELMET_CODE,\
        BUILDING_ZONE_GUARD_CODE,\
        BUILDING_CROWD_REGION_EXCEED_CODE,\
        BUILDING_NOSAFEHELMET_CODE,\
        BUILDING_FALL_CODE,\
        BUILDING_TEZHONGCHELIANGZHUAPAI,\
        BUILDING_REFLECTIVE_VEST_CODE,\
        BUILDING_YICHANGTINGCHE,\
        BUILDING_TIMER_CODE,\
        BUILDING_HEARTBEAT_CODE,\
        BUILDING_HEAD_BODY_DETECT_CODE
    };

    static const std::set<std::string> all_keliu_and_gongdi_code_regex{\
        BUILDING_TIMER_PATTERN,\
        BUILDING_HEAD_BODY_DETECT_PATTERN_CODE
    };

    inline bool judge_if_is_keliu_or_gongdi_violation_code(std::string code){
        for(auto e: all_keliu_and_gongdi_code){
            if(code==e){
                return true;
            }
        }
        for(auto e: all_keliu_and_gongdi_code_regex){
            if(std::regex_match(code, std::regex(e))){
                return true;
            }
        }
        return false;
    }
}   
#endif // VSS_VIOLATION_CODE_HPP
