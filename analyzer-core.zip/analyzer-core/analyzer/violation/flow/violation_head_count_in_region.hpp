#ifndef VSS_VIOLATION_HEAD_COUNT_IN_REGION_HPP
#define VSS_VIOLATION_HEAD_COUNT_IN_REGION_HPP

#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"

namespace FLOW {

    class ViolationHeadCountInRegionFactory : public IViolationFactory
    {
        public:
        ViolationHeadCountInRegionFactory(const std::string& id, const std::string& cfg);
            virtual ~ViolationHeadCountInRegionFactory()=default;

        public:
            virtual const std::string& id()const;
            virtual spIViolation CreateIViolation(const BoxF& obj);

        protected:
            std::string                              id_;
            spViolationMassiveflowCommonConfig       cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_HEAD_COUNT_IN_REGION_HPP

