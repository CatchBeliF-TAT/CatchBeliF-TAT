#ifndef VSS_VIOLATION_SAFEHELMET_V3_HPP
#define VSS_VIOLATION_SAFEHELMET_V3_HPP

#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"

namespace FLOW {

    class ViolationSafeHelmetV3Factory : public IViolationFactory
    {
        public:
        ViolationSafeHelmetV3Factory(const std::string& id, const std::string& cfg);
            virtual ~ViolationSafeHelmetV3Factory()=default;

        public:
            virtual const std::string& id()const;
            virtual spIViolation CreateIViolation(const BoxF& obj);

        protected:
            std::string                              id_;
            spViolationMassiveflowCommonConfig       cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_SAFEHELMET_V3_HPP

