#ifndef VSS_VIOLATION_FLOW_FIGHT_HPP
#define VSS_VIOLATION_FLOW_FIGHT_HPP

#include "violation/violation_interface.hpp"
#include "violation_flow_common.hpp"


namespace FLOW {

// class ViolationFightClassifyConfig {
//  public:
//   ViolationFightClassifyConfig(const std::string& json);
//   bool ParseJson(const std::string& json);

//  public:
//   std::shared_ptr<inference::ViolationConfig> data_;
//   std::string                                 code_;
//   bool                                        enable_output_picture_;
//   std::string                                 err_;
//   float                                       fight_classify_score_thresh_;
// };

// typedef std::shared_ptr<ViolationFightClassifyConfig> spViolationFightClassifyConfig;


 class ViolationFightClassifyFactory : public IViolationFactory
 {
public:
   ViolationFightClassifyFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationFightClassifyFactory()=default;

public:
    virtual const std::string& id()const;
    virtual spIViolation CreateIViolation(const BoxF& obj);

protected:
    std::string                              id_;
    spViolationMassiveflowCommonConfig      cfg_;
 };

} // namespace FLOW
#endif // VSS_VIOLATION_DEBUG_HPP

