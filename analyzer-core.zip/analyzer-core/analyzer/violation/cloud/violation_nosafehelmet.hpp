#ifndef VSS_VIOLATION_CLOUD_NOSAFEHELMET_HPP
#define VSS_VIOLATION_CLOUD_NOSAFEHELMET_HPP

#include <serving/violation_config.pb.h>
#include "violation/violation_interface.hpp"

namespace inference {
class ViolationConfig;
}

namespace FLOW {

class ViolationNosafehelmetConfig {
 public:
  ViolationNosafehelmetConfig(const std::string& json);
  bool ParseJson(const std::string& json);

 public:
  std::shared_ptr<inference::ViolationConfig> data_;
  std::string code_;
  bool enable_output_picture_;
  std::vector<float> violate_box_;
  int cooling_second_;
  float threshold_;
};

typedef std::shared_ptr<ViolationNosafehelmetConfig>
    spViolationNosafehelmetConfig;

class ViolationNosafehelmetFactory : public IViolationFactory {
 public:
  ViolationNosafehelmetFactory(const std::string& id, const std::string& cfg);
  virtual ~ViolationNosafehelmetFactory() = default;

 public:
  virtual const std::string& id() const;
  virtual spIViolation CreateIViolation(const BoxF& obj);

 protected:
  std::string id_;
  spViolationNosafehelmetConfig cfg_;
};

}  // namespace FLOW
#endif  // VSS_VIOLATION_DEBUG_HPP
