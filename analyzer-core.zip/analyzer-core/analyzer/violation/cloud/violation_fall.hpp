#ifndef VSS_VIOLATION_CLOUD_FALL_HPP
#define VSS_VIOLATION_CLOUD_FALL_HPP

#include <serving/violation_config.pb.h>
#include "serving/config.pb.h"
#include "violation/violation_interface.hpp"

namespace inference {
class ViolationConfig;
}

namespace FLOW {

class ViolationFallConfig {
 public:
  ViolationFallConfig(const std::string& json);
  bool ParseJson(const std::string& json);

 public:
  std::shared_ptr<inference::ViolationConfig> data_;
  std::string code_;
  bool enable_output_picture_;
  std::vector<float> violate_box_;
  int cooling_second_;
  float detect_thresh_;
  float fall_thresh_;

 protected:
  inference::FallDetect fall_config_;
};

typedef std::shared_ptr<ViolationFallConfig> spViolationFallConfig;

class ViolationFallFactory : public IViolationFactory {
 public:
  ViolationFallFactory(const std::string& id, const std::string& cfg);
  virtual ~ViolationFallFactory() = default;

 public:
  virtual const std::string& id() const;
  virtual spIViolation CreateIViolation(const BoxF& obj);

 protected:
  std::string id_;
  spViolationFallConfig cfg_;
};

}  // namespace FLOW
#endif  // VSS_VIOLATION_DEBUG_HPP