#include "violation_safehelmet.hpp"

#include <memory>
#include <unordered_map>

#include "common/helper.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation/violation_util.hpp"
#include "violation_cloud_base.hpp"

namespace FLOW {

using namespace std;

ViolationSafehelmetConfig::ViolationSafehelmetConfig(const std::string& json)
    : cooling_second_(1) {
  //  const auto& document = get_document(json);
  //  code_ = get_string(document, "code", code_);
  //  enable_output_picture_ =
  //      get_bool(document, "enable_output_picture", enable_output_picture_);
  ////  violate_box = get_array<float>(document, "violate_box", violate_box);

  std::string err;
  auto violation_cfg = std::make_shared<inference::ViolationConfig>();
  json2pb(json, violation_cfg.get(), &err);
  if (!err.empty()) {
    LOG(WARNING) << err << ", json= " << json;
    return;
  }
  auto& cfg = *violation_cfg;
  const int MIN_SIZE = 2 * 3;
  cooling_second_ =
      cfg.has_cooling_second() ? cfg.cooling_second() : cooling_second_;
  for (int i = 0; i < cfg.conditions_size(); i++) {
    const auto& cond = cfg.conditions(i);
    if (cond.name() == "violate_box") {
      CHECK_GE(cond.data_size(), MIN_SIZE);
      std::copy_n(cond.data().begin(), cond.data_size() / 2 * 2,
                  std::back_inserter(violate_box_));
    }
  }
  enable_output_picture_ = cfg.enable_output_picture();
  data_ = violation_cfg;
}

class ViolationSafehelmetClassify : public ViolationCloudBase {
 public:
  ViolationSafehelmetClassify(int object_id, const std::string& violation_id,
                              const spViolationSafehelmetConfig cfg)
      : ViolationCloudBase(object_id, violation_id, cfg->data_), cfg_(cfg) {}

  virtual ~ViolationSafehelmetClassify() = default;

 public:
  virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
  virtual result_list_t get_results() const;
  void log_info(const ImageObjectsInfo& objs) const;
  result_list_t try_get_alarm(const ImageObjectsInfo& objs);

 protected:
  const spViolationSafehelmetConfig cfg_;
  bool is_violation_;
  std::string stream_id_;
};

class ICAlgEngine;

result_list_t ViolationSafehelmetClassify::get_results() const {
  result_list_t retv;
  const auto obj_id = object_id_;
  const auto stream_id = snapshots_[0].image->channel_id;
  const auto violation_code = cfg_->data_->code();
  const auto violation_name = cfg_->data_->name();
  const auto violation_id = violation_id_;
  const auto snapshots = snapshots_;
  const auto enable_output_picture = cfg_->enable_output_picture_;
  // const auto enable_save_picture = cfg_->data_->enable_save_debug_picture();
  const auto is_violation = is_violation_;
  auto action = [=](ICAlgEngine* engine) -> spEventProto {
    auto retv = std::make_shared<inference::Event>();
    inference::Event& event_with_type = *retv;
    event_with_type.set_event_type(get_event_type_form_code(violation_code));
    inference::MassiveFlowEvent& cloudEvent =
        *(event_with_type.mutable_massive_flow_event());
    cloudEvent.set_stream_id(stream_id);
    cloudEvent.set_task_id(stream_id);
    cloudEvent.set_event_type(atoi(violation_code.c_str()));
    for (int i = 0; i < snapshots.size(); i++) {
      auto& image = snapshots[i].image;
      auto snap1 = cloudEvent.add_snapshots();
      snap1->set_now(snapshots[i].now.time_since_epoch().count());
      if (enable_output_picture) {
        snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
      }

      for (auto& box : image->objects) {
        auto obj = snap1->add_objects();
        std::stringstream buff;
        buff << "safehelmet";
        obj->set_type(buff.str());
        obj->set_score(box.score);
        obj->add_box(box.xmin);
        obj->add_box(box.ymin);
        obj->add_box(box.xmax);
        obj->add_box(box.ymax);
      }
    }

    return retv;
  };
  retv.push_back(action);
  return retv;
}

result_list_t ViolationSafehelmetClassify::check(BoxF& box,
                                                 const ImageObjectsInfo& objs) {
  result_list_t retv;
  if (!snapshots_.empty() &&
      get_elapsed_time(objs).count() < cfg_->cooling_second_ * 1000) {
    return retv;
  }
  VecBoxF inBoxes;
  std::copy_if(objs.clouds.safe_helmet_event.safe_helmets.begin(),
               objs.clouds.safe_helmet_event.safe_helmets.end(),
               std::back_inserter(inBoxes), [this](const BoxF& one) {
                 return valid_box_center_in_polygon(
                     one, cfg_->violate_box_.data(), cfg_->violate_box_.size());
               });

  VecBoxF outBoxes;
  for (int i = 0; i < inBoxes.size(); i++) {
    auto inBox = inBoxes[i];
    if (0 == inBox.label) {
      outBoxes.push_back(inBox);
      if (false) {
        if ((objs.count >= 0) && (objs.count <= 10000000)) {
          cv::Mat img_proto = *(objs.sframe->getMat());
          auto img_proto1 = img_proto.clone();
          cv::rectangle(img_proto1, cv::Point(inBox.xmin, inBox.ymin),
                        cv::Point(inBox.xmax, inBox.ymax),
                        cv::Scalar(0, 0, 255), 2, 1, 0);
          stringstream ss;
          ss << "test-out-count-"
             << "-frame" << objs.count << "-safehelmet-box-" << inBox.xmin
             << "-" << inBox.ymin << "-" << inBox.xmax << "-" << inBox.ymax
             << "-score-" << inBox.score << ".jpg";
          cv::imwrite(ss.str(), img_proto1);
        }
      }
    }
  }

  if (outBoxes.size() > 0) {
    this->clear_snapshot();
    this->add_snapshot(BoxF(), objs);
    this->snapshots_.back().image->objects = outBoxes;
    return get_results();
  }

  return retv;
}

ViolationSafehelmetFactory::ViolationSafehelmetFactory(const std::string& id,
                                                       const std::string& cfg)
    : IViolationFactory(),
      id_(id),
      cfg_(std::make_shared<ViolationSafehelmetConfig>(cfg)) {}

const std::string& ViolationSafehelmetFactory::id() const { return id_; }

spIViolation ViolationSafehelmetFactory::CreateIViolation(const BoxF& obj) {
  if (obj.label == -1) {
    return std::make_shared<ViolationSafehelmetClassify>(obj.uid, id_, cfg_);
  } else {
    return nullptr;
  }
}

REGISTER_VIOLATION(FLOW_SAFEHELMET_CODE, Safehelmet);

}  // namespace FLOW
