#ifndef VSS_OBJECT_VIOLATION_FACTORY_HPP
#define VSS_OBJECT_VIOLATION_FACTORY_HPP

#include <string>
#include <map>
#include "violation_interface.hpp"

namespace FLOW {

class ObjectViolations{
    public:
        ObjectViolations()=default;
        ViolationList& GetViolations() {return vl_;}
    protected:
        ViolationList vl_;
};
typedef std::shared_ptr<ObjectViolations> spObjectViolations;

class ObjectViolationsFactory
{
public:
    void AddViolation(const std::string& violation_id, const std::string& config);
    void RemoveViolation(const std::string& violation_id);
    bool CheckActiveTime(const std::string& violation_id, time_point_milliseconds now);

public:
    spObjectViolations CreateViolations(const BoxF& obj);
    spObjectViolations CreateViolations(const BoxF& obj, const std::string& violation_id);
    spObjectViolations CreateViolations(const std::string& violation_id);
    spObjectViolations CreateViolations(const BoxF& obj, time_point_milliseconds now);

protected:
    typedef std::map<std::string, spIViolationFactory> MapIViolationFactory;
    MapIViolationFactory factorys_;
};

} // namespace FLOW
#endif // VSS_OBJECT_VIOLATION_FACTORY_HPP
