#ifndef VSS_GANGWEI_VIOLATION_BASE_HPP
#define VSS_GANGWEI_VIOLATION_BASE_HPP

#include <chrono>
#include <vector>
#include <list>

#include "serving/violation_config.pb.h"

#include "violation/violation_interface.hpp"
#include "violation/violation_registry.hpp"

#include "violation_rule.hpp"

namespace FLOW {

typedef std::shared_ptr<inference::MassiveflowViolationConfig>  spGangweiViolationConfiguration;

using sys_milliseconds = std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds>;

struct GangweiFrameResult
{
    GangweiFrameResult(){
        violative = false;
    }
    bool                violative;
    sys_milliseconds    time;       
};

struct CountResult
{
    CountResult(){
        total_count = 0;
    }
    int                                     total_count;
    std::unordered_map<std::string, int>    area_count;       
};

class GangweiViolationRule;
typedef std::shared_ptr<GangweiViolationRule> spGangweiViolationRule;
typedef std::unordered_map<std::string, std::vector<float>> AreaMap;

class GangweiViolationConfig {
public:
    GangweiViolationConfig(const std::string& json);
    bool ParseJson(const std::string& json);

public:
    spGangweiViolationConfiguration violation_cfg_;
    AreaMap                     areas_;
};
typedef std::shared_ptr<GangweiViolationConfig> spGangweiViolationConfig;


// 岗位Violation基类
class GangweiViolationBase : public IViolation, public std::enable_shared_from_this<GangweiViolationBase>
{
public:
    GangweiViolationBase(int object_id, const std::string& violation_id, const spGangweiViolationConfiguration& violation_cfg);
    virtual ~GangweiViolationBase()=default;

public:
    virtual const std::string&              id()const;
    virtual result_list_t                   check(BoxF&, const ImageObjectsInfo&);

protected:
    virtual result_list_t                   process(BoxF&, const ImageObjectsInfo&)=0;
    virtual bool                            filter(const ImageObjectsInfo&)=0;

protected:
    const std::string                       violation_id_;
    const spGangweiViolationConfiguration       violation_cfg_;
    float                                   threshold_;
};

class GangweiViolationProcessBase : public GangweiViolationBase
{
public:
    GangweiViolationProcessBase(int object_id, const std::string& violation_id, const spGangweiViolationConfiguration& violation_cfg);
    virtual ~GangweiViolationProcessBase()=default;

protected:
    virtual result_list_t                           process(BoxF&, const ImageObjectsInfo&);
    virtual result_list_t                           get_results(const ImageObjectsInfo&);
    virtual GangweiFrameResult                          get_frame_result(const ImageObjectsInfo&)=0;
    virtual bool                                    filter(const ImageObjectsInfo&);

    bool                                            filter_static(const ImageObjectsInfo&);
    std::unordered_map<std::string, CountResult>   count(const ImageObjectsInfo&, AreaMap&);

protected:
    std::list<GangweiFrameResult>           frame_result_;
    sys_milliseconds                        last_alarm_time_;
    bool                                    need_filter_static_;
    ImageObjectsInfo                        last_alarm_info_;
    std::vector<spGangweiViolationRule>     rules_;
};

} // namespace FLOW
#endif // VSS_GANGWEI_VIOLATION_BASE_HPP
