#ifndef VSS_VIOLATION_GANGWEI_LIGANG_HPP
#define VSS_VIOLATION_GANGWEI_LIGANG_HPP

#include "violation/violation_interface.hpp"

namespace FLOW {

class GangweiViolationConfig;
typedef std::shared_ptr<GangweiViolationConfig> spGangweiViolationConfig;

class ViolationGangweiLigangFactory : public IViolationFactory 
{
public:
    ViolationGangweiLigangFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationGangweiLigangFactory()=default;

public:
    virtual const std::string&  id()const;
    virtual spIViolation        CreateIViolation(const BoxF& obj);

protected:
    std::string                 id_;
    spGangweiViolationConfig        cfg_;
    
};

} // namespace FLOW
#endif // VSS_VIOLATION_GANGWEI_LIGANG_HPP
