#ifndef VSS_GANGWEI_VIOLATION_RULE_HPP
#define VSS_GANGWEI_VIOLATION_RULE_HPP

#include <vector>
#include <string>

#include "gangwei_const.hpp"

namespace FLOW {

class GangweiViolationRule 
{
public:
    GangweiViolationRule(const std::string& id, const std::string& area);
    GangweiViolationRule(const std::string& id);
    virtual ~GangweiViolationRule()=default;

public:
    void SetIdentities(const std::vector<GangweiIdentity>& identities);
    void SetExceptIdentities(const std::vector<GangweiIdentity>& all, const std::vector<GangweiIdentity>& identities);
    void SetBehaviors(const std::vector<GangweiBehavior>& behaviors);
    void SetExceptBehaviors(const std::vector<GangweiBehavior>& all, const std::vector<GangweiBehavior>& behaviors);
    void SetIdentityScore(float identity_score);
    void SetBehaviorScore(float behavior_score);


    std::string Id();
    bool CheckArea(const std::string& area);
    bool CheckIdentity(GangweiIdentity identity, float identity_score);
    bool CheckBehavior(GangweiBehavior behavior, float behavior_score);

protected:
    std::string             id_;
    std::string             area_;
    std::vector<GangweiIdentity>   identities_;
    std::vector<GangweiBehavior>   behaviors_;
    float                   identity_score_;
    float                   behavior_score_;
};

} // namespace FLOW
#endif // VSS_GANGWEI_VIOLATION_RULE_HPP
