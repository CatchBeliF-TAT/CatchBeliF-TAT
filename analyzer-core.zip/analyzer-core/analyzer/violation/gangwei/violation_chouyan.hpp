#ifndef VSS_VIOLATION_GANGWEI_CHOUYAN_HPP
#define VSS_VIOLATION_GANGWEI_CHOUYAN_HPP

#include "violation/violation_interface.hpp"

namespace FLOW {

class GangweiViolationConfig;
typedef std::shared_ptr<GangweiViolationConfig> spGangweiViolationConfig;

class ViolationGangweiChouyanFactory : public IViolationFactory 
{
public:
    ViolationGangweiChouyanFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationGangweiChouyanFactory()=default;

public:
    virtual const std::string&  id()const;
    virtual spIViolation        CreateIViolation(const BoxF& obj);

protected:
    std::string                 id_;
    spGangweiViolationConfig        cfg_;
    
};

} // namespace FLOW
#endif // VSS_VIOLATION_GANGWEI_CHOUYAN_HPP
