#ifndef GANGWEI_CONST_HPP
#define GANGWEI_CONST_HPP

#include <string>
#include <unordered_map>
#include <vector>

namespace FLOW {

enum GangweiIdentity
{
    //当前仍使用ducha模型，使用督查算法结果
    GANGWEI_IDENTITY_PEOPLE = 0,
    GANGWEI_IDENTITY_LIGHT_BLUE = 1,
    GANGWEI_IDENTITY_DARK_BLUE = 2,
    GANGWEI_IDENTITY_MAJIA = 3,
    GANGWEI_IDENTITY_BLACK = 4,
};

enum GangweiBehavior
{
    //当前仍使用ducha模型，使用督查算法结果
    GANGWEI_BEHAVIOR_NORMAL = 0,
    GANGWEI_BEHAVIOR_PHONE = 1,
    GANGWEI_BEHAVIOR_CALL = 2,
    GANGWEI_BEHAVIOR_SMOKE = 3,
    GANGWEI_BEHAVIOR_SLEEP = 4,
};

static const std::string GANGWEI_CLASSIFY("gangwei_classify"); // 行为服饰type

static const std::string GANGWEI_WANSHOUJI_CODE("4000");
static const std::string GANGWEI_CHOUYAN_CODE("4010");
static const std::string GANGWEI_SHUIJIAO_CODE("4020");
static const std::string GANGWEI_LIGANG_CODE("4050");

static const std::vector<GangweiIdentity> ALL_GANGWEI_IDENTITIES = {GANGWEI_IDENTITY_PEOPLE, GANGWEI_IDENTITY_LIGHT_BLUE, GANGWEI_IDENTITY_DARK_BLUE, GANGWEI_IDENTITY_MAJIA, GANGWEI_IDENTITY_BLACK};
static const std::vector<GangweiBehavior> ALL_GANGWEI_BEHAVIORS = {GANGWEI_BEHAVIOR_NORMAL, GANGWEI_BEHAVIOR_PHONE, GANGWEI_BEHAVIOR_CALL, GANGWEI_BEHAVIOR_SMOKE, GANGWEI_BEHAVIOR_SLEEP};

static const std::unordered_map<int, std::string> GANGWEI_IDENTITY_NAME_MAP{{GANGWEI_IDENTITY_PEOPLE,"people"},
                                                                            {GANGWEI_IDENTITY_LIGHT_BLUE,"lightBlue"},
                                                                            {GANGWEI_IDENTITY_DARK_BLUE,"darkBlue"},
                                                                            {GANGWEI_IDENTITY_MAJIA,"maJia"},
                                                                            {GANGWEI_IDENTITY_BLACK,"black"}};
static const std::unordered_map<int, std::string> GANGWEI_BEHAVIOR_NAME_MAP{{GANGWEI_BEHAVIOR_NORMAL,"normal"},
                                                                            {GANGWEI_BEHAVIOR_PHONE,"phone"},
                                                                            {GANGWEI_BEHAVIOR_CALL,"call"},
                                                                            {GANGWEI_BEHAVIOR_SMOKE,"smoke"},
                                                                            {GANGWEI_BEHAVIOR_SLEEP,"sleep"}};
}
#endif //GANGWEI_CONST_HPP
