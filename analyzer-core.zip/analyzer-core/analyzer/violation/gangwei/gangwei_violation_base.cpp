#include "gangwei_violation_base.hpp"

#include "common/log.hpp"
#include "common/helper.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_event.pb.h"

#include "violation/violation_util.hpp"

namespace FLOW {

class ICAlgEngine;

//
// GangweiViolationConfig
//
GangweiViolationConfig::GangweiViolationConfig(const std::string& json)
{
    auto result = this->ParseJson(json);
    CHECK(result);
}

bool GangweiViolationConfig::ParseJson(const std::string& json) {
    std::string err;
    violation_cfg_ = std::make_shared<inference::MassiveflowViolationConfig>();
    LOG(INFO) << "json: " << json;
    json2pb(json, violation_cfg_.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }

    // validate config
    const auto& cfg = *violation_cfg_;
    if (cfg.min_time_threshold() < 10 || cfg.min_time_threshold() > 3600) {
        LOG(WARNING) << "min_time_threshold should between [10, 3600]";
        return false;
    }
    if (cfg.cooling_second() < 10 || cfg.cooling_second() > 3600) {
        LOG(WARNING) << "cooling_second should between [10, 3600]";
        return false;
    }
    if (cfg.min_time_threshold() > cfg.cooling_second()) {
        LOG(WARNING) << "min_time_threshold must <= cooling_second";
        return false;
    }

    areas_.clear();
    for (int i=0; i<cfg.roi_size(); i++) {
        const auto& roi = cfg.roi(i);
        std::vector<float> area;

        auto point_size = roi.data_size();
        if (point_size %2 !=0 || point_size < 6) {
            LOG(WARNING) << "scope length should be even and >= 6";
            return false;
        }

        std::copy_n(roi.data().begin(), point_size, std::back_inserter(area));
        areas_[std::to_string(i)] = area;
    }
    return true;
}

void clear_expired_frame_result(std::list<GangweiFrameResult>& result, int duration) {
    if (result.size() <= 0) {
        return;
    }
    auto last = result.back().time;
    for (auto iter = result.begin(); iter != result.end();) {
        auto diff = last - iter->time;
        if (diff.count() > duration){
            iter = result.erase(iter);
        } else {
            // no need go through all data because it is sorted by time
            // the rest data will surely in duration
            break;
        }
    }
}

//
// GangweiViolationBase
//
GangweiViolationBase::GangweiViolationBase(int object_id, const std::string& violation_id, const spGangweiViolationConfiguration& violation_cfg)
    : violation_id_(violation_id)
    , violation_cfg_(violation_cfg)
{
    threshold_ = violation_cfg_->threshold();
    if (threshold_ <= 0) {
        threshold_ = 0.8;
    }
}

const std::string& GangweiViolationBase::id() const{
    return violation_id_;
}

result_list_t GangweiViolationBase::check(BoxF& box, const ImageObjectsInfo& objs)
{
    if (!filter(objs)) {
        return result_list_t();
    }

    return process(box, objs);
}

//
// GangweiViolationProcessBase
//
GangweiViolationProcessBase::GangweiViolationProcessBase(int object_id, const std::string& violation_id, const spGangweiViolationConfiguration& violation_cfg)
    : GangweiViolationBase(object_id, violation_id, violation_cfg)
    , need_filter_static_(false)
{
    threshold_ = violation_cfg_->threshold();
    if (threshold_ <= 0) {
        threshold_ = 0.8;
    }
}

bool GangweiViolationProcessBase::filter(const ImageObjectsInfo& objs) {
    return objs.type & GANGWEI_DETECT_TYPE;
}

result_list_t GangweiViolationProcessBase::process(BoxF& box, const ImageObjectsInfo& objs)
{
    auto result = get_frame_result(objs);
    auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
    result.time = now;
    frame_result_.push_back(result);

    auto diff = now - frame_result_.front().time;
    if (diff.count() < violation_cfg_->min_time_threshold()*1000) {
        return result_list_t();
    }

    diff = now - last_alarm_time_;
    if (diff.count() < violation_cfg_->cooling_second()*1000) {
        clear_expired_frame_result(frame_result_, violation_cfg_->min_time_threshold()*1000);
        return result_list_t();
    }

    bool send_alarm = false;
    float count = 0;
    for (auto& res : frame_result_) {
        if (res.violative) {
            count++;
        }
    }
    LOG(INFO) << "task : " << objs.channel_id
                << ", model : " << violation_cfg_->code()
                << ", count : " << count << " / " << frame_result_.size()
                << ", ratio : " << count/frame_result_.size()
                << ", threshold : " << threshold_;
    if (count/frame_result_.size() > threshold_) {
        send_alarm = true;
    }

    clear_expired_frame_result(frame_result_, violation_cfg_->min_time_threshold()*1000);

    if (send_alarm){
        if (need_filter_static_ && filter_static(objs)) {
            LOG(INFO) << "try to send alarm for : " << objs.channel_id
                      << ", at " << now.time_since_epoch().count()
                      << ", but ignored due to static filter";
            return result_list_t();
        }

        LOG(INFO) << "send alarm for task : " << objs.channel_id
                  << ", at " << now.time_since_epoch().count();
        last_alarm_time_ = now;
        return get_results(objs);
    }
    return result_list_t();
}


std::unordered_map<std::string, CountResult> GangweiViolationProcessBase::count(const ImageObjectsInfo& info, AreaMap& areas)
{
    std::unordered_map<std::string, CountResult> retv;
    for (const auto& detection : info.gangwei_objects) {
        for (const auto& area_iter : areas) {
            auto& area_id = area_iter.first;
            auto& area = area_iter.second;
            bool found = false;
            for(const auto& rule : rules_) {
                if (!valid_box_center_bottom_in_polygon(detection, area.data(), area.size())) {
                    continue;
                }
                if (!rule->CheckIdentity(GangweiIdentity(detection.ducha_colour.type), detection.ducha_colour.score)) {
                    continue;
                }
                if (!rule->CheckBehavior(GangweiBehavior(detection.ducha_action.type), detection.ducha_action.score)) {
                    continue;
                }
                found = true;
                retv[rule->Id()].total_count++;
                retv[rule->Id()].area_count[area_id]++;
            }

            if (found) {
                break;
            }
        }
    }
    return retv;
}

bool GangweiViolationProcessBase::filter_static(const ImageObjectsInfo& info)
{
    auto last_info = last_alarm_info_;
    last_alarm_info_ = info;

    if (info.gangwei_objects.size() != 1 && last_info.gangwei_objects.size() != 1) {
        return false;
    }

    float average_perimeter = info.gangwei_objects[0].xmax - info.gangwei_objects[0].xmin
                            + info.gangwei_objects[0].ymax - info.gangwei_objects[0].ymin
                            + last_info.gangwei_objects[0].xmax - last_info.gangwei_objects[0].xmin
                            + last_info.gangwei_objects[0].ymax - last_info.gangwei_objects[0].ymin;

    float center1_x = (info.gangwei_objects[0].xmax + info.gangwei_objects[0].xmin)/2.0f;
    float center1_y = (info.gangwei_objects[0].ymax + info.gangwei_objects[0].ymin)/2.0f;
    float center2_x = (last_info.gangwei_objects[0].xmax + last_info.gangwei_objects[0].xmin)/2.0f;
    float center2_y = (last_info.gangwei_objects[0].ymax + last_info.gangwei_objects[0].ymin)/2.0f;

    float distance_x = center2_x-center1_x;
    float distance_y = center2_y-center1_y;
    float distance = sqrt(distance_x*distance_x + distance_y*distance_y);

    if (distance/average_perimeter >= 0.06) {
        return false;
    }


    return true;
}

result_list_t GangweiViolationProcessBase::get_results(const ImageObjectsInfo& info) {
    result_list_t retv;

    const auto task_id = info.channel_id;
    const auto stream_id = info.channel_id;
    const auto violation_code = violation_cfg_->code();
    const auto violation_id = violation_id_;
    const auto image_info = info;
    const auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());

    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event = *retv;
        event.set_event_type(GANGWEI_CLASSIFY);
        auto classify_event = event.mutable_massive_flow_event();
        classify_event->set_task_id(task_id);
        classify_event->set_stream_id(stream_id);
        classify_event->set_event_type(atoi(violation_code.c_str()));
        classify_event->set_violation_id(violation_id);

        auto snapshot = classify_event->add_snapshots();
        snapshot->set_now(now.time_since_epoch().count());
        snapshot->set_image(Helper::get_pic(*(image_info.sframe->getMat())));
        for(auto& obj : image_info.gangwei_objects){
            auto object = snapshot->add_objects();
            object->set_gangwei_identity_type(std::to_string(obj.ducha_colour.type));
            auto identity_name = GANGWEI_IDENTITY_NAME_MAP.find(obj.ducha_colour.type);
            if (identity_name != GANGWEI_IDENTITY_NAME_MAP.end()) {
                object->set_gangwei_identity_name(identity_name->second);
            }
            object->set_gangwei_identity_score(obj.ducha_colour.score);

            object->set_gangwei_behavior_type(std::to_string(obj.ducha_action.type));
            auto behavior_name = GANGWEI_BEHAVIOR_NAME_MAP.find(obj.ducha_action.type);
            if (behavior_name != GANGWEI_BEHAVIOR_NAME_MAP.end()) {
                object->set_gangwei_behavior_name(behavior_name->second);
            }
            object->set_gangwei_behavior_score(obj.ducha_action.score);

            object->add_box(obj.xmin);
            object->add_box(obj.ymin);
            object->add_box(obj.xmax);
            object->add_box(obj.ymax);
        }

        return retv;
    };

    retv.push_back(action);
    return retv;
}

} // namespace FLOW
