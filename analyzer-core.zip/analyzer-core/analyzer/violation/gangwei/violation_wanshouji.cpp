#include "violation_wanshouji.hpp"

#include <iterator>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "gangwei_violation_base.hpp"

namespace FLOW {

//
// ViolationGangweiWanshouji
//
class ViolationGangweiWanshouji : public GangweiViolationProcessBase
{
public:
    ViolationGangweiWanshouji(int object_id, const std::string& violation_id, const spGangweiViolationConfig& cfg);
    virtual ~ViolationGangweiWanshouji()=default;

public:
    virtual GangweiFrameResult get_frame_result(const ImageObjectsInfo& infos);
    
protected:
    const spGangweiViolationConfig    cfg_;
};

ViolationGangweiWanshouji::ViolationGangweiWanshouji(int object_id, const std::string& violation_id, const spGangweiViolationConfig& cfg)
    : GangweiViolationProcessBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    need_filter_static_ = false;

    auto phone = std::make_shared<GangweiViolationRule>("phone");
    phone->SetBehaviors({GANGWEI_BEHAVIOR_PHONE});
    rules_.push_back(phone);
}

GangweiFrameResult ViolationGangweiWanshouji::get_frame_result(const ImageObjectsInfo& info)
{
    GangweiFrameResult result;
    auto frame_count = count(info, cfg_->areas_);
    if (frame_count["phone"].total_count > 0 ) {
        result.violative = true;
    }
    
    return result;
}

//
// ViolationGangweiWanshoujiFactory
//
ViolationGangweiWanshoujiFactory::ViolationGangweiWanshoujiFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<GangweiViolationConfig>(cfg))
{
}

const std::string& ViolationGangweiWanshoujiFactory::id()const
{
    return id_;
}

spIViolation ViolationGangweiWanshoujiFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationGangweiWanshouji>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(GANGWEI_WANSHOUJI_CODE, GangweiWanshouji);

} // namespace FLOW
