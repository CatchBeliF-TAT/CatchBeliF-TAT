#include "violation_ligang.hpp"

#include <iterator>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "gangwei_violation_base.hpp"

namespace FLOW {

//
// ViolationGangweiLigang
//
class ViolationGangweiLigang : public GangweiViolationProcessBase
{
public:
    ViolationGangweiLigang(int object_id, const std::string& violation_id, const spGangweiViolationConfig& cfg);
    virtual ~ViolationGangweiLigang()=default;

public:
    virtual GangweiFrameResult get_frame_result(const ImageObjectsInfo& infos);
    
protected:
    const spGangweiViolationConfig    cfg_;
};

ViolationGangweiLigang::ViolationGangweiLigang(int object_id, const std::string& violation_id, const spGangweiViolationConfig& cfg)
    : GangweiViolationProcessBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    need_filter_static_ = false;

    auto people = std::make_shared<GangweiViolationRule>("people");
    rules_.push_back(people);
}

GangweiFrameResult ViolationGangweiLigang::get_frame_result(const ImageObjectsInfo& info)
{
    GangweiFrameResult result;
    auto frame_count = count(info, cfg_->areas_);
    if (violation_cfg_->roi_independent()){
        // 任一区域内无人，则离岗
        for (const auto& area : cfg_->areas_) {
            if (frame_count["people"].area_count[area.first] == 0) {
                result.violative = true;
                break;
            }
        }
    } else {
        // 所有区域加起来无人，则离岗
        if (frame_count["people"].total_count == 0) {
            result.violative = true;
        }
    }
    
    
    return result;
}

//
// ViolationGangweiLigangFactory
//
ViolationGangweiLigangFactory::ViolationGangweiLigangFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<GangweiViolationConfig>(cfg))
{
}

const std::string& ViolationGangweiLigangFactory::id()const
{
    return id_;
}

spIViolation ViolationGangweiLigangFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationGangweiLigang>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(GANGWEI_LIGANG_CODE, GangweiLigang);

} // namespace FLOW
