#include "violation_chouyan.hpp"

#include <iterator>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "gangwei_violation_base.hpp"


namespace FLOW {

//
// ViolationGangweiChouyan
//
class ViolationGangweiChouyan : public GangweiViolationProcessBase
{
public:
    ViolationGangweiChouyan(int object_id, const std::string& violation_id, const spGangweiViolationConfig& cfg);
    virtual ~ViolationGangweiChouyan()=default;

public:
    virtual GangweiFrameResult get_frame_result(const ImageObjectsInfo& infos);
    
protected:
    const spGangweiViolationConfig    cfg_;
};

ViolationGangweiChouyan::ViolationGangweiChouyan(int object_id, const std::string& violation_id, const spGangweiViolationConfig& cfg)
    : GangweiViolationProcessBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    need_filter_static_ = false;
    
    auto smoke = std::make_shared<GangweiViolationRule>("smoke");
    smoke->SetBehaviors({GANGWEI_BEHAVIOR_SMOKE});
    rules_.push_back(smoke);
}

GangweiFrameResult ViolationGangweiChouyan::get_frame_result(const ImageObjectsInfo& info)
{
    GangweiFrameResult result;
    auto frame_count = count(info, cfg_->areas_);
    if (frame_count["smoke"].total_count > 0 ) {
        result.violative = true;
    }
    
    return result;
}

//
// ViolationGangweiChouyanFactory
//
ViolationGangweiChouyanFactory::ViolationGangweiChouyanFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<GangweiViolationConfig>(cfg))
{
}

const std::string& ViolationGangweiChouyanFactory::id()const
{
    return id_;
}

spIViolation ViolationGangweiChouyanFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationGangweiChouyan>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(GANGWEI_CHOUYAN_CODE, GangweiChouyan);

} // namespace FLOW
