#include "violation_rule.hpp"

namespace FLOW {

//
// GangweiViolationRule
//
GangweiViolationRule::GangweiViolationRule(const std::string& id, const std::string& area)
    : id_(id)
    , area_(area)
    , identity_score_(-1)
    , behavior_score_(-1)
{
}

GangweiViolationRule::GangweiViolationRule(const std::string& id)
    : id_(id)
    , identity_score_(-1)
    , behavior_score_(-1)
{
}

void GangweiViolationRule::SetIdentities(const std::vector<GangweiIdentity>& identities)
{
    identities_ = identities;
}

void GangweiViolationRule::SetExceptIdentities(const std::vector<GangweiIdentity>& all, const std::vector<GangweiIdentity>& identities)
{
    identities_ = {};
    for (auto& val : all) {
        bool find = false;
        for (auto& val2 : identities) {
            if (val == val2) {
                find = true;
                break;
            }
        }
        if (!find) {
            identities_.push_back(val);
        }
    }
}

void GangweiViolationRule::SetBehaviors(const std::vector<GangweiBehavior>& behaviors)
{
    behaviors_ = behaviors;
}

void GangweiViolationRule::SetExceptBehaviors(const std::vector<GangweiBehavior>& all, const std::vector<GangweiBehavior>& behaviors)
{
    behaviors_ = {};
    for (auto& val : all) {
        bool find = false;
        for (auto& val2 : behaviors) {
            if (val == val2) {
                find = true;
                break;
            }
        }
        if (!find) {
            behaviors_.push_back(val);
        }
    }
}

void GangweiViolationRule::SetIdentityScore(float identity_score)
{
    identity_score_ = identity_score;
}

void GangweiViolationRule::SetBehaviorScore(float behavior_score)
{
    behavior_score_ = behavior_score;
}

std::string GangweiViolationRule::Id()
{
    return id_;
}

bool GangweiViolationRule::CheckArea(const std::string& area)
{
    return area_ == area;
}

bool GangweiViolationRule::CheckIdentity(GangweiIdentity identity, float identity_score)
{
    if (identities_.empty()) return true;
    if (identity_score_ > 0 && identity_score < identity_score_ ) {
        return false;
    }

    for(auto const& val : identities_) {
        if (val == identity) {
            return true;
        }
    }
    return false;
}

bool GangweiViolationRule::CheckBehavior(GangweiBehavior behavior, float behavior_score)
{
    if (behaviors_.empty()) return true;
    if (behavior_score_ > 0 && behavior_score < behavior_score_ ) {
        return false;
    }

    for(auto const& val : behaviors_) {
        if (val == behavior) {
            return true;
        }
    }
    return false;
}

} // namespace FLOW