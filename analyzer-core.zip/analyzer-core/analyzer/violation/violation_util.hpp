#ifndef VSS_VIOLATION_UTIL_HPP
#define VSS_VIOLATION_UTIL_HPP

#include "common/type.hpp"
#include "common/tad_internal.hpp"

namespace FLOW {
inline bool valid_box_in_range(const BoxF& box, int x, int y, float percent) {
    const float minx = x*percent;
    const float miny = y*percent;
    return (box.xmin > minx && box.xmax < (x-minx) &&
           box.ymin > miny && box.ymax < (y-miny));
}

inline float cross(const PointF &p1, const PointF &p2, const PointF &p3) {
  const float x1 = p2.x - p1.x;
  const float y1 = p2.y - p1.y;
  const float x2 = p3.x - p1.x;
  const float y2 = p3.y - p1.y;
  return x1 * y2 - x2 * y1;
}

inline bool is_intersect(const PointF &p1, const PointF &p2,
                         const PointF &p3,const PointF &p4) {
  bool intersect = false;
  if (std::max(p1.x, p2.x) >= std::min(p3.x, p4.x) &&
      std::max(p3.x, p4.x) >= std::min(p1.x, p2.x) &&
      std::max(p1.y, p2.y) >= std::min(p3.y, p4.y) &&
      std::max(p3.y, p4.y) >= std::min(p1.y, p2.y)) {
    if (cross(p1, p2, p3) * cross(p1, p2, p4) <= 0 &&
        cross(p3, p4, p1) * cross(p3, p4, p2) <= 0) {
      intersect = true;
    }
  }
  return intersect;
}

inline float is_intersect_v2(const PointF &p1, const PointF &p2,
                         const PointF &p3,const PointF &p4) {
  if (std::max(p1.x, p2.x) <= std::min(p3.x, p4.x) ||
      std::max(p3.x, p4.x) <= std::min(p1.x, p2.x) ||
      std::max(p1.y, p2.y) <= std::min(p3.y, p4.y) ||
      std::max(p3.y, p4.y) <= std::min(p1.y, p2.y)){
    return 0;
  }

  auto area1 = cross(p1, p2, p3);
  auto area2 = cross(p1, p2, p4);
  if ( area1*area2  > 0 ) {
    return 0;
  }
  auto area3 = cross(p3, p4, p1);
  auto area4 = area3 + area1 - area2;
  if ( area3*area4  > 0 ) {
    return 0;
  }

  auto t = area1 / ( area4 - area3 ); 
  t = (t>0.5f)?(1-t)/t:t/(1-t);
  return t;
}

// 线在box左侧
inline bool valid_box_across_lines_v2(const BoxF &box, const float *points, float percent) {
  const auto dx = (1.0f-percent)/2.0f*(box.xmax-box.xmin);
  const auto dy = (1.0f-percent)/2.0f*(box.ymax-box.ymin);
  const PointF s_s(points[0], points[1]), s_e(points[2], points[3]);
  const PointF b_s(box.xmin+dx, box.ymax-dy), b_e(box.xmax-dx, box.ymin+dy);
  return is_intersect(s_s, s_e, b_s, b_e);
}

// 线在box右侧
inline bool valid_box_across_lines_v1(const BoxF &box, const float *points, float percent) {
  const auto dx = (1.0f-percent)/2.0f*(box.xmax-box.xmin);
  const auto dy = (1.0f-percent)/2.0f*(box.ymax-box.ymin);
  const PointF s_s(points[0], points[1]), s_e(points[2], points[3]);
  const PointF b_s(box.xmax-dx, box.ymin+dy), b_e(box.xmin+dx, box.ymax-dy);
  return is_intersect(s_s, s_e, b_s, b_e);
}

// 线在box的percent比例缩小框上
inline bool valid_box_across_lines(const FLOW::BoxF &box, const float *points, float percent) {
  const auto dx = (1.0f-percent)/2.0f*(box.xmax-box.xmin);
  const auto dy = (1.0f-percent)/2.0f*(box.ymax-box.ymin);
  const PointF s_s(points[0], points[1]), s_e(points[2], points[3]);
  const PointF p1(box.xmin+dx, box.ymin+dy), p2(box.xmin+dx, box.ymax-dy), p3(box.xmax-dx, box.ymax-dy), p4(box.xmax-dx, box.ymin+dy);
  return is_intersect(s_s, s_e, p1, p2) || 
        is_intersect(s_s, s_e, p1, p4) || 
        is_intersect(s_s, s_e, p2, p3) ||
        is_intersect(s_s, s_e, p3, p4);

}

// box最下端边与框做交叉
inline bool valid_box_across_lines_gaosu(const BoxF &box, const float *points, float percent) {
  const auto dx = (1.0f-percent)/2.0f*(box.xmax-box.xmin);
  const auto dy = (1.0f-percent)/2.0f*(box.ymax-box.ymin);
  const PointF s_s(points[0], points[1]), s_e(points[2], points[3]);
  const PointF p1(box.xmin+dx, box.ymin+dy), p2(box.xmin+dx, box.ymax-dy), p3(box.xmax-dx, box.ymax-dy), p4(box.xmax-dx, box.ymin+dy);
  return  is_intersect(s_s, s_e, p3, p2);

}

// box1,box2的scale中心点线在的两侧
inline bool valid_boxes_scale_center_across_lines(
  const FLOW::BoxF &box1, const FLOW::BoxF &box2, float x, float y, const float *points) {
  const PointF s_s(points[0], points[1]), s_e(points[2], points[3]);
  const PointF b_s(box1.xmin+(box1.xmax-box1.xmin)*x, box1.ymin+(box1.ymax-box1.ymin)*y);
  const PointF b_e(box2.xmin+(box2.xmax-box2.xmin)*x, box2.ymin+(box2.ymax-box2.ymin)*y);
  return is_intersect(s_s, s_e, b_s, b_e);    
}

// box1,box2的中心点线在的两侧
inline bool valid_boxes_center_across_lines(const FLOW::BoxF &box1, const FLOW::BoxF &box2, const float *points) {
  const PointF s_s(points[0], points[1]), s_e(points[2], points[3]);
  return is_intersect(s_s, s_e, box1.CenterFloat(), box2.CenterFloat());    
}

inline float get_cross_line_angle(const FLOW::BoxF &box1,const FLOW::BoxF &box2, const float *points) {
    const double eps = 1e-10;
    const auto p1 = box1.CenterFloat();
    const auto p2 = box2.CenterFloat();
    const auto p3 = FLOW::Point<float>(points[0], points[1]);
    const auto p4 = FLOW::Point<float>(points[2], points[3]);
    double k1 = (p1.y - p2.y) / (p1.x - p2.x + eps);
    double k2 = (p3.y - p4.y) / (p3.x - p4.x + eps);
    double tan_theta = (k1 - k2) / (1 + k1 * k2);
    double theta = (double)(atan(tan_theta) * 180. / M_PI);
    return std::abs(theta);
}

inline float get_cross_line_angle(const float *points, const float *points2) {
    const double eps = 1e-10;
    const auto p1 = FLOW::Point<float>(points[0], points[1]);
    const auto p2 = FLOW::Point<float>(points[2], points[3]);
    const auto p3 = FLOW::Point<float>(points2[0], points2[1]);
    const auto p4 = FLOW::Point<float>(points2[2], points2[3]);
    double k1 = (p1.y - p2.y) / (p1.x - p2.x + eps);
    double k2 = (p3.y - p4.y) / (p3.x - p4.x + eps);
    double tan_theta = (k1 - k2) / (1 + k1 * k2);
    double theta = (double)(atan(tan_theta) * 180. / M_PI);
    return std::abs(theta);
}

//计算2维空间2个向量积
inline int get_cross_line_cross_product(const FLOW::BoxF &box1, const FLOW::BoxF &box2, const float *points2) {
    const auto p1 = box1.CenterFloat();
    const auto p2 = box2.CenterFloat();
    const auto p3 = FLOW::Point<float>(points2[0], points2[1]);
    const auto p4 = FLOW::Point<float>(points2[2], points2[3]);

    FLOW::Point<float> vector_car{p2.x-p1.x, p2.y-p1.y};
    FLOW::Point<float> vector_line{p4.x-p3.x, p4.y-p3.y};
    double cross_product = vector_car.x*vector_line.y - vector_line.x*vector_line.y;
    return static_cast<int> (cross_product);
}

inline float get_box_across_lines(const FLOW::BoxF &box, const float *points) {
    const PointF s_s(points[0], points[1]), s_e(points[2], points[3]);
    const PointF b_s(box.xmin, box.ymin), b_e(box.xmax, box.ymax);
    return is_intersect_v2(s_s, s_e, b_s, b_e);
}

inline int pnpoly(const float *vert_xy, int nvert, float testx, float testy)
{
  int ix, iy, jx, jy, c = 0;
  for (ix=0,iy=1,jx=nvert-2,jy=nvert-1; iy<nvert; jx=ix,jy=iy,ix+=2,iy+=2) {
    if ( ((vert_xy[iy]>testy) != (vert_xy[jy]>testy)) &&
     (testx < (vert_xy[jx]-vert_xy[ix]) * (testy-vert_xy[iy]) / (vert_xy[jy]-vert_xy[iy]) + vert_xy[ix]) )
       c = !c;
  }
  return c;
}

inline bool valid_box_intersect_polygon(const FLOW::BoxF &box, const float *points, int n) {
  const float center_x = (box.xmin+box.xmax)/2.0f;
  const float center_y = (box.ymin+box.ymax)/2.0f;
  const int   nums     = n/2*2;
  return pnpoly(points, nums, center_x, center_y) ||
        pnpoly(points, nums, box.xmin, box.ymin) || 
        pnpoly(points, nums, box.xmax, box.ymax);
}

// box1,box2的scale中心点在多边形内
inline bool valid_boxes_scale_center_in_polygon(const FLOW::BoxF &box, float x, float y, const float *points, int n) {
  const float center_x = box.xmin+(box.xmax-box.xmin)*x;
  const float center_y = box.ymin+(box.ymax-box.ymin)*y;
  const int   nums     = n/2*2;
  return pnpoly(points, nums, center_x, center_y);
}

inline bool valid_box_center_in_polygon(const FLOW::BoxF &box, const float *points, int n) {
  const float center_x = (box.xmin+box.xmax)/2.0f;
  const float center_y = (box.ymin+box.ymax)/2.0f;
  const int   nums     = n/2*2;
  return pnpoly(points, nums, center_x, center_y);
}

inline bool valid_box_center_bottom_in_polygon(const FLOW::BoxF &box, const float *points, int n) {
  const float center_x = (box.xmin+box.xmax)/2.0f;
  const float center_y = box.ymin*0.25+box.ymax*0.75;
  const int   nums     = n/2*2;
  return pnpoly(points, nums, center_x, center_y);
}

inline bool valid_box_box_distance(const FLOW::BoxF &box, const FLOW::BoxF &box2, float percent) {
  const float dx1=box2.xmax-box2.xmin;
  const float dy1=box2.ymax-box2.ymin;
  const float dx2=(box.xmax+box.xmin-box2.xmax-box2.xmin)/2;
  const float dy2=(box.ymax+box.ymin-box2.ymax-box2.ymin)/2;
  const float dd1 = dx1*dx1+dy1*dy1;
  const float dd2 = dx2*dx2+dy2*dy2;
  return dd1>0 && (dd2/dd1) < percent*percent;
}

inline float point_to_seg_distance_sqr(const PointF & pt, const PointF & p, const PointF & q, float& t)
{
	float pqx = q.x - p.x;
	float pqy = q.y - p.y;
	float dx = pt.x - p.x;
	float dy = pt.y - p.y;
	float d = pqx*pqx + pqy*pqy;
	t = pqx*dx + pqy*dy;
	if (d > 0) t /= d;
	if (t < 0) t = 0;
	else if (t > 1) t = 1;
	dx = p.x + t*pqx - pt.x;
	dy = p.y + t*pqy - pt.y;
	return dx*dx + dy*dy;
}

// p1->(p3,p4) - p2->(p3,p4)
inline float get_moving_distance_to_line(const PointF &p1, const PointF &p2,
                         const PointF &p3,const PointF &p4) {
  float t;
  auto dd1 = point_to_seg_distance_sqr(p1,p3,p4,t);
  auto dd2 = point_to_seg_distance_sqr(p2,p3,p4,t);
  return sqrtf(dd1)-sqrtf(dd2);
}

inline double get_polygon_area(const float* points, int n) {
  const int size = n/2;
  if (size < 3) return 0;

  double a = 0;
  for (int i = 0, j = size -1; i < size; ++i){
    a += ((double)points[j*2] + points[i*2]) * ((double)points[j*2+1] - points[i*2+1]);
    j = i;
  }
  return fabs(a * 0.5);
}
//todo, 可能和上面的功能重复
inline  bool interior_polygon(BoxF box, VecPointF polygon_points) {

        float xmax = INT_MIN;
        float xmin = INT_MAX;
        float ymax = INT_MIN;
        float ymin = INT_MAX;

        for(auto &point:polygon_points){
            xmax = xmax<point.x?point.x:xmax;
            ymax = ymax<point.y?point.y:ymax;

            xmin = xmin>point.x?point.x:xmin;
            ymin = ymin>point.y?point.y:ymin;
        }

        float center_point_x = (box.xmin + box.xmax)*1.0/2;
        float center_point_y = (box.ymin + box.ymax)*1.0/2;

        if(center_point_x>xmin && center_point_x<xmax && center_point_y>ymin && center_point_y<ymax){
            int intersections = 0;
            for(int i = 0;i < polygon_points.size(); i++){
                const auto start_point = polygon_points[i];
                const auto end_point = polygon_points[(i+1)%polygon_points.size()];
                if (center_point_y>=std::min(start_point.y,end_point.y)&&center_point_y<std::max(start_point.y,end_point.y)){
                    const float intersect_x = ((start_point.x- end_point.x)*(center_point_y - start_point.y)/(start_point.y-end_point.y)+start_point.x);
                    if (center_point_x>intersect_x){
                        intersections = !intersections;
                    }
                }
            }
            return intersections%2;
        }
        else{
            return false;
        }
}

inline VecInt filter_points_by_distance(const VecPointF & points, const PointF & p, const float distance){
  VecInt output;
  const auto d2 = distance*distance;
  const auto points_distance = [](const PointF& p1,const PointF& p2) { 
    return (p1.x-p2.x)*(p1.x-p2.x) + (p1.y-p2.y)*(p1.y-p2.y);
  };
  for(int i=0; i < points.size(); i++) {
    if (points_distance(p, points[i]) <= d2) {
      output.push_back(i);
    }
  }
  return std::move(output);
}

inline std::vector<VecInt> group_points_by_distance(const VecPointF & points, const float distance){
  std::vector<VecInt> retv,tmp_retv;
  const auto d2 = distance*distance;
  std::vector<VecFloat> distances(points.size(),VecFloat(points.size(),-1));
  const auto points_distance = [](const PointF& p1,const PointF& p2) { 
    return (p1.x-p2.x)*(p1.x-p2.x) + (p1.y-p2.y)*(p1.y-p2.y);
  };
  for(int i=0;i<points.size();i++) {
    for(int j=0;j<points.size();j++) {
      if(distances[i][j] >= 0) continue;
      if(i==j) distances[i][j]=0;
      distances[i][j] = points_distance(points[i],points[j]);
      distances[i][j] = distances[j][i];
    }
  }
  
  for(int i=0;i<points.size();i++) {
    tmp_retv[i].push_back(i);
  }

  const auto merge = [&distances, &d2](VecInt& v1, VecInt& v2){
    if (v1.empty() || v2.empty()) {
      return false;
    }
    for(int i=0;i<v1.size();i++) {
      for(int j=0;j<v2.size();j++) {
        if(distances[v1[i]][v2[j]] <= d2) {
          v1.insert(v1.end(), v2.begin(), v2.begin());
          v2.clear();
          return true;
        }
      }
    }
    return false;
  };

  for(int i=0;i<tmp_retv.size();i++) {
    int has_merge=0;
    for(int j=i;j<tmp_retv.size();j++) {
      has_merge += merge(retv[i],retv[j]);
    }
    if (has_merge) {
      i--;
    }
  }
  std::copy_if(tmp_retv.begin(), tmp_retv.end(),
              std::back_inserter(retv),
              [](const VecInt& v){ return !v.empty(); });
  return retv;
}

inline std::pair<float,float> get_foot_of_perpendicular(const std::pair<float,float>& p,
                                                 const std::pair<float,float>& s,
                                                 const std::pair<float,float>& e,
                                                 bool use_value=true) {
  std::pair<float,float> retv;
  double dx = s.first - e.first;
  double dy = s.second - e.second;

  if( abs(dx) < 1e-7 && abs(dy) < 1e-7 ) {
    retv = s;
    return use_value ? retv : std::pair<float,float>{0,0};
  }

  double u = (p.first - s.first)*(s.first - e.first) + (p.second - s.second)*(s.second - e.second);
  u = u/((dx*dx)+(dy*dy));

  if (!use_value) {
    retv.first = u;
    retv.second = u;
  } else {
    retv.first = s.first + u*dx;
    retv.second = s.second + u*dy;
  }
  return retv;
}

} // namespace FLOW
#endif // VSS_VIOLATION_UTIL_HPP
