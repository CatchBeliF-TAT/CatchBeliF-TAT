#ifndef VSS_VIOLATION_BASE_HPP
#define VSS_VIOLATION_BASE_HPP


#include <chrono>
#include <map>
#include <vector>

#include "serving/violation_config.pb.h"
#include "violation/violation_interface.hpp"
#include "violation/violation_registry.hpp"
#include "algorithm/traffic_light/traffic_light_recog.hpp"
namespace inference{
    class ViolationEvent;
}

namespace FLOW {

typedef std::shared_ptr<ImageObjectsInfo> spImageObjectsInfo;
using sys_milliseconds = std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds>;
struct ViolationSnapshot
{
    BoxF                box;
    VecBoxF             minor_boxes;
    spImageObjectsInfo  image;
    sys_milliseconds    now;

    float               avgspeed=-1.0f;
    float               speed_standard_deviation=-1.0f;
    float               ratio=-1.0f;
    int                 count=-1;
    float               time_interval=-1.0f;
    float               distance_interval=-1.0f;
    float               time_ratio=-1.0f;
    float               space_ratio=-1.0f;
    float               vehicle_queue=-1.0f;
    int                 traffic_status=-1;
    std::map<int, int>  cars_count_by_type;

    VecFloat            direction_angle_min_max;
    int                 traffic_light_color_while_violate_ = TrafficLight::kColorEmpty;
};

typedef std::shared_ptr<inference::ViolationConfig> spViolationConfig;
typedef std::shared_ptr<inference::MassiveflowViolationConfig> spMassiveflowViolationConfig;

class ViolationBase : public IViolation, public std::enable_shared_from_this<ViolationBase>
{
public:
    ViolationBase(const BoxF& box, const std::string& violation_id, const spViolationConfig& violation_cfg);
    ViolationBase(int object_id, const std::string& violation_id, const spViolationConfig& violation_cfg);
    ViolationBase(const BoxF& box, const std::string& violation_id, const spMassiveflowViolationConfig& violation_cfg);
    ViolationBase(int object_id, const std::string& violation_id, const spMassiveflowViolationConfig& violation_cfg);


    virtual ~ViolationBase()=default;

public:
    virtual const std::string&  id()const;
    virtual result_list_t       check(BoxF& box, const ImageObjectsInfo& objs)=0;
    virtual bool                check_ptz(const ImageObjectsInfo&)const;

protected:
    virtual size_t          add_snapshot(const int traffic_light_color, const BoxF& box, const ImageObjectsInfo& objs);
    virtual size_t          add_snapshot(const BoxF& box, const ImageObjectsInfo& objs);
    virtual size_t          add_snapshot(const BoxF& box, const ImageObjectsInfo& objs, const int index);
    virtual void            clear_snapshot();
    virtual result_list_t   get_results()const;
    virtual bool            results_filter(const inference::ViolationEvent& e)const;
    virtual void            snapshotidx_setter(inference::ViolationEvent& e)const;
    virtual std::chrono::milliseconds get_elapsed_time(const ImageObjectsInfo& frame, size_t since=-1) const;
    virtual std::chrono::milliseconds get_time_point(const ImageObjectsInfo& frame) const;

protected:
    static const std::string&   get_event_type_form_code(const std::string& code);
    static void                 clear_all_img(inference::ViolationEvent* event);

protected:
    std::vector<ViolationSnapshot>        snapshots_;

protected:
    const int                             object_id_;
    const std::string                     violation_id_;
    const spViolationConfig               violation_cfg_;
    const spMassiveflowViolationConfig    mf_violation_cfg_;
    const BoxF                            box_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_BASE_HPP
