#ifndef VSS_VIOLATION_COMMON_TEMPLATE_HPP
#define VSS_VIOLATION_COMMON_TEMPLATE_HPP

#include <functional>
#include "violation_common.hpp"

namespace FLOW {
//
// ViolationCommonFactoryTemplate
//
template< bool (*fnFilter)(const BoxF& obj) >
class ViolationObjectFilter{
public:
    ViolationObjectFilter(const std::string& ){}
    bool operator()(const BoxF& obj) { return fnFilter(obj); }
};

template< typename fnObjFilter >
class ViolationCommonFactoryTemplate : public ViolationCommonFactory
{
public:
    ViolationCommonFactoryTemplate( const std::string& violation_id,
                                    const std::string& violation_cfg)
                            : ViolationCommonFactory(violation_id, violation_cfg, fnObjFilter(violation_cfg))
    {
    }
    virtual ~ViolationCommonFactoryTemplate()=default;
    virtual spIViolation        CreateIViolation(const BoxF& obj) {
        return ViolationCommonFactory::CreateIViolation(obj);
    }
};


} // namespace FLOW
#endif // VSS_VIOLATION_COMMON_TEMPLATE_HPP
