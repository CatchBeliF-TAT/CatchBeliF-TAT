
#include <set>
#include <iterator>
#include <memory>
#include <unordered_map>
#include <numeric>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"

#include "serving/violation_event.pb.h"

#include "violation_object_detect.hpp"
#include "common/tad_internal.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"

namespace FLOW {

static const std::string OBJECT_DETECT_CODE("219901");
static const std::string OBJECT_DETECT_NEW_CODE("2199");
static const std::set<int> OBJECT_LIST = {OBJECT_TYPE_PERSON, OBJECT_TYPE_VEHICLE, OBJECT_TYPE_NONMOTOR};
static const std::unordered_map<std::string, int> OBJECT_NAME_LABEL = {{"Person", OBJECT_TYPE_PERSON},
                                                                       {"Vehicle", OBJECT_TYPE_VEHICLE},
                                                                       {"Nonmotor", OBJECT_TYPE_NONMOTOR}};

// ViolationObjectDetectConfig
class ViolationObjectDetectConfig {
public:
    ViolationObjectDetectConfig(const std::string& json)
        :violation_cfg_(std::make_shared<inference::ViolationConfig>()) {
        auto result = this->ParseJson(json);
        CHECK(result);
    }
    bool ParseJson(const std::string& json) {
        std::string err;
        json2pb(json, violation_cfg_.get(), &err);
        if (!err.empty()) {
            LOG(WARNING) << err << ", json= " << json;
            return false;
        }

        for (const auto& condition : violation_cfg_->conditions()) {
            if (condition.name() == "sub_type") {
                for (const auto& type : condition.sub_type()) {
                    if (OBJECT_NAME_LABEL.count(type) == 0) {
                        LOG(WARNING) << "invalid sub type : " << type;
                        return false;
                    }
                    catch_list_.insert(OBJECT_NAME_LABEL.at(type));
                }
            }
        }
        return true;
    }
public:
    spViolationConfig violation_cfg_;
    std::set<int> catch_list_;
};

// ViolationObjectDetect
class ViolationObjectDetect : public ViolationBase
{
public:
    ViolationObjectDetect(int object_id, const std::string& violation_id, const spViolationObjectDetectConfig& cfg);
    virtual ~ViolationObjectDetect() = default;

public:
    virtual result_list_t check(BoxF&, const ImageObjectsInfo&);
    virtual result_list_t get_results() const;

protected:
    spViolationObjectDetectConfig   cfg_;
    time_t                          last_report_time_;
    bool                            event_sent;
};

ViolationObjectDetect::ViolationObjectDetect(int object_id, const std::string& violation_id, const spViolationObjectDetectConfig& cfg)
    : ViolationBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
    , last_report_time_(0)
    , event_sent(false)
{
}

result_list_t ViolationObjectDetect::check(BoxF& box, const ImageObjectsInfo& objs)
{
    result_list_t retv;
    if (!cfg_->catch_list_.empty() && cfg_->catch_list_.count(box.label) == 0) {
        // 抓拍列表为空,说明抓拍所有
        // 不为空，且当前目标不在抓拍列表中，退出
        return retv;
    }

    if (cfg_->violation_cfg_->cooling_second() > 0) {
        // 有冷却时间，立刻预警一次，之后每隔冷却时间再预警一次
        time_t now;
        time(&now);
        if (now - last_report_time_ >= cfg_->violation_cfg_->cooling_second()) {
            this->clear_snapshot();
            this->add_snapshot(box, objs);
            retv = get_results();
            last_report_time_ = now;
        }
    } else {
        // 无冷却时间，只预警一次
        if (!event_sent) {
            this->clear_snapshot();
            this->add_snapshot(box, objs);
            retv = get_results();
            event_sent = true;
        }
    }
    return retv;
}

result_list_t ViolationObjectDetect::get_results() const {
    result_list_t retv;
    const auto obj_id = object_id_;
    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = violation_cfg_->code();
    const auto violation_name = violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;
    const auto enable_output_picture = violation_cfg_->enable_output_picture();
    const auto enable_save_picture = violation_cfg_->enable_save_debug_picture();

    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event_with_type = *retv;
        event_with_type.set_event_type(get_event_type_form_code(violation_code));
        inference::ViolationEvent& event = *(event_with_type.mutable_traffic_event());
        event.set_stream_id(stream_id);
        event.set_obj_id(obj_id);
        event.set_violation_id(violation_id);
        event.set_violation_code(violation_code);
        event.set_violation_name(violation_name);
        for(int i = 0; i < snapshots.size(); i++){
            auto& box = snapshots[i].box;
            auto& image = snapshots[i].image;
            auto& minor_boxes = snapshots[i].minor_boxes;
            auto snap1 = event.add_snapshots();
            snap1->set_pts(snapshots[i].image->pts);
            snap1->set_now(snapshots[i].now.time_since_epoch().count());
            if (enable_output_picture && image->sframe != nullptr){
                snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
            }
            if (image->ntp_time_stamp > 0) {
               snap1->set_ntp_time_stamp(image->ntp_time_stamp);
            }
            for(const auto& box : minor_boxes) {
                auto obj = snap1->add_minor_objects();
                obj->set_id(box.uid);
                obj->set_type(std::to_string(box.label));
                obj->set_score(box.score);
                obj->add_box(box.xmin);
                obj->add_box(box.ymin);
                obj->add_box(box.xmax);
                obj->add_box(box.ymax);
            }

            auto obj = snap1->add_objects();
            std::stringstream buff; buff<<box.label;
            obj->set_id(box.uid);
            obj->set_type(buff.str());
            obj->set_score(box.score);
            obj->add_box(box.xmin);
            obj->add_box(box.ymin);
            obj->add_box(box.xmax);
            obj->add_box(box.ymax);

            if (!image->sframe) {
                continue;
            }

            if (enable_save_picture){
                std::stringstream buff;
                buff <<stream_id <<"/pic_" << violation_id << "_" << obj_id <<"_" << i <<".jpg";
                auto fname = buff.str();
                std::ofstream of;
                mkdir(stream_id.c_str(),0755);
                of.open(fname);
                std::vector<unsigned char> im_data;
                cv::imencode(".jpg", *(image->sframe->getMat()), im_data);
                of.write((const char*)im_data.data(),im_data.size());
                LOG(INFO)<<"==>pic result "<<fname <<","<<of.is_open()<<","<<of.tellp();
                of.close();
            }
        }

        return retv;
    };
    retv.push_back(action);
    return retv;
}

// ViolationObjectDetectFactory
ViolationObjectDetectFactory::ViolationObjectDetectFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(std::make_shared<ViolationObjectDetectConfig>(cfg))
{
}

const std::string& ViolationObjectDetectFactory::id()const
{
    return id_;
}

spIViolation ViolationObjectDetectFactory::CreateIViolation(const BoxF& obj)
{
    if (OBJECT_LIST.count(obj.label) > 0){
        return std::make_shared<ViolationObjectDetect>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(OBJECT_DETECT_CODE, ObjectDetect);
REGISTER_VIOLATION(OBJECT_DETECT_NEW_CODE, ObjectDetect);

} // namespace FLOW
