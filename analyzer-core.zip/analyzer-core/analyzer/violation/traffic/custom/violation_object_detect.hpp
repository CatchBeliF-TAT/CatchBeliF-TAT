#ifndef VSS_VIOLATION_OBJECT_DETECT_HPP
#define VSS_VIOLATION_OBJECT_DETECT_HPP

#include <vector>
#include <memory>

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationObjectDetectConfig;
typedef std::shared_ptr<ViolationObjectDetectConfig> spViolationObjectDetectConfig;

class ViolationObjectDetectFactory : public ViolationCommonFactory 
 {
public:
    ViolationObjectDetectFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationObjectDetectFactory()=default;

public:
    virtual const std::string& id()const;
    virtual spIViolation CreateIViolation(const BoxF& obj);

protected:
    std::string                     id_;
    spViolationObjectDetectConfig   cfg_;
 };

} // namespace FLOW
#endif // VSS_VIOLATION_OBJECT_DETECT_HPP
