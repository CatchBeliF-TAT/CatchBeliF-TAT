#include "locus.hpp"
#include <math.h>
#include <vector>

namespace FLOW {

using namespace std;

static VecPointF Interpolation(VecPointF pointlist, int num_max_point = 100) {
  VecPointF normpointlist;
  //   int num_max_point = 100;
  int num_point = pointlist.size();
  int rep_num = (num_max_point - num_point) / (num_point - 1);
  int remain_num = num_max_point - rep_num * (num_point - 1) - num_point;
  std::vector<int> inter_num;
  for (int i = 0; i < num_point; i++) {
    if (remain_num > 0) {
      inter_num.push_back(rep_num + 1);
    } else {
      inter_num.push_back(rep_num);
    }
    remain_num--;
  }
  for (int i = 0; i < num_point - 1; i++) {
    float dx = (pointlist[i + 1].x - pointlist[i].x) / float(inter_num[i] + 1);
    float dy = (pointlist[i + 1].y - pointlist[i].y) / float(inter_num[i] + 1);
    // normpointlist.push_back(pointlist[i]);
    for (int j = 0; j < inter_num[i] + 1; j++) {
      PointF temp_p;
      temp_p.x = pointlist[i].x + dx * j;
      temp_p.y = pointlist[i].y + dy * j;
      normpointlist.push_back(temp_p);
    }
  }
  normpointlist.push_back(PointF{pointlist[num_point - 1]});
  return normpointlist;
}

double cross_angle(PointF p1, PointF p2, PointF p3, PointF p4) {
  double eps = 1e-10;
  double k1 = (p1.y - p2.y) / (p1.x - p2.x + eps);
  double k2 = (p3.y - p4.y) / (p3.x - p4.x + eps);
  double tan_theta = (k1 - k2) / (1 + k1 * k2);
  double theta = (double)(atan(tan_theta) * 180. / M_PI);
  return std::abs(theta);
}

void Locus::Update(const VecPointF pointlist) {
  if (count_cars_ == 0) {
    for (int i = 0; i < average_path_.size(); i++) {
      average_path_[i].x = pointlist[i].x;
      average_path_[i].y = pointlist[i].y;
      long_term_average_path_[i].x = long_term_average_path_[i].x;
      long_term_average_path_[i].y = long_term_average_path_[i].y;
    }
  } else {
    for (int i = 0; i < average_path_.size(); i++) {
      average_path_[i].x = moving_ratio_ * average_path_[i].x +
                           (1 - moving_ratio_) * pointlist[i].x;
      average_path_[i].y = moving_ratio_ * average_path_[i].y +
                           (1 - moving_ratio_) * pointlist[i].y;

      long_term_average_path_[i].x =
          long_term_moving_ratio_ * long_term_average_path_[i].x +
          (1 - long_term_moving_ratio_) * pointlist[i].x;
      long_term_average_path_[i].y =
          long_term_moving_ratio_ * long_term_average_path_[i].y +
          (1 - long_term_moving_ratio_) * pointlist[i].y;
    }
  }

  count_cars_++;
}

Locus::Locus() {
  moving_ratio_ = 0.9;
  long_term_moving_ratio_ = 0.99;
  num_max_point_ = 100;
  count_cars_ = 0;
  average_path_.resize(num_max_point_);
  memset(&average_path_[0], 0, sizeof(PointF) * num_max_point_);
  voliation_path_.resize(num_max_point_);
  memset(&voliation_path_[0], 0, sizeof(PointF) * num_max_point_);
  long_term_average_path_.resize(num_max_point_);
  memset(&long_term_average_path_[0], 0, sizeof(PointF) * num_max_point_);
  correct_path_.resize(num_max_point_);
  memset(&correct_path_[0], 0, sizeof(PointF) * num_max_point_);
}

void Locus::Add(const std::string id, PointF point) {
  if (point_map_.find(id) != point_map_.end()) {
    point_map_.at(id).push_back(point);
  } else {
    point_map_[id] = VecPointF{point};
  }
}

static int check_angle(VecPointF point_list, VecPointF average_path) {
  int miss_match_angle_count = 0;
  int path_diff = 10;
  for (int i = 0; i < average_path.size() - path_diff - 1; i++) {
    double angle = cross_angle(point_list[i], point_list[i + path_diff],
                               average_path[i], average_path[i + path_diff]);
    if (angle > 45.0f) {
      miss_match_angle_count++;
      //  return -1;
    }
  }
  if (float(miss_match_angle_count) / average_path.size() > 0.2) return -1;
  return 0;
}

bool Locus::Check(const std::string id) {
  if (point_map_.find(id) != point_map_.end()) {
    auto point_list = point_map_.at(id);
    if (point_list.size() <= 1) {
      return false;
    }
    auto point_list_norm = Interpolation(point_list);
    if (count_cars_ < 10) {
      Update(point_list_norm);
      return false;
    } else if (check_angle(point_list_norm, average_path_) == -1) {
      voliation_path_.assign(point_list_norm.begin(), point_list_norm.end());
      return true;
    } else {
      correct_path_.assign(point_list_norm.begin(), point_list_norm.end());
      Update(point_list_norm);
      return false;
    }
  }
  return false;
}

void Locus::Remove(const string id) {
  if (point_map_.find(id) != point_map_.end()) {
    point_map_.erase(id);
  }
}

}  // namespace FLOW
// class locus
