/*
 * @Author: your name
 * @Date: 2020-10-15 17:46:59
 * @LastEditTime: 2020-10-30 11:10:55
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /analyzer-flow/analyzer/algorithm/locus/locus.hpp
 */
#ifndef VSS_VIOLATION_LOCUS_HPP
#define VSS_VIOLATION_LOCUS_HPP 

#include "serving/config.pb.h"
#include "common/type.hpp"


namespace FLOW {


class Locus {
 public:

  Locus();
  
  void Add(const std::string id, PointF point);

  bool Check(const std::string id);

  void Remove(const std::string id);

  VecPointF AvgPath() { return average_path_; };

  VecPointF VoilationPath() { return voliation_path_; };

  VecPointF CorrectPath() { return correct_path_; };

 private:
  void Update(const VecPointF point_list);
  inference::Algorithm config_;
  float moving_ratio_;
  float long_term_moving_ratio_;
  int num_max_point_;
  int count_cars_;
  std::map<std::string, VecPointF> point_map_;
  VecPointF average_path_;
  VecPointF long_term_average_path_;
  VecPointF voliation_path_;
  VecPointF correct_path_;
  // std::vector<VecFloat> score_buffer_;
};



}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_LOCUS_LOCUS_HPP_
