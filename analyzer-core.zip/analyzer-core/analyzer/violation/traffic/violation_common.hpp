#ifndef VSS_VIOLATION_COMMON_HPP
#define VSS_VIOLATION_COMMON_HPP

#include <vector>
#include <memory>
#include <functional>

#include "serving/violation_config.pb.h"
#include "violation/violation_interface.hpp"
#include "violation_base.hpp"

namespace FLOW {

class ViolationCommonConfig;

typedef std::shared_ptr<ViolationCommonConfig> spViolationCommonConfig;


class ViolationCommonFactory : public IViolationFactory 
{
public:
    typedef std::function<bool(const BoxF& current_box)> fn_pre_check_action;

public:
    ViolationCommonFactory( const std::string& violation_id,
                            const std::string& violation_cfg);
    ViolationCommonFactory( const std::string& violation_id,
                            const std::string& violation_cfg,
                            fn_pre_check_action fn);
    virtual ~ViolationCommonFactory()=default;

public:
    virtual const std::string&  id()const;
    virtual spIViolation        CreateIViolation(const BoxF& obj) override;
    virtual bool                check_time(time_point_milliseconds now) override;

protected:
    std::string             violation_id_;
    spViolationCommonConfig violation_cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_COMMON_HPP
