#ifndef VSS_VIOLATION_REVOLVE_STATUS_CHECK_HPP
#define VSS_VIOLATION_REVOLVE_STATUS_CHECK_HPP

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

    class ViolationRevolveStatusCheckConfig;
    typedef std::shared_ptr<ViolationRevolveStatusCheckConfig> spViolationRevolveStatusCheckConfig;

    class ViolationRevolveStatusCheckFactory : public ViolationCommonFactory
    {
    public:
        ViolationRevolveStatusCheckFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationRevolveStatusCheckFactory()=default;

    public:
        virtual const std::string&      id()const;
        virtual spIViolation            CreateIViolation(const BoxF& obj);

    protected:
        std::string                                   id_;
        spViolationRevolveStatusCheckConfig           cfg_;
    };
} // namespace FLOW
#endif // VSS_VIOLATION_REVOLVE_STATUS_CHECK_HPP