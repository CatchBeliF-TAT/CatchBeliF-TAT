#ifndef VSS_VIOLATION_PAIDUICHANGDU_HPP
#define VSS_VIOLATION_PAIDUICHANGDU_HPP

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

    class ViolationPaiDuiChangDuConfig;
    typedef std::shared_ptr<ViolationPaiDuiChangDuConfig> spViolationPaiDuiChangDuConfig;

    class ViolationPaiDuiChangDuFactory : public ViolationCommonFactory
    {
    public:
        ViolationPaiDuiChangDuFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationPaiDuiChangDuFactory()=default;

    public:
        virtual const std::string& id()const;
        virtual spIViolation CreateIViolation(const BoxF& obj);

    protected:
        std::string                         id_;
        spViolationPaiDuiChangDuConfig      cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_PAIDUICHANGDU_HPP
