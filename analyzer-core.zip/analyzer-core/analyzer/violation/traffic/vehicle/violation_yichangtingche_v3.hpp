#ifndef __VIOLATION_YICHANGTINGCHE_V3_H__
#define __VIOLATION_YICHANGTINGCHE_V3_H__

#include <vector>
#include <memory>

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationYichangtingcheV3Config;
typedef std::shared_ptr<ViolationYichangtingcheV3Config> spViolationYichangtingcheV3Config;

class ViolationYichangtingcheV3Factory : public ViolationCommonFactory 
{
public:
    ViolationYichangtingcheV3Factory(const std::string& id, const std::string& cfg);
    virtual ~ViolationYichangtingcheV3Factory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                         id_;
    spViolationYichangtingcheV3Config   cfg_;
};

} // namespace FLOW

#endif // __VIOLATION_YICHANGTINGCHE_V3_H__