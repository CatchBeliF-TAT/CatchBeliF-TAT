#ifndef VSS_VIOLATION_ZHUANWANBURANGZHIXING_FJDC_HPP
#define VSS_VIOLATION_ZHUANWANBURANGZHIXING_FJDC_HPP

#include <memory>
#include <vector>
#include "violation/traffic/violation_common.hpp"

namespace FLOW {
class ViolationZhuanwanburangzhixingfjdcConfig;
typedef std::shared_ptr<ViolationZhuanwanburangzhixingfjdcConfig> spViolationZhuanwanburangzhixingfjdcConfig;
class ViolationZhuanwanburangzhixingfjdcFactory : public ViolationCommonFactory 
{
public:
    ViolationZhuanwanburangzhixingfjdcFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationZhuanwanburangzhixingfjdcFactory()=default;

public:
    virtual const std::string&  id()const;
    virtual spIViolation        CreateIViolation(const BoxF& obj);

protected:
    std::string                                 id_;
    spViolationZhuanwanburangzhixingfjdcConfig  cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_ZHUANWANBURANGZHIXING_FJDC_HPP
