
#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"

#include "serving/violation_config.pb.h"
#include "common/tad_internal.hpp"
#include "violation/conditions/line_condition.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_zhuanwanburangzhixingfjdc.hpp"

namespace FLOW {

static const std::string ZWBRZXFDJC_CODE("2122");

class ViolationZhuanwanburangzhixingfjdcConfig {
public:
    ViolationZhuanwanburangzhixingfjdcConfig(const std::string& json);

protected:
    bool ParseJson(const std::string& json);

public:
    typedef std::vector<float> VecFloat;
    float start_line[4];
    float violate_line[4];
    float stop_line[4];
    VecFloat fjdc_box;

    fn_check_action     start_line_checker;
    fn_check_action     violate_line_checker;
    fn_check_action     end_line_checker;

    spViolationConfig  violation_cfg;
};

//
// ViolationZhuanwanburangzhixingfjdcConfig
//
ViolationZhuanwanburangzhixingfjdcConfig::ViolationZhuanwanburangzhixingfjdcConfig(const std::string& json)
    : start_line{0.0f}
    , violate_line{0.0f}
    , stop_line{0.0f}
    , fjdc_box()
    , violation_cfg(std::make_shared<inference::ViolationConfig>())
{
    auto result = this->ParseJson(json);
    CHECK(result);
}

bool ViolationZhuanwanburangzhixingfjdcConfig::ParseJson(const std::string& json) {
    std::string err;
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }

    auto& cfg = *violation_cfg;
    const int MIN_SIZE = 4;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "start_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), MIN_SIZE, std::begin(start_line));
            start_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
        } else if (cond.name() == "violate_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), MIN_SIZE, std::begin(violate_line));
            violate_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
        } else if (cond.name() == "stop_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), MIN_SIZE, std::begin(stop_line));
            end_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
        } else if (cond.name() =="fjdc_box" || cond.name() =="person_box") {
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(fjdc_box));
        }
    }
    return start_line_checker && violate_line_checker && end_line_checker && fjdc_box.size() >= 4;
}

//
// ViolationZhuanwanburangzhixingfjdc
//
class ViolationZhuanwanburangzhixingfjdc : public ViolationBase
{
public:
    ViolationZhuanwanburangzhixingfjdc(int object_id, const std::string& violation_id, const spViolationZhuanwanburangzhixingfjdcConfig cfg);
    virtual ~ViolationZhuanwanburangzhixingfjdc()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& frame);

protected:
    enum STATUS{
        eUNDEFINE,
        eENTER_VIEW,
        eCROSS_VIOLATE,
        eCROSS_ENDLINE,
        eEND,
    };

protected:
    spViolationZhuanwanburangzhixingfjdcConfig  cfg_;
    STATUS                          status_;
    std::map<int, BoxF>             persions_;
    BoxF                            last_box_;
};

ViolationZhuanwanburangzhixingfjdc::ViolationZhuanwanburangzhixingfjdc(int object_id, const std::string& violation_id, const spViolationZhuanwanburangzhixingfjdcConfig cfg)
    : ViolationBase(object_id, violation_id, cfg->violation_cfg)
    , cfg_(cfg)
    , status_(eUNDEFINE)
    , persions_()
{
}

result_list_t ViolationZhuanwanburangzhixingfjdc::check(BoxF& box, const ImageObjectsInfo& frame)
{
    result_list_t retv;
    // init last_box_
    if (last_box_.uid == -1) {
        last_box_ = box;
    }
    std::shared_ptr<void> update_last_box(nullptr,[&](void*){
        last_box_ = box;
    });

    switch (status_)
    {
    case eUNDEFINE:
        if (valid_box_in_range(box, frame.sframe->width(), frame.sframe->height(), cfg_->violation_cfg->plate_available_box_percent()) &&
            cfg_->start_line_checker(last_box_, box, frame)){
            status_ = eENTER_VIEW;
            this->add_snapshot(box, frame);
            LOG(INFO)<<"==>enter view, "<< frame.channel_id<<","<<violation_id_<<","<<object_id_;
        }
        break;
    case eENTER_VIEW:
        if (cfg_->violate_line_checker(last_box_, box, frame)){
            status_ = eCROSS_VIOLATE;
            this->add_snapshot(box, frame);
            LOG(INFO)<<"==>cross violate line, "<< frame.channel_id<<","<<violation_id_<<","<<object_id_;
            std::for_each(frame.objects.begin(),frame.objects.end(),[=](const BoxF& one){
                if (one.label == OBJECT_TYPE_NONMOTOR &&
                        pnpoly(cfg_->fjdc_box.data(), cfg_->fjdc_box.size()/2*2, (one.xmin+one.xmax)/2, (one.ymin+one.ymax)/2)){
                    persions_[one.uid]=one;
                }
            });
        }
        break;
    case eCROSS_VIOLATE:
        if (cfg_->end_line_checker(last_box_, box, frame)){
            status_ = eCROSS_ENDLINE;
            LOG(INFO)<<"==>cross end line, "<< frame.channel_id<<","<<violation_id_<<","<<object_id_;

            const auto car1 = snapshots_.back().box.CenterFloat();
            const auto car2 = box.CenterFloat();
            auto cross_persion = std::find_if(frame.objects.begin(),frame.objects.end(), [=](const BoxF& one)->bool{
                if (one.label == OBJECT_TYPE_NONMOTOR && 
                        persions_.find(one.uid) != persions_.end() &&
                        pnpoly(cfg_->fjdc_box.data(), cfg_->fjdc_box.size()/2*2, (one.xmin+one.xmax)/2, (one.ymin+one.ymax)/2)){
                    const auto& one_old = persions_.find(one.uid)->second;
                    const auto persion1=one_old.CenterFloat();
                    const auto persion2=one.CenterFloat();
                    if (is_intersect(persion1,persion2,car1,car2)) {
                        return false;
                    }
                    // on car one side, check distance
                    const float dis1=get_moving_distance_to_line(persion1,persion2,car1,car2);
                    float min_move = (one.xmax-one.xmin)*(one.xmax-one.xmin) + (one.ymax-one.ymin)*(one.ymax-one.ymin);
                    min_move = sqrtf(min_move)/4.0f;
                    if (dis1<-min_move) {
                        return false;
                    }
                    return true;
                } else {
                    return false;
                }
            });

            if (cross_persion != frame.objects.end()) {
                status_ = eEND;
                this->add_snapshot(box, frame);
                retv = get_results();
            }
        }

        break;
    case eCROSS_ENDLINE:
    case eEND:
    default:
        break;
    }

    // update violate state
    static int colors[]={0,0,2,2,3};
    if (status_ != eUNDEFINE) {
        box.violate_state = colors[status_];
    }
    return retv;
}

//
// ViolationZhuanwanburangzhixingfjdcFactory
//
ViolationZhuanwanburangzhixingfjdcFactory::ViolationZhuanwanburangzhixingfjdcFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(std::make_shared<ViolationZhuanwanburangzhixingfjdcConfig>(cfg))
{
}

const std::string& ViolationZhuanwanburangzhixingfjdcFactory::id()const
{
    return id_;
}

spIViolation ViolationZhuanwanburangzhixingfjdcFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == OBJECT_TYPE_VEHICLE){
        return std::make_shared<ViolationZhuanwanburangzhixingfjdc>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(ZWBRZXFDJC_CODE, Zhuanwanburangzhixingfjdc);

} // namespace FLOW
