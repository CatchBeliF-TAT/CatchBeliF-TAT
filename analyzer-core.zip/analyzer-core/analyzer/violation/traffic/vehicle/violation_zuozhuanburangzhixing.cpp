#include "violation_zuozhuanburangzhixing.hpp"
#include "common/pbjson.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
namespace FLOW {

ViolationZzbrzxConfig::ViolationZzbrzxConfig(const std::string& json)
    : m_violation_cfg(std::make_shared<inference::ViolationConfig>()) {
    bool result = this->ParseJson(json);
    CHECK(result);
}

bool ViolationZzbrzxConfig::ParseJson(const std::string& json) {
    std::string err;
    json2pb(json, m_violation_cfg.get(), &err);
    if (!err.empty()) {
        LOG(WARNING) << err << ", json= " << json;
        return false;
    }

    auto& cfg = *m_violation_cfg;
    const int MIN_SIZE = 4;
    inference::Condition mid_condition;
    for (int i = 0; i < cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "zuo_start_line") {
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(m_zuo_start_line));
            m_zuo_start_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
            mid_condition = cfg.conditions(i);
        } else if (cond.name() == "zuo_end_line") {
            CHECK_GE(cond.data_size(), MIN_SIZE);
             std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(m_zuo_end_line));
            m_zuo_end_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
            
        } else if (cond.name() == "zhi_start_line") {
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(m_zhi_start_line));
        } else if (cond.name() == "zhi_end_line") {
            CHECK_GE(cond.data_size(), MIN_SIZE);
           std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(m_zhi_end_line));
        }
    }

    if(!m_zuo_start_line_checker || !m_zuo_end_line_checker) 
        return false;
    
    m_zuo_mid_line.push_back((m_zhi_start_line[0] + m_zhi_start_line[2]) / 2);
    m_zuo_mid_line.push_back((m_zhi_start_line[1] + m_zhi_start_line[3]) / 2);
    m_zuo_mid_line.push_back((m_zhi_end_line[0] + m_zhi_end_line[2]) / 2);
    m_zuo_mid_line.push_back((m_zhi_end_line[1] + m_zhi_end_line[3]) / 2);
   
    mid_condition.set_data(0,m_zuo_mid_line[0]);
    mid_condition.set_data(1,m_zuo_mid_line[1]);
    mid_condition.set_data(2,m_zuo_mid_line[2]);
    mid_condition.set_data(3,m_zuo_mid_line[3]);

    m_zuo_mid_line_checker = CreateLineCondition(mid_condition, false, google::protobuf::RepeatedField<float>());
    m_zuo_mid_line_converter =
        CoordinateTransform_copy(m_zuo_mid_line[0], m_zuo_mid_line[1], m_zuo_mid_line[2], m_zuo_mid_line[3]);
    
    m_zhi_violate_box.insert(m_zhi_violate_box.end(), m_zhi_start_line.begin(), m_zhi_start_line.end());
    if (is_intersect(PointF(m_zhi_start_line[0], m_zhi_start_line[1]), PointF(m_zhi_end_line[0], m_zhi_end_line[1]),
                     PointF(m_zhi_start_line[2], m_zhi_start_line[3]), PointF(m_zhi_end_line[2], m_zhi_end_line[3]))) {
        m_zhi_violate_box.insert(m_zhi_violate_box.end(), m_zhi_end_line.begin(), m_zhi_end_line.end());
    } else {
        m_zhi_violate_box.insert(m_zhi_violate_box.end(), m_zhi_end_line.begin() + 2, m_zhi_end_line.end());
        m_zhi_violate_box.insert(m_zhi_violate_box.end(), m_zhi_end_line.begin(), m_zhi_end_line.begin() + 2);
    }
    return true;
}

ViolationZuoZhuanBuRangZhiXing::ViolationZuoZhuanBuRangZhiXing(int object_id, const std::string& violation_id,
                                                               const spViolationZzbrzxConfig& cfg)
    : ViolationBase(object_id, violation_id, cfg->m_violation_cfg)
    , m_cfg(cfg)
    , m_enter_zuo_end_line(false)
    , m_becovered_is_zhixing(false)
    , m_status(eUNDEFINE)
    , m_box_center_in_mid(0.0f) {}

bool ViolationZuoZhuanBuRangZhiXing::EnterZuoStartLine(const BoxF& box, const ImageObjectsInfo& objs) {
    if (m_last_box.uid == -1) return false;

    return m_cfg->m_zuo_start_line_checker(m_last_box, box, objs);
}
bool ViolationZuoZhuanBuRangZhiXing::EnterZuoMidLine(const BoxF& box,const ImageObjectsInfo& objs)
{
    return m_cfg->m_zuo_mid_line_checker(m_last_box, box, objs);
}
bool ViolationZuoZhuanBuRangZhiXing::EnterZuoEndLine(const BoxF& box, const ImageObjectsInfo& objs) {
    return m_cfg->m_zuo_end_line_checker(m_last_box, box, objs);
}
bool ViolationZuoZhuanBuRangZhiXing::HasHistoryZhiCarOnBecovered(const BoxF& box, const ImageObjectsInfo& objs) {
    //左转车中心点投影x坐标
    m_box_center_in_mid = m_cfg->m_zuo_mid_line_converter.X(box.CenterFloat().x, box.CenterFloat().y);
    for (auto obj : objs.objects) {  //是否为记录的历史直行车道的车辆
        if (m_zhi_car_history.find(obj.uid) == m_zhi_car_history.end()) continue;
        //是否在直行车道内
        if (!BoxCenterInZhiXingArea(obj)) {
            //debug
            LOG(INFO) << "==>debug history obj.uid " << obj.uid<<"not in ZhiXingArea"<< objs.channel_id << "," << violation_id_ << ","
                          << object_id_;
            continue;
        }
        float m_obj_center_in_mid = m_cfg->m_zuo_mid_line_converter.X(obj.CenterFloat().x, obj.CenterFloat().y);
        //中心点的投影坐标是否被遮挡
        if (m_box_center_in_mid < m_obj_center_in_mid) {
            LOG(INFO) << "==>debug history obj.uid " << obj.uid<<"touying > box "<< objs.channel_id << "," << violation_id_ << ","
                          << object_id_;
            continue;
        };
        //记录被遮挡的车辆
        m_zhi_car_becovered.insert(obj.uid);
    }

    if (m_zhi_car_becovered.empty()) return false;
    return true;
}

bool ViolationZuoZhuanBuRangZhiXing::AnyoneCarBecoveredisZhiXing(const BoxF& box, const ImageObjectsInfo& objs,int & becovered_someone) {
    for (auto obj : objs.objects) {  //是否为被遮挡的车辆
        if (m_zhi_car_becovered.find(obj.uid) == m_zhi_car_becovered.end()) continue;
        //是否在直行车道内
        if (!BoxPointsInZhiXingArea(obj)) {
            continue;
        }
        float m_obj_center_in_mid = m_cfg->m_zuo_mid_line_converter.X(obj.CenterFloat().x, obj.CenterFloat().y);
        //被遮挡的车投影小于左车之前的投影，continue
        if (m_box_center_in_mid > m_obj_center_in_mid) {
            continue;
        };
        becovered_someone = obj.uid;
        return true;
    }
    return false;
}

bool ViolationZuoZhuanBuRangZhiXing::BoxCenterInZhiXingArea(const BoxF& box) {
    return valid_box_center_in_polygon(box, m_cfg->m_zhi_violate_box.data(), m_cfg->m_zhi_violate_box.size());
}

bool ViolationZuoZhuanBuRangZhiXing::BoxPointsInZhiXingArea(const BoxF& box)
{
    return valid_box_intersect_polygon(box, m_cfg->m_zhi_violate_box.data(), m_cfg->m_zhi_violate_box.size());
}

bool ViolationZuoZhuanBuRangZhiXing::BoxsPointsInZhiXingArea(const BoxF& filter_box, const ImageObjectsInfo& objs) {
    for (auto& obj : objs.objects) {
        if (obj.label != OBJECT_TYPE_VEHICLE) {
            continue;
        }
        if (obj.uid == filter_box.uid) {
            continue;
        }
        if (!BoxPointsInZhiXingArea(obj)) {
            continue;
        }
        //debug
        LOG(INFO) << "==>debug obj.uid " << obj.uid<<"in ZhiXingArea"<< objs.channel_id << "," << violation_id_ << ","
                          << object_id_;
        m_zhi_car_history.insert(obj.uid);
    }

    if (m_zhi_car_history.empty()) return false;

    return true;
}


result_list_t ViolationZuoZhuanBuRangZhiXing::check(BoxF& box, const ImageObjectsInfo& objs) {
    result_list_t retv;

    switch (m_status) {
        case eUNDEFINE:
            
            //左转车是否进入左转起始线
            if (!EnterZuoStartLine(box, objs)) {
                break;
            }
            this->m_zhi_car_history.clear();
            this->clear_snapshot();
            this->add_snapshot(box, objs);

            LOG(INFO) << "==>zuo car enter start line ;" << objs.channel_id << "," << violation_id_ << "," << object_id_;

            //记录直行车道范围内的车辆，若无车，结束
            if (!BoxsPointsInZhiXingArea(box, objs)) {
                LOG(INFO) << "==>no car on zhixing area ,end ;" << objs.channel_id << "," << violation_id_ << ","
                          << object_id_;
                m_status = eEND;
            }
            else
                m_status = eEnterZhiXingArea;
            break;
        case eEnterZhiXingArea:

            //左转车是否进入直行车道中间线
            if (!EnterZuoMidLine(box,objs)) {
                break;
            }
            LOG(INFO) << "==>zuo car enter mid line ;" << objs.channel_id << "," << violation_id_ << ","
                      << object_id_;
            //左转车已到直行车道，判断是否遮挡了之前记录的直行车
            if (!HasHistoryZhiCarOnBecovered(box, objs)) {
                //未遮挡，结束
                LOG(INFO) << "==>zuo car don't cover anyone,end ;" << objs.channel_id << "," << violation_id_ << ","
                          << object_id_;
                m_status = eEND;
                break;
            }
            m_status = eEnterZuoEndLine;
            this->add_snapshot(box, objs);
            break;
        case eEnterZuoEndLine:

            //判断左转车是否过停止线
            if (!m_enter_zuo_end_line) 
            {
                if(EnterZuoEndLine(box, objs))
                {
                    LOG(INFO) << "==>zuo car enter end line ;" << objs.channel_id << "," << violation_id_ << ","
                          << object_id_;
                    this->add_snapshot(box, objs);
                    m_enter_zuo_end_line = true;
                }
                
            }
            //判断被遮挡的车是否为直行车
            if (!m_becovered_is_zhixing) 
            {
                int becovered_someone = -1;
                if(AnyoneCarBecoveredisZhiXing(box, objs,becovered_someone))
                {
                    LOG(INFO) << "==>zuo car cover zhi xing car " << becovered_someone << " ;" <<objs.channel_id << "," << violation_id_ << ","
                          << object_id_;
                    m_becovered_is_zhixing =true;
                }
                
            }

            if (m_enter_zuo_end_line && m_becovered_is_zhixing) {
                LOG(INFO) << "==>zuo zhuan bu rang zhi xing setup,create event ;" << objs.channel_id << "," << violation_id_
                          << "," << object_id_;
                retv = get_results();
                this->clear_snapshot();
                m_status = eEvent;
            }
            break;
        case eEvent:
            break;
        case eEND:
        default:
            break;
    }

    m_last_box = box;
    static int colors[] = {0, 0, 2, 3,0};
    if (m_status != eUNDEFINE) {
        box.violate_state = colors[m_status];
    }
    return retv;
}

ViolationZuoZhuanBuRangZhiXingFactory::ViolationZuoZhuanBuRangZhiXingFactory(const std::string& id,
                                                                             const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , m_id(id)
    , m_cfg(std::make_shared<ViolationZzbrzxConfig>(cfg)) {}

const std::string& ViolationZuoZhuanBuRangZhiXingFactory::id() const { return m_id; }

spIViolation ViolationZuoZhuanBuRangZhiXingFactory::CreateIViolation(const BoxF& obj) {
    if (obj.label == OBJECT_TYPE_VEHICLE) {
        return std::make_shared<ViolationZuoZhuanBuRangZhiXing>(obj.uid, m_id, m_cfg);
    } else {
        return nullptr;
    }
}

REGISTER_VIOLATION(ZZBRZX_CODE, ZuoZhuanBuRangZhiXing);
// REGISTER_VIOLATION_PATTERN(ZZBRZX_CODE_PATTERN, ZuoZhuanBuRangZhiXing);

}  // namespace FLOW
