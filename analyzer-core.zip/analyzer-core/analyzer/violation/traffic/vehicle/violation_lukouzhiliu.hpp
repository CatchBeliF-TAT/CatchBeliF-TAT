#ifndef VSS_VIOLATION_LUKOUZHILIU_HPP
#define VSS_VIOLATION_LUKOUZHILIU_HPP

#include <vector>
#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationLukouzhiliuConfig;
typedef std::shared_ptr<ViolationLukouzhiliuConfig> spViolationLukouzhiliuConfig;

class ViolationLukouzhiliuFactory : public ViolationCommonFactory 
{
public:
    ViolationLukouzhiliuFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationLukouzhiliuFactory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                      id_;
    spViolationLukouzhiliuConfig     cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_LUKOUZHILIU_HPP
