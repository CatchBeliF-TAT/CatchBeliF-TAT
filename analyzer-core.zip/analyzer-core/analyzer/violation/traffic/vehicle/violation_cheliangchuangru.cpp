
#include <iterator>
#include <vector>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"
#include "serving/violation_config.pb.h"

#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_cheliangchuangru.hpp"

namespace FLOW {

    static const std::string CLCR_NAME("cheliangchuangru");
    static const std::string CLCR_CODE("2442");

//
// ViolationCheliangchuangruConfig
//
    class ViolationCheliangchuangruConfig {
    public:
        ViolationCheliangchuangruConfig(const std::string& json)
                : violate_box()
                , parking_second(10)
        {
            auto result=this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json);
    public:
        typedef     std::vector<float> VecFloat;
        VecFloat    start_line;
        VecFloat    violate_box;
        int         parking_second;
        spViolationConfig  violation_cfg;
    };

    bool ViolationCheliangchuangruConfig::ParseJson(const std::string& json) {
        std::string err;
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;
        const int MIN_SIZE = 2*3;
        for (int i=0; i<cfg.conditions_size(); i++) {
            const auto& cond = cfg.conditions(i);
            if (cond.name() == "start_line"){
                CHECK_GE(cond.data_size(), 4);
                std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(start_line));
            }
            if (cond.name() == "violate_box"){
                CHECK_GE(cond.data_size(), MIN_SIZE);
                std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box));
                if (cond.has_parking_second()) {
                    parking_second = cond.parking_second();
                }
            }
        }
        return true;
    }
//
// ViolationCheliangchuangru
//
    class ViolationCheliangchuangru : public ViolationBase
    {
    public:
        ViolationCheliangchuangru(int object_id, const std::string& violation_id, const spViolationCheliangchuangruConfig cfg);
        virtual ~ViolationCheliangchuangru()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

    protected:
        enum STATUS{
            eUNDEFINE,
            eENTER_VIEW,
            eENTER_AREA,
            eEND,
        };

    protected:
        const spViolationCheliangchuangruConfig     cfg_;
        STATUS                                      status_;
    };

    ViolationCheliangchuangru::ViolationCheliangchuangru(int object_id, const std::string& violation_id, const spViolationCheliangchuangruConfig cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
            , status_(eUNDEFINE)
    {
    }

    result_list_t ViolationCheliangchuangru::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        switch (status_)
        {
            case eUNDEFINE:
                if (valid_box_in_range(box, objs.sframe->width(), objs.sframe->height(), cfg_->violation_cfg->plate_available_box_percent()) &&
                    valid_box_across_lines(box, cfg_->start_line.data(), 0.75f)){
                    status_ = eENTER_VIEW;
                    this->add_snapshot(box, objs);
                    LOG(INFO)<<"==>enter view, "<<violation_id_<<","<<object_id_;
                }
                break;
            case eENTER_VIEW:
                if ( valid_box_center_in_polygon(box, cfg_->violate_box.data(), cfg_->violate_box.size()) ){
                    status_ = eENTER_AREA;
                    this->add_snapshot(box, objs);
                    LOG(INFO)<<"==>stage one ready, "<<violation_id_<<","<<object_id_;
                }
                break;
            case eENTER_AREA:
                if ( valid_box_center_in_polygon(box, cfg_->violate_box.data(), cfg_->violate_box.size()) &&
                    this->get_elapsed_time(objs) >= std::chrono::milliseconds(cfg_->parking_second*1000*10/10) ) {
                    this->add_snapshot(box, objs);
                    LOG(INFO) << "==>stage two ready, " << violation_id_ << "," << object_id_;
                    retv = get_results();
                    status_ = eEND;
                    this->clear_snapshot();
                }
                break;
            case eEND:
            default:
                break;
        }

        static int colors[]={0,0,2,3};
        if (status_ != eUNDEFINE) {
            box.violate_state = colors[status_];
        }
        return retv;
    }

//
// ViolationCheliangchuangruFactory
//
    ViolationCheliangchuangruFactory::ViolationCheliangchuangruFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationCheliangchuangruConfig>(cfg))
    {
    }

    const std::string& ViolationCheliangchuangruFactory::id()const {
        return id_;
    }

    spIViolation ViolationCheliangchuangruFactory::CreateIViolation(const BoxF& obj){
        if (obj.label == OBJECT_TYPE_VEHICLE){
            return std::make_shared<ViolationCheliangchuangru>(obj.uid, id_, cfg_);
        } else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(CLCR_CODE, Cheliangchuangru);

} // namespace FLOW
