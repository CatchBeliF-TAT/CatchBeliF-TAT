
#include <map>
#include <iterator>
#include <functional>
#include <algorithm>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"

#include "serving/violation_config.pb.h"
#include "common/tad_internal.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_count_checker_by_obj.hpp"

namespace FLOW {

static const std::string ZHANDAOJINGYING_CODE("2463");

//
// ViolationCountCheckerByObjConfig
//
ViolationCountCheckerByObjConfig::ViolationCountCheckerByObjConfig(const std::string& json)
    : violate_box()
    , parking_second(60)
    , cooling_second(600)
    , min_car_count(-1)
    , min_nonmotor_count(-1)
    , min_person_count(-1)
    , max_move_percent(-1)
    , distance(-1)
    , user_def_compare([](const BoxF& b1,const BoxF& b2){ return b1.uid == b2.uid; })
{
    auto result=this->ParseJson(json);
    CHECK(result);
    if (violation_cfg && 
        (violation_cfg->code()== ZHANDAOJINGYING_CODE)) {
        max_move_percent = (max_move_percent<0) ? 0.1 : max_move_percent;
        min_person_count = (min_person_count<0) ? 1 : min_person_count;
        min_car_count = (min_car_count<0) ? 1 : min_car_count;
        distance = (distance<0) ? 0.1 : distance;
    }
    if (max_move_percent > 0) {
        user_def_compare = [&](const BoxF &b1, const BoxF &b2){
            return b1.uid == b2.uid && valid_box_box_distance(b1, b2, max_move_percent);
        };
    }
}

bool ViolationCountCheckerByObjConfig::ParseJson(const std::string& json) {
    std::string err;
    violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }
    auto& cfg = *violation_cfg;
    cooling_second = cfg.has_cooling_second()?cfg.cooling_second():cooling_second;
    const int MIN_SIZE = 2*3;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "violate_box"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box));
            if (cond.has_parking_second()) {
                parking_second = cond.parking_second();
            }
            if (cond.has_car_count()) {
                min_car_count = cond.car_count();
            }
            if (cond.has_nonmotor_count()) {
                min_nonmotor_count = cond.nonmotor_count();
            }
            if (cond.has_person_count()) {
                min_person_count = cond.person_count();
            }
            if (cond.has_max_move_percent()) {
                max_move_percent = cond.max_move_percent();
            }
            if (cond.has_distance()) {
                distance = cond.distance();
            }
        }
    }
    return true;
}

//
// ViolationCountCheckerByObj
//
class ViolationCountCheckerByObj : public ViolationBase
{
public:
    ViolationCountCheckerByObj(int object_id, const std::string& violation_id, const ViolationCountCheckerByObjConfig& cfg);
    virtual ~ViolationCountCheckerByObj()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& info);

protected:
    enum STATUS{
        eUNDEFINE,
        eENTER_VIEW,
        eMID_TIME_UP,
        eLAST_TIME_UP,
        eCOOL_TIME_UP,
        eEND,
    };

protected:
    ViolationCountCheckerByObjConfig    cfg_;
    STATUS                         status_;
    std::map<int,BoxF>             pre_objs;
};

ViolationCountCheckerByObj::ViolationCountCheckerByObj(int object_id, const std::string& violation_id, const ViolationCountCheckerByObjConfig& cfg)
    : ViolationBase(object_id, violation_id, cfg.violation_cfg)
    , cfg_(cfg)
    , status_(eUNDEFINE)
{
}

result_list_t ViolationCountCheckerByObj::check(BoxF& box, const ImageObjectsInfo& info)
{
    result_list_t retv;

    size_t car_count = -1;
    size_t nonomotor_count = -1;
    size_t person_count = -1;
    VecBoxF in_objs;

    static const auto to_map = 
        [](const VecBoxF& vb) {
            std::map<int,BoxF> out;
            std::for_each(vb.cbegin(), vb.cend(),[&](const BoxF& b){
                out[b.uid] = b;
            });
            return out;
        };
    static const auto uid_equal = 
        [](const BoxF& b1,const BoxF& b2) {
            return b1.uid == b2.uid;
        };
    static const auto uid_less = 
        [](const BoxF& b1,const BoxF& b2) {
            return b1.uid < b2.uid;
        };
    static const auto with_label = 
        [](const int label, const BoxF& b1) {
            return b1.label == label;
        };

    static const auto match_requires = 
        [](const std::map<int,int>& requires,const VecBoxF& boxes)->int {
            for(const auto& req : requires) {
                if (req.second >= 0) {
                    auto count=std::count_if(boxes.cbegin(), boxes.cend(),
                                    std::bind(with_label, req.first, std::placeholders::_1));
                    if (count < req.second) { return false; }
                }
            }
            return true;
        };

    const auto requires= std::map<int,int>{
        {OBJECT_TYPE_VEHICLE,   cfg_.min_car_count},
        {OBJECT_TYPE_NONMOTOR,  cfg_.min_nonmotor_count},
        {OBJECT_TYPE_PERSON,    cfg_.min_person_count},
    };
    
    // status process
    switch (status_)
    {
    case eUNDEFINE:
        if (!valid_box_center_in_polygon(box, cfg_.violate_box.data(), cfg_.violate_box.size())){
            return retv;
        }
        // filter by violate_box
        std::copy_if(info.objects.cbegin(), info.objects.cend(), std::back_inserter(in_objs),
            [this](const BoxF& b){
                return valid_box_center_in_polygon(b, cfg_.violate_box.data(), cfg_.violate_box.size());
        });
        
        // filter by distance
        if (cfg_.distance > 0) {
            auto max_distance = cfg_.distance * std::max(info.sframe->width(), info.sframe->height());
            max_distance = cfg_.distance > 1 ? cfg_.distance : max_distance;
            VecPointF centers(in_objs.size());
            std::transform(in_objs.cbegin(), in_objs.cend(), centers.begin(),
                        [&](const BoxF& obj) { return obj.CenterFloat(); });
            auto ids = filter_points_by_distance(centers, box.CenterFloat(), max_distance);
            VecBoxF tmp;
            std::for_each(ids.cbegin(), ids.cend(), 
                        [&in_objs, &tmp](int i) {tmp.push_back(in_objs[i]);}
            );
            in_objs.swap(tmp);
        }

        // check count requirements
        if (!match_requires(requires, in_objs)) {
            return retv;
        }

        status_ = eENTER_VIEW;
        pre_objs = to_map(in_objs);
        this->add_snapshot(box, info);
        LOG(INFO)<<"==>stage one ready, "<<info.channel_id<<", "<<violation_id_<<","<<object_id_;
        break;
    case eENTER_VIEW:
        if (this->get_elapsed_time(info).count() < (cfg_.parking_second*1000)) {
            break;
        }
        if (!valid_box_center_in_polygon(box, cfg_.violate_box.data(), cfg_.violate_box.size())){
            this->clear_snapshot();
            status_ = eUNDEFINE;
            return retv;
        }
        std::copy_if(info.objects.cbegin(), info.objects.cend(), std::back_inserter(in_objs),
            [this](const BoxF& box){
                return pre_objs.count(box.uid) > 0 &&
                    cfg_.user_def_compare(pre_objs[box.uid], box) &&
                    valid_box_center_in_polygon(box, cfg_.violate_box.data(), cfg_.violate_box.size());
        });
        
        // filter by distance
        if (cfg_.distance > 0) {
            auto max_distance = cfg_.distance * std::max(info.sframe->width(), info.sframe->height());
            max_distance = cfg_.distance > 1 ? cfg_.distance : max_distance;
            VecPointF centers(in_objs.size());
            std::transform(in_objs.cbegin(), in_objs.cend(), centers.begin(),
                        [&](const BoxF& obj) { return obj.CenterFloat(); });
            auto ids = filter_points_by_distance(centers, box.CenterFloat(), max_distance);
            VecBoxF tmp;
            std::for_each(ids.cbegin(), ids.cend(), 
                        [&in_objs, &tmp](int i) {tmp.push_back(in_objs[i]);}
            );
            in_objs.swap(tmp);
        }

        // check count requirements
        if (!match_requires(requires, in_objs)) {
            status_ = eUNDEFINE;
            this->clear_snapshot();
            LOG(INFO)<<"==>stage two dorp, "<<info.channel_id<<", "<<violation_id_<<","<<object_id_;
            return retv;
        }

        status_ = eLAST_TIME_UP;
        this->add_snapshot(box, info);
        LOG(INFO)<<"==>stage two ready, "<<info.channel_id<<", "<<violation_id_<<","<<object_id_;
        retv =  get_results();
        // for cooling_second 
        this->clear_snapshot();
        this->add_snapshot(box, ImageObjectsInfo());
        break;
    case eLAST_TIME_UP:
        if (cfg_.cooling_second > 0) {
            auto elapsed_time = this->get_elapsed_time(info);
            if ( elapsed_time.count() >= (cfg_.cooling_second*1000) ) {
                status_ = eUNDEFINE;
                this->clear_snapshot();
            }
        } else {
            status_ = eEND;
        }
        break;
    case eEND:
    default:
        break;
    }

    static int colors[]={0,2,2,3,3,3};
    if (status_ != eUNDEFINE) {
        box.violate_state = colors[status_];
    }

    return retv;
}

//
// ViolationCountCheckerByObjFactory
//
ViolationCountCheckerByObjFactory::ViolationCountCheckerByObjFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(cfg)
{
}

const std::string& ViolationCountCheckerByObjFactory::id()const
{
    return id_;
}

spIViolation ViolationCountCheckerByObjFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == OBJECT_TYPE_VEHICLE){
        return std::make_shared<ViolationCountCheckerByObj>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }

}

REGISTER_VIOLATION(ZHANDAOJINGYING_CODE, CountCheckerByObj);

} // namespace FLOW
