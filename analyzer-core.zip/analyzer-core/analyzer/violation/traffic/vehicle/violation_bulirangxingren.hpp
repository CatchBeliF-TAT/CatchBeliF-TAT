#ifndef VSS_VIOLATION_BULIRANGXINGREN_HPP
#define VSS_VIOLATION_BULIRANGXINGREN_HPP

#include <memory>
#include <vector>

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationBulirangxingrenConfig;
typedef std::shared_ptr<ViolationBulirangxingrenConfig> spViolationBulirangxingrenConfig;

class ViolationBulirangxingrenFactory : public ViolationCommonFactory {
public:
    ViolationBulirangxingrenFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationBulirangxingrenFactory() = default;

public:
    virtual const std::string& id() const;
    virtual spIViolation CreateIViolation(const BoxF& obj);

protected:
    std::string id_;
    spViolationBulirangxingrenConfig cfg_;
};

}  // namespace FLOW
#endif  // VSS_VIOLATION_BULIRANGXINGREN_HPP
