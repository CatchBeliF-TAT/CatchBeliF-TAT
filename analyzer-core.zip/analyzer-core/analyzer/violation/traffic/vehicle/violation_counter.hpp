#ifndef VSS_VIOLATION_COUNTER_HPP
#define VSS_VIOLATION_COUNTER_HPP

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

    class ViolationCounterConfig;
    typedef std::shared_ptr<ViolationCounterConfig> spViolationCounterConfig;

    class ViolationCounterFactory : public ViolationCommonFactory
    {
    public:
        ViolationCounterFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationCounterFactory()=default;

    public:
        virtual const std::string&      id()const;
        virtual spIViolation            CreateIViolation(const BoxF& obj);

    protected:
        std::string                         id_;
        spViolationCounterConfig           cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_COUNTER_HPP
