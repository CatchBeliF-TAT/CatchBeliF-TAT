
#include <iterator>
#include <map>
#include <vector>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"
#include "serving/violation_config.pb.h"


#include "violation/traffic/violation_base.hpp"
#include "violation_revolve_status_check.hpp"

namespace FLOW {

    // 球机转动事件
    static const std::string CAMERA_REVOLVE_EVENT_NAME("CAMERA_REVOLVE_EVENT_COUNTER");
    static const std::string CAMERA_REVOLVE_EVENT_CODE("2483");
//
// ViolationRevolveStatusCheckConfig
//
    class ViolationRevolveStatusCheckConfig {
    public:
        ViolationRevolveStatusCheckConfig(const std::string& json): cooling_second(2)
        {
            auto result=this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json);
    public:
        typedef             std::vector<float> VecFloat;
        spViolationConfig   violation_cfg;
        bool                if_check_revolve = false;
        int                 cooling_second;
    };

    bool ViolationRevolveStatusCheckConfig::ParseJson(const std::string& json) {
        std::string err;
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(ERROR) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;
        if (cfg.has_enable_check_revolve()) {
            if_check_revolve = cfg.enable_check_revolve();
        } else {
            if_check_revolve = false;
        }
        return true;
    }
//
// ViolationRevolveStatusCheck
//
    class ViolationRevolveStatusCheck : public ViolationBase
    {
    public:
        ViolationRevolveStatusCheck(int object_id, const std::string& violation_id, const spViolationRevolveStatusCheckConfig cfg);
        virtual ~ViolationRevolveStatusCheck()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

    protected:
        bool                                          last_image_revolve_status_;
        const spViolationRevolveStatusCheckConfig                cfg_;
        bool                                            cooling_status_;
    };

    ViolationRevolveStatusCheck::ViolationRevolveStatusCheck(int object_id, const std::string& violation_id, const spViolationRevolveStatusCheckConfig cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
            ,last_image_revolve_status_(false)
            , cooling_status_(false)
    {
    }

    result_list_t ViolationRevolveStatusCheck::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        
        if (! cfg_->if_check_revolve) {
            return retv;
        }
        
        if ( cooling_status_ ) {
            auto elapsed_time = this->get_elapsed_time(objs);
            if ( elapsed_time.count() >= cfg_->cooling_second*1000 ) {
                cooling_status_ = false;
                this->clear_snapshot();
            }
            return retv;
        }
        
        const bool revolve_status = objs.jitter_status == 2 ? true : false;
        
        if ( last_image_revolve_status_ && !revolve_status) {
            last_image_revolve_status_ = false;
            this->add_snapshot(BoxF(),objs);
            auto result = get_results();
            retv.splice(retv.end(), result);
            cooling_status_ = true;

        } else if ( !last_image_revolve_status_ && revolve_status) {
            last_image_revolve_status_ = true;
            this->add_snapshot(BoxF(),objs);
        }
    
        return retv;
    }

//
// ViolationRevolveStatusCheckFactory
//
    ViolationRevolveStatusCheckFactory::ViolationRevolveStatusCheckFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationRevolveStatusCheckConfig>(cfg))
    {
    }

    const std::string& ViolationRevolveStatusCheckFactory::id()const {
        return id_;
    }

    spIViolation ViolationRevolveStatusCheckFactory::CreateIViolation(const BoxF& obj){
        if (obj.uid == -1){
            return std::make_shared<ViolationRevolveStatusCheck>(obj.uid, id_, cfg_);
        } else {
            return nullptr;
        }
    }
    REGISTER_VIOLATION(CAMERA_REVOLVE_EVENT_CODE, RevolveStatusCheck);

} // namespace FLOW