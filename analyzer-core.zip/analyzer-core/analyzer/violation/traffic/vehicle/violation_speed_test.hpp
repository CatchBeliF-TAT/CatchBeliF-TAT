#ifndef VSS_VIOLATION_SPEED_TEST_HPP
#define VSS_VIOLATION_SPEED_TEST_HPP

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

    class ViolationSpeedTestConfig;
    typedef std::shared_ptr<ViolationSpeedTestConfig> spViolationSpeedTestConfig;

    class ViolationSpeedTestFactory : public ViolationCommonFactory
    {
    public:
        ViolationSpeedTestFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationSpeedTestFactory()=default;

    public:
        virtual const std::string&      id()const;
        virtual spIViolation            CreateIViolation(const BoxF& obj);

    protected:
        std::string                         id_;
        spViolationSpeedTestConfig          cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_SPEED_TEST_HPP
