
#include <set>
#include <iterator>
#include <memory>
#include <unordered_map>
#include <numeric>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/clipper.hpp"

#include "violation_jiaotongyongdu.hpp"
#include "common/tad_internal.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "algorithm/traffic_light/traffic_light_recog.hpp"

namespace FLOW {

static const std::string JIAOTONGYONGDU_NAME("jiaotongyongdu");
static const std::string JIAOTONGYONGDU_CODE("2431");
static const std::string PAIDUIYICHU_NAME("jiaotongyongdu");
static const std::string PAIDUIYICHU_CODE("2468");
static const std::string PAIDUIYICHU_RED_NAME("jiaotongyongdu-red");
static const std::string PAIDUIYICHU_RED_CODE("2469");


// 通用模版
static const std::string JIAOTONGYONGDU_PATTERN("^2431[0-9]{2}$");

double area_boxes(const VecBoxF& objs) {
    ClipperLib::Clipper clpr;
    for (auto &obj : objs) {
        const ClipperLib::Path path{
            {(int)obj.xmin, (int)obj.ymin},
            {(int)obj.xmin, (int)obj.ymax},
            {(int)obj.xmax, (int)obj.ymax},
            {(int)obj.xmax, (int)obj.ymin},
            {(int)obj.xmin, (int)obj.ymin},
        };
        clpr.AddPath(path, ClipperLib::ptSubject, true);
    }
    ClipperLib::Paths uni;
    clpr.Execute(ClipperLib::ctUnion, uni, ClipperLib::pftEvenOdd);
    double area = std::accumulate(uni.begin(), uni.end(), 0.0l, 
        [](double a, ClipperLib::Path p){
            return a + ClipperLib::Area(p);
        }
    );
    return std::abs(area);
}

// ViolationJiaotongyongduConfig
class ViolationJiaotongyongduConfig {
public:
    ViolationJiaotongyongduConfig(const std::string& json){
        auto result = this->ParseJson(json);
        CHECK(result);
    }
    bool ParseJson(const std::string& json) {
        std::string err;
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;
        name = cfg.name();
        code = cfg.code();
        cooling_second = cfg.has_cooling_second()?cfg.cooling_second():cooling_second;
        has_traffic_light = cfg.traffic_light_box_size();
        const int MIN_SIZE = 2*3;
        for (int i=0; i<cfg.conditions_size(); i++) {
            const auto& cond = cfg.conditions(i);
            if (cond.name() == "violate_box"){
                CHECK_GE(cond.data_size(), MIN_SIZE);
                std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box));
                violate_box_area = get_polygon_area(violate_box.data(), violate_box.size());
                if (cond.has_parking_second()) {
                    parking_second = cond.parking_second();
                }
                if (cond.has_car_count()) {
                    min_car_count  = cond.car_count();
                }
                if (cond.has_cover_ratio()) {
                    cover_ratio    = cond.cover_ratio();
                }
            }
        }
        return true;
    }
public:
    typedef     std::vector<float> VecFloat;
    VecFloat    violate_box;
    double      violate_box_area=1e-7;
    int         parking_second=60;
    int         cooling_second=600;
    int         min_car_count=-1;
    float       cover_ratio=-1;
    bool        has_traffic_light=false;
    std::string code;
    std::string name;
    spViolationConfig  violation_cfg;
    BoxF        traffic_light_box;
};

// ViolationJiaotongyongdu
class ViolationJiaotongyongdu : public ViolationBase
{
public:
    ViolationJiaotongyongdu(int object_id, const std::string& violation_id, const spViolationJiaotongyongduConfig& cfg);
    virtual ~ViolationJiaotongyongdu() = default;

public:
    virtual result_list_t check(BoxF&, const ImageObjectsInfo&);

protected:
    enum STATUS{
        eUNDEFINE,
        eENTER_VIEW,
        eCOOLING,
        eEND,
    };

protected:
    spViolationJiaotongyongduConfig     cfg_;
    STATUS                              status_;
    std::set<int64_t>                   in_boxes_uid_;
};

ViolationJiaotongyongdu::ViolationJiaotongyongdu(int object_id, const std::string& violation_id, const spViolationJiaotongyongduConfig& cfg)
    : ViolationBase(object_id, violation_id, cfg->violation_cfg)
    , cfg_(cfg)
    , status_(eUNDEFINE)
    , in_boxes_uid_()
{
}

result_list_t ViolationJiaotongyongdu::check(BoxF& box, const ImageObjectsInfo& objs)
{
    result_list_t retv;
    VecBoxF inBoxes;
    double area = 0.0f;
    auto i = objs.tlc.find(violation_id_);
    auto color = TrafficLight::kColorEmpty;
    if(i!=objs.tlc.end()){
        color = i->second.color;
    }
    switch (status_)
    {
    case eUNDEFINE:
        if ((cfg_->cover_ratio <= 0) && (cfg_->min_car_count <= 0)) {
            break;
        }
        if (cfg_->has_traffic_light && color != TrafficLight::kColorRed ) {
            break;
        }
        std::copy_if(objs.objects.begin(), objs.objects.end(),
                        std::back_inserter(inBoxes), [this](const BoxF& one){
            return one.label == OBJECT_TYPE_VEHICLE && valid_box_center_in_polygon(one, cfg_->violate_box.data(), cfg_->violate_box.size());
        });
        if ((cfg_->min_car_count > 0) && (inBoxes.size() < cfg_->min_car_count)) {
            break;
        }
        if (cfg_->cover_ratio > 0) {
            area = area_boxes(inBoxes);
            if (area/cfg_->violate_box_area < cfg_->cover_ratio) {
                break;
            }
        }
        status_ = eENTER_VIEW;
        this->add_snapshot(box, objs);
        this->snapshots_.back().image->objects = inBoxes;
        in_boxes_uid_.clear();
        std::for_each(inBoxes.begin(), inBoxes.end(), [&](const BoxF& b) {in_boxes_uid_.insert(b.uid);});
        LOG(INFO)<<"==>stage 1 ready, "<<violation_id_<<", "<<object_id_ 
                    << ", count=" << inBoxes.size() << ", cover_ratio=" << area/cfg_->violate_box_area;
        break;
    case eENTER_VIEW:
        if (cfg_->has_traffic_light && color != TrafficLight::kColorRed ) {
            status_ = eUNDEFINE;
            this->clear_snapshot();
            break;
        }
        if (this->get_elapsed_time(objs).count() < cfg_->parking_second*1000) {
            break;
        }
        std::copy_if(objs.objects.begin(), objs.objects.end(),
                        std::back_inserter(inBoxes), [this](const BoxF& one){
            return one.label == OBJECT_TYPE_VEHICLE && 
                   valid_box_center_in_polygon(one, cfg_->violate_box.data(), cfg_->violate_box.size()) &&
                   (in_boxes_uid_.find(one.uid) != in_boxes_uid_.end());
        });
        if ((cfg_->min_car_count > 0) && (inBoxes.size() <= cfg_->min_car_count)) {
            status_ = eUNDEFINE;
            this->clear_snapshot();
            break;
        }
        if (cfg_->cover_ratio > 0) {
            area = area_boxes(inBoxes);
            if (area/cfg_->violate_box_area < cfg_->cover_ratio) {
                status_ = eUNDEFINE;
                this->clear_snapshot(); 
                break;
            }
        }
        status_ = eCOOLING;
        this->add_snapshot(box, objs);
        this->snapshots_.back().image->objects = inBoxes;
        LOG(INFO)<<"==>stage 2 ready, "<<violation_id_<<", "<<object_id_ 
                    << ", count=" << inBoxes.size() << ", cover_ratio=" << area/cfg_->violate_box_area;
        retv = get_results();
        break;
    case eCOOLING:
        if (this->get_elapsed_time(objs).count() >= cfg_->cooling_second*1000) {
            status_ = eUNDEFINE;
            this->clear_snapshot();
        }
        break;
    case eEND:
    default:
        break;
    }
   return retv;
}

// ViolationJiaotongyongduFactory
ViolationJiaotongyongduFactory::ViolationJiaotongyongduFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(std::make_shared<ViolationJiaotongyongduConfig>(cfg))
{
}

const std::string& ViolationJiaotongyongduFactory::id()const
{
    return id_;
}

spIViolation ViolationJiaotongyongduFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationJiaotongyongdu>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(JIAOTONGYONGDU_CODE, Jiaotongyongdu);
REGISTER_VIOLATION(PAIDUIYICHU_CODE, Jiaotongyongdu);
REGISTER_VIOLATION(PAIDUIYICHU_RED_CODE, Jiaotongyongdu);
REGISTER_VIOLATION_PATTERN(JIAOTONGYONGDU_PATTERN, Jiaotongyongdu);

} // namespace FLOW
