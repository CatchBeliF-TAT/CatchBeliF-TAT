#include <iterator>
#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"

#include "algorithm/traffic_light/traffic_light_recog.hpp"

#include "serving/violation_config.pb.h"
#include "common/tad_internal.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_cut_frame.hpp"

#include "serving/violation_event.pb.h"

#include "common/helper.hpp"


namespace FLOW {

//截帧code
static const std::string THROW_FRAME_CUT_CODE_NEW("243801");
static const std::string FIR_FRAME_CUT_CODE_NEW("243701");
static const std::string FOG_FRAME_CUT_CODE_NEW("243501");
static const std::string CONSTRUCT_FRAME_CUT_CODE_NEW("230701");
//已经不用了,兼容旧版本先留着,后续有别的地方用就删除了
static const std::string THROW_FRAME_CUT_CODE("6438");
static const std::string FIR_FRAME_CUT_CODE("6437");
static const std::string FOG_FRAME_CUT_CODE("6435");
static const std::string CONSTRUCT_FRAME_CUT_CODE("6307");


//
// ViolationCutFrameConfig
//
class ViolationCutFrameConfig {
public:
    ViolationCutFrameConfig(const std::string& json):
        cooling_interval_(2),
        frame_num_(1),
        detect_interval_(60),
        frame_frequency_(2)
    {
        auto result=this->ParseJson(json);
        CHECK(result);
    }
    bool ParseJson(const std::string& json);
public:
    spViolationConfig  violation_cfg_;
    int                cooling_interval_;
    int                frame_num_;
    int                detect_interval_;
    int                frame_frequency_;
};

bool ViolationCutFrameConfig::ParseJson(const std::string& json) {
    std::string err;
    violation_cfg_ = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg_.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }
    const auto& cfg = *violation_cfg_;
    if(cfg.has_cooling_second()){
        cooling_interval_ = cfg.cooling_second();
    }
    if ( cfg.has_cut_frame_config() ) {
        const auto &cut_frame_config = cfg.cut_frame_config();
        frame_num_ = cut_frame_config.frame_num();
        detect_interval_ = cut_frame_config.detect_interval();
        frame_frequency_ = cut_frame_config.frame_frequency();
    }
    return true;
}
//
// ViolationCutFrame
//
class ViolationCutFrame : public ViolationBase
{
public:
    ViolationCutFrame(int object_id, const std::string& violation_id, const spViolationCutFrameConfig cfg);
    virtual ~ViolationCutFrame()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
    virtual result_list_t get_results() const;
protected:
    enum STATUS{
        eUNDEFINE,
        eENTER_VIEW,
        eWAIT,
        eNOWAIT,
        eEND,
    };
    const spViolationCutFrameConfig            cfg_;
    int                                        frame_num_;
    STATUS                                     status_;

};

ViolationCutFrame::ViolationCutFrame(int object_id, const std::string& violation_id, const spViolationCutFrameConfig cfg)
    : ViolationBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
    , status_(eUNDEFINE)
    ,frame_num_(0)
{
}

result_list_t ViolationCutFrame::check(BoxF& box, const ImageObjectsInfo& objs)
{    
    result_list_t retv;
    
    auto elapsed_time = this->get_elapsed_time(objs);

    switch (status_)
    {
    case eUNDEFINE:
        frame_num_ = 0;
        this->clear_snapshot();
        this->add_snapshot(box, objs);
        ++frame_num_;
        if ( cfg_->frame_num_*cfg_->frame_frequency_ > cfg_->detect_interval_ ) {
            status_ = eNOWAIT;
        } else {
            status_ = eENTER_VIEW;
        }
        retv =  get_results();
        break;
    case eENTER_VIEW:
        if (frame_num_ >= cfg_->frame_num_) {
            status_ = eWAIT;
            break;
        }
        if ( elapsed_time.count() >= cfg_->frame_frequency_*1000 ) {
            this->clear_snapshot();
            this->add_snapshot(box, objs);
            ++frame_num_;
            retv =  get_results();
        }
        break;

    case eWAIT:
        if ( elapsed_time.count() + ( cfg_->frame_num_-1 )*cfg_->frame_frequency_*1000 >= cfg_->detect_interval_*1000 ) {
            status_ = eUNDEFINE;
            this->clear_snapshot();
        }
        break;
    case eNOWAIT:
        if ( elapsed_time.count() >= cfg_->frame_frequency_*1000 ) {
            this->clear_snapshot();
            this->add_snapshot(box, objs);
            retv =  get_results();
        }
        break;
    default:
        break;
    }
    
    return retv;
}

result_list_t ViolationCutFrame::get_results()const{
        result_list_t retv;
        const auto stream_id = snapshots_[0].image->channel_id;
        const auto violation_code = violation_cfg_->code();
        const auto violation_name = violation_cfg_->name();
        const auto violation_id = violation_id_;
        const auto snapshots = snapshots_;

        auto action = [=](ICAlgEngine* engine) -> spEventProto {
            auto retv = std::make_shared<inference::Event>();
            inference::Event& event = *retv;
            static const std::string TadTypeYBYTFrameCut  = "frame_cut";
            event.set_event_type(TadTypeYBYTFrameCut);

            inference::MassiveFlowEvent * mass_event = event.mutable_massive_flow_event();
            mass_event->set_stream_id(stream_id);
            mass_event->set_task_id(stream_id);
            mass_event->set_violation_id(violation_id);
            mass_event->set_event_type(atoi(violation_code.c_str()));

            for(int i=0;i<snapshots.size();i++){
                auto& image = snapshots[i].image;
                auto snap1 = mass_event->add_snapshots();
                snap1->set_now(snapshots[i].now.time_since_epoch().count());
                snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
            }

            return retv;
        };
        retv.push_back(action);
        return retv;
    }

//
// ViolationCutFrameFactory
//
ViolationCutFrameFactory::ViolationCutFrameFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(std::make_shared<ViolationCutFrameConfig>(cfg))
{
}

const std::string& ViolationCutFrameFactory::id()const {
    return id_;
}

spIViolation ViolationCutFrameFactory::CreateIViolation(const BoxF& obj){
    if (obj.label == -1){
        return std::make_shared<ViolationCutFrame>(obj.uid, id_, cfg_);
    }
    else {
        return nullptr;
    }
}

REGISTER_VIOLATION(THROW_FRAME_CUT_CODE_NEW, CutFrame);
REGISTER_VIOLATION(FIR_FRAME_CUT_CODE_NEW, CutFrame);
REGISTER_VIOLATION(FOG_FRAME_CUT_CODE_NEW, CutFrame);
REGISTER_VIOLATION(CONSTRUCT_FRAME_CUT_CODE_NEW, CutFrame);

REGISTER_VIOLATION(THROW_FRAME_CUT_CODE, CutFrame);
REGISTER_VIOLATION(FIR_FRAME_CUT_CODE, CutFrame);
REGISTER_VIOLATION(FOG_FRAME_CUT_CODE, CutFrame);
REGISTER_VIOLATION(CONSTRUCT_FRAME_CUT_CODE, CutFrame);

} // namespace FLOW
