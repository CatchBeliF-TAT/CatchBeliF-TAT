
#include "violation_speed_test.hpp"

#include <iterator>
#include <map>
#include <vector>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"
#include "serving/violation_config.pb.h"


#include "violation/traffic/violation_base.hpp"
#include "violation/conditions/line_condition.hpp"
#include "violation/violation_util.hpp"

namespace FLOW {

    static const std::string JDC_SPEED_TEST_NAME("SpeedTest");
    static const std::string JDC_SPEED_TEST_HIGH_CODE("2451");
    static const std::string JDC_SPEED_TEST_LOW_CODE("2452");

//
// ViolationSpeedTestConfig
//
    class ViolationSpeedTestConfig {
    public:
        ViolationSpeedTestConfig(const std::string& json)
                : violate_box()
                , distance(.0f)
                , max_speed(-1.0f)
                , min_speed(-1.0f)
        {
            auto result=this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json);
    public:
        fn_check_action start_line_checker;
        fn_check_action end_line_checker;
        typedef     std::vector<float> VecFloat;
        VecFloat    start_line;
        VecFloat    end_line;
        VecFloat    violate_box;
        float       distance;
        float       max_speed;
        float       min_speed;

        spViolationConfig  violation_cfg;
    };

    bool ViolationSpeedTestConfig::ParseJson(const std::string& json) {
        std::string err;
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;
        const int MIN_SIZE = 2*3;
        for (int i=0; i<cfg.conditions_size(); i++) {
            const auto& cond = cfg.conditions(i);
            if (cond.name() == "start_line"){
                CHECK_GE(cond.data_size(), 4);
                std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(start_line));
                start_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
            }
            if (cond.name() == "stop_line"){
                CHECK_GE(cond.data_size(), 4);
                std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(end_line));
                end_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
                if (cond.has_distance()) {
                    distance = cond.distance();
                }
                if (cond.has_max_speed()) {
                    max_speed = cond.max_speed();
                }
                if (cond.has_min_speed()) {
                    min_speed = cond.min_speed();
                }
            }
        }
        return true;
    }
//
// ViolationSpeedTest
//
    class ViolationSpeedTest : public ViolationBase
    {
    public:
        ViolationSpeedTest(int object_id, const std::string& violation_id, const spViolationSpeedTestConfig cfg);
        virtual ~ViolationSpeedTest()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

    protected:
        enum STATUS{
            eUNDEFINE,
            eENTER_VIEW,
            eENTER_VIOLATION,
            eEND,
        };

    protected:
        const spViolationSpeedTestConfig            cfg_;
        STATUS                                      status_;
        BoxF                                        last_box_;
    };

    ViolationSpeedTest::ViolationSpeedTest(int object_id, const std::string& violation_id, const spViolationSpeedTestConfig cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
            , status_(eUNDEFINE)
    {
    }

    result_list_t ViolationSpeedTest::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;

        // init last_box_
        if (last_box_.uid == -1) {
            last_box_ = box;
        }
        std::shared_ptr<void> update_last_box(nullptr,[&](void*){
            last_box_ = box;
        });

        if (eUNDEFINE == status_){
            if (cfg_->start_line_checker(last_box_, box, objs)) {
                status_ = eENTER_VIEW;
                LOG(INFO)<<"==>enter 1, "<<objs.channel_id<<", "<<violation_id_<<", "<<object_id_;
                this->add_snapshot(box, objs);
            }
        } else if (eENTER_VIEW == status_) {
            if (cfg_->end_line_checker(last_box_, box, objs)) {
                status_ = eENTER_VIOLATION;
                auto interval = this->get_elapsed_time(objs);
                auto speed = cfg_->distance * 1000.0f * 3.6f / std::max<int>(interval.count(), 1);
                LOG(INFO)<<"==>enter 2, "<<objs.channel_id<<", "<<violation_id_<<", "<<object_id_<<", speed: "<<speed;
                this->add_snapshot(box, objs);
                this->snapshots_.back().avgspeed = speed;
                if (cfg_->min_speed>0 && speed<cfg_->min_speed) {
                    return get_results();
                }
                if (cfg_->max_speed>0 && speed>cfg_->max_speed) {
                    return get_results();
                }
            }
        } else if (eENTER_VIOLATION == status_){
            status_ = eEND;
            this->clear_snapshot();
        } else {
            // nop
        }
        return retv;
    }

//
// ViolationSpeedTestFactory
//
    ViolationSpeedTestFactory::ViolationSpeedTestFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationSpeedTestConfig>(cfg))
    {
    }

    const std::string& ViolationSpeedTestFactory::id()const {
        return id_;
    }

    spIViolation ViolationSpeedTestFactory::CreateIViolation(const BoxF& obj){
        if (obj.label == OBJECT_TYPE_VEHICLE){
            return std::make_shared<ViolationSpeedTest>(obj.uid, id_, cfg_);
        } else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(JDC_SPEED_TEST_HIGH_CODE, SpeedTest);
    REGISTER_VIOLATION(JDC_SPEED_TEST_LOW_CODE, SpeedTest);

} // namespace FLOW