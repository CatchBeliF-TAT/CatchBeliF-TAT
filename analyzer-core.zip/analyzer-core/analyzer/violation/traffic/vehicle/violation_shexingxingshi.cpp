#include <iterator>
#include <map>
#include <vector>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"
#include "serving/violation_config.pb.h"

#include "violation_shexingxingshi.hpp"

#include "violation/traffic/violation_base.hpp"
#include "violation/conditions/line_condition.hpp"
#include "violation/violation_util.hpp"

namespace FLOW {
    static const std::string SHEXINGXINGSHI_NAME("shexingxingshi");
    static const std::string SHEXINGXINGSHI_CODE("2472");

class ViolationShexingxingshiConfig {
public:
    ViolationShexingxingshiConfig(const std::string& json)
    {
        auto result = ParseJson(json);
    }
    bool ParseJson(const std::string& json);
public:
    float violate_line[4];
    VecFloat    violate_box;
    bool enable_output_picture;
    bool enable_save_picture;
    spViolationConfig  violation_cfg_;
};

bool ViolationShexingxingshiConfig::ParseJson(const std::string& json) {
    std::string err;
    violation_cfg_ = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg_.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }
    auto& cfg = *violation_cfg_;
    const int MIN_SIZE = 4;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "violate_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), MIN_SIZE, std::begin(violate_line));
        } else if (cond.name() == "violate_box"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box));
        }
    }
    //plate_available_box_percent = cfg.plate_available_box_percent();
    enable_output_picture = cfg.enable_output_picture();
    enable_save_picture = cfg.enable_save_debug_picture();
    return true;
}

class ViolationShexingxingshi : public ViolationBase
    {
    public:
        ViolationShexingxingshi(int object_id, const std::string& violation_id, const spViolationShexingxingshiConfig& cfg);
        virtual ~ViolationShexingxingshi()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

    protected:
        enum STATUS{
            eUNDEFINE,
            eENTER_VIEW,
            eFIRST_CHANGE_DIRECTION,
            eSECOND_CHANGE_DIRECTION,
            eEND,
        };
        const spViolationShexingxingshiConfig   cfg_;
        STATUS                                  status_;
        BoxF                                    start_box_;
        int                                     car_driving_direction_;
};

ViolationShexingxingshi::ViolationShexingxingshi(int object_id, const std::string& violation_id, const spViolationShexingxingshiConfig& cfg)
    : ViolationBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
    , status_(eUNDEFINE)
    , car_driving_direction_(0)
{
}

result_list_t ViolationShexingxingshi::check(BoxF& box, const ImageObjectsInfo& objs) {
    result_list_t retv;
    int current_direction = 0;
    switch(status_)
    {
        case eUNDEFINE:
            if ( valid_box_center_in_polygon(box, cfg_->violate_box.data(), cfg_->violate_box.size())) {
                start_box_ = box;
                status_ = eENTER_VIEW;
                LOG(INFO)<<"==>enter view, "<<violation_id_<<","<<object_id_;
            }
            break;
        case eENTER_VIEW:
            if ( !valid_box_center_in_polygon(box, cfg_->violate_box.data(), cfg_->violate_box.size())) {
                status_ = eUNDEFINE;
                car_driving_direction_ = 0;
                break;
            }
            current_direction = get_cross_line_cross_product(start_box_,box, cfg_->violate_line);
            if (current_direction*car_driving_direction_ == 0) {
                if (current_direction != 0){
                    car_driving_direction_ = current_direction;
                }
            } else if (current_direction*car_driving_direction_ < 0) {
                status_ = eFIRST_CHANGE_DIRECTION;
                car_driving_direction_ = current_direction;
                LOG(INFO)<<"==>first change direction, "<<violation_id_<<","<<object_id_;
                this->add_snapshot(box, objs);
            }
            break;
        
        case eFIRST_CHANGE_DIRECTION:
            if ( !valid_box_center_in_polygon(box, cfg_->violate_box.data(), cfg_->violate_box.size())) {
                status_ = eUNDEFINE;
                car_driving_direction_ = 0;
                break;
            }
            current_direction = get_cross_line_cross_product(start_box_,box, cfg_->violate_line);     
            if (current_direction*car_driving_direction_ < 0) {
                status_ = eSECOND_CHANGE_DIRECTION;
                car_driving_direction_ = current_direction;
                LOG(INFO)<<"==>second change direction, "<<violation_id_<<","<<object_id_;
                this->add_snapshot(box, objs);
            }
            break;
        case eSECOND_CHANGE_DIRECTION:
            if ( !valid_box_center_in_polygon(box, cfg_->violate_box.data(), cfg_->violate_box.size())) {
                status_ = eUNDEFINE;
                car_driving_direction_ = 0;
                break;
            }
            current_direction = get_cross_line_cross_product(start_box_,box, cfg_->violate_line);
            if (current_direction*car_driving_direction_ < 0) {
                status_ = eEND;
                car_driving_direction_ = current_direction;
                this->add_snapshot(box, objs);
                LOG(INFO)<<"==> shexingxingshi event, "<<violation_id_<<","<<object_id_;
                retv = get_results();
            }
            break;
        case eEND:
        default:
            break;
    }
    static int colors[]={0,0,2,3,2};
    if (status_ != eUNDEFINE) {
        box.violate_state = colors[status_];
    }
    return retv;
}

ViolationShexingxingshiFactory::ViolationShexingxingshiFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationShexingxingshiConfig>(cfg))
    {
    }

const std::string& ViolationShexingxingshiFactory::id()const {
    return id_;
}

spIViolation ViolationShexingxingshiFactory::CreateIViolation(const BoxF& obj){
    if (obj.label == OBJECT_TYPE_VEHICLE){
        return std::make_shared<ViolationShexingxingshi>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(SHEXINGXINGSHI_CODE, Shexingxingshi);
}