#ifndef TAD_VIOLATION_VEHICLE_COMMON_HPP
#define TAD_VIOLATION_VEHICLE_COMMON_HPP

#include "violation/traffic/violation_common_template.hpp"

namespace FLOW {
    bool fnOBJECT_TYPE_VEHICLE_FILTER(const BoxF& obj);
    typedef ViolationObjectFilter<fnOBJECT_TYPE_VEHICLE_FILTER> OBJECT_TYPE_VEHICLE_FILTER;
    typedef ViolationCommonFactoryTemplate<OBJECT_TYPE_VEHICLE_FILTER> ViolationVehicleCommonFactory;

    bool fnOBJECT_TYPE_VEHICLE_LARGECAR_FILTER(const BoxF& obj);
    typedef ViolationObjectFilter<fnOBJECT_TYPE_VEHICLE_LARGECAR_FILTER> OBJECT_TYPE_VEHICLE_LARGECAR_FILTER;
    typedef ViolationCommonFactoryTemplate<OBJECT_TYPE_VEHICLE_LARGECAR_FILTER> ViolationDaxingchezhangyongxiaoxingchedaoFactory;

    bool fnOBJECT_TYPE_VEHICLE_GAOSU_LARGECAR_FILTER(const BoxF& obj);
    typedef ViolationObjectFilter<fnOBJECT_TYPE_VEHICLE_GAOSU_LARGECAR_FILTER> OBJECT_TYPE_VEHICLE_GAOSU_LARGECAR_FILTER;
    typedef ViolationCommonFactoryTemplate<OBJECT_TYPE_VEHICLE_GAOSU_LARGECAR_FILTER> ViolationGaosuDaxingchezhangyongxiaoxingchedaoFactory;

    bool fnOBJECT_TYPE_VEHICLE_TRUCK_FILTER(const BoxF& obj);
    typedef ViolationObjectFilter<fnOBJECT_TYPE_VEHICLE_TRUCK_FILTER> OBJECT_TYPE_VEHICLE_TRUCK_FILTER;
    typedef ViolationCommonFactoryTemplate<OBJECT_TYPE_VEHICLE_TRUCK_FILTER> ViolationJinzhidahuocheFactory;
}

#endif //TAD_VIOLATION_VEHICLE_COMMON_HPP
