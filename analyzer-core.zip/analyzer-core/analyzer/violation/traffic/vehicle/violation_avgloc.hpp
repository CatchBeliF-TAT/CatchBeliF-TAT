/*
 * @Author: your name
 * @Date: 2020-10-09 14:58:19
 * @LastEditTime: 2020-10-30 10:02:04
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: /analyzer-flow/analyzer/violation/traffic/vehicle/violation_avgloc.hpp
 */
#ifndef VSS_VIOLATION_AVGLOC_HPP
#define VSS_VIOLATION_AvgLOC_HPP

#include "violation/traffic/violation_common.hpp"


namespace FLOW {

    class ViolationAvgLocConfig;
    typedef std::shared_ptr<ViolationAvgLocConfig> spViolationAvgLocConfig;

    class ViolationAvgLocFactory : public ViolationCommonFactory
    {
    public:
        ViolationAvgLocFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationAvgLocFactory()=default;

    public:
        virtual const std::string&      id()const;
        virtual spIViolation            CreateIViolation(const BoxF& obj);

    protected:
        std::string                         id_;
        spViolationAvgLocConfig             cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_AvgLoc_HPP
