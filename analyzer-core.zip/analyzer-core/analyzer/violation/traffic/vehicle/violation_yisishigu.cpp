#include "violation_yisishigu.hpp"
#include <map>
#include <set>
#include <tuple>
#include "algorithm/plate/vehicle_plate.hpp"
#include "algorithm/traffic_light/traffic_light_recog.hpp"
#include "algorithm/vehicleattribute/behaviour_attr.hpp"
#include "algorithm/vehicleattribute/construct_attr.hpp"
#include "algorithm/vehicleattribute/vehicle_attr.hpp"
#include "common/helper.hpp"
#include "common/pbjson.hpp"
#include "core/alg_engine/alg_engine_interface.hpp"
#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"
#include "violation/traffic/violation_base.hpp"
#include "violation/traffic/violation_common.hpp"
#include "violation/violation_util.hpp"
namespace FLOW {

static const std::string YSSG_CODE("2416");
static const std::string YSSG_NAME("yisishigu");
// static const std::string YCTC_CODE("2432");
// static const std::string YCTC_NAME("yichangtingche");

REGISTER_VIOLATION(YSSG_CODE, yisishijian);
// REGISTER_VIOLATION(YCTC_CODE, yisishijian);
class ViolationyisishijianConfig {
public:
    ViolationyisishijianConfig(const std::string& json);
    ~ViolationyisishijianConfig() = default;
    bool ParseJson(const std::string& json);

public:
    typedef std::vector<float> VecFloat;
    VecFloat m_violate_box;
    int m_parking_second;
    int m_cooling_second;
    int m_max_car_count;
    int m_min_car_count;
    int m_min_person_count;
    std::string code;
    std::string name;
    spViolationConfig violation_cfg;
};

ViolationyisishijianConfig::ViolationyisishijianConfig(const std::string& json)
    : m_violate_box()
    , m_parking_second(10)
    , m_cooling_second(-1)
    , m_max_car_count(std::numeric_limits<int>::max())
    , m_min_car_count(1)
    , m_min_person_count(-1) {
    auto result = this->ParseJson(json);
    CHECK(result);
}

bool ViolationyisishijianConfig::ParseJson(const std::string& json) {
    std::string err;
    violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()) {
        LOG(WARNING) << err << ", json= " << json;
        return false;
    }
    auto& cfg = *violation_cfg;
    name = cfg.name();
    code = cfg.code();
    m_cooling_second = cfg.has_cooling_second() ? cfg.cooling_second() : m_cooling_second;

    const int MIN_SIZE = 2 * 3;
    for (int i = 0; i < cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "violate_box") {
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size() / 2 * 2, std::back_inserter(m_violate_box));
            if (cond.has_parking_second()) {
                m_parking_second = cond.parking_second();
            }
            if (cond.has_min_car_count()) {
                m_min_car_count = cond.min_car_count();
            }

            if (cond.has_car_count()) {
                m_max_car_count = cond.car_count() > m_min_car_count ? cond.car_count() : m_min_car_count;
            }

            if (cond.has_person_count()) {
                m_min_person_count = cond.person_count();
            }
        }
    }

    return true;
}

class Violationyisishijian : public ViolationBase {
public:
    Violationyisishijian(int object_id, const std::string& violation_id, const spViolationyisishijianConfig& cfg);
    virtual ~Violationyisishijian() = default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
    virtual result_list_t get_results() const override;
    bool BoxCenterInArea(const BoxF& box) const;
    bool IsParking(const BoxF& box, const BoxF& box2) const;
    bool IsParking(const BoxF& box, const BoxF& box2, int* recheak, float fmin_IoU = 0.1) const;
    int save_in_area_car(const ImageObjectsInfo& frameInfo);
    int update_in_area_person(const ImageObjectsInfo& frameInfo);
    void copy_in_area_person(VecBoxF& persons, const ImageObjectsInfo& frameInfo) const;
    std::tuple<int, int> update_parking_car(const ImageObjectsInfo& frameInfo, bool recheak = false,
                                            float fmin_IoU = 0.1);

protected:
    enum STATUS {
        eUNDEFINE,
        eFIRST_TIME_UP,
        ePERSON_AND_CAR_SECOND_TIME_UP,
        ePERSON_AND_CAR_THIRD_TIME_UP,
        ePERSON_AND_CAR_FOUTRTH_TIME_UP,
        eCAR_SECOND_TIME_UP,
        eEND_TIME_UP,
        eCOOL_TIME_UP
    };

protected:
#define RECHEAK 6
    struct obj_parking_info {
        obj_parking_info(const BoxF& obj)
            : m_obj(obj)
            , recheak(RECHEAK) {}

        const BoxF m_obj;
        int recheak;
    };
    typedef std::shared_ptr<obj_parking_info> spobj_parking_info;

    spViolationyisishijianConfig m_cfg;
    STATUS m_status;
    std::map<int, spobj_parking_info> m_objs_parking_car;
    std::set<int> m_car_union;
    std::set<int> m_person;
};

Violationyisishijian::Violationyisishijian(int object_id, const std::string& violation_id,
                                           const spViolationyisishijianConfig& cfg)
    : ViolationBase(object_id, violation_id, cfg->violation_cfg)
    , m_cfg(cfg)
    , m_status(eUNDEFINE) {}

bool Violationyisishijian::BoxCenterInArea(const BoxF& box) const {
    return valid_box_center_in_polygon(box, m_cfg->m_violate_box.data(), m_cfg->m_violate_box.size());
}

bool Violationyisishijian::IsParking(const BoxF& box, const BoxF& box2) const { return Boxes::IoU(box, box2) > 0.7; }

bool Violationyisishijian::IsParking(const BoxF& box, const BoxF& box2, int* recheak, float fmin_IoU) const {
    (*recheak)--;
    float fIoU = Boxes::IoU(box, box2);
    if (fIoU > (0.7 > fmin_IoU ? 0.7 : fmin_IoU)) {
        *recheak = RECHEAK;
        return true;
    }

    if (*recheak >= 0 && fIoU > fmin_IoU) return true;

    return false;
}

int Violationyisishijian::save_in_area_car(const ImageObjectsInfo& frameInfo) {
    int count = 0;
    for (auto& obj : frameInfo.objects) {
        if (obj.delete_flag) {
            continue;
        }
        if (obj.label != OBJECT_TYPE_VEHICLE) {
            continue;
        }
        if (BoxCenterInArea(obj)) {
            m_objs_parking_car.insert(std::make_pair(obj.uid, std::make_shared<obj_parking_info>(obj)));
            count++;
        }
    }
    return count;
}

int Violationyisishijian::update_in_area_person(const ImageObjectsInfo& frameInfo) {
    m_person.clear();
    for (auto& obj : frameInfo.objects) {
        if (obj.delete_flag) {
            continue;
        }
        if (obj.label != OBJECT_TYPE_PERSON) {
            continue;
        }
        if (BoxCenterInArea(obj)) {
            m_person.insert(obj.uid);
        }
    }
    return m_person.size();
}

void Violationyisishijian::copy_in_area_person(VecBoxF& persons, const ImageObjectsInfo& frameInfo) const {
    for (auto& box : frameInfo.objects) {
        if (m_person.find(box.uid) == m_person.end()) {
            continue;
        }
        persons.push_back(box);
    }
}

std::tuple<int, int> Violationyisishijian::update_parking_car(const ImageObjectsInfo& frameInfo, bool recheak,
                                                              float fmin_IoU) {
    m_car_union.clear();
    for (auto& obj : frameInfo.objects) {
        auto history_obj = m_objs_parking_car.find(obj.uid);
        if (history_obj == m_objs_parking_car.end()) {
            continue;
        }

        if (obj.delete_flag) {
            m_objs_parking_car.erase(history_obj);
            continue;
        }

        bool bparking = recheak ? IsParking(obj, history_obj->second->m_obj, &history_obj->second->recheak, fmin_IoU)
                                : IsParking(obj, history_obj->second->m_obj);
        if (!bparking) {
            m_objs_parking_car.erase(history_obj);
            continue;
        }
        m_car_union.insert(obj.uid);
    }

    return std::make_tuple(m_objs_parking_car.size(), m_car_union.size());
}

result_list_t Violationyisishijian::check(BoxF& box, const ImageObjectsInfo& objs) {
    result_list_t retv;
    switch (m_status) {
        case eUNDEFINE:
            m_objs_parking_car.clear();
            //查看车辆数
            if (save_in_area_car(objs) >= m_cfg->m_min_car_count) {
                m_status = eFIRST_TIME_UP;
                this->clear_snapshot();
                this->add_snapshot(box, objs);
            }

            break;
        case eFIRST_TIME_UP: {
            //查看1s内停车数量是否达标
            auto elapsed_time = this->get_elapsed_time(objs, 0);
            int parking_count = std::get<0>(update_parking_car(objs));
            if (parking_count >= m_cfg->m_min_car_count) {
                if (elapsed_time.count() > 1000) {
                    if (parking_count > m_cfg->m_max_car_count) {
                        m_status = eUNDEFINE;
                        break;
                    }
                    if (m_cfg->m_min_person_count > 0) {
                        m_status = ePERSON_AND_CAR_SECOND_TIME_UP;
                    } else {
                        m_status = eCAR_SECOND_TIME_UP;
                    }

                    LOG(INFO) << "==>stage one ready, " << objs.channel_id << "," << violation_id_
                              << ",parking_car_count:" << parking_count
                              << ",more then config min car count:" << m_cfg->m_min_car_count
                              << " and less then config max car count:" << m_cfg->m_max_car_count;
                }

            } else {
                m_status = eUNDEFINE;
            }
        } break;
        case ePERSON_AND_CAR_SECOND_TIME_UP:
            //在此期间人数曾经超出过设定值
            {
                int person_count = update_in_area_person(objs);
                if (person_count >= m_cfg->m_min_person_count) {
                    m_status = ePERSON_AND_CAR_THIRD_TIME_UP;
                    LOG(INFO) << "==>person and car stage two ready (second), " << objs.channel_id << ","
                              << violation_id_ << ",person_count:" << person_count
                              << ",more then config min person count:" << m_cfg->m_min_person_count;
                    this->add_snapshot(box, objs);
                    copy_in_area_person(this->snapshots_.back().minor_boxes, *this->snapshots_.back().image);
                    break;
                }

                auto elapsed_time = this->get_elapsed_time(objs, 0);
                if (elapsed_time.count() > m_cfg->m_parking_second * 1000 * 5 / 10) {
                    m_status = ePERSON_AND_CAR_FOUTRTH_TIME_UP;
                }

                int parking_count = std::get<0>(update_parking_car(objs, true, 0.5));
                if (parking_count < m_cfg->m_min_car_count || parking_count > m_cfg->m_max_car_count) {
                    LOG(INFO) << "==>ePERSON_AND_CAR_SECOND_TIME_UP change to eUNDEFINE, " << objs.channel_id << ","
                              << violation_id_ << ",parking_car_count:" << parking_count
                              << ",not more then config min car count:" << m_cfg->m_min_car_count
                              << " and less then config max car count:" << m_cfg->m_max_car_count;
                    m_status = eUNDEFINE;
                }
            }
            break;
        case ePERSON_AND_CAR_THIRD_TIME_UP: {
            auto elapsed_time = this->get_elapsed_time(objs, 0);
            if (elapsed_time.count() > m_cfg->m_parking_second * 1000 * 5 / 10) {
                m_status = eEND_TIME_UP;
                break;
            }
            int parking_count = std::get<0>(update_parking_car(objs, true, 0.5));
            if (parking_count < m_cfg->m_min_car_count || parking_count > m_cfg->m_max_car_count) {
                LOG(INFO) << "==>ePERSON_AND_CAR_THIRD_TIME_UP change to eUNDEFINE, " << objs.channel_id << ","
                          << violation_id_ << ",parking_car_count:" << parking_count
                          << ",not more then config min car count:" << m_cfg->m_min_car_count
                          << " and less then config max car count:" << m_cfg->m_max_car_count;
                m_status = eUNDEFINE;
            }
        }

        break;
        case ePERSON_AND_CAR_FOUTRTH_TIME_UP: {
            int person_count = update_in_area_person(objs);
            if (person_count >= m_cfg->m_min_person_count) {
                m_status = eEND_TIME_UP;
                LOG(INFO) << "==>person and car stage two ready (foutrth), " << objs.channel_id << "," << violation_id_
                          << ",person_count:" << person_count
                          << ",more then config min person count:" << m_cfg->m_min_person_count;

                this->add_snapshot(box, objs);
                copy_in_area_person(this->snapshots_.back().minor_boxes, *this->snapshots_.back().image);
                break;
            }

            auto elapsed_time = this->get_elapsed_time(objs, 0);
            if (elapsed_time.count() > m_cfg->m_parking_second * 1000) {
                LOG(INFO) << "==>ePERSON_AND_CAR_FOUTRTH_TIME_UP change to eUNDEFINE, " << objs.channel_id << ","
                          << violation_id_ << ",person_count always "
                          << "less then config min person count:" << m_cfg->m_min_person_count
                          << " in the parking_second:" << m_cfg->m_parking_second;
                m_status = eUNDEFINE;
                break;
            }
            int parking_count = std::get<0>(update_parking_car(objs, true, 0.2));
            if (parking_count < m_cfg->m_min_car_count || parking_count > m_cfg->m_max_car_count) {
                LOG(INFO) << "==>ePERSON_AND_CAR_FOUTRTH_TIME_UP change to eUNDEFINE, " << objs.channel_id << ","
                          << violation_id_ << ",parking_car_count:" << parking_count
                          << ",not more then config min car count:" << m_cfg->m_min_car_count
                          << " and less then config max car count:" << m_cfg->m_max_car_count;
                m_status = eUNDEFINE;
            }
        } break;
        case eCAR_SECOND_TIME_UP: {
            //查看车是否停留持续m_parking_second * 0.5
            auto elapsed_time = this->get_elapsed_time(objs, 0);
            int parking_count = std::get<0>(update_parking_car(objs, true, 0.5));
            if (parking_count >= m_cfg->m_min_car_count && parking_count <= m_cfg->m_max_car_count) {
                if (elapsed_time.count() > m_cfg->m_parking_second * 1000 * 5 / 10) {
                    m_status = eEND_TIME_UP;
                    LOG(INFO) << "==>stage two ready, " << objs.channel_id << "," << violation_id_
                              << ",parking_car_count:" << parking_count
                              << ",more then config min car count:" << m_cfg->m_min_car_count
                              << " and less then config max car count:" << m_cfg->m_max_car_count;
                    this->add_snapshot(box, objs);
                }

            } else {
                LOG(INFO) << "==>eCAR_SECOND_TIME_UP change to eUNDEFINE, " << objs.channel_id << "," << violation_id_
                          << ",parking_car_count:" << parking_count
                          << ",not more then config min car count:" << m_cfg->m_min_car_count
                          << " and less then config max car count:" << m_cfg->m_max_car_count;
                m_status = eUNDEFINE;
            }
        } break;
        case eEND_TIME_UP: {
            //查看车是否停留持续m_parking_second
            auto elapsed_time = this->get_elapsed_time(objs, 0);
            std::tuple<int, int> t = update_parking_car(objs, true, 0.2);
            int parking_count = std::get<0>(t);
            if (parking_count >= m_cfg->m_min_car_count && parking_count <= m_cfg->m_max_car_count) {
                if (elapsed_time.count() > m_cfg->m_parking_second * 1000) {
                    if (std::get<1>(t) < m_cfg->m_min_car_count) {
                        //最后一张图确保当前帧未被遮挡的停车数量满足条件
                        LOG(INFO) << "==>eEND_TIME_UP change to eUNDEFINE, " << objs.channel_id << "," << violation_id_
                                  << ",parking_car_count:" << parking_count
                                  << ",but not be covered parking car count is:" << std::get<1>(t)
                                  << ",not more then config min car count:" << m_cfg->m_min_car_count
                                  << " and less then config max car count:" << m_cfg->m_max_car_count;
                        m_status = eUNDEFINE;
                        break;
                    }
                    m_status = eCOOL_TIME_UP;
                    LOG(INFO) << "==>stage end ready, " << objs.channel_id << "," << violation_id_
                              << ",parking_car_count:" << parking_count
                              << ",not be covered parking car count is:" << std::get<1>(t)
                              << ",more then config min car count:" << m_cfg->m_min_car_count
                              << " and less then config max car count:" << m_cfg->m_max_car_count;
                    this->add_snapshot(box, objs);
                    retv = get_results();

                    // for cooling_second
                    this->clear_snapshot();
                    this->add_snapshot(box, ImageObjectsInfo());
                }

            } else {
                LOG(INFO) << "==>eEND_TIME_UP change to eUNDEFINE, " << objs.channel_id << "," << violation_id_
                          << ",parking_car_count:" << parking_count
                          << ",not more then config min car count:" << m_cfg->m_min_car_count
                          << " and less then config max car count:" << m_cfg->m_max_car_count;
                m_status = eUNDEFINE;
            }
        } break;
        case eCOOL_TIME_UP:
            if (this->get_elapsed_time(objs).count() >= m_cfg->m_cooling_second * 1000) {
                m_status = eUNDEFINE;
            }
            break;
        default:
            break;
    }

    static int colors[] = {0, 0, 0, 0, 2, 0, 2, 3};

    if (m_status == ePERSON_AND_CAR_FOUTRTH_TIME_UP || m_status >= eEND_TIME_UP) {
        auto elapsed_time = this->get_elapsed_time(objs, 0);
        for (auto& obj : objs.objects) {
            if (m_objs_parking_car.find(obj.uid) != m_objs_parking_car.end()) {
                obj.violate_state = colors[m_status];
            }
        }
    }
    return retv;
}

result_list_t Violationyisishijian::get_results() const {
    result_list_t retv;
    const auto obj_id = object_id_;
    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = violation_cfg_->code();
    const auto violation_name = violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;
    std::set<int> parking_car_union = m_car_union;

    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event_with_type = *retv;
        event_with_type.set_event_type(get_event_type_form_code(violation_code));
        // warning
        inference::ViolationEvent& event = *(event_with_type.mutable_traffic_event());
        event.set_stream_id(stream_id);
        event.set_obj_id(obj_id);
        event.set_violation_id(violation_id);
        event.set_violation_code(violation_code);
        event.set_violation_name(violation_name);

        for (int i = 0; i < snapshots.size(); i++) {
            auto& image = snapshots[i].image;
            auto& persons = snapshots[i].minor_boxes;
            auto snap1 = event.add_snapshots();
            snap1->set_now(snapshots[i].now.time_since_epoch().count());
            snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
            // add objects

            for (auto& box : image->objects) {
                if (parking_car_union.find(box.uid) == parking_car_union.end()) {
                    continue;
                }
                auto obj = snap1->add_objects();
                obj->set_id(box.uid);
                obj->set_type(std::to_string(box.label));
                obj->set_score(box.score);
                obj->add_box(box.xmin);
                obj->add_box(box.ymin);
                obj->add_box(box.xmax);
                obj->add_box(box.ymax);

                //get attribute
                {
                    if (!image->sframe) {
                        continue;
                    }
                    VecBoxF car_boxes({box});
                    engine->ProcessByName("post", image->sframe, car_boxes);
                    if (!car_boxes[0].plates.empty() && !car_boxes[0].plates[0].content.empty()) {
                        const auto& palte_info = car_boxes[0].plates[0];
                        auto plate = obj->mutable_plate();
                        plate->set_number(palte_info.content);
                        plate->set_score(palte_info.score);
                        auto x_pair =
                            std::minmax_element(palte_info.points.begin(), palte_info.points.end(),
                                                [](const PlateInfo<float>::PointT& p1,
                                                   const PlateInfo<float>::PointT& p2) { return p1.x < p2.x; });
                        auto y_pair =
                            std::minmax_element(palte_info.points.begin(), palte_info.points.end(),
                                                [](const PlateInfo<float>::PointT& p1,
                                                   const PlateInfo<float>::PointT& p2) { return p1.y < p2.y; });
                        plate->add_box(x_pair.first->x);
                        plate->add_box(y_pair.first->y);
                        plate->add_box(x_pair.second->x);
                        plate->add_box(y_pair.second->y);
                        if (palte_info.label != -1) {
                            plate->set_plate_type(Plate::helperGetStringPlateType(palte_info.label));
                        }
                        std::copy(palte_info.score_by_character.begin(), palte_info.score_by_character.end(),
                                  google::protobuf::RepeatedFieldBackInserter(plate->mutable_score_by_character()));
                    }

                    if (car_boxes[0].attr_type.type != -1) {
                        if (box.label == OBJECT_TYPE_VEHICLE) {
                            obj->set_sub_type(Attribute::helperGetStringVehicleType(
                                (Attribute::VehicleType)car_boxes[0].attr_type.type));
                        } else {
                            obj->set_sub_type(Attribute::helperGetStringWaimaiType(
                                (Attribute::WaimaiType)car_boxes[0].attr_type.type));
                        }
                        obj->set_sub_type_score(car_boxes[0].attr_type.score);
                    }

                    if (car_boxes[0].special_car_type.type != -1) {
                        obj->set_special_car_type(Attribute::helperGetStringVehicleSpecialType(
                            (Attribute::VehicleSpecialType)car_boxes[0].special_car_type.type));
                        obj->set_special_car_type_score(car_boxes[0].special_car_type.score);
                    }

                    if (car_boxes[0].traffic_person_type.type != -1) {
                        obj->set_person_type(Attribute::helperGetStringConstructionCLSType(
                            (Attribute::ConstructionCLSType)car_boxes[0].traffic_person_type.type));
                        obj->set_person_type_score(car_boxes[0].traffic_person_type.score);
                    }

                    if (car_boxes[0].attr_direction.type != -1) {
                        obj->set_direction(Attribute::helperGetStringVehicleDirectionType(
                            (Attribute::VehicleDirectionType)car_boxes[0].attr_direction.type));
                        obj->set_direction_score(car_boxes[0].attr_direction.score);
                    }

                    for_each(car_boxes[0].behaviour_types.begin(), car_boxes[0].behaviour_types.end(),
                             [&](const Attr attr) {
                                 obj->add_nonmotor_behaviour(Attribute::helperGetStringNoMotorBehaviourType(
                                     (Attribute::NoMotorBehaviourType)attr.type));
                                 obj->add_nonmotor_behaviour_score(attr.score);
                             });

                    if (car_boxes[0].nonmotor_type.type != -1) {
                        obj->set_nonmotor_type(Attribute::helperGetStringNoMotorType(
                            (Attribute::NonMotorType)car_boxes[0].nonmotor_type.type));
                        obj->set_nonmotor_type_score(car_boxes[0].nonmotor_type.score);
                    }
                }
            }

            for (auto& box : persons) {
                auto obj = snap1->add_minor_objects();
                obj->set_id(box.uid);
                obj->set_type(std::to_string(box.label));
                obj->set_score(box.score);
                obj->add_box(box.xmin);
                obj->add_box(box.ymin);
                obj->add_box(box.xmax);
                obj->add_box(box.ymax);
            }
        }
        return retv;
    };
    retv.push_back(action);
    return retv;
}

ViolationyisishijianFactory::ViolationyisishijianFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(std::make_shared<ViolationyisishijianConfig>(cfg)) {}

const std::string& ViolationyisishijianFactory::id() const { return id_; }

spIViolation ViolationyisishijianFactory::CreateIViolation(const BoxF& obj) {
    if (obj.label == -1) {
        return std::make_shared<Violationyisishijian>(obj.uid, id_, cfg_);
    } else {
        return nullptr;
    }

    // if (obj.label == OBJECT_TYPE_VEHICLE){
    //     return std::make_shared<Violationyisishijian>(obj.uid, id_, cfg_);
    // }
    // else {
    //     return nullptr;
    // }
}

}  // namespace FLOW