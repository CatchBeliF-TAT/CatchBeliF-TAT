#ifndef VSS_VIOLATION_CHELIANGXIANSHI_HPP
#define VSS_VIOLATION_CHELIANGXIANSHI_HPP

#include <vector>
#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationCheliangxianshiConfig;
typedef std::shared_ptr<ViolationCheliangxianshiConfig> spViolationCheliangxianshiConfig;

class ViolationCheliangxianshiFactory : public ViolationCommonFactory 
{
public:
    ViolationCheliangxianshiFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationCheliangxianshiFactory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                         id_;
    spViolationCheliangxianshiConfig    cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_CHELIANGXIANSHI_HPP
