#ifndef VSS_VIOLATION_YUEXIANTINGCHE_HPP
#define VSS_VIOLATION_YUEXIANTINGCHE_HPP

#include <vector>
#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationYuexiantingcheConfig;
typedef std::shared_ptr<ViolationYuexiantingcheConfig> spViolationYuexiantingcheConfig;

class ViolationYuexiantingcheFactory : public ViolationCommonFactory 
{
public:
    ViolationYuexiantingcheFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationYuexiantingcheFactory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                         id_;
    spViolationYuexiantingcheConfig     cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_YUEXIANTINGCHE_HPP
