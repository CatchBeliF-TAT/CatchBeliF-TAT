#ifndef VSS_VIOLATION_SHEXINGXINGSHI_HPP
#define VSS_VIOLATION_SHEXINGXINGSHI_HPP

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

    class ViolationShexingxingshiConfig;
    typedef std::shared_ptr<ViolationShexingxingshiConfig> spViolationShexingxingshiConfig;

    class ViolationShexingxingshiFactory : public ViolationCommonFactory
    {
    public:
        ViolationShexingxingshiFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationShexingxingshiFactory()=default;

    public:
        virtual const std::string&      id()const;
        virtual spIViolation            CreateIViolation(const BoxF& obj);

    protected:
        std::string                         id_;
        spViolationShexingxingshiConfig     cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_REVERSE_DRIVING_HPP
