#ifndef VIOLATION_YISISHIJIAN_HPP
#define VIOLATION_YISISHIJIAN_HPP
#include <memory>
#include "violation/traffic/violation_common.hpp"
namespace FLOW{

class ViolationyisishijianConfig;
typedef std::shared_ptr<ViolationyisishijianConfig> spViolationyisishijianConfig;

class ViolationyisishijianFactory : public ViolationCommonFactory 
{
public:
    ViolationyisishijianFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationyisishijianFactory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                   id_;
    spViolationyisishijianConfig  cfg_;
};


}

#endif