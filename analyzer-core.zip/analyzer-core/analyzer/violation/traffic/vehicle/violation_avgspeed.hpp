#ifndef VSS_VIOLATION_AVGSPEED_HPP
#define VSS_VIOLATION_AVGSPEED_HPP

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

    class ViolationAvgspeedConfig;
    typedef std::shared_ptr<ViolationAvgspeedConfig> spViolationAvgspeedConfig;

    class ViolationAvgspeedFactory : public ViolationCommonFactory
    {
    public:
        ViolationAvgspeedFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationAvgspeedFactory()=default;

    public:
        virtual const std::string&      id()const;
        virtual spIViolation            CreateIViolation(const BoxF& obj);

    protected:
        std::string                         id_;
        spViolationAvgspeedConfig           cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_AVGSPEED_HPP
