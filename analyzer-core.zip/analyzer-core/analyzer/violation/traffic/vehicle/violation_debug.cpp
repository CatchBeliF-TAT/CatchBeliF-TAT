#include <unordered_map>
#include <memory>

#include "common/log.hpp"
#include "common/tad_internal.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_debug.hpp"

namespace FLOW {

using namespace std;

class ViolationPrinter : public IViolation
{
public:
    ViolationPrinter(const std::string& id, int obj_id);
    virtual ~ViolationPrinter();

public:
    virtual const std::string&  id()const;
    virtual result_list_t       check(BoxF&, const ImageObjectsInfo&);

protected:
    std::string id_;
    int         obj_id_;
};    

ViolationPrinter::ViolationPrinter(const string&id, int obj_id)
    : id_(id)
    , obj_id_(obj_id)
{
}

ViolationPrinter::~ViolationPrinter()
{
}

const std::string& ViolationPrinter::id()const
{
    return id_;
}

result_list_t ViolationPrinter::check(BoxF& box, const ImageObjectsInfo& objs)
{
    for (auto& x:objs.objects) {
        x.violate_state = 1;
    }
   return result_list_t();
}

ViolationPrinterFactory::ViolationPrinterFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
{
}

const std::string& ViolationPrinterFactory::id()const
{
    return id_;
}

spIViolation ViolationPrinterFactory::CreateIViolation(const BoxF& obj)
{
   return std::make_shared<ViolationPrinter>(id_, obj.uid);
}

REGISTER_VIOLATION("-1", Printer);

} // namespace FLOW
