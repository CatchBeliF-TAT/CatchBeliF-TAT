
#include <map>
#include <vector>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"
#include "serving/violation_config.pb.h"

#include "violation/conditions/line_condition.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_avgspeed.hpp"

namespace FLOW {

    static const std::string PJSD_NAME("Avgspeed");
    static const std::string PJSD_CODE("2710");

//
// ViolationAvgspeedConfig
//
    class ViolationAvgspeedConfig {
    public:
        ViolationAvgspeedConfig(const std::string& json)
        {
            auto result=this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json);
    public:
        typedef     std::vector<float> VecFloat;
        float       distance;
        spViolationConfig  violation_cfg;
        fn_check_action    start_line_checker;
        fn_check_action    end_line_checker;
    };

    bool ViolationAvgspeedConfig::ParseJson(const std::string& json) {
        std::string err;
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;
        const int MIN_SIZE = 2*3;
        for (int i=0; i<cfg.conditions_size(); i++) {
            const auto& cond = cfg.conditions(i);
            if (cond.name() == "start_line"){
                CHECK_GE(cond.data_size(), 4);
                start_line_checker = CreateLineCondition(cond, false, cfg.roi());
            }
            if (cond.name() == "stop_line"){
                CHECK_GE(cond.data_size(), 4);
                if (cond.has_distance()) {
                    distance = cond.distance();
                }
                end_line_checker = CreateLineCondition(cond, false, cfg.roi());
            }
        }
        return start_line_checker && end_line_checker;
    }
//
// ViolationAvgspeed
//
    class ViolationAvgspeed : public ViolationBase
    {
    public:
        ViolationAvgspeed(int object_id, const std::string& violation_id, const spViolationAvgspeedConfig cfg);
        virtual ~ViolationAvgspeed()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

    protected:
        struct Cars_Info{
            std::chrono::milliseconds         car_start;
            std::chrono::milliseconds         car_end;
            bool                              car_sflag = false;
            bool                              car_eflag = false;
            BoxF                              last_obj;
        };

    protected:
        const spViolationAvgspeedConfig            cfg_;
        std::chrono::milliseconds                  pre_time_;
        float                                      sumavg_speed_;
        int                                        cars_cnt_;
        std::map<int, Cars_Info>                   cars_info_;
    };

    ViolationAvgspeed::ViolationAvgspeed(int object_id, const std::string& violation_id, const spViolationAvgspeedConfig cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
            , cars_cnt_(0)
            , sumavg_speed_(0.0)
            , pre_time_(-1)
    {
    }

    result_list_t ViolationAvgspeed::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        auto now = this->get_time_point(objs);
        for (const auto& obj : objs.objects) {
            if (obj.uid < 0) {
                continue;
            }
            if (obj.delete_flag) {
                if (cars_info_.find(obj.uid) != cars_info_.end()) {
                    cars_info_.erase(obj.uid);
                }
                continue;
            }
            if (obj.label == OBJECT_TYPE_VEHICLE) {
                if (cars_info_.count(obj.uid) == 0) {
                    // init last_obj
                    cars_info_[obj.uid].last_obj = obj;
                }
                auto& car_info = cars_info_[obj.uid];
                if (!car_info.car_sflag) {
                    if (cfg_->start_line_checker(car_info.last_obj, obj, objs)) {
                        car_info.car_sflag = true;
                        car_info.car_start = now;
                    }
                } else if (!car_info.car_eflag) {
                    if (cfg_->end_line_checker(car_info.last_obj, obj, objs)) {
                        car_info.car_eflag = true;
                        car_info.car_end = now;
                        const auto d = (car_info.car_end - car_info.car_start).count();
                        const auto tmp_speed_ = cfg_->distance * 1000 / std::max<int>(d, 1);
                        sumavg_speed_ += tmp_speed_;
                        cars_cnt_++;
                    }
                } else {
                    continue;
                    // nop
                }
                // update last_obj
                car_info.last_obj = obj;
            }  // end if (obj.label == OBJECT_TYPE_VEHICLE)
        }

        if (pre_time_.count() < 0) {
            pre_time_ = now;
        }
        if (now - pre_time_ >= std::chrono::milliseconds(60 * 1000)) {
            this->add_snapshot(box, objs);
            float avgspeed = cars_cnt_ == 0 ? 0.0f : (sumavg_speed_ / cars_cnt_);
            this->snapshots_.back().avgspeed = avgspeed;
            this->snapshots_.back().count = cars_cnt_;
            retv = get_results();
            cars_cnt_ = 0;
            sumavg_speed_ = 0.0;
            pre_time_ = now;
            this->clear_snapshot();
        }

        return retv;
    }

//
// ViolationAvgspeedFactory
//
    ViolationAvgspeedFactory::ViolationAvgspeedFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationAvgspeedConfig>(cfg))
    {
    }

    const std::string& ViolationAvgspeedFactory::id()const {
        return id_;
    }

    spIViolation ViolationAvgspeedFactory::CreateIViolation(const BoxF& obj){
        if (obj.label == -1){
            return std::make_shared<ViolationAvgspeed>(obj.uid, id_, cfg_);
        } else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(PJSD_CODE, Avgspeed);

} // namespace FLOW