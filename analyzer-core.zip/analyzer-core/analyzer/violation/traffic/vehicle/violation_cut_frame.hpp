#ifndef VSS_VIOLATION_CUT_FRAME_HPP
#define VSS_VIOLATION_CUT_FRAME_HPP

#include <vector>
#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationCutFrameConfig;
typedef std::shared_ptr<ViolationCutFrameConfig> spViolationCutFrameConfig;

class ViolationCutFrameFactory : public ViolationCommonFactory 
{
public:
    ViolationCutFrameFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationCutFrameFactory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                      id_;
    spViolationCutFrameConfig            cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_CUT_FRAME_HPP
