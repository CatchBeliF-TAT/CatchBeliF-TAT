
#include <iterator>
#include <map>
#include <vector>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"
#include "serving/violation_config.pb.h"


#include "violation/traffic/violation_base.hpp"
#include "violation/conditions/line_condition.hpp"
#include "violation/violation_util.hpp"
#include "violation_counter.hpp"

namespace FLOW {

    // 交通流量
    static const std::string VEHICLE_COUNTER_NAME("VEHICLE_COUNTER");
    static const std::string VEHICLE_COUNTER_CODE("2700");
    static const std::string NONMOTOR_COUNTER_NAME("NONMOTOR_COUNTER");
    static const std::string NONMOTOR_COUNTER_CODE("2800");
    static const std::string PERSON_COUNTER_NAME("PERSON_COUNTER");
    static const std::string PERSON_COUNTER_CODE("2900");

//
// ViolationCounterConfig
//
    class ViolationCounterConfig {
    public:
        ViolationCounterConfig(const std::string& json)
                : label(-1)
                , ticker_second(60)
                , start_line()
                , end_line()
        {
            auto result=this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json);
    public:
        typedef             std::vector<float> VecFloat;
        int                 label;
        int                 ticker_second;
        VecFloat            start_line;
        VecFloat            end_line;
        spViolationConfig   violation_cfg;

        fn_check_action     start_line_checker;
        fn_check_action     end_line_checker;
    };

    bool ViolationCounterConfig::ParseJson(const std::string& json) {
        std::string err;
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(ERROR) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;
        if (cfg.has_cooling_second()) {
            ticker_second = cfg.cooling_second();
        }
        for (int i=0; i<cfg.conditions_size(); i++) {
            const auto& cond = cfg.conditions(i);
            if (cond.name() == "violate_line") {
                CHECK_GE(cond.data_size(), 4);
                std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(start_line));
                start_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
            }
            if (cond.name() == "stop_line") {
                CHECK_GE(cond.data_size(), 4);
                std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(end_line));
                end_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
            }
        }
        if (!start_line_checker) {
            LOG(ERROR) << err <<"violate_line config error";
            return false;
        }
        if (!end_line_checker) {
            LOG(ERROR) << err <<"stop_line config error";
            return false;
        }
        if (cfg.code() == VEHICLE_COUNTER_CODE) {
            label = ObjectType::OBJECT_TYPE_VEHICLE;
        } else if (cfg.code() == NONMOTOR_COUNTER_CODE) {
            label = ObjectType::OBJECT_TYPE_NONMOTOR;
        } else if (cfg.code() == PERSON_COUNTER_CODE) {
            label = ObjectType::OBJECT_TYPE_PERSON;
        } else {
            LOG(ERROR) << err <<"code config error";
            return false;
        }
        return true;
    }
//
// ViolationCounter
//
    class ViolationCounter : public ViolationBase
    {
    public:
        ViolationCounter(int object_id, const std::string& violation_id, const spViolationCounterConfig cfg);
        virtual ~ViolationCounter()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

    protected:
        struct Cars_Info{
            bool    car_sflag=false;
            bool    car_eflag=false;
            BoxF    last_obj;
            std::vector<ViolationSnapshot>  snapshots;
        };

    protected:
        const spViolationCounterConfig          cfg_;
        std::chrono::milliseconds               pre_time_;
        std::map<int, Cars_Info>                cars_info_;
    };

    ViolationCounter::ViolationCounter(int object_id, const std::string& violation_id, const spViolationCounterConfig cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
            , pre_time_(-1)
    {
    }

    result_list_t ViolationCounter::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        for (const auto& obj : objs.objects) {
            if (obj.uid < 0) {
                continue;
            }
            if (obj.label != cfg_->label) {
                continue;
            }
            if (obj.delete_flag) {
                if (cars_info_.find(obj.uid) != cars_info_.end()) {
                    cars_info_.erase(obj.uid);
                }
                continue;
            }
            if (cars_info_.count(obj.uid) == 0) {
                cars_info_[obj.uid].last_obj = obj;
            }
            // update cars_info_.last_obj when destructor update_last_box
            std::shared_ptr<void> update_last_box(nullptr,[&](void*){
                if (cars_info_.count(obj.uid) != 0) {
                    cars_info_[obj.uid].last_obj = obj;
                }
            });

            auto& car_info = cars_info_[obj.uid];
            if (!car_info.car_sflag &&
                cfg_->start_line_checker(car_info.last_obj, obj, objs)) {
                LOG(INFO)<<"==>enter view, "<<violation_id_<<","<<obj.uid;
                car_info.car_sflag = true;
                this->snapshots_.swap(car_info.snapshots);
                this->add_snapshot(obj,objs);
                this->snapshots_.swap(car_info.snapshots);
            } else if (car_info.car_sflag &&
                !car_info.car_eflag &&
                cfg_->end_line_checker(car_info.last_obj, obj, objs)) {
                LOG(INFO)<<"==>counter++, "<<violation_id_<<","<<obj.uid;
                car_info.car_eflag = true;
                this->snapshots_.swap(car_info.snapshots);
                this->add_snapshot(obj,objs);
                this->snapshots_.swap(car_info.snapshots);

                // create message
                this->clear_snapshot();
                this->snapshots_.swap(car_info.snapshots);
                auto result = get_results();
                retv.splice(retv.end(), result);
                this->clear_snapshot();
            } else {
                // nop
            }
            // update last_obj
            box.violate_state = (car_info.car_sflag + car_info.car_eflag);
            // obj.status
        }

        // ticker message
        auto now = this->get_time_point(objs);
        if (pre_time_.count() < 0) {
            pre_time_ = now;
        }
        if (now - pre_time_ >= std::chrono::milliseconds(cfg_->ticker_second * 1000)) {
            pre_time_ = now;
            this->add_snapshot(BoxF(), objs);
            auto result = get_results();
            retv.splice(retv.end(), result);
            this->clear_snapshot();
        }

        return retv;
    }

//
// ViolationCounterFactory
//
    ViolationCounterFactory::ViolationCounterFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationCounterConfig>(cfg))
    {
    }

    const std::string& ViolationCounterFactory::id()const {
        return id_;
    }

    spIViolation ViolationCounterFactory::CreateIViolation(const BoxF& obj){
        if (obj.label == -1){
            return std::make_shared<ViolationCounter>(obj.uid, id_, cfg_);
        } else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(VEHICLE_COUNTER_CODE, Counter);
    REGISTER_VIOLATION(NONMOTOR_COUNTER_CODE, Counter);
    REGISTER_VIOLATION(PERSON_COUNTER_CODE, Counter);

} // namespace FLOW