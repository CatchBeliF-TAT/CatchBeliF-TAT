#include <iterator>
#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"

#include "algorithm/traffic_light/traffic_light_recog.hpp"

#include "serving/violation_config.pb.h"
#include "common/tad_internal.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_debug_new.hpp"

#include "serving/violation_event.pb.h"

#include "algorithm/plate/vehicle_plate.hpp"
#include "algorithm/vehicleattribute/vehicle_attr.hpp"
#include "common/helper.hpp"
#include "core/alg_engine/alg_engine_interface.hpp"

namespace FLOW {

static const std::string TRAFFIC_DEBUG_CODE("2498");

//
// ViolationDebugConfig
//
class ViolationDebugConfig {
public:
    ViolationDebugConfig(const std::string& json):
        cooling_interval_(1),
        cooling_picture_interval_(0)
    {
        auto result=this->ParseJson(json);
        CHECK(result);
    }
    bool ParseJson(const std::string& json);
public:
    spViolationConfig  violation_cfg;
    int                cooling_interval_;
    int                cooling_picture_interval_;
};

bool ViolationDebugConfig::ParseJson(const std::string& json) {
    std::string err;
    violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }
    const auto& cfg = *violation_cfg;
    if(cfg.has_cooling_interval()){
        cooling_interval_ = cfg.cooling_interval();
    }
    if (cfg.has_cooling_picture_interval()) {
        cooling_picture_interval_ = cfg.cooling_picture_interval();
    }
    return true;
}
//
// ViolationDebug
//
class ViolationDebug : public ViolationBase
{
public:
    ViolationDebug(int object_id, const std::string& violation_id, const spViolationDebugConfig cfg);
    virtual ~ViolationDebug()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
    virtual result_list_t get_results()const;
protected:

    const spViolationDebugConfig            cfg_;

public:
    int                                     frame_num_;
};

ViolationDebug::ViolationDebug(int object_id, const std::string& violation_id, const spViolationDebugConfig cfg)
    : ViolationBase(object_id, violation_id, cfg->violation_cfg)
    , cfg_(cfg)
    , frame_num_(0)
{
}

result_list_t ViolationDebug::get_results()const{
    result_list_t retv;
    const auto obj_id = object_id_;
    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = violation_cfg_->code();
    const auto violation_name = violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;

    int cooling_picture_interval = cfg_->cooling_picture_interval_;
    int frame_num = frame_num_;
    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event_with_type = *retv;
        event_with_type.set_event_type("vehicle");//need fix: 暂时写死
        inference::ViolationEvent& event = *(event_with_type.mutable_traffic_event());
        event.set_stream_id(stream_id);
        event.set_obj_id(obj_id);
        event.set_violation_id(violation_id);
        event.set_violation_code(violation_code);
        event.set_violation_name(violation_name);

        for(int i=0;i<snapshots.size();i++){
            auto& image = snapshots[i].image;
            auto snap1 = event.add_snapshots();

            if (image->ntp_time_stamp > 0) {
               snap1->set_ntp_time_stamp(image->ntp_time_stamp);
            }

            snap1->set_now(snapshots[i].now.time_since_epoch().count());
            if (cooling_picture_interval != 0 ) {
                if (frame_num_ % cooling_picture_interval == 0 && image->sframe != nullptr){
                    snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
                }
            }
            // add objects
            for(auto& box : image->objects) {
                auto obj = snap1->add_objects();
                obj->add_box(box.xmin);
                obj->add_box(box.ymin);
                obj->add_box(box.xmax);
                obj->add_box(box.ymax);

                if(box.label!= -1){
                    std::string name="error";
                    if(box.label==1){
                        name = "person";
                    }else if(box.label==2){
                        name = "motor_vehicle";
                    }else if(box.label==3){
                        name = "non-motor_vehicle";
                    }
                    obj->set_type(name);
                    obj->set_score(box.score);
                }

                if( box.attr_type.type != -1) {
                    if (box.label == OBJECT_TYPE_VEHICLE){
                        obj->set_sub_type(Attribute::helperGetStringVehicleType(
                            (Attribute::VehicleType)box.attr_type.type));
  	                }
                    obj->set_sub_type_score(box.attr_type.score);
                }

                if (box.special_car_type.type != -1) {
                    obj->set_special_car_type(Attribute::helperGetStringVehicleSpecialType(
                        (Attribute::VehicleSpecialType)box.special_car_type.type));
                    obj->set_special_car_type_score(box.special_car_type.score);
                }

                if (box.attr_direction.type != -1) {
                    obj->set_direction(Attribute::helperGetStringVehicleDirectionType(
                            (Attribute::VehicleDirectionType)box.attr_direction.type));
                    obj->set_direction_score(box.attr_direction.score);
                }

                if(box.uid!= -1){
                    obj->set_uid(box.uid);
                }
            }
        }

        return retv;
    };
    retv.push_back(action);
    return retv;
}

result_list_t ViolationDebug::check(BoxF& box, const ImageObjectsInfo& objs)
{    
    result_list_t retv;
    if(objs.count % cfg_->cooling_interval_){
        return retv;
    }   
    frame_num_++;
    this->clear_snapshot();
    this->add_snapshot(BoxF(), objs);
    return get_results();
}

//
// ViolationDebugFactory
//
ViolationDebugFactory::ViolationDebugFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(std::make_shared<ViolationDebugConfig>(cfg))
{
}

const std::string& ViolationDebugFactory::id()const {
    return id_;
}

spIViolation ViolationDebugFactory::CreateIViolation(const BoxF& obj){
    if (obj.uid == -1){
        return std::make_shared<ViolationDebug>(obj.uid, id_, cfg_);
    }
    else {
        return nullptr;
    }
}

REGISTER_VIOLATION(TRAFFIC_DEBUG_CODE, Debug);

} // namespace FLOW
