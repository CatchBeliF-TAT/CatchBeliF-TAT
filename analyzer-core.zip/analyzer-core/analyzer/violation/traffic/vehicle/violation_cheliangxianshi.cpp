
#include <iterator>
#include <regex>
#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"

#include "algorithm/traffic_light/traffic_light_recog.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"
#include "common/tad_internal.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_cheliangxianshi.hpp"

namespace FLOW {

using namespace std;

static const std::string CHELIANGXIANSHI_NAME("cheliangxianshi");
static const std::string CHELIANGXIANSHI_CODE("2119");

using sys_milliseconds = std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds>;
//
// TimeCondition
//
class _TimeCondition {
public:
    _TimeCondition() 
        : available_times_()
        , week_pattern_(".*")
        , plate_pattern_(".*")
    {
    }
public:
    typedef std::vector<int64_t> Times;
    Times               available_times_;
    std::regex          week_pattern_;
    std::regex          plate_pattern_;
protected:
    bool inTimes(int64_t t) const{
        for (size_t i = 1; i < available_times_.size(); i += 2) {
            if ( t >= available_times_[i-1] && t < available_times_[i]) {
                return true;
            }
        }
        return false;
    }
public:
    bool TimeMatch(sys_milliseconds t) const{
        auto tt = std::chrono::system_clock::to_time_t(t);
        struct tm* ptm = localtime(&tt);
        stringstream ss; ss << ptm->tm_wday;
        int64_t hhss=  ptm->tm_hour*100 + ptm->tm_min;
        return inTimes(hhss) && std::regex_match(ss.str(), week_pattern_);
    }
    bool PlateMatch(const std::string& plate) const{
        return std::regex_match(plate, plate_pattern_);
    }
};

//
// ViolationCheliangxianshiConfig
//
class ViolationCheliangxianshiConfig {
public:
    ViolationCheliangxianshiConfig(const std::string& json)
        : violate_line_()
        , start_date_(-1)
        , end_date_(-1)
        , time_condition_map_()
    {
        auto result=this->ParseJson(json);
        CHECK(result);
    }
    bool ParseJson(const std::string& json);
public:
    typedef     std::vector<float> VecFloat;
    typedef     std::map<string, _TimeCondition> TimeConditionMap;
    VecFloat            violate_line_;
    int64_t             start_date_;
    int64_t             end_date_;
    TimeConditionMap    time_condition_map_;
    spViolationConfig   violation_cfg_;
};

std::pair<bool,std::string> startsWith(const string& haystack, const string& needle) {
    std::pair<bool,std::string> retv;
    retv.first = needle.length() <= haystack.length() && equal(needle.begin(), needle.end(), haystack.begin());
    if (retv.first) {
        retv.second = haystack.substr(needle.length());
    }
    return retv;
}

bool ViolationCheliangxianshiConfig::ParseJson(const std::string& json) {
    std::string err;
    auto violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }
    auto& cfg = *violation_cfg;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "violate_line"){
            CHECK_GE(cond.data_size(), 4);
            std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(violate_line_));
        }
        if (cond.name() == "start_date"){
            start_date_ = cond.data_number();
        }
        if (cond.name() == "end_date"){
            end_date_ = cond.data_number();
        }
        std::pair<bool,std::string> value;
        if ( (value=startsWith(cond.name(), "available_times")).first ){
            CHECK_GE(cond.data_size()/2, 1);
            auto& available_times = time_condition_map_[value.second].available_times_;
            available_times.clear();
            std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(available_times));
        }
        if ( (value=startsWith(cond.name(), "week_pattern")).first ){
            auto& week_pattern = time_condition_map_[value.second].week_pattern_;
            week_pattern = std::regex(cond.data_string());
        }
        if ( (value=startsWith(cond.name(), "plate_pattern")).first ){
            auto& plate_pattern = time_condition_map_[value.second].plate_pattern_;
            plate_pattern = std::regex(cond.data_string());
        }

    }
    violation_cfg_ = violation_cfg;
    return true;
}
//
// ViolationCheliangxianshi
//
class ViolationCheliangxianshi : public ViolationBase
{
public:
    ViolationCheliangxianshi(int object_id, const std::string& violation_id, const spViolationCheliangxianshiConfig cfg);
    virtual ~ViolationCheliangxianshi()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
    virtual bool results_filter(const inference::ViolationEvent& e) const;

protected:
    enum STATUS{
        eUNDEFINE,
        eENTER_VIEW,
        eEND,
    };

protected:
    const spViolationCheliangxianshiConfig    cfg_;
    STATUS                                    status_;
};

ViolationCheliangxianshi::ViolationCheliangxianshi(int object_id, const std::string& violation_id, const spViolationCheliangxianshiConfig cfg)
    : ViolationBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
    , status_(eUNDEFINE)
{
}

result_list_t ViolationCheliangxianshi::check(BoxF& box, const ImageObjectsInfo& objs)
{
    result_list_t retv;
    switch (status_)
    {
    case eUNDEFINE:
        if (valid_box_in_range(box, objs.sframe->width(), objs.sframe->height(), cfg_->violation_cfg_->plate_available_box_percent()) &&
            valid_box_across_lines(box, cfg_->violate_line_.data(), 0.75f)){
            status_ = eENTER_VIEW;
            this->add_snapshot(box, objs);
            LOG(INFO)<<"==>enter view, "<<violation_id_<<","<<object_id_;
        }
        break;
    case eENTER_VIEW:
            retv = get_results();
            status_ = eEND;
    case eEND:
    default:
        break;
    }
    return retv;
}

bool ViolationCheliangxianshi::results_filter(const inference::ViolationEvent& e)const{
    if (ViolationBase::results_filter(e)) {
        return true;
    }
    if (e.snapshots_size() > 0 && 
        e.snapshots(0).objects_size()>0 &&
        e.snapshots(0).objects(0).has_plate()) {
        const auto& number = e.snapshots(0).objects(0).plate().number();
        sys_milliseconds now{std::chrono::milliseconds{e.snapshots(0).now()}};
        for (const auto& value : cfg_->time_condition_map_) {
            if (value.second.TimeMatch(now) && value.second.PlateMatch(number)) {
                return false;
            }
        }
    }
    return true;
}

//
// ViolationCheliangxianshiFactory
//
ViolationCheliangxianshiFactory::ViolationCheliangxianshiFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(std::make_shared<ViolationCheliangxianshiConfig>(cfg))
{
}

const std::string& ViolationCheliangxianshiFactory::id()const {
    return id_;
}

spIViolation ViolationCheliangxianshiFactory::CreateIViolation(const BoxF& obj){
    auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
    int64_t iNow = now.time_since_epoch().count();
   
    if (obj.label == OBJECT_TYPE_VEHICLE &&
        (cfg_->start_date_ == -1 || iNow >= cfg_->start_date_) &&
        (cfg_->end_date_   == -1 || iNow <  cfg_->end_date_  )) {
        for (auto& value : cfg_->time_condition_map_) {
            if (value.second.TimeMatch(now)) {
                return std::make_shared<ViolationCheliangxianshi>(obj.uid, id_, cfg_);
            }
        }
    }
    return nullptr;
}

//REGISTER_VIOLATION(CHELIANGXIANSHI_CODE, Cheliangxianshi);

} // namespace FLOW
