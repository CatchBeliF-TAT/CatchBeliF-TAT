
#include <iterator>
#include <map>
#include <vector>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"
#include "serving/violation_config.pb.h"

#include "violation_reverse_driving.hpp"

#include "violation/traffic/violation_base.hpp"
#include "violation/conditions/line_condition.hpp"
#include "violation/violation_util.hpp"

namespace FLOW {

    static const std::string NIXING_V2_NAME("ReverseDriving");
    static const std::string NIXING_V2_CODE("2454");

//
// ViolationReverseDrivingConfig
//
    class ViolationReverseDrivingConfig {
    public:
        ViolationReverseDrivingConfig(const std::string& json)
            : threshold(0.5)
        {
            auto result=this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json);
        float projected_length(const BoxF& b)const;
    public:
        typedef     std::vector<float> VecFloat;
        float       threshold;
        VecFloat    start_line;
        VecFloat    mid_line;
        float       mid_line_distance;
        VecFloat    end_line;
        VecFloat    violation_rect;
        float       x_scale;
        float       y_scale;
        fn_check_action start_line_checker;
        fn_check_action end_line_checker;
        spViolationConfig  violation_cfg;
    };

    bool ViolationReverseDrivingConfig::ParseJson(const std::string& json) {
        std::string err;
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;
        const int MIN_SIZE = 2*3;
        for (int i=0; i<cfg.conditions_size(); i++) {
            const auto& cond = cfg.conditions(i);
            if (cond.name() == "start_line"){
                CHECK_GE(cond.data_size(), 4);
                if(cond.has_mode_args() && cond.mode_args().has_center()) {
                    const auto center = cond.mode_args().center();
                    x_scale = center.has_x() ? center.x() : 0.5;
                    y_scale = center.has_y() ? center.y() : 0.5;
                }
                std::copy_n(cond.data().begin(), 4, std::back_inserter(start_line));
                start_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
                if (cond.has_threshold()) {
                    threshold = cond.threshold();
                }
            }
            if (cond.name() == "stop_line"){
                CHECK_GE(cond.data_size(), 4);
                if(cond.has_mode_args() && cond.mode_args().has_center()) {
                    const auto center = cond.mode_args().center();
                    x_scale = center.has_x() ? center.x() : 0.5;
                    y_scale = center.has_y() ? center.y() : 0.5;
                }
                std::copy_n(cond.data().begin(), 4, std::back_inserter(end_line));
                end_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
                if (cond.has_threshold()) {
                    threshold = cond.threshold();
                }
            }
        }
        if (!start_line_checker || !end_line_checker) {
            return false;
        }
        mid_line.resize(4);
        for(int i=0;i<start_line.size();i+=2) {
            mid_line[0]+=start_line[i]; 
            mid_line[1]+=start_line[i+1]; 
        }
        for(int j=0;j<end_line.size();j+=2) {
            mid_line[2]+=end_line[j]; 
            mid_line[3]+=end_line[j+1]; 
        }
        mid_line[0]/=(start_line.size()/2);
        mid_line[1]/=(start_line.size()/2);
        mid_line[2]/=(end_line.size()/2);
        mid_line[3]/=(end_line.size()/2);
        mid_line_distance += (mid_line[2]-mid_line[0])*(mid_line[2]-mid_line[0]);
        mid_line_distance += (mid_line[3]-mid_line[1])*(mid_line[3]-mid_line[1]);
        mid_line_distance = std::sqrt(mid_line_distance);

        // violation_rect
        violation_rect.insert(violation_rect.end(), start_line.begin(), start_line.end());
        if (is_intersect(
                PointF(start_line[0],start_line[1]),
                PointF(end_line[0],end_line[1]),
                PointF(start_line[2],start_line[3]),
                PointF(end_line[2],end_line[3]))
            ) {
            violation_rect.insert(violation_rect.end(), end_line.begin(), end_line.end());
        } else {
            violation_rect.insert(violation_rect.end(), end_line.begin()+2, end_line.end());
            violation_rect.insert(violation_rect.end(), end_line.begin(), end_line.begin()+2);
        }

        return true;
    }

    float ViolationReverseDrivingConfig::projected_length(const BoxF& b)const {
        const auto x = b.xmin + x_scale*(b.xmax-b.xmin) - mid_line[0];
        const auto y = b.ymin + y_scale*(b.ymax-b.ymin) - mid_line[1];
        const auto x2 = mid_line[2] - mid_line[0];
        const auto y2 = mid_line[3] - mid_line[1];
        const auto retv = (x*x2+y*y2)/mid_line_distance;
        return retv;
    }
//
// ViolationReverseDriving
//
    class ViolationReverseDriving : public ViolationBase
    {
    public:
        ViolationReverseDriving(int object_id, const std::string& violation_id, const spViolationReverseDrivingConfig cfg);
        virtual ~ViolationReverseDriving()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

    protected:
        enum STATUS{
            eUNDEFINE,
            eENTER_VIEW,
            eENTER_VIOLATION,
            eEND,
        };
        const spViolationReverseDrivingConfig   cfg_;
        STATUS                                  status_;
        BoxF                                    last_box_;
        float                                   max_distance_;
    };

    ViolationReverseDriving::ViolationReverseDriving(int object_id, const std::string& violation_id, const spViolationReverseDrivingConfig cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
            , status_(eUNDEFINE)
            , max_distance_(0)
    {
    }

    result_list_t ViolationReverseDriving::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;

        // init last_box_
        if (last_box_.uid == -1) {
            last_box_ = box;
        }
        std::shared_ptr<void> update_last_box(nullptr,[&](void*){
            last_box_ = box;
        });

        switch (status_)
        {
        case eUNDEFINE:
            if (valid_box_center_in_polygon(box, cfg_->violation_rect.data(), cfg_->violation_rect.size())) {
                LOG(INFO)<<"==>enter, "<<objs.channel_id<<", "<<violation_id_<<", "<<object_id_; 
                status_ = eENTER_VIEW;
            }
            break;
        case eENTER_VIEW:
            {
                auto current_distance = cfg_->projected_length(box);
                //LOG(INFO)<<"==>enter 0, "<<object_id_<<","<<current_distance;
                if (current_distance <=0 || current_distance >= cfg_->mid_line_distance) {
                    // nop
                    break;
                }
                if (current_distance > cfg_->mid_line_distance) {
                    LOG(INFO)<<"==>out, "<<objs.channel_id<<", "<<violation_id_<<", "<<object_id_; 
                    this->clear_snapshot();
                    status_ = eEND;
                } else if (current_distance > max_distance_) {
                    if (max_distance_ == 0) {
                        LOG(INFO)<<"==>enter max_update, "<<objs.channel_id<<", "<<violation_id_<<", "<<object_id_;  
                    }
                    this->clear_snapshot();
                    this->add_snapshot(box, objs);
                    max_distance_ = current_distance;
                }
                else if ( (max_distance_-current_distance) / cfg_->mid_line_distance >= cfg_->threshold ) {
                    LOG(INFO)<<"==>enter reverse, "<<objs.channel_id<<", "<<violation_id_<<", "<<object_id_<<", distance_threshold:" << (max_distance_-current_distance) / cfg_->mid_line_distance;
                    this->add_snapshot(box, objs);
                    status_ = eENTER_VIOLATION;
                    retv = get_results();
                    this->clear_snapshot();
                } else {
                    // nop
                }
            }
            break;
        case eENTER_VIOLATION:
            break;
        case eEND:
            break;
        default:
            break;
        }

        if (status_ != eUNDEFINE) {
            static int colors[]={0,0,3,0};
            box.violate_state = colors[status_];
        }
        return retv;
    }

//
// ViolationReverseDrivingFactory
//
    ViolationReverseDrivingFactory::ViolationReverseDrivingFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationReverseDrivingConfig>(cfg))
    {
    }

    const std::string& ViolationReverseDrivingFactory::id()const {
        return id_;
    }

    spIViolation ViolationReverseDrivingFactory::CreateIViolation(const BoxF& obj){
        if (obj.label == OBJECT_TYPE_VEHICLE){
            return std::make_shared<ViolationReverseDriving>(obj.uid, id_, cfg_);
        } else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(NIXING_V2_CODE, ReverseDriving);

} // namespace FLOW