
#include <iterator>
#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"

#include "serving/violation_config.pb.h"
#include "common/tad_internal.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_wanggexiantingche.hpp"
#include "violation/flow/violation_flow_code.hpp"

namespace FLOW {

static const std::string WGXTC_NAME("wanggexiantingche");
static const std::string WGXTC_CODE("2108");
static const std::string WFTC_NAME("weifatingche");
static const std::string WFTC_CODE("2118");
static const std::string RXHDXTC_NAME("renxinghengdaoxiantingche");
static const std::string RXHDXTC_CODE("2124");
static const std::string GSKCXY_NAME("kaichexiyan");
static const std::string GSKCXY_CODE("2152");
static const std::string GSYCTC_CODE_NEW("2432");

// 通用模版
static const std::string WGXTC_PATTERN("^2108[0-9]{2}$");

inline bool is_highway(const std::string& code) {
    return code.substr(0,2) == "24";
}
//
// ViolationWanggexiantingcheConfig
//
ViolationWanggexiantingcheConfig::ViolationWanggexiantingcheConfig(const std::string& json)
    : violate_box()
    , parking_second(10)
    , cooling_second(-1)
    , max_car_count(-1)
    , min_car_count(-1)
    , gaosu_limit_count(4)
    , person_count(-1)
    , plate_available_box_percent(0.025f)
    , max_move_percent(0.1)
    , scale_x(0.5)
    , scale_y(0.5)
    , enable_output_picture(true)
    , enable_save_picture(false)
    , enable_use_pts(false)
    , enable_valid_box_check(true)
{
    auto result=this->ParseJson(json);
    CHECK(result);
}

bool ViolationWanggexiantingcheConfig::ParseJson(const std::string& json) {
    std::string err;
    violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }
    auto& cfg = *violation_cfg;
    name = cfg.name();
    code = cfg.code();
    cooling_second = cfg.has_cooling_second()?cfg.cooling_second():cooling_second;
    if (cfg.has_enable_valid_box_check()) {
        enable_valid_box_check = cfg.enable_valid_box_check();
    } else {
        enable_valid_box_check = is_highway(violation_cfg->code()) ? false : true;
    }
    const int MIN_SIZE = 2*3;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "violate_box"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box));
            if (cond.has_parking_second()) {
                parking_second = cond.parking_second();
            }
            if (cond.has_car_count()) {
                max_car_count = cond.car_count();
            }else{
                max_car_count = 0xFFFF;
            }

            if (cond.has_min_car_count()) {
                min_car_count = cond.min_car_count();
            }else{
                min_car_count = 0;
            }
            if (cond.has_goasu_yongdu_count()) {
                gaosu_limit_count = cond.goasu_yongdu_count();
            }
            if (cond.has_person_count()) {
                person_count = cond.person_count();
            }
            if (cond.has_mode_args()) {
                auto mode_args = cond.mode_args();
                if (mode_args.has_center() )  {
                    auto center = mode_args.center();
                    if (center.has_x()) {
                        scale_x = center.x();
                    }
                    if (center.has_y()) {
                        scale_y = center.y();
                    }
                }
            }
        }
    }
    plate_available_box_percent = cfg.plate_available_box_percent();
    enable_output_picture = cfg.enable_output_picture();
    enable_save_picture = cfg.enable_save_debug_picture();
    return true;
}

int intersection_n(const std::vector<float>& violate_box, const ImageObjectsInfo& objs1, const ImageObjectsInfo& objs2) {
    int count = 0;
    std::set<int> objs1_set;
    for(auto& obj : objs1.objects) {
        if (obj.label != OBJECT_TYPE_VEHICLE) {
            continue;
        }
        if (valid_box_center_in_polygon(obj, violate_box.data(), violate_box.size())) {
            objs1_set.insert(obj.uid);
        }
    }
    for(auto& obj : objs2.objects) {
        count += (objs1_set.find(obj.uid) != objs1_set.end());
    }
    return count;
}

//
// ViolationWanggexiantingche
//
class ViolationWanggexiantingche : public ViolationBase
{
public:
    ViolationWanggexiantingche(int object_id, const std::string& violation_id, const ViolationWanggexiantingcheConfig& cfg);
    virtual ~ViolationWanggexiantingche()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
    int update_out_count(const ImageObjectsInfo& frameInfo);
    int count_in_area_person(const ImageObjectsInfo& frameInfo) const;
    int count_in_area_car(const ImageObjectsInfo& frameInfo) const;

protected:
    enum STATUS{
        eUNDEFINE,
        eENTER_VIEW,
        eMID_TIME_UP,
        eLAST_TIME_UP,
        eCOOL_TIME_UP,
        eEND,
    };

protected:
    ViolationWanggexiantingcheConfig    cfg_;
    STATUS                              status_;
    std::map<int,BoxF>                  in_objs_;
    std::set<int>                       out_objs_;
    int                                 max_person_count_;
    bool                                first_enter_;
};

ViolationWanggexiantingche::ViolationWanggexiantingche(int object_id, const std::string& violation_id, const ViolationWanggexiantingcheConfig& cfg)
    : ViolationBase(object_id, violation_id, cfg.violation_cfg)
    , cfg_(cfg)
    , status_(eUNDEFINE)
    , max_person_count_(0)
    , first_enter_(false)
{
}

int ViolationWanggexiantingche::update_out_count(const ImageObjectsInfo& frameInfo) {
    int count =0;
    for(auto& obj : frameInfo.objects) {
        if (obj.label != OBJECT_TYPE_VEHICLE) {
            continue;
        }
        if (out_objs_.count(obj.uid)) {
            continue;
        }
        if (in_objs_.count(obj.uid)) {
            if (!valid_boxes_scale_center_in_polygon(obj, cfg_.scale_x, cfg_.scale_y, cfg_.violate_box.data(), cfg_.violate_box.size())) {
                count++;
                out_objs_.insert(obj.uid);
            }
        } else if (valid_boxes_scale_center_in_polygon(obj, cfg_.scale_x, cfg_.scale_y, cfg_.violate_box.data(), cfg_.violate_box.size())) {
            in_objs_[obj.uid] = obj;
        } else {
            // nop
        }
    }
    return count;
}

int ViolationWanggexiantingche::count_in_area_person(const ImageObjectsInfo& frameInfo) const {
    int count =0;
    for(auto& obj : frameInfo.objects) {
        if (obj.label != OBJECT_TYPE_PERSON) {
            continue;
        }
        if (valid_boxes_scale_center_in_polygon(obj, cfg_.scale_x, cfg_.scale_y, cfg_.violate_box.data(), cfg_.violate_box.size())) {
            count++;
        }
    }
    return count;
}

int ViolationWanggexiantingche::count_in_area_car(const ImageObjectsInfo& frameInfo) const {
    int count =0;
    for(auto& obj : frameInfo.objects) {
        if (obj.label != OBJECT_TYPE_VEHICLE) {
            continue;
        }
        if (valid_boxes_scale_center_in_polygon(obj, cfg_.scale_x, cfg_.scale_y, cfg_.violate_box.data(), cfg_.violate_box.size())) {
            count++;
        }
    }
    return count;
}

result_list_t ViolationWanggexiantingche::check(BoxF& box, const ImageObjectsInfo& objs)
{
    result_list_t retv;

    switch (status_)
    {
    case eUNDEFINE: 
        if (cfg_.enable_valid_box_check &&
            !valid_box_in_range(box, objs.sframe->width(), objs.sframe->height(), cfg_.plate_available_box_percent)) {
                break;
        }
        if (valid_boxes_scale_center_in_polygon(box, cfg_.scale_x, cfg_.scale_y, cfg_.violate_box.data(), cfg_.violate_box.size())){
            status_ = eENTER_VIEW;
            this->in_objs_.clear();
            this->out_objs_.clear();
            this->max_person_count_=0;
            this->clear_snapshot();
            this->add_snapshot(box, objs);
            if (first_enter_) {
                LOG(INFO)<<"==>enter view, "<<objs.channel_id<<","<<violation_id_<<","<<object_id_;
                first_enter_ = true;
            }
        }
        break;
    case eENTER_VIEW:
        if (valid_box_box_distance(box, snapshots_.back().box, cfg_.max_move_percent) && 
            valid_boxes_scale_center_in_polygon(box, cfg_.scale_x, cfg_.scale_y, cfg_.violate_box.data(), cfg_.violate_box.size())){
            update_out_count(objs);
            auto elapsed_time = this->get_elapsed_time(objs);
            if ( elapsed_time.count() >= (cfg_.parking_second*1000*3/10) &&
                 elapsed_time.count() < (cfg_.parking_second*1000*6/10) ) {
                status_ = eMID_TIME_UP;
                this->add_snapshot(box, objs);
                LOG(INFO)<<"==>stage one ready, "<<objs.channel_id<<","<<violation_id_<<","<<object_id_;
            }
        } else {
            status_ = eUNDEFINE;
        }
        break;
    case eMID_TIME_UP:
        if (valid_box_box_distance(box, snapshots_.back().box, cfg_.max_move_percent) && 
            valid_boxes_scale_center_in_polygon(box, cfg_.scale_x, cfg_.scale_y, cfg_.violate_box.data(), cfg_.violate_box.size())){
            update_out_count(objs);
            this->max_person_count_ = std::max(this->max_person_count_, this->count_in_area_person(objs));
            auto elapsed_time = this->get_elapsed_time(objs, 0);
            if ( elapsed_time.count() >= (cfg_.parking_second*1000) &&
                elapsed_time.count() < (cfg_.parking_second*1000*2.1f) ){
                const int paking_in_car_count = intersection_n(cfg_.violate_box, objs, *(this->snapshots_.front().image));
                bool need_reset = false;
                if (paking_in_car_count > cfg_.max_car_count || paking_in_car_count<cfg_.min_car_count) {
                    need_reset = true;
                }
                if (is_highway(cfg_.code)){
                    if (cfg_.gaosu_limit_count > 0 &&
                        this->count_in_area_car(objs) > cfg_.gaosu_limit_count) { // 停车较多
                        if (this->out_objs_.size() < cfg_.gaosu_limit_count) { // 开出车辆偏少
                            need_reset = true;
                        } else if (paking_in_car_count > cfg_.gaosu_limit_count) { // 开不出去的车辆较多
                            if ( elapsed_time.count() >= cfg_.parking_second*1000*2 ) {
                                need_reset = true;
                            } else { // 延长观察时间
                                break;
                            }
                        }
                    }
                }
                if (cfg_.person_count > 0 &&
                    this->max_person_count_ < cfg_.person_count) {
                    need_reset = true;
                }
                if (need_reset) {
                    status_ = eUNDEFINE;
                    LOG(INFO)<<"==>stage two drop, "<<objs.channel_id
                        <<","<<violation_id_
                        <<","<<object_id_
                        <<", i="<<paking_in_car_count
                        <<", o="<<this->out_objs_.size()
                        <<", p="<<this->max_person_count_;
                    break;
                }
                status_ = eLAST_TIME_UP;
                this->add_snapshot(box, objs);
                LOG(INFO)<<"==>stage two ready, "<<objs.channel_id<<","<<violation_id_<<","<<object_id_;
                retv =  get_results();

                // for cooling_second 
                this->clear_snapshot();
                this->add_snapshot(box, ImageObjectsInfo());
            }
        } else {
            status_ = eUNDEFINE;
        }
        break;
    case eLAST_TIME_UP:
        if (cfg_.cooling_second > 0) {
            auto elapsed_time = this->get_elapsed_time(objs);
            if ( elapsed_time.count() >= (cfg_.cooling_second*1000) ) {
                status_ = eUNDEFINE;
            }
        } else {
            status_ = eEND;
        }
        break;
    case eEND:
    default:
        break;
    }

    static int colors[]={0,0,2,3,3,3};
    if (status_ != eUNDEFINE) {
        box.violate_state = colors[status_];
    }
    return retv;
}

//
// ViolationWanggexiantingcheFactory
//
ViolationWanggexiantingcheFactory::ViolationWanggexiantingcheFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(cfg)
{
}

const std::string& ViolationWanggexiantingcheFactory::id()const
{
    return id_;
}

spIViolation ViolationWanggexiantingcheFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == OBJECT_TYPE_VEHICLE){
        return std::make_shared<ViolationWanggexiantingche>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }

}

REGISTER_VIOLATION(WGXTC_CODE, Wanggexiantingche);
REGISTER_VIOLATION(WFTC_CODE, Wanggexiantingche);
REGISTER_VIOLATION(RXHDXTC_CODE, Wanggexiantingche);
REGISTER_VIOLATION(GSKCXY_CODE, Wanggexiantingche);
REGISTER_VIOLATION(BUILDING_YICHANGTINGCHE, Wanggexiantingche);
REGISTER_VIOLATION_PATTERN(WGXTC_PATTERN, Wanggexiantingche);
REGISTER_VIOLATION(GSYCTC_CODE_NEW, Wanggexiantingche);
} // namespace FLOW
