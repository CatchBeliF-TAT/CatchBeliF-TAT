#ifndef VSS_VIOLATION_JIASAI_HPP
#define VSS_VIOLATION_JIASAI_HPP

#include <vector>
#include <memory>

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationJiasaiConfig;
typedef std::shared_ptr<ViolationJiasaiConfig> spViolationJiasaiConfig;
class ViolationJiasaiFactory : public ViolationCommonFactory 
{
public:
    ViolationJiasaiFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationJiasaiFactory()=default;

public:
    virtual const std::string&  id()const;
    virtual spIViolation        CreateIViolation(const BoxF& obj);

protected:
    std::string                     id_;
    spViolationJiasaiConfig         cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_JIASAI_HPP
