#ifndef VSS_VIOLATION_DAWANXIAOZHUAN_HPP
#define VSS_VIOLATION_DAWANXIAOZHUAN_HPP

#include <vector>
#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationDawanxiaozhuanConfig {
public:
    ViolationDawanxiaozhuanConfig(const std::string& json);
    bool ParseJson(const std::string& json);
    bool ParseJsonV2(const std::string& json);

public:
    typedef std::vector<float> VecFloat;
    float start_line[4];
    float violate_line[4];
    VecFloat stop_line;
    float plate_available_box_percent;
    bool  enable_output_picture;
    bool  enable_save_picture;
    std::string code;
    std::string name;
    spViolationConfig  violation_cfg;
};

class ViolationDawanxiaozhuanFactory : public ViolationCommonFactory 
{
public:
    ViolationDawanxiaozhuanFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationDawanxiaozhuanFactory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                   id_;
    ViolationDawanxiaozhuanConfig cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_DAWANXIAOZHUAN_HPP
