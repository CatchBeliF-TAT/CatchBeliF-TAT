#include <vector>
#include <numeric>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/clipper.hpp"
#include "common/tad_internal.hpp"

#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_chedaozhanyonglv.hpp"

namespace FLOW {

    static const std::string CDZYL_NAME("chedaozhanyonglv");
    static const std::string CDZYL_CODE("2720");

    double area_boxes(const VecBoxF& objs, std::vector<float> box_path) {
        ClipperLib::Clipper clpr;
        for (auto &obj : objs) {
            const ClipperLib::Path path{
                    {(int)obj.xmin, (int)obj.ymin},
                    {(int)obj.xmin, (int)obj.ymax},
                    {(int)obj.xmax, (int)obj.ymax},
                    {(int)obj.xmax, (int)obj.ymin},
                    {(int)obj.xmin, (int)obj.ymin},
            };
            clpr.AddPath(path, ClipperLib::ptSubject, true);
        }
        ClipperLib::Path path_;
        for(int i=0;i<box_path.size();i+=2){
            path_.push_back(ClipperLib::IntPoint(box_path[i], box_path[i+1]));
        }
        path_.push_back(ClipperLib::IntPoint(box_path[0], box_path[1]));
        clpr.AddPath(path_, ClipperLib::ptClip, true);
        ClipperLib::Paths inter;
        clpr.Execute(ClipperLib::ctIntersection, inter, ClipperLib::pftNonZero);
        double area = std::accumulate(inter.begin(), inter.end(), 0.0l,
                                      [](double a, ClipperLib::Path p){
                                          return a + ClipperLib::Area(p);
                                      }
        );
        return std::abs(area);
    }


// ViolationChedaozhanyonglvConfig
    class ViolationChedaozhanyonglvConfig {
    public:
        ViolationChedaozhanyonglvConfig(const std::string& json){
            auto result = this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json) {
            std::string err;
            violation_cfg = std::make_shared<inference::ViolationConfig>();
            json2pb(json, violation_cfg.get(), &err);
            if (!err.empty()){
                LOG(WARNING) << err <<", json= "<< json;
                return false;
            }
            auto& cfg = *violation_cfg;
            name = cfg.name();
            code = cfg.code();
            const int MIN_SIZE = 2*3;
            for (int i=0; i<cfg.conditions_size(); i++) {
                const auto& cond = cfg.conditions(i);
                if (cond.name() == "violate_box"){
                    CHECK_GE(cond.data_size(), MIN_SIZE);
                    std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box));
                    violate_box_area = get_polygon_area(violate_box.data(), violate_box.size());
                }
            }
            return true;
        }
    public:
        typedef     std::vector<float> VecFloat;
        VecFloat    violate_box;
        float       violate_box_area;
        std::string code;
        std::string name;
        spViolationConfig  violation_cfg;
    };

// ViolationChedaozhanyonglv
    class ViolationChedaozhanyonglv : public ViolationBase
    {
    public:
        ViolationChedaozhanyonglv(int object_id, const std::string& violation_id, const spViolationChedaozhanyonglvConfig& cfg);
        virtual ~ViolationChedaozhanyonglv() = default;

    public:
        virtual result_list_t check(BoxF&, const ImageObjectsInfo&);

    protected:
        spViolationChedaozhanyonglvConfig     cfg_;
        std::chrono::milliseconds             pre_time_;
        std::chrono::milliseconds             one_min_;
        double                                ratio_;
        int                                   ratio_cnt_;
    };

    ViolationChedaozhanyonglv::ViolationChedaozhanyonglv(int object_id, const std::string& violation_id, const spViolationChedaozhanyonglvConfig& cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
            , ratio_(0.0f)
            , ratio_cnt_(0)
            , pre_time_(-1)
            , one_min_(-1)
    {
    }

    result_list_t ViolationChedaozhanyonglv::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        auto now = this->get_time_point(objs);
        if (pre_time_.count() < 0) {
            pre_time_ = now;
        }
        if (now - pre_time_ >= std::chrono::milliseconds(1000)) {
            if(objs.objects.size() != 0){
                float tmp_area = (area_boxes(objs.objects, cfg_->violate_box) / cfg_->violate_box_area);
                ratio_ += tmp_area;
                ratio_cnt_ ++;
            }
            pre_time_ = now;
        }

        if (one_min_.count() < 0) {
            one_min_ = now;
        }
        if (now - one_min_ >= std::chrono::milliseconds(60 * 1000)) {
            this->add_snapshot(box, objs);
            this->snapshots_.back().ratio = ratio_ / ratio_cnt_;
            retv = get_results();
            ratio_ = 0.0f;
            ratio_cnt_ = 0;
            one_min_ = now;
            this->clear_snapshot();
        }

        return retv;
    }

// ViolationChedaozhanyonglvFactory
    ViolationChedaozhanyonglvFactory::ViolationChedaozhanyonglvFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationChedaozhanyonglvConfig>(cfg))
    {
    }

    const std::string& ViolationChedaozhanyonglvFactory::id()const
    {
        return id_;
    }

    spIViolation ViolationChedaozhanyonglvFactory::CreateIViolation(const BoxF& obj)
    {
        if (obj.label == -1){
            return std::make_shared<ViolationChedaozhanyonglv>(obj.uid, id_, cfg_);
        }
        else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(CDZYL_CODE, Chedaozhanyonglv);
//    REGISTER_VIOLATION_PATTERN(CDZYL_PATTERN, Chedaozhanyonglv);

} // namespace FLOW
