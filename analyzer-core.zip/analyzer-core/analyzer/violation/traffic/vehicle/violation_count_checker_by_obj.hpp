#ifndef VSS_VIOLATION_COUNT_CHECKER_BY_OBJ_HPP
#define VSS_VIOLATION_COUNT_CHECKER_BY_OBJ_HPP

#include <vector>
#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationCountCheckerByObjConfig {
public:
    ViolationCountCheckerByObjConfig(const std::string& json);
    bool ParseJson(const std::string& json);
public:
    typedef std::function<bool(const BoxF&,const BoxF&)> fn_compare_box;
    typedef     std::vector<float> VecFloat;
    VecFloat    violate_box;
    int         parking_second;
    int         cooling_second;
    int         min_car_count;
    int         min_nonmotor_count;
    int         min_person_count;
    float       max_move_percent;
    float       distance;

    fn_compare_box     user_def_compare;
    spViolationConfig  violation_cfg;
};


class ViolationCountCheckerByObjFactory : public ViolationCommonFactory 
{
public:
    ViolationCountCheckerByObjFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationCountCheckerByObjFactory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                       id_;
    ViolationCountCheckerByObjConfig  cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_COUNT_CHECKER_BY_OBJ_HPP
