
#include <iterator>
#include <map>
#include <vector>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"
#include "serving/violation_config.pb.h"

#include "violation_groupchangelanes.hpp"
#include "violation/violation_util.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/conditions/line_condition.hpp"

namespace FLOW {

    static const std::string QUNTIBIANDAO_NAME("GroupChangeLanes");
    static const std::string QUNTIBIANDAO_CODE("2471");

//
// ViolationGroupChangeLanesConfig
//
    class ViolationGroupChangeLanesConfig {
    public:
        ViolationGroupChangeLanesConfig(const std::string& json)
                : car_count(3)
                , period_second(60)
        {
            auto result=this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json);
    public:
        fn_check_action     start_line_checker;
        fn_check_action     end_line_checker;
        int                 car_count;
        int                 period_second;
        spViolationConfig   violation_cfg;
    };

    bool ViolationGroupChangeLanesConfig::ParseJson(const std::string& json) {
        std::string err;
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;
        const int MIN_SIZE = 2*3;
        const auto& roi_data = cfg.roi();
        for (int i=0; i<cfg.conditions_size(); i++) {
            const auto& cond = cfg.conditions(i);
            if (cond.name() == "start_line"){
                CHECK_GE(cond.data_size(), 4);
                start_line_checker = CreateLineCondition(cond, false, roi_data);
            }
            if (cond.name() == "stop_line"){
                CHECK_GE(cond.data_size(), 4);
                end_line_checker = CreateLineCondition(cond, false, roi_data);
                if (cond.has_car_count()) {
                    car_count = cond.car_count();
                }
                if (cond.has_period_second()) {
                    period_second = cond.period_second();
                }
            }
        }
        if (!start_line_checker) {
            LOG(ERROR) << err <<"violate_line config error";
            return false;
        }
        if (!end_line_checker) {
            LOG(ERROR) << err <<"stop_line config error";
            return false;
        }
        return true;
    }
//
// ViolationGroupChangeLanes
//
    class ViolationGroupChangeLanes : public ViolationBase
    {
    public:
        ViolationGroupChangeLanes(int object_id, const std::string& violation_id, const spViolationGroupChangeLanesConfig cfg);
        virtual ~ViolationGroupChangeLanes()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

    protected:
        struct Cars_Info{
            std::chrono::milliseconds         car_start;
            std::chrono::milliseconds         car_end;
            bool                car_sflag;
            bool                car_eflag;
            BoxF                last_obj;
        };

    protected:
        const spViolationGroupChangeLanesConfig    cfg_;
        std::chrono::milliseconds                  pre_time_;
        std::map<int, Cars_Info>                   cars_info_;
        std::map<int, Cars_Info>                   period_cars_info_;
    };

    ViolationGroupChangeLanes::ViolationGroupChangeLanes(int object_id, const std::string& violation_id, const spViolationGroupChangeLanesConfig cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
            , pre_time_(-1)
            , cars_info_()
            , period_cars_info_()
    {
    }

    result_list_t ViolationGroupChangeLanes::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        auto now = this->get_time_point(objs);
        for (const auto& obj : objs.objects) {
            if (obj.uid < 0) {
                continue;
            }
            if (obj.delete_flag) {
                if (cars_info_.count(obj.uid) > 0) {
                    cars_info_.erase(obj.uid);
                }
                continue;
            }
            if (obj.label == OBJECT_TYPE_VEHICLE) {
                if (cars_info_.count(obj.uid) == 0){
                    // init last_obj
                    cars_info_[obj.uid].last_obj = obj;
                }
                if (! cars_info_[obj.uid].car_sflag) {
                    if (cfg_->start_line_checker(cars_info_[obj.uid].last_obj, obj, objs)) {
                        cars_info_[obj.uid].car_sflag = true;
                        cars_info_[obj.uid].car_start = now;
                    }
                } else if (! cars_info_[obj.uid].car_eflag) {
                    if (cfg_->end_line_checker(cars_info_[obj.uid].last_obj, obj, objs)) {
                        cars_info_[obj.uid].car_eflag = true;
                        cars_info_[obj.uid].car_end = now;
                        period_cars_info_[obj.uid] = cars_info_[obj.uid];
                    }
                } else {
                    continue;
                    // nop
                }
                // update last_obj
                cars_info_[obj.uid].last_obj = obj;
            }
        }

        if (pre_time_.count() < 0) {
            pre_time_ = now;
        }
        if (now - pre_time_ >= std::chrono::milliseconds(cfg_->period_second * 1000)) {
            if(period_cars_info_.size() >= cfg_->car_count) {
                this->clear_snapshot();
                this->add_snapshot(BoxF{}, objs);
                // result
                retv = get_results();
            }
            pre_time_ = now;
            period_cars_info_.clear();
            this->clear_snapshot();
        }

        return retv;
    }

//
// ViolationGroupChangeLanesFactory
//
    ViolationGroupChangeLanesFactory::ViolationGroupChangeLanesFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationGroupChangeLanesConfig>(cfg))
    {
    }

    const std::string& ViolationGroupChangeLanesFactory::id()const {
        return id_;
    }

    spIViolation ViolationGroupChangeLanesFactory::CreateIViolation(const BoxF& obj){
        if (obj.label == -1){
            return std::make_shared<ViolationGroupChangeLanes>(obj.uid, id_, cfg_);
        } else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(QUNTIBIANDAO_CODE, GroupChangeLanes);

} // namespace FLOW