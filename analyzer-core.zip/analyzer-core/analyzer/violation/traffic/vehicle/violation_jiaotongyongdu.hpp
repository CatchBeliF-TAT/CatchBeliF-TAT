#ifndef VSS_VIOLATION_JIAOTONGYONGDU_HPP
#define VSS_VIOLATION_JIAOTONGYONGDU_HPP

#include <vector>
#include <memory>

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationJiaotongyongduConfig;
typedef std::shared_ptr<ViolationJiaotongyongduConfig> spViolationJiaotongyongduConfig;

class ViolationJiaotongyongduFactory : public ViolationCommonFactory 
 {
public:
    ViolationJiaotongyongduFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationJiaotongyongduFactory()=default;

public:
    virtual const std::string& id()const;
    virtual spIViolation CreateIViolation(const BoxF& obj);

protected:
    std::string                     id_;
    spViolationJiaotongyongduConfig   cfg_;
 };

} // namespace FLOW
#endif // VSS_VIOLATION_JIAOTONGYONGDU_HPP
