#include <vector>
#include <map>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_paiduichangdu.hpp"

namespace FLOW {

    static const std::string PDCD_NAME("paiduichangdu");
    static const std::string PDCD_CODE("2740");

    typedef     std::vector<float> VecFloat;
// ViolationPaiDuiChangDuConfig
    class ViolationPaiDuiChangDuConfig {
    public:
        ViolationPaiDuiChangDuConfig(const std::string& json){
            auto result = this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json) {
            std::string err;
            violation_cfg = std::make_shared<inference::ViolationConfig>();
            json2pb(json, violation_cfg.get(), &err);
            if (!err.empty()){
                LOG(WARNING) << err <<", json= "<< json;
                return false;
            }
            auto& cfg = *violation_cfg;
            name = cfg.name();
            code = cfg.code();
            const int MIN_SIZE = 2*3;
            for (int i=0; i<cfg.conditions_size(); i++) {
                const auto& cond = cfg.conditions(i);
                if (cond.name() == "isoline"){
                    std::map<float, VecFloat> dis_line_map;
                    std::vector<VecFloat> vec_line;
                    int data_size = cond.data_size(), distance_size = cond.multi_distance_size();
                    CHECK_GE(data_size, MIN_SIZE);
                    CHECK_EQ(data_size%4, 0);
                    CHECK_EQ(data_size/4, distance_size);
                    for ( int start = 0; start < data_size - 3 ;start += 4) {
                        VecFloat tmp_line;
                        std::copy_n(cond.data().begin()+start, 4, std::back_inserter(tmp_line));
                        vec_line.push_back(tmp_line);
                    }
                    std::copy_n(cond.multi_distance().begin(), distance_size, std::back_inserter(distance));
                    for ( int dist_i = 0; dist_i < distance.size(); ++dist_i ){
                        dis_line_map.insert(std::make_pair(distance[dist_i], vec_line[dist_i]));
                    }
                    int index = 0;
                    for ( const auto &ele : dis_line_map ) {
                        distance[index] = ele.first;
                        vec_line[index] = ele.second;
                        index++;
                    }
                    //取相邻线的中点连线与中线长度
                    for ( int line_no = 0; line_no < vec_line.size()-1; line_no++) {
                        const auto &line_1 = vec_line[line_no];
                        const auto &line_2 = vec_line[line_no + 1];
                        VecFloat violation_rect;
                        violation_rect.insert(violation_rect.end(), line_1.begin(), line_1.end());
                        if (is_intersect(
                            PointF(line_1[0],line_1[1]),
                            PointF(line_2[0],line_2[1]),
                            PointF(line_1[2],line_1[3]),
                            PointF(line_2[2],line_2[3]))
                        ) {
                             violation_rect.insert(violation_rect.end(), line_2.begin(), line_2.end());
                        } else {
                            violation_rect.insert(violation_rect.end(), line_2.begin()+2, line_2.end());
                            violation_rect.insert(violation_rect.end(), line_2.begin(), line_2.begin()+2);
                        }
                        vec_violate_box.push_back(violation_rect);
                        //VecFloat  mid_line;
                        //mid_line.push_back((line_1[2] + line_1[0])/2.0);
                        //mid_line.push_back((line_1[3] + line_1[1])/2.0);

                        //mid_line.push_back((line_2[2] + line_2[0])/2.0);
                        //mid_line.push_back((line_2[3] + line_2[1])/2.0);
                        //float mid_line_distance = (mid_line[2] - mid_line[0])*(mid_line[2] - mid_line[0]);
                        //mid_line_distance += (mid_line[3] - mid_line[1])*(mid_line[3] - mid_line[1]);
                        //vec_mid_line.push_back(mid_line);
                        //vec_mid_line_distance.push_back(std::sqrt(mid_line_distance));
                    }
                    if ( cond.has_parking_second() ) {
                        parking_second = cond.parking_second();
                    }
                    if(cond.has_mode_args() && cond.mode_args().has_center()) {
                        const auto center = cond.mode_args().center();
                        scale_x = center.has_x() ? center.x() : 0.5;
                        scale_y = center.has_y() ? center.y() : 1.0;
                    }
                }
            }
            return !distance.empty() && !vec_violate_box.empty();
        }
    public:
        std::vector<VecFloat>   vec_violate_box;
        //std::vector<VecFloat>   vec_mid_line;
        //VecFloat                vec_mid_line_distance;
        VecFloat                distance;
        std::string             code;
        std::string             name;
        int                     parking_second = 3;
        float                   max_move_percent = 0.1;
        float                   scale_x = 0.5;
        float                   scale_y = 1.0;
        spViolationConfig       violation_cfg;
    };

// ViolationPaiDuiChangDu
    class ViolationPaiDuiChangDu : public ViolationBase
    {
    public:
        ViolationPaiDuiChangDu(int object_id, const std::string& violation_id, const spViolationPaiDuiChangDuConfig& cfg);
        virtual ~ViolationPaiDuiChangDu() = default;

    public:
        virtual result_list_t check(BoxF&, const ImageObjectsInfo&);
    public:
        struct CarInfo{
            BoxF                      car_box = BoxF();
            std::chrono::milliseconds start_park_time;
            int                       line_index = -1;
            bool                      update_status = false;
        };
        typedef std::map<int, CarInfo> CarMapInRoad;
    private:
        void updateCarsLocationAndState(const VecBoxF& objects);
        void updateCarLocation(const BoxF& obj, CarInfo& car_info);
        //float projected_length(const BoxF& b, const VecFloat& mid_line, float distance, bool start_point) const;
    protected:
        spViolationPaiDuiChangDuConfig        cfg_;
        std::chrono::milliseconds             pre_time_;
        std::chrono::milliseconds             one_min_;
        std::chrono::milliseconds             obj_time_;
        float                                 max_vehicle_queue_;
        CarMapInRoad                          cars_in_road_;  
    };

    ViolationPaiDuiChangDu::ViolationPaiDuiChangDu(int object_id, const std::string& violation_id, const spViolationPaiDuiChangDuConfig& cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
            , pre_time_(-1)
            , one_min_(-1)
            , max_vehicle_queue_(0.0)
    {
    }

    void ViolationPaiDuiChangDu::updateCarsLocationAndState(const VecBoxF& objects) {
        for (const auto &obj : objects) {
            if ( obj.label != OBJECT_TYPE_VEHICLE) {
                continue;
            }
            if ( cars_in_road_.find ( obj.uid ) != cars_in_road_.end() ) {
                if ( !valid_box_box_distance(obj, cars_in_road_[obj.uid].car_box, cfg_->max_move_percent) ) {
                    updateCarLocation(obj, cars_in_road_[obj.uid]);
                } else {
                    cars_in_road_[obj.uid].update_status = true;
                }
            } else {
                CarInfo car_info = CarInfo();
                updateCarLocation(obj, car_info);
                cars_in_road_.insert(std::make_pair(obj.uid, car_info));
            }
        }

        for ( auto it = cars_in_road_.begin(); it != cars_in_road_.end(); ) {
            if ( !it->second.update_status) {
                cars_in_road_.erase(it++);
            } else {
                it->second.update_status = false;
                it++;
            }
        }
        
    }
    ////计算投影长度
    //float ViolationPaiDuiChangDu::projected_length(const BoxF& b, const VecFloat& mid_line, float distance, bool start_point) const {
    //    float x, y;
    //    if ( start_point ) {
    //        x = b.xmin + cfg_->scale_x*(b.xmax-b.xmin) - mid_line[0];
    //        y = b.ymin + cfg_->scale_y*(b.ymax-b.ymin) - mid_line[1];
    //    } else {
    //        x = b.xmin + cfg_->scale_x*(b.xmax-b.xmin) - mid_line[2];
    //        y = b.ymin + cfg_->scale_y*(b.ymax-b.ymin) - mid_line[3];
    //    }
    //    const auto x2 = mid_line[2] - mid_line[0];
    //    const auto y2 = mid_line[3] - mid_line[1];
    //    const auto retv = (x*x2+y*y2)/distance;
    //    return retv;
    //}

    //void ViolationPaiDuiChangDu::updateCarLocation(const BoxF& obj, CarInfo& car_info) {
    //    int start_line_no = 0, end_line_no = cfg_->vec_mid_line.size();
    //    int stop_line_no = -1;
    //    while ( start_line_no < end_line_no ) {
    //        int line_no = (start_line_no + end_line_no )/2;
    //        float distance_1 = projected_length(obj, cfg_->vec_mid_line[line_no], cfg_->vec_mid_line_distance[line_no], true);
    //        float distance_2 = projected_length(obj, cfg_->vec_mid_line[line_no], cfg_->vec_mid_line_distance[line_no], false);
    //        float result = distance_1 * distance_2;
    //        if ( result < 0.0f ) { //选取的点与中线的头尾连线的线在中线上的投影长度相乘为负数, 说明选取的点在中线之间的位置
    //            stop_line_no = line_no + 1;
    //            break;
    //        } else if ( result == 0.0f ){ //选取的点刚好在线上, 则取所在点所在线的距离
    //            if ( distance_1 == 0.0f) {
    //                stop_line_no = line_no;
    //            } else {
    //                stop_line_no = line_no + 1;
    //            }
    //            break;
    //        } else {
    //            if ( distance_1 > 0 ) {
    //                start_line_no = line_no + 1;
    //            } else {
    //                end_line_no = line_no;
    //            }
    //        }
    //    }
        
    //    car_info.car_box = obj;
    //    car_info.line_index = stop_line_no;
    //    car_info.update_status = true;
    //    car_info.start_park_time = obj_time_;
    //}

    void ViolationPaiDuiChangDu::updateCarLocation(const BoxF& obj, CarInfo& car_info) {
        const auto vec_violate_box = cfg_->vec_violate_box;

        const auto& size = vec_violate_box.size();
        if (valid_boxes_scale_center_in_polygon(obj, cfg_->scale_x, cfg_->scale_y, vec_violate_box[0].data(), vec_violate_box[0].size()) ||
           valid_boxes_scale_center_in_polygon(obj, 0.5, 0.0, vec_violate_box[0].data(), vec_violate_box[0].size()) ||
           valid_boxes_scale_center_in_polygon(obj, 0.5, 1.0, vec_violate_box[0].data(), vec_violate_box[0].size())) {
            car_info.car_box = obj;
            car_info.line_index = 1;
            car_info.update_status = true;
            car_info.start_park_time = obj_time_;
            return;
        }
        if ( size >= 2) {
            if ( valid_boxes_scale_center_in_polygon(obj, cfg_->scale_x, cfg_->scale_y, vec_violate_box[size-1].data(), vec_violate_box[size-1].size()) ||
                valid_boxes_scale_center_in_polygon(obj, 0.5, 0.0, vec_violate_box[size-1].data(), vec_violate_box[size-1].size()) ||
                valid_boxes_scale_center_in_polygon(obj, 0.5, 1.0, vec_violate_box[size-1].data(), vec_violate_box[size-1].size()) ) {
                car_info.car_box = obj;
                car_info.line_index = size;
                car_info.update_status = true;
                car_info.start_park_time = obj_time_;
                return;
            }
        }

        for ( int i = 1; i < size - 1; ++i) {
            if ( valid_boxes_scale_center_in_polygon(obj, cfg_->scale_x, cfg_->scale_y, vec_violate_box[i].data(), vec_violate_box[i].size())) {
                car_info.car_box = obj;
                car_info.line_index = i + 1;
                car_info.update_status = true;
                car_info.start_park_time = obj_time_;
                break;
            }
        }
        return;
    }
    result_list_t ViolationPaiDuiChangDu::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        auto now = this->get_time_point(objs);
        obj_time_ = now;
        if (pre_time_.count() < 0) {
            pre_time_ = now;
        }
        if (now - pre_time_ >= std::chrono::milliseconds(1000)) {
            updateCarsLocationAndState(objs.objects);
            for ( const auto& car_info : cars_in_road_ ) {
                if ( (now - car_info.second.start_park_time).count() >=  cfg_->parking_second*1000 && car_info.second.line_index >= 0 ) {
                    max_vehicle_queue_ = std::max(max_vehicle_queue_, cfg_->distance[car_info.second.line_index]);
                }
            }
            pre_time_ = now;
        }

        if (one_min_.count() < 0) {
            one_min_ = now;
        }
        if (now - one_min_ >= std::chrono::milliseconds(60 * 1000)) {
            this->add_snapshot(box, objs);
            this->snapshots_.back().vehicle_queue = max_vehicle_queue_;
            retv = get_results();
            max_vehicle_queue_ = 0.0;
            one_min_ = now;
            this->clear_snapshot();
        }

        return retv;
    }

// ViolationPaiDuiChangDuFactory
    ViolationPaiDuiChangDuFactory::ViolationPaiDuiChangDuFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationPaiDuiChangDuConfig>(cfg))
    {
    }

    const std::string& ViolationPaiDuiChangDuFactory::id()const
    {
        return id_;
    }

    spIViolation ViolationPaiDuiChangDuFactory::CreateIViolation(const BoxF& obj)
    {
        if (obj.label == -1){
            return std::make_shared<ViolationPaiDuiChangDu>(obj.uid, id_, cfg_);
        }
        else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(PDCD_CODE, PaiDuiChangDu);
} // namespace FLOW
