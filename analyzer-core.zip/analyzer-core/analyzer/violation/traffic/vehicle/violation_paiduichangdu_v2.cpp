#include <iterator>
#include <map>
#include <vector>
#include <chrono>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_paiduichangdu_v2.hpp"
#include "algorithm/vehicleattribute/vehicle_attr.hpp"
#include "serving/violation_event.pb.h"
#include "core/alg_engine/alg_engine_interface.hpp"

namespace FLOW {

    static const std::string PDCDV2_NAME("paiduichangduv2");
    static const std::string PDCDV2_CODE("2760");

//
// ViolationPaiduichangduV2Config
//
    class ViolationPaiduichangduV2Config {
    public:
        ViolationPaiduichangduV2Config(const std::string& json)
        {
            auto result=this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json);
    protected:
        typedef std::vector<float>                 VecFloat;
    public:
        VecFloat           violate_box;
        float              scale_x = 0.5;
        float              scale_y = 1;
        spViolationConfig  violation_cfg;
    };

    bool ViolationPaiduichangduV2Config::ParseJson(const std::string& json) {
        std::string err;
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;

        const int MIN_SIZE = 2 * 3;

        for (int i=0; i<cfg.conditions_size(); i++) {
            const auto& cond = cfg.conditions(i);

            if (cond.name() == "violate_box") {
                CHECK_GE(cond.data_size(), MIN_SIZE);
                std::copy_n(cond.data().begin(), cond.data_size() / 2 * 2, std::back_inserter(violate_box));
                
                if(cond.has_mode_args() && cond.mode_args().has_center()) {
                    const auto center = cond.mode_args().center();
                    scale_x = center.has_x() ? center.x() : 0.5;
                    scale_y = center.has_y() ? center.y() : 0.5;
                }
            }
        }
        return violate_box.size();
    }
//
// ViolationPaiduichangduV2
//
    class ViolationPaiduichangduV2 : public ViolationBase
    {
    public:
        ViolationPaiduichangduV2(int object_id, const std::string& violation_id, const spViolationPaiduichangduV2Config cfg);
        virtual ~ViolationPaiduichangduV2()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
        virtual result_list_t get_results()const; 
    protected:
        const spViolationPaiduichangduV2Config   cfg_;
        VecBoxF                                  cars_in_roi_;
    };

    ViolationPaiduichangduV2::ViolationPaiduichangduV2(int object_id, const std::string& violation_id, const spViolationPaiduichangduV2Config cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
    {
    }

    result_list_t ViolationPaiduichangduV2::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
    
        auto now = this->get_time_point(objs);
        
        if (this->snapshots_.empty()) {
            // add first picture for get elapsed time
            this->add_snapshot(BoxF(), objs);
        }

        if (this->get_elapsed_time(objs) >= std::chrono::milliseconds(1000) ) {
            this->clear_snapshot();
            this->add_snapshot(BoxF(), objs);
            cars_in_roi_.clear();
            for (const auto& box : objs.objects) {
                if ( box.delete_flag || box.label != OBJECT_TYPE_VEHICLE) {
                    continue;
                }
                if ( valid_boxes_scale_center_in_polygon(box, cfg_->scale_x, cfg_->scale_y, cfg_->violate_box.data(), cfg_->violate_box.size()) ) {
                    cars_in_roi_.push_back(box);
                }
            }
            retv = get_results();
        }

        return retv;
    }
    result_list_t ViolationPaiduichangduV2::get_results()const{
        result_list_t retv;
        const auto obj_id = object_id_;
        const auto stream_id = snapshots_[0].image->channel_id;
        const auto violation_code = violation_cfg_->code();
        const auto violation_name = violation_cfg_->name();
        const auto violation_id = violation_id_;
        const auto snapshot = snapshots_[0];
        const auto objects = cars_in_roi_;
        auto action = [=](ICAlgEngine* engine) -> spEventProto {
            auto retv = std::make_shared<inference::Event>();
            inference::Event& event_with_type = *retv;
            event_with_type.set_event_type("lltj");
            inference::ViolationEvent& event = *(event_with_type.mutable_traffic_event());
            event.set_stream_id(stream_id);
            event.set_obj_id(obj_id);
            event.set_violation_id(violation_id);
            event.set_violation_code(violation_code);
            event.set_violation_name(violation_name);
            
            auto& image = snapshot.image;
            auto snap1 = event.add_snapshots();

           if (image->ntp_time_stamp > 0) {
                snap1->set_ntp_time_stamp(image->ntp_time_stamp);
            }

            snap1->set_now(snapshot.now.time_since_epoch().count());
                
            // add objects
            for(auto& box : objects) {
                auto obj = snap1->add_objects();
                obj->add_box(box.xmin);
                obj->add_box(box.ymin);
                obj->add_box(box.xmax);
                obj->add_box(box.ymax);

                if(box.label!= -1){
                    std::to_string(box.label);
                    obj->set_score(box.score);
                }
                
                if( box.attr_type.type != -1) {
                    if (box.label == OBJECT_TYPE_VEHICLE){
                        obj->set_sub_type(Attribute::helperGetStringVehicleType(
                            (Attribute::VehicleType)box.attr_type.type));
                    }
                    obj->set_sub_type_score(box.attr_type.score);
                }

                if (box.special_car_type.type != -1) {
                    obj->set_special_car_type(Attribute::helperGetStringVehicleSpecialType(
                        (Attribute::VehicleSpecialType)box.special_car_type.type));
                    obj->set_special_car_type_score(box.special_car_type.score);
                }

                if (box.attr_direction.type != -1) {
                    obj->set_direction(Attribute::helperGetStringVehicleDirectionType(
                            (Attribute::VehicleDirectionType)box.attr_direction.type));
                    obj->set_direction_score(box.attr_direction.score);
                }

                if(box.uid!= -1){
                    obj->set_id(box.uid);
                }
            }

            return retv;
        };
        retv.push_back(action);
        return retv;
    }

//
// ViolationPaiduichangduV2Factory
//
    ViolationPaiduichangduV2Factory::ViolationPaiduichangduV2Factory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationPaiduichangduV2Config>(cfg))
    {
    }

    const std::string& ViolationPaiduichangduV2Factory::id()const {
        return id_;
    }

    spIViolation ViolationPaiduichangduV2Factory::CreateIViolation(const BoxF& obj){
        if (obj.label == -1){
            return std::make_shared<ViolationPaiduichangduV2>(obj.uid, id_, cfg_);
        } else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(PDCDV2_CODE, PaiduichangduV2);
} // namespace FLOW
