
#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"

#include "serving/violation_config.pb.h"
#include "common/tad_internal.hpp"
#include "violation/conditions/line_condition.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_zhuanwanburangzhixingfjdcv2.hpp"
#include "algorithm/traffic_light/traffic_light_recog.hpp"
#include "violation/conditions/sub_type_condition.hpp"
#include "violation/conditions/special_car_type_condition.hpp"
namespace FLOW {

static const std::string ZWBRZXFDJCV2_CODE("2129");

class ViolationZhuanwanburangzhixingfjdcV2Config {
public:
    ViolationZhuanwanburangzhixingfjdcV2Config(const std::string& json);

protected:
    bool ParseJson(const std::string& json);

public:
    typedef std::function<bool(const inference::ViolationEvent& e)> fn_filter_action;
    typedef struct {int index; fn_filter_action fun;} filter_action;

    typedef std::vector<float> VecFloat;
    float start_line[4];
    float violate_line[4];
    float stop_line[4];
    VecFloat fjdc_stop_box;
    VecFloat fjdc_run_box;

    fn_check_action     start_line_checker;
    fn_check_action     violate_line_checker;
    fn_check_action     end_line_checker;
    std::shared_ptr<filter_action>              special_car_type_condition_;
    std::shared_ptr<filter_action>              sub_type_condition_;
    spViolationConfig  violation_cfg;
    bool               has_traffic_light=false;
};

ViolationZhuanwanburangzhixingfjdcV2Config::ViolationZhuanwanburangzhixingfjdcV2Config(const std::string& json)
    : start_line{0.0f}
    , violate_line{0.0f}
    , stop_line{0.0f}
    , fjdc_stop_box()
    , fjdc_run_box()
    , violation_cfg(std::make_shared<inference::ViolationConfig>())
{
    auto result = this->ParseJson(json);
    CHECK(result);

    // add special_car_type_condition_
    special_car_type_condition_ = std::make_shared<filter_action>();
    special_car_type_condition_->fun = CreateSpecialCarTypeCondition(violation_cfg.get());

    // add sub_type_condition_
    sub_type_condition_ = std::make_shared<filter_action>();
    sub_type_condition_->fun = CreateSubTypeCondition(violation_cfg.get());
}

bool ViolationZhuanwanburangzhixingfjdcV2Config::ParseJson(const std::string& json) {
    std::string err;
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }

    auto& cfg = *violation_cfg;
    has_traffic_light = cfg.traffic_light_box_size();
    const int MIN_SIZE = 4;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "start_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), MIN_SIZE, std::begin(start_line));
            start_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
        } else if (cond.name() == "violate_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), MIN_SIZE, std::begin(violate_line));
            violate_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
        } else if (cond.name() == "stop_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), MIN_SIZE, std::begin(stop_line));
            end_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
        } else if (cond.name() =="fjdc_stop_box") {
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(fjdc_stop_box));
        } else if (cond.name() =="fjdc_run_box") {
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(fjdc_run_box));
        }
    }
    return true;
}

class ViolationZhuanwanburangzhixingfjdcV2 : public ViolationBase
{
public:
    ViolationZhuanwanburangzhixingfjdcV2(int object_id, const std::string& violation_id, const spViolationZhuanwanburangzhixingfjdcV2Config cfg);
    virtual ~ViolationZhuanwanburangzhixingfjdcV2()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& frame);
    virtual bool results_filter(const inference::ViolationEvent& e) const;
protected:
    enum STATUS{
        eUNDEFINE,
        eCROCESSED_FIRST_LINE,
        eCROCESSED_SECOND_LINE,
        eNONMOTOR_IN_RUN,
        eCROCESSED_THIRD_LINE
    };

protected:
    spViolationZhuanwanburangzhixingfjdcV2Config  cfg_;
    STATUS                          status_;
    std::map<int, BoxF>             nonmotors_;
    BoxF                            last_box_;
    bool                            maked_first_pic = false;
};

ViolationZhuanwanburangzhixingfjdcV2::ViolationZhuanwanburangzhixingfjdcV2(int object_id, const std::string& violation_id, const spViolationZhuanwanburangzhixingfjdcV2Config cfg)
    : ViolationBase(object_id, violation_id, cfg->violation_cfg)
    , cfg_(cfg)
    , status_(eUNDEFINE)
    , nonmotors_()
{
}

result_list_t ViolationZhuanwanburangzhixingfjdcV2::check(BoxF& box, const ImageObjectsInfo& frame)
{
    result_list_t retv;
    // init last_box_
    if (last_box_.uid == -1) {
        last_box_ = box;
    }
    std::shared_ptr<void> update_last_box(nullptr,[&](void*){
        last_box_ = box;
    });

    auto i = frame.tlc.find(violation_id_);
    auto color = TrafficLight::kColorEmpty;
    if(i!=frame.tlc.end()){
        color = i->second.color;
    }
    if(status_==eUNDEFINE){
        if (valid_box_in_range(box, frame.sframe->width(), frame.sframe->height(), cfg_->violation_cfg->plate_available_box_percent()) &&
            cfg_->start_line_checker(last_box_, box, frame)){
            status_ = eCROCESSED_FIRST_LINE;
            LOG(INFO)<<"==>enter view, "<< frame.channel_id<<","<<violation_id_<<","<<object_id_;
        }
    }

    if(status_==eCROCESSED_FIRST_LINE){
        if (cfg_->violate_line_checker(last_box_, box, frame)){
            status_ = eCROCESSED_SECOND_LINE;
            LOG(INFO)<<"==>cross violate line, "<< frame.channel_id<<","<<violation_id_<<","<<object_id_;
        }else{
            std::for_each(frame.objects.begin(),frame.objects.end(),[this](const BoxF& one){
                if (one.label == OBJECT_TYPE_NONMOTOR &&
                        pnpoly(cfg_->fjdc_stop_box.data(), cfg_->fjdc_stop_box.size()/2*2, (one.xmin+one.xmax)/2, (one.ymin+one.ymax)/2)){
                    nonmotors_[one.uid]=one;
                }
            });
            if(nonmotors_.empty()){
                box.violate_state = 2;//yellow
            }else{
                box.violate_state = 255000;//green
                if(!maked_first_pic){
                    this->add_snapshot(box, frame);
                    maked_first_pic = true;
                }
            }
        }
    }

    if(status_==eCROCESSED_SECOND_LINE){
        auto blocked_nonmotor = std::find_if(frame.objects.begin(),frame.objects.end(), [this](const BoxF& one)->bool{
            if (one.label == OBJECT_TYPE_NONMOTOR && 
                    nonmotors_.find(one.uid) != nonmotors_.end() &&
                    pnpoly(cfg_->fjdc_run_box.data(), cfg_->fjdc_run_box.size()/2*2, (one.xmin+one.xmax)/2, (one.ymin+one.ymax)/2)){
                return true;
            }else{
                return false;
            }
        });

        if (blocked_nonmotor != frame.objects.end()) {
            status_ = eNONMOTOR_IN_RUN;
            if(cfg_->has_traffic_light && color!=TrafficLight::kColorEmpty){
                this->add_snapshot(color, box, frame);
            }else{
                this->add_snapshot(box, frame);
            }
        }
        box.violate_state = 255000000; //blue 
    }

    if(status_==eNONMOTOR_IN_RUN){
        box.violate_state = 203192255; //pink
        if (cfg_->end_line_checker(last_box_, box, frame)){
            status_ = eCROCESSED_THIRD_LINE;
            LOG(INFO)<<"==>cross end line, "<< frame.channel_id<<","<<violation_id_<<","<<object_id_;
            this->add_snapshot(box, frame);
            retv = get_results();
        }         
    }

    if(status_==eCROCESSED_THIRD_LINE){
        box.violate_state = 3;//red
    }

    return retv;
}

bool ViolationZhuanwanburangzhixingfjdcV2::results_filter(const inference::ViolationEvent& e)const{
    if (ViolationBase::results_filter(e)) {
        return true;
    }
    if (! cfg_->special_car_type_condition_->fun(e)) {
        LOG(INFO) << "==>match filter: " << "special_car_type" << ", "
                << e.stream_id() << "," 
                << e.violation_id() << ","
                << e.obj_id()<< ","
                << e.violation_code();
        return true;
    }
    if (! cfg_->sub_type_condition_->fun(e)) {
        LOG(INFO) << "==>match filter: " << "sub_type" << ", "
                << e.stream_id() << "," 
                << e.violation_id() << ","
                << e.obj_id()<< ","
                << e.violation_code();
        return true;
    }
    return false;
}

//
// ViolationZhuanwanburangzhixingfjdcV2Factory
//
ViolationZhuanwanburangzhixingfjdcV2Factory::ViolationZhuanwanburangzhixingfjdcV2Factory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(std::make_shared<ViolationZhuanwanburangzhixingfjdcV2Config>(cfg))
{
}

const std::string& ViolationZhuanwanburangzhixingfjdcV2Factory::id()const
{
    return id_;
}

spIViolation ViolationZhuanwanburangzhixingfjdcV2Factory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == OBJECT_TYPE_VEHICLE){
        return std::make_shared<ViolationZhuanwanburangzhixingfjdcV2>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(ZWBRZXFDJCV2_CODE, ZhuanwanburangzhixingfjdcV2);

} // namespace FLOW
