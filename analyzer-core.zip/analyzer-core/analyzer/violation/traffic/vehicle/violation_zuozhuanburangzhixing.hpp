#ifndef __VIOLATION_ZUOZHUANBURANGZHIXING__
#define __VIOLATION_ZUOZHUANBURANGZHIXING__

#include <vector>
#include <memory>

#include "violation/traffic/violation_common.hpp"
#include "violation/conditions/line_condition.hpp"
namespace FLOW {

static const std::string ZZBRZX_NAME("zuozhuanburangzhixing");
static const std::string ZZBRZX_CODE("2134");

// 通用模版
//static const std::string ZZBRZX_CODE_PATTERN("^2134[0-9]{2}$");

inline bool is_highway(const std::string& code) {
    return code.substr(0,2) == "24";
}

class CoordinateTransform_copy {
public:
    CoordinateTransform_copy(float x1=0, float y1=0, float x2=0, float y2=0) {
        const float dx = x2-x1;
        const float dy = y2-y1;
        const float dd = dx*dx + dy*dy;
        const float d = sqrt(dd);
        if (d < 1e-6) {
            cos_ = 1;
            sin_ = 0;
        } else {
            sin_ = dy/d;
            cos_ = dx/d;
        }
        sin2x_ = 2*cos_*sin_;
        x_ = x1;
        y_ = y1;
    }
    float X(float x, float y) const {
        return (x-x_)*cos_ + (y-y_)*sin_;
    }
    float Y(float x, float y) const {
        return (y-y_)*cos_ - (x-x_)*sin_;
    }
    float Sin2x() const {
        return sin2x_;
    }
protected:
    float sin_;
    float cos_;
    float x_;
    float y_;
    float sin2x_;
};

class ViolationZzbrzxConfig
{
public:
    ViolationZzbrzxConfig(const std::string& json);
    bool ParseJson(const std::string& json);

public:
    spViolationConfig  m_violation_cfg;
    std::string m_code;
    std::string m_name;

    typedef     std::vector<float> m_VecFloat;
    VecFloat    m_zuo_start_line;
    VecFloat    m_zuo_mid_line; 
    VecFloat    m_zuo_end_line;
    fn_check_action m_zuo_start_line_checker;
    fn_check_action m_zuo_end_line_checker;
    fn_check_action m_zuo_mid_line_checker;
    CoordinateTransform_copy m_zuo_mid_line_converter;

    VecFloat    m_zhi_start_line;
    VecFloat    m_zhi_end_line;
    VecFloat    m_zhi_violate_box;
};
typedef std::shared_ptr<ViolationZzbrzxConfig> spViolationZzbrzxConfig;

class ViolationZuoZhuanBuRangZhiXing: public ViolationBase
{
public:
    ViolationZuoZhuanBuRangZhiXing(int object_id, const std::string& violation_id, const spViolationZzbrzxConfig& cfg);
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
private:
    bool EnterZuoStartLine(const BoxF& box,const ImageObjectsInfo& objs);
    bool EnterZuoMidLine(const BoxF& box,const ImageObjectsInfo& objs);
    bool EnterZuoEndLine(const BoxF& box,const ImageObjectsInfo& objs);
    bool HasHistoryZhiCarOnBecovered(const BoxF& box, const ImageObjectsInfo& objs);
    bool AnyoneCarBecoveredisZhiXing(const BoxF& box, const ImageObjectsInfo& objs,int & becovered_someone);
    bool BoxCenterInZhiXingArea(const BoxF& box);
    bool BoxPointsInZhiXingArea(const BoxF& box);
    bool BoxsPointsInZhiXingArea(const BoxF& filter_box,const ImageObjectsInfo& objs);
    
protected:
    enum STATUS{
        eUNDEFINE,
        eEnterZhiXingArea,
        eEnterZuoEndLine,
        eEvent,
        eEND
    };
public:
    spViolationZzbrzxConfig     m_cfg;
    std::set<int>               m_zhi_car_history; //在左转车过停止线之前就在直行车道的直行车
    std::set<int>               m_zhi_car_becovered; //m_zhi_car_history中被左转车遮挡的直行车
    bool                        m_enter_zuo_end_line;
    bool                        m_becovered_is_zhixing;
    STATUS                      m_status;
    BoxF                        m_last_box;
    float                       m_box_center_in_mid;   
};

class ViolationZuoZhuanBuRangZhiXingFactory : public ViolationCommonFactory 
{
public:
    ViolationZuoZhuanBuRangZhiXingFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationZuoZhuanBuRangZhiXingFactory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                         m_id;
    spViolationZzbrzxConfig   m_cfg;
};


} // namespace FLOW

#endif