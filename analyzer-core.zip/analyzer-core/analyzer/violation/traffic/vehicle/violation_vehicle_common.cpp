#include "violation_vehicle_common.hpp"
#include "algorithm/vehicleattribute/vehicle_attr.hpp"
#include "common/pbjson.hpp"
#include "violation/violation_registry.hpp"
#include "violation/flow/violation_flow_code.hpp"

namespace FLOW {
using namespace std;

    bool fnOBJECT_TYPE_VEHICLE_TRUCK_FILTER(const BoxF& obj){
        return (obj.label == OBJECT_TYPE_VEHICLE &&
                (obj.attr_type.type == Attribute::Vehicle_Middle_Truck ||
                obj.attr_type.type == Attribute::Vehicle_Heavy_Truck ||
                obj.attr_type.type == Attribute::Vehicle_Van_Truck ||
                obj.special_car_type.type == Attribute::Vehicle_Muck_Truck));
    }

    bool fnOBJECT_TYPE_VEHICLE_FILTER(const BoxF& obj){
        return (obj.label == OBJECT_TYPE_VEHICLE);
    }

    bool fnOBJECT_TYPE_VEHICLE_LARGECAR_FILTER(const BoxF& obj){
        return (obj.label == OBJECT_TYPE_VEHICLE &&
            obj.attr_type.type != Attribute::Vehicle_Car &&
            obj.attr_type.type != Attribute::Vehicle_Pick_up &&
            obj.attr_type.type != Attribute::Vehicle_Light_bus &&
            obj.attr_type.type != Attribute::Vehicle_Light_Truck);
    }

    bool fnOBJECT_TYPE_VEHICLE_GAOSU_LARGECAR_FILTER(const BoxF& obj){
        return (obj.label == OBJECT_TYPE_VEHICLE &&
            obj.attr_type.type != Attribute::Vehicle_Car &&
            obj.attr_type.type != Attribute::Vehicle_Light_bus &&
            obj.attr_type.type != Attribute::Vehicle_Bus);
    }

    bool in_times(const std::vector<int>& available_times) {
        const auto now = std::chrono::system_clock::now();
        auto tt = std::chrono::system_clock::to_time_t(now);
        struct tm* ptm = localtime(&tt);
        int iNow =  ptm->tm_hour * 100 +  ptm->tm_min;
        bool bAvailable = false;

        const int count = available_times.size()/2*2;
        for (int i=0; i<count; i+=2) {
            if ( iNow >= available_times[i] && iNow< available_times[i+1]) {
                bAvailable = true;
            }
        }
        return bAvailable;
    }

    class OBJECT_TYPE_VEHICLE_TIME_FILTER{
    public:
        OBJECT_TYPE_VEHICLE_TIME_FILTER(const std::string& cfg){
            auto config_data = std::make_shared<inference::ViolationConfig>();
            string err;
            json2pb(cfg, config_data.get(), &err);
            auto& conditions = config_data->conditions();
            for(auto condition : conditions) {
                if (condition.name() == "available_times") {
                    available_times_.clear();
                    std::copy_n(condition.data().begin(), condition.data().size()/2*2, std::back_inserter(available_times_));
                }
            }
        }
        bool operator()(const BoxF& obj){
            return fnOBJECT_TYPE_VEHICLE_FILTER(obj) && in_times(available_times_);
        }
    public:
        std::vector<int> available_times_;
    };

    // 城市交通
    static const std::string DAWANXIAOZHUAN_CODE("2101");
    static const std::string SHIXIANBIANDAO_CODE("2102");
    static const std::string JIDONGCHEZHANYONGFEIJIDONGCHEDAO_CODE("2103");
    static const std::string BUANDAOXIANGXIANXINGSHI_CODE("2106");
    static const std::string NIXIANGXINGSHI_CODE("2105");
    static const std::string BIANGENGCHEDAOYINGXIANGQITACHE_CODE("2110");
    static const std::string LIANXUBIANDAO_CODE("2111");
    static const std::string WEIXIANLUDUANDIAOTOU_CODE("2112");
    static const std::string CHUANGJINLING_CODE("2113");
    static const std::string ZHANYONGGONGJIAOCHEDAO_CODE("2114");
    static const std::string ZHANYONGZHONGYUNLIANGCHEDAO_CODE("2123");
    static const std::string JINZHIDAHUOCHE_CODE("2115");
    static const std::string DAXINGCHEZHANYONGXIAOXINGCHEDAO_CODE("2116");
    static const std::string KEHUOFENDAO_CODE("2117");
    static const std::string CHUANGHONGDENG_CODE("2121");
    static const std::string CHELIANGXIANSHI_CODE("2119");
    static const std::string ZHANYONGYINGJICHEDAO_CODE("2125");
    static const std::string CHUANYUEDAOLIUXIAN_CODE("2126");
    static const std::string DAXINGCHEYOUZHUAN_CODE("2128");
    static const std::string TEZHONGCHELIANGZHUAPAI_CODE("2140");
    static const std::string TEZHONGCHELIANGZHUAPAIV2_CODE("2141");
    static const std::string CHELIANGZHUAPAI("2190");
    static const std::string CHELIANGZHUAPAI_PATTERN("^2190[0-9]{2}$");
    
    // 交通流量
    static const std::string VEHICLE_LUKOULIULIANG("2750");
    static const std::string VEHICLE_TRAFFIC_INFO_PATTERN("^27[0-9]{2}$");

    // 通用模版
    static const std::string VEHICLE_PATTERN("^2100[0-9]{2}$");
    static const std::string VEHICLE_PATTERN_NEW("2100");

    // 交通事件
    static const std::string GAOSU_SHIXIANBIANDAO_CODE("2151");
    static const std::string GAOSU_JINZHIDAHUOCHE_CODE("2153");
    static const std::string GAOSU_JINZHICHUANYUEDAOLIUXIAN_CODE("2154");
    static const std::string GAOSU_SHIXIANBIANDAO_CODE_NEW("2412");
    static const std::string GAOSU_JINZHIDAHUOCHE_CODE_NEW("2417");
    static const std::string GAOSU_JINZHICHUANYUEDAOLIUXIAN_CODE_NEW("2413");
    static const std::string GAOSU_NIXIANGXINGSHI_CODE("2411");
    static const std::string GAOSU_ZHANYONGYINGJICHEDAO_CODE("2414");
    static const std::string GAOSU_ZHANYONGYINGJICHEDAOV2_CODE("2418");
    static const std::string GAOSU_DAXINGCHEZHANYONGZHUCHEDAO_CODE("2415");
    static const std::string GAOSU_CHELIANGDAOCHE_CODE("2443");
    static const std::string GAOSU_LIANXUBIANDAO_CODE("2444");
    static const std::string GAOSU_WEIHUAPINCHE_CODE("2453");
    static const std::string GAOSU_CHELIANGSHIRURENXINGDAO_CODE("2464");
    //static const std::string GAOSU_SHEXINGJIASHI_COED("2472");
    static const std::string GAOSU_GUISUJIASHI_COED("2473");


    REGISTER_VIOLATION(DAWANXIAOZHUAN_CODE, VehicleCommon);
    REGISTER_VIOLATION(SHIXIANBIANDAO_CODE, VehicleCommon);
    REGISTER_VIOLATION(BIANGENGCHEDAOYINGXIANGQITACHE_CODE, VehicleCommon);
    REGISTER_VIOLATION(JIDONGCHEZHANYONGFEIJIDONGCHEDAO_CODE, VehicleCommon);
    REGISTER_VIOLATION(BUANDAOXIANGXIANXINGSHI_CODE, VehicleCommon);
    REGISTER_VIOLATION(NIXIANGXINGSHI_CODE, VehicleCommon);
    REGISTER_VIOLATION(LIANXUBIANDAO_CODE, VehicleCommon);
    REGISTER_VIOLATION(WEIXIANLUDUANDIAOTOU_CODE, VehicleCommon);
    REGISTER_VIOLATION(CHUANGJINLING_CODE, VehicleCommon);
    REGISTER_VIOLATION(CHUANGHONGDENG_CODE, VehicleCommon);
    REGISTER_VIOLATION(ZHANYONGGONGJIAOCHEDAO_CODE, VehicleCommon);
    REGISTER_VIOLATION(ZHANYONGZHONGYUNLIANGCHEDAO_CODE, VehicleCommon);
    REGISTER_VIOLATION(JINZHIDAHUOCHE_CODE, Jinzhidahuoche);
    REGISTER_VIOLATION(DAXINGCHEYOUZHUAN_CODE, VehicleCommon);
    REGISTER_VIOLATION(DAXINGCHEZHANYONGXIAOXINGCHEDAO_CODE, Daxingchezhangyongxiaoxingchedao);
    REGISTER_VIOLATION(KEHUOFENDAO_CODE, Jinzhidahuoche);
    REGISTER_VIOLATION(CHELIANGXIANSHI_CODE, VehicleCommon);
    REGISTER_VIOLATION(ZHANYONGYINGJICHEDAO_CODE, VehicleCommon);
    REGISTER_VIOLATION(CHUANYUEDAOLIUXIAN_CODE, VehicleCommon);
    REGISTER_VIOLATION(TEZHONGCHELIANGZHUAPAI_CODE, VehicleCommon);
    REGISTER_VIOLATION(TEZHONGCHELIANGZHUAPAIV2_CODE, VehicleCommon);
    REGISTER_VIOLATION(BUILDING_TEZHONGCHELIANGZHUAPAI, VehicleCommon);
    REGISTER_VIOLATION(CHELIANGZHUAPAI_PATTERN, VehicleCommon);
    REGISTER_VIOLATION(CHELIANGZHUAPAI, VehicleCommon);

    REGISTER_VIOLATION(VEHICLE_LUKOULIULIANG, VehicleCommon);
    REGISTER_VIOLATION_PATTERN(VEHICLE_TRAFFIC_INFO_PATTERN, VehicleCommon);

    REGISTER_VIOLATION_PATTERN(VEHICLE_PATTERN, VehicleCommon);
    REGISTER_VIOLATION_PATTERN(VEHICLE_PATTERN_NEW, VehicleCommon);

    REGISTER_VIOLATION(GAOSU_SHIXIANBIANDAO_CODE, VehicleCommon);
    REGISTER_VIOLATION(GAOSU_JINZHIDAHUOCHE_CODE, Jinzhidahuoche);
    REGISTER_VIOLATION(GAOSU_JINZHICHUANYUEDAOLIUXIAN_CODE, VehicleCommon);
    REGISTER_VIOLATION(GAOSU_SHIXIANBIANDAO_CODE_NEW, VehicleCommon);
    REGISTER_VIOLATION(GAOSU_JINZHIDAHUOCHE_CODE_NEW, Jinzhidahuoche);
    REGISTER_VIOLATION(GAOSU_JINZHICHUANYUEDAOLIUXIAN_CODE_NEW, VehicleCommon);
    REGISTER_VIOLATION(GAOSU_NIXIANGXINGSHI_CODE, VehicleCommon);
    REGISTER_VIOLATION(GAOSU_ZHANYONGYINGJICHEDAO_CODE, VehicleCommon);
    REGISTER_VIOLATION(GAOSU_ZHANYONGYINGJICHEDAOV2_CODE, VehicleCommon);
    REGISTER_VIOLATION(GAOSU_DAXINGCHEZHANYONGZHUCHEDAO_CODE, GaosuDaxingchezhangyongxiaoxingchedao);
    REGISTER_VIOLATION(GAOSU_CHELIANGDAOCHE_CODE, VehicleCommon);
    REGISTER_VIOLATION(GAOSU_LIANXUBIANDAO_CODE, VehicleCommon);
    REGISTER_VIOLATION(GAOSU_WEIHUAPINCHE_CODE, VehicleCommon);
    REGISTER_VIOLATION(GAOSU_CHELIANGSHIRURENXINGDAO_CODE, VehicleCommon);
    //REGISTER_VIOLATION(GAOSU_SHEXINGJIASHI_COED, VehicleCommon);
    REGISTER_VIOLATION(GAOSU_GUISUJIASHI_COED, VehicleCommon);

} // namespace FLOW
