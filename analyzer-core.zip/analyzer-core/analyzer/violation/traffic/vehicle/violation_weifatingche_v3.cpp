
#include <iterator>
#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"

#include "serving/violation_config.pb.h"
#include "common/tad_internal.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_weifatingche_v3.hpp"
#include "violation/flow/violation_flow_code.hpp"

namespace FLOW {

//违法停车缓行版
static const std::string WFTCV3_NAME("weifatingchev3");
static const std::string WFTCV3_CODE("2133");
//违法停车提示
static const std::string WFTCTS_NAME("weifatingchetishi");
static const std::string WFTCTS_CODE("2142");


//
// ViolationWeifatingcheV3Config
//
ViolationWeifatingcheV3Config::ViolationWeifatingcheV3Config(const std::string& json)
    : violate_box()
    , pre_parking_second(5)
    , parking_second(10)
    , cooling_second(-1)
    , max_car_count(-1)
    , plate_available_box_percent(0.025f)
    , max_move_percent(0.1)
    , enable_output_picture(true)
    , enable_save_picture(false)
    , enable_use_pts(false)
    , enable_valid_box_check(true)
{
    auto result=this->ParseJson(json);
    CHECK(result);
}

bool ViolationWeifatingcheV3Config::ParseJson(const std::string& json) {
    std::string err;
    violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }
    auto& cfg = *violation_cfg;
    name = cfg.name();
    code = cfg.code();
    cooling_second = cfg.has_cooling_second()?cfg.cooling_second():cooling_second;
    if (cfg.has_enable_valid_box_check()) {
        enable_valid_box_check = cfg.enable_valid_box_check();
    } 
    const int MIN_SIZE = 2*3;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "violate_box"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box));
            if (cond.has_parking_second()) {
                parking_second = cond.parking_second();
            }
            if (cond.has_pre_parking_second()) {
                pre_parking_second = cond.pre_parking_second();
            }
            if (cond.has_max_car_count()) {
                max_car_count = cond.max_car_count();
            }else{
                max_car_count = 0xFFFF;
            }            
        }
    }
    plate_available_box_percent = cfg.plate_available_box_percent();
    enable_output_picture = cfg.enable_output_picture();
    enable_save_picture = cfg.enable_save_debug_picture();
    return true;
}

static int intersection_n(const std::vector<float>& violate_box, const ImageObjectsInfo& objs1, const ImageObjectsInfo& objs2) {
    int count = 0;
    std::set<int> objs1_set;
    for(auto& obj : objs1.objects) {
        if (obj.label != OBJECT_TYPE_VEHICLE) {
            continue;
        }
        if (valid_box_center_in_polygon(obj, violate_box.data(), violate_box.size())) {
            objs1_set.insert(obj.uid);
        }
    }
    for(auto& obj : objs2.objects) {
        count += (objs1_set.find(obj.uid) != objs1_set.end());
    }
    return count;
}

//
// ViolationWeifatingcheV3
//
class ViolationWeifatingcheV3 : public ViolationBase
{
public:
    ViolationWeifatingcheV3(int object_id, const std::string& violation_id, const ViolationWeifatingcheV3Config& cfg);
    virtual ~ViolationWeifatingcheV3()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

protected:
    enum STATUS{
        eUNDEFINE,
        eENTER_VIEW,
        eSTAY_TIME_UP,//停够t秒后进行后续检查
        eMID_TIME_UP,
        eLAST_TIME_UP,
        eCOOL_TIME_UP,
        eEND,
    };

protected:
    ViolationWeifatingcheV3Config       cfg_;
    STATUS                              status_;
    bool                                first_enter_;
};

ViolationWeifatingcheV3::ViolationWeifatingcheV3(int object_id, const std::string& violation_id, const ViolationWeifatingcheV3Config& cfg)
    : ViolationBase(object_id, violation_id, cfg.violation_cfg)
    , cfg_(cfg)
    , status_(eUNDEFINE)
    , first_enter_(false)
{
}

result_list_t ViolationWeifatingcheV3::check(BoxF& box, const ImageObjectsInfo& objs)
{
    result_list_t retv;

    switch (status_)
    {
    case eUNDEFINE: 
        if (cfg_.enable_valid_box_check &&
            !valid_box_in_range(box, objs.sframe->width(), objs.sframe->height(), cfg_.plate_available_box_percent)) {
                break;
        }
        if (valid_box_center_in_polygon(box, cfg_.violate_box.data(), cfg_.violate_box.size())){
            status_ = eENTER_VIEW;
            this->clear_snapshot();
            this->add_snapshot(box, objs);
            if (first_enter_) {
                LOG(INFO)<<"==>enter view, "<<objs.channel_id<<","<<violation_id_<<","<<object_id_;
                first_enter_ = true;
            }
        }
        break;
    case eENTER_VIEW:
        if ( valid_box_box_distance(box, snapshots_.back().box, cfg_.max_move_percent) &&
            valid_box_center_in_polygon(box, cfg_.violate_box.data(), cfg_.violate_box.size())){
                auto elapsed_time = this->get_elapsed_time(objs);
                if ( elapsed_time.count() >= (cfg_.pre_parking_second*1000) ) {
                    status_ = eSTAY_TIME_UP;
                    this->clear_snapshot();
                    this->add_snapshot(box, objs);
                    LOG(INFO)<<"==>stage one ready, "<<objs.channel_id<<","<<violation_id_<<","<<object_id_;
                }
        } else {
            status_ = eUNDEFINE;
        }
        break;
    case eSTAY_TIME_UP:
        if ( valid_box_center_in_polygon(box, cfg_.violate_box.data(), cfg_.violate_box.size())){
            auto elapsed_time = this->get_elapsed_time(objs);
            if ( elapsed_time.count() >= (cfg_.parking_second*1000/2.0) ) {
                status_ = eMID_TIME_UP;
                this->add_snapshot(box, objs);
                LOG(INFO)<<"==>stage two ready, "<<objs.channel_id<<","<<violation_id_<<","<<object_id_;
            }
        } else {
            status_ = eUNDEFINE;
        }
        break;
    case eMID_TIME_UP:
        if ( valid_box_center_in_polygon(box, cfg_.violate_box.data(), cfg_.violate_box.size())){
            auto elapsed_time = this->get_elapsed_time(objs, 0);
            if ( elapsed_time.count() >= (cfg_.parking_second*1000) &&
                elapsed_time.count() < (cfg_.parking_second*1000*2.1f) ){
                const int paking_in_car_count = intersection_n(cfg_.violate_box, objs, *(this->snapshots_.front().image));
                bool need_reset = false;
                if (paking_in_car_count > cfg_.max_car_count) {
                    need_reset = true;
                }
                if (need_reset) {
                    status_ = eUNDEFINE;
                    LOG(INFO)<<"==>stage three drop, "<<objs.channel_id
                        <<","<<violation_id_
                        <<","<<object_id_
                        <<", i="<<paking_in_car_count;
                    break;
                }
                status_ = eLAST_TIME_UP;
                this->add_snapshot(box, objs);
                LOG(INFO)<<"==>stage three ready, "<<objs.channel_id<<","<<violation_id_<<","<<object_id_;
                retv =  get_results();

                // for cooling_second 
                this->clear_snapshot();
                this->add_snapshot(box, ImageObjectsInfo());
            }
        } else {
            status_ = eUNDEFINE;
        }
        break;
    case eLAST_TIME_UP:
        if (cfg_.cooling_second > 0) {
            auto elapsed_time = this->get_elapsed_time(objs);
            if ( elapsed_time.count() >= (cfg_.cooling_second*1000) ) {
                status_ = eUNDEFINE;
            }
        } else {
            status_ = eEND;
        }
        break;
    case eEND:
    default:
        break;
    }

    static int colors[]={0,0,2,2,3,3};
    if (status_ != eUNDEFINE) {
        box.violate_state = colors[status_];
    }
    return retv;
}

//
// ViolationWeifatingcheV3Factory
//
ViolationWeifatingcheV3Factory::ViolationWeifatingcheV3Factory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(cfg)
{
}

const std::string& ViolationWeifatingcheV3Factory::id()const
{
    return id_;
}

spIViolation ViolationWeifatingcheV3Factory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == OBJECT_TYPE_VEHICLE){
        return std::make_shared<ViolationWeifatingcheV3>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }

}

REGISTER_VIOLATION_PATTERN(WFTCV3_CODE, WeifatingcheV3);
REGISTER_VIOLATION_PATTERN(WFTCTS_CODE, WeifatingcheV3);

} // namespace FLOW
