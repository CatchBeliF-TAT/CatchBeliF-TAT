#ifndef VSS_VIOLATION_DEBUG_HPP
#define VSS_VIOLATION_DEBUG_HPP

#include <vector>
#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationDebugConfig;
typedef std::shared_ptr<ViolationDebugConfig> spViolationDebugConfig;

class ViolationDebugFactory : public ViolationCommonFactory 
{
public:
    ViolationDebugFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationDebugFactory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                      id_;
    spViolationDebugConfig            cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_DEBUG_HPP
