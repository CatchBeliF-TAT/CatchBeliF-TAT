#ifndef VSS_VIOLATION_WEIFATINGCHE_V3_HPP
#define VSS_VIOLATION_WEIFATINGCHE_V3_HPP

#include <vector>
#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationWeifatingcheV3Config {
public:
    ViolationWeifatingcheV3Config(const std::string& json);
    bool ParseJson(const std::string& json);
public:
    typedef     std::vector<float> VecFloat;
    VecFloat    violate_box;
    int         pre_parking_second;
    int         parking_second;
    int         cooling_second;
    int         max_car_count;
    float       plate_available_box_percent;
    float       max_move_percent;
    bool        enable_output_picture;
    bool        enable_save_picture;
    bool        enable_use_pts;
    bool        enable_valid_box_check;
    std::string code;
    std::string name;
    spViolationConfig  violation_cfg;
};


class ViolationWeifatingcheV3Factory : public ViolationCommonFactory 
{
public:
    ViolationWeifatingcheV3Factory(const std::string& id, const std::string& cfg);
    virtual ~ViolationWeifatingcheV3Factory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                       id_;
    ViolationWeifatingcheV3Config     cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_WEIFATINGCHE_V3_HPP
