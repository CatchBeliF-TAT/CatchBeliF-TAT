#ifndef VSS_VIOLATION_REVERSE_DRIVING_HPP
#define VSS_VIOLATION_REVERSE_DRIVING_HPP

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

    class ViolationReverseDrivingConfig;
    typedef std::shared_ptr<ViolationReverseDrivingConfig> spViolationReverseDrivingConfig;

    class ViolationReverseDrivingFactory : public ViolationCommonFactory
    {
    public:
        ViolationReverseDrivingFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationReverseDrivingFactory()=default;

    public:
        virtual const std::string&      id()const;
        virtual spIViolation            CreateIViolation(const BoxF& obj);

    protected:
        std::string                         id_;
        spViolationReverseDrivingConfig     cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_REVERSE_DRIVING_HPP
