#ifndef VSS_VIOLATION_COUNT_CHECKER_HPP
#define VSS_VIOLATION_COUNT_CHECKER_HPP

#include <vector>
#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationCountCheckerConfig {
public:
    ViolationCountCheckerConfig(const std::string& json);
    bool ParseJson(const std::string& json);
public:
    typedef std::function<bool(const BoxF&,const BoxF&)> fn_compare_box;
    typedef     std::vector<float> VecFloat;
    VecFloat    violate_box;
    int         parking_second;
    int         cooling_second;
    int         min_car_count;
    int         min_nonmotor_count;
    int         min_person_count;
    int         min_nonmotor_with_person_count;
    float       max_move_percent;
    float       distance;

    fn_compare_box     user_def_compare;
    spViolationConfig  violation_cfg;
};


class ViolationCountCheckerFactory : public ViolationCommonFactory 
{
public:
    ViolationCountCheckerFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationCountCheckerFactory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                       id_;
    ViolationCountCheckerConfig  cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_COUNT_CHECKER_HPP
