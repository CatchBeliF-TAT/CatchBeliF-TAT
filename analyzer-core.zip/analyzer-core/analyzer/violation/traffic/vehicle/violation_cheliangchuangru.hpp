#ifndef VSS_VIOLATION_CHELIANGCHUANGRU_HPP
#define VSS_VIOLATION_CHELIANGCHUANGRU_HPP

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

    class ViolationCheliangchuangruConfig;
    typedef std::shared_ptr<ViolationCheliangchuangruConfig> spViolationCheliangchuangruConfig;

    class ViolationCheliangchuangruFactory : public ViolationCommonFactory
    {
    public:
        ViolationCheliangchuangruFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationCheliangchuangruFactory()=default;

    public:
        virtual const std::string&      id()const;
        virtual spIViolation            CreateIViolation(const BoxF& obj);

    protected:
        std::string                           id_;
        spViolationCheliangchuangruConfig     cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_CHELIANGCHUANGRU_HPP
