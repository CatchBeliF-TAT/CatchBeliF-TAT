#ifndef VSS_VIOLATION_WANGGEXIANTINGCHE_HPP
#define VSS_VIOLATION_WANGGEXIANTINGCHE_HPP

#include <vector>
#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationWanggexiantingcheConfig {
public:
    ViolationWanggexiantingcheConfig(const std::string& json);
    bool ParseJson(const std::string& json);
public:
    typedef     std::vector<float> VecFloat;
    VecFloat    violate_box;
    int         parking_second;
    int         cooling_second;
    int         max_car_count;
    int         min_car_count;
    int         gaosu_limit_count;
    int         person_count;
    float       plate_available_box_percent;
    float       max_move_percent;
    float       scale_x;
    float       scale_y;
    bool        enable_output_picture;
    bool        enable_save_picture;
    bool        enable_use_pts;
    bool        enable_valid_box_check;
    std::string code;
    std::string name;
    spViolationConfig  violation_cfg;
};


class ViolationWanggexiantingcheFactory : public ViolationCommonFactory 
{
public:
    ViolationWanggexiantingcheFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationWanggexiantingcheFactory()=default;

public:
    virtual const std::string&      id()const;
    virtual spIViolation            CreateIViolation(const BoxF& obj);

protected:
    std::string                       id_;
    ViolationWanggexiantingcheConfig  cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_WANGGEXIANTINGCHE_HPP
