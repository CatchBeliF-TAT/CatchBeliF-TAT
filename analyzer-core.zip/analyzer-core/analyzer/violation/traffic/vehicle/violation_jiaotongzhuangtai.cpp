#include <iterator>
#include <map>
#include <vector>
#include <chrono>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_jiaotongzhuangtai.hpp"

namespace FLOW {

    static const std::string JTZT_NAME("jiaotongzhuangtai");
    static const std::string JTZT_CODE("2730");

// 两点间距离
    inline float point2point(const PointF& a, const PointF& b) {
        return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
    }

//
// ViolationJiaotongzhuangtaiConfig
//
    class ViolationJiaotongzhuangtaiConfig {
    public:
        ViolationJiaotongzhuangtaiConfig(const std::string& json)
                : min_car_count(3)
                , enable_use_pts(false)
                , time_ratio("box")
                , standard_speed(30.0)
                , max_speed(250.0f/3.6f)
                , b_center_across(false)
                , send_time(60)
        {
            auto result=this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json);
    public:
        typedef            std::vector<float> VecFloat;
        int                min_car_count;
        int                send_time;
        bool               enable_use_pts;
        std::string        time_ratio;
        float              standard_speed;
        float              max_speed;
        VecFloat           distance;
        VecFloat           box;
        VecFloat           order_box;
        VecPointF          mid_line;
        float              mid_line_len;
        bool               b_center_across;
        spViolationConfig  violation_cfg;
    };

    bool ViolationJiaotongzhuangtaiConfig::ParseJson(const std::string& json) {
        std::string err;
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;
        for (int i=0; i<cfg.conditions_size(); i++) {
            const auto& cond = cfg.conditions(i);

            if (cond.name() == "traffic_status") {
                CHECK_GE(cond.data_size(), 16);
                std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(box));
                order_box = VecFloat{
                    box[0], box[1], box[2], box[3],
                    box[6], box[7], box[10],box[11],
                    box[14],box[15],box[12],box[13],
                    box[8], box[9], box[4], box[5]
                };
                mid_line =  {
                    {(box[0]  + box[2])  / 2, (box[1]  + box[3])  / 2},
                    {(box[4]  + box[6])  / 2, (box[5]  + box[7])  / 2},
                    {(box[8]  + box[10]) / 2, (box[9]  + box[11]) / 2},
                    {(box[12] + box[14]) / 2, (box[13] + box[15]) / 2},
                };
                mid_line_len = point2point(mid_line[0], mid_line[3]);
                b_center_across = cond.has_center_across() ? cond.center_across() : b_center_across;
                CHECK_GE(cond.multi_distance_size(), 3);
                std::copy_n(cond.multi_distance().begin(), cond.multi_distance_size()/3*3, std::back_inserter(distance));

                if (cond.has_parking_second()) {
                    send_time = cond.parking_second();
                }
                if (cond.has_standard_speed()) {
                    standard_speed = cond.standard_speed();
                }
                if (cond.has_max_speed()) {
                    max_speed = cond.max_speed();
                }
                if (cond.has_car_count()) {
                    min_car_count = cond.car_count();
                }
                if (cond.has_time_ratio()) {
                    time_ratio = cond.time_ratio();
                }
            }
        }
        return true;
    }
//
// ViolationJiaotongzhuangtai
//
    class ViolationJiaotongzhuangtai : public ViolationBase
    {
    public:
        ViolationJiaotongzhuangtai(int object_id, const std::string& violation_id, const spViolationJiaotongzhuangtaiConfig cfg);
        virtual ~ViolationJiaotongzhuangtai()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

    protected:
        bool _valid_box_across_lines(const BoxF &last_box, const BoxF &box, const float *points, float percent) {
            if (cfg_->b_center_across) {
                return valid_boxes_center_across_lines(last_box, box, points);
            } else {
                return valid_box_across_lines(box, points, percent);
            }
        }

    protected:
        struct Cars_Info{
            BoxF                              pre_pst;
            std::chrono::milliseconds         car_start;
            std::chrono::milliseconds         car_end;
            bool                              car_sflag = false;
            bool                              car_eflag = false;
            float                             avg_speed = 0.0f;
        };

    protected:
        typedef std::vector<float>                 VecFloat;
        const spViolationJiaotongzhuangtaiConfig   cfg_;
        float                                      sum_avg_speed_;              // 60秒之内的总平均速度
        float                                      sum_space_ratio_;            // 60秒之内的总车道占有率
        float                                      sum_vehicle_queue_;          // 60秒之内的车总排队长度
        float                                      sum_time_interval_;          // 60秒之内的总车头时距
        float                                      sum_distance_interval_;      // 60秒之内的总车头间距
        int                                        cars_count_;                 // 车流量
        int                                        sum_ratio_;                  // 60秒之内的总帧数
        int                                        per_time_ratio_;             // 每一帧的占有数量
        int                                        interval_count_;             // 计算车头时的间距数量
        int                                        pre_car_;                    // 上一辆车的id
        std::map<int, Cars_Info>                   cars_info_;                  // 车辆的信息
        std::vector<int>                           clear_vec_;                  // 对于需要删除的id，每60秒删除一次
        std::map<int, int>                         cars_count_by_type_;         // 车型-车流量
        VecFloat                                   cars_speed_;                 // 用于计算速度标准差
    };

    ViolationJiaotongzhuangtai::ViolationJiaotongzhuangtai(int object_id, const std::string& violation_id, const spViolationJiaotongzhuangtaiConfig cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
            , cars_count_(0)
            , pre_car_(-1)
            , interval_count_(0)
            , sum_ratio_(0)
            , per_time_ratio_(0)
            , sum_avg_speed_(0.0f)
            , sum_space_ratio_(0.0f)
            , sum_vehicle_queue_(0.0f)
            , sum_time_interval_(0.0f)
            , sum_distance_interval_(0.0f)
    {
    }

    int traffic_status_func(const float& v, const float& cfg_v);
    std::vector<PointF> merge_intervals(std::vector<PointF>& intervals);
    PointF interval_func(const BoxF &box, PointF point_a, PointF point_b);
    float cal_distance(PointF interval, PointF l1, PointF l2, PointF p_a, PointF p_b, std::vector<float> distance);
    result_list_t ViolationJiaotongzhuangtai::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        int car_in_count = 0;
        auto now = this->get_time_point(objs);
        std::vector<PointF> intervals;

        for (const auto& obj : objs.objects) {
            if (obj.delete_flag) {
                clear_vec_.push_back(obj.uid);
                continue;
            }
            if (obj.label != OBJECT_TYPE_VEHICLE) {
                continue;
            }
            if (! valid_box_center_in_polygon(obj, cfg_->order_box.data(), cfg_->order_box.size())) {
                continue;
            }
            car_in_count += (cfg_->time_ratio == "line"
                                ? valid_box_across_lines(obj, cfg_->box.data() + 4, 0.75f)
                                : 1);
            PointF interval = interval_func(obj, cfg_->mid_line[0], cfg_->mid_line[3]);
            if (interval.x >= 0.0f && interval.x <= cfg_->mid_line_len &&
                interval.y >= 0.0f && interval.y <= cfg_->mid_line_len) {
                intervals.push_back(interval);
            }

            if (cars_info_.count(obj.uid) == 0){
                cars_info_[obj.uid].pre_pst = obj;
            }

            auto& current_car_info = cars_info_[obj.uid];
            if (!current_car_info.car_sflag &&
                this->_valid_box_across_lines(current_car_info.pre_pst, obj, cfg_->box.data() + 4, 0.75f)) {
                current_car_info.car_sflag = true;
                current_car_info.car_start = now;
            }
            if (current_car_info.car_sflag &&
                !current_car_info.car_eflag &&
                this->_valid_box_across_lines(current_car_info.pre_pst, obj, cfg_->box.data() + 8, 0.75f)) {
                current_car_info.car_eflag  = true;
                current_car_info.car_end    = now;
                current_car_info.avg_speed  = cfg_->distance[1] * 1000 /
                                                    std::max<float>((current_car_info.car_end - current_car_info.car_start).count(), 1.0f);
                if (current_car_info.avg_speed >= cfg_->max_speed) {
                    continue;
                }
                // cal global
                cars_speed_.push_back(current_car_info.avg_speed);
                sum_avg_speed_                 += current_car_info.avg_speed;
                sum_time_interval_             += cars_info_.find(pre_car_) == cars_info_.end() ? 0.0f
                                                    : ((current_car_info.car_end - cars_info_[pre_car_].car_end).count()) / 1000.0;
                sum_distance_interval_         += cars_info_.find(pre_car_) == cars_info_.end() ? 0.0f
                                                    : ( fabs(current_car_info.avg_speed - cars_info_[pre_car_].avg_speed)
                                                    * (current_car_info.car_end - cars_info_[pre_car_].car_end)).count() / 1000.0;
                if (cars_info_.find(pre_car_) != cars_info_.end()) {
                    interval_count_ ++;
                }
                cars_count_ ++;
                cars_count_by_type_[obj.attr_type.type]++;
                pre_car_    = obj.uid;
            }
        }

        // 时间占有率
        sum_ratio_ ++;
        if (car_in_count) {
            per_time_ratio_ ++;
        }

        // 空间占有率 排队长度
        if (intervals.size() != 0) {
            float per_interval_distance = 0.0f;
            auto multi_value = merge_intervals(intervals);
            for (auto& value : multi_value) {
                per_interval_distance += cal_distance(value, cfg_->mid_line[1], cfg_->mid_line[2], cfg_->mid_line[0], cfg_->mid_line[3], cfg_->distance);
            }
            sum_space_ratio_   += per_interval_distance / (cfg_->distance[0] + cfg_->distance[1] + cfg_->distance[2]);
            sum_vehicle_queue_ += cal_distance(PointF{multi_value[0].x, multi_value[multi_value.size() - 1].y},
                                                cfg_->mid_line[1], cfg_->mid_line[2], cfg_->mid_line[0], cfg_->mid_line[3], cfg_->distance);
        }
        if (this->snapshots_.empty()) {
            // add first picture for get elapsed time
            this->add_snapshot(box, objs);
            this->snapshots_.back().image = CloneWithoutImage(this->snapshots_.back().image);
        }
        if (this->get_elapsed_time(objs) >= std::chrono::milliseconds(cfg_->send_time * 1000)) {
            this->clear_snapshot();
            this->add_snapshot(box, objs);
            this->snapshots_.back().image = CloneWithoutImage(this->snapshots_.back().image);
            float avg_speed                           = (cars_count_ == 0 ? 0.0f : (3.6 * sum_avg_speed_ / cars_count_));
            this->snapshots_.back().avgspeed          =  avg_speed;
            this->snapshots_.back().count             =  cars_count_;
            this->snapshots_.back().cars_count_by_type=  cars_count_by_type_;
            this->snapshots_.back().time_interval     = (cars_count_ < cfg_->min_car_count ? -1.0f : (sum_time_interval_ / interval_count_));
            this->snapshots_.back().distance_interval = (cars_count_ < cfg_->min_car_count ? -1.0f : (sum_distance_interval_ / interval_count_));
            this->snapshots_.back().time_ratio        = (cars_count_ < cfg_->min_car_count ? -1.0f : 1.0 * per_time_ratio_ / sum_ratio_);
            this->snapshots_.back().space_ratio       = (sum_space_ratio_ / sum_ratio_);
            this->snapshots_.back().vehicle_queue     = (sum_vehicle_queue_ / sum_ratio_);
            this->snapshots_.back().traffic_status    = (cars_count_ < cfg_->min_car_count ? (sum_space_ratio_ / sum_ratio_ > 0.7 ? 5 : 1)
                                                      : traffic_status_func(avg_speed, cfg_->standard_speed));
            if (cars_count_ > 0) {
                float speed_standard_deviation = 0.0f;
                for (auto s : cars_speed_) {
                    speed_standard_deviation += std::pow(s - avg_speed, 2);
                }
                speed_standard_deviation = std::sqrt(speed_standard_deviation/cars_count_);
                this->snapshots_.back().speed_standard_deviation = speed_standard_deviation;
            }

            retv = get_results();
            cars_count_        = 0;
            cars_count_by_type_.clear();
            interval_count_    = 0;
            sum_ratio_         = 0;
            per_time_ratio_    = 0;
            sum_space_ratio_   = 0.0f;
            sum_vehicle_queue_ = 0.0f;
            sum_avg_speed_     = 0.0f;
            sum_time_interval_ = 0.0f;
            sum_distance_interval_ = 0.0f;
            cars_speed_.clear();

            for (auto& uid : clear_vec_) {
                cars_info_.erase(uid);
            }
            clear_vec_.clear();
        }

        return retv;
    }

//
// ViolationJiaotongzhuangtaiFactory
//
    ViolationJiaotongzhuangtaiFactory::ViolationJiaotongzhuangtaiFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationJiaotongzhuangtaiConfig>(cfg))
    {
    }

    const std::string& ViolationJiaotongzhuangtaiFactory::id()const {
        return id_;
    }

    spIViolation ViolationJiaotongzhuangtaiFactory::CreateIViolation(const BoxF& obj){
        if (obj.label == -1){
            return std::make_shared<ViolationJiaotongzhuangtai>(obj.uid, id_, cfg_);
        } else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(JTZT_CODE, Jiaotongzhuangtai);

    int traffic_status_func(const float& v, const float& cfg_v) {
        auto value = v/cfg_v;
        if (value < 0.3)        return 5;
        else if (value < 0.4)   return 4;
        else if (value < 0.5)   return 3;
        else if (value < 0.7)   return 2;
        else                    return 1;
    }


    PointF point2line(const float& line_k, const float& line_b, const PointF& point);
    PointF interval_func(const BoxF &box, PointF point_a, PointF point_b) {
        PointF interval;
        // k不存在
        if (point_b.x == point_a.x) {
            interval.x = (point_b.y > point_a.y ? (box.ymin > point_a.y ? box.ymin - point_a.y : 0.0f)
                       : (box.ymax > point_a.y ? 0.0f : point_a.y - box.ymax));
            interval.y = (point_b.y > point_a.y ? (box.ymax > point_b.y ? point_b.y - point_a.y : box.ymax - point_a.y)
                       : (box.ymin < point_b.y ? point_a.y - point_b.y : point_a.y - box.ymin));
            return interval;
        }
        // k==0
        if (point_a.y == point_b.y) {
            interval.x = (point_b.x > point_a.x ? (box.xmin > point_a.x ? box.xmin - point_a.x : 0.0f)
                       : (box.xmax > point_a.x ? 0.0f : point_a.x - box.xmax));
            interval.y = (point_b.x > point_a.x ? (box.xmax > point_b.x ? point_b.x - point_a.x : box.xmax - point_a.x)
                       : (box.xmin < point_b.x ? point_a.x - point_b.x : point_a.x - box.xmin));
            return interval;
        }
        float line_k = (point_b.y - point_a.y) / (point_b.x - point_a.x);
        float line_b = point_a.y - line_k * point_a.x;
        PointF point1(box.xmin, box.ymin), point2(box.xmin, box.ymax), point3(box.xmax, box.ymax), point4(box.xmax, box.ymin);
        // k > 0 取point1 point3
        if (line_k > 0) {
            PointF xmin = point2line(line_k, line_b, point1);
            PointF xmax = point2line(line_k, line_b, point3);
            interval.x = (point_b.x > point_a.x ? (xmin.x > point_a.x ? point2point(xmin, point_a) : 0.0f)
                       : (xmax.x > point_a.x ? 0.0f : point2point(xmax, point_a)));
            interval.y = (point_b.x > point_a.x ? (xmax.x > point_b.x ? point2point(point_b, point_a) : point2point(xmax, point_a))
                       : (xmin.x < point_b.x ? point2point(point_b, point_a) : point2point(xmin, point_a)));
        }
        // k < 0 取point2 point4
        if (line_k < 0) {
            PointF xmin = point2line(line_k, line_b, point2);
            PointF xmax = point2line(line_k, line_b, point4);
            interval.x = (point_b.x > point_a.x ? (xmin.x > point_a.x ? point2point(xmin, point_a) : 0.0f)
                       : (xmax.x > point_a.x ? 0.0f : point2point(xmax, point_a)));
            interval.y = (point_b.x > point_a.x ? (xmax.x > point_b.x ? point2point(point_b, point_a) : point2point(xmax, point_a))
                       : (xmin.x < point_b.x ? point2point(point_b, point_a) : point2point(xmin, point_a)));
        }
        return interval;
    }

    // 根据比例计算实际距离
    float cal_distance(PointF interval,PointF l1,PointF l2,PointF p_a,PointF p_b,std::vector<float> distance) {
        PointF tmp1, tmp2;
        if (p_b.x != p_a.x) {
            float line_k = (p_b.y - p_a.y) / (p_b.x - p_a.x);
            float line_b = p_a.y - line_k * p_a.x;
            tmp1 = point2line(line_k, line_b, l1);
            tmp2 = point2line(line_k, line_b, l2);
        }
        else {
            tmp1.x = tmp2.x = p_a.x;
            tmp1.y = l1.y;
            tmp2.y = l2.y;
        }
        std::vector<float> multi_line{point2point(p_a, tmp1), point2point(p_a, tmp2), point2point(p_a, p_b)};
        float sum_distance = 0.0f;
        int i = 0;
        for ( ;i < multi_line.size(); i ++) {
            if (interval.x <= multi_line[i]) {
                break;
            }
        }
        int j = i;
        float last = interval.x;
        for ( ;j < multi_line.size(); j ++) {
            if (interval.y <= multi_line[j]) {
                sum_distance += distance[j] * ((interval.y - last) / (j == 0 ? multi_line[j] : multi_line[j] - multi_line[j-1]));
                break;
            }
            float val = multi_line[j] - last;
            sum_distance += distance[j] * (val / (j == 0 ? multi_line[j] : multi_line[j] - multi_line[j-1]));
            last = multi_line[j];
        }
        return sum_distance;
    }

    // 合并区间
    std::vector<PointF> merge_intervals(std::vector<PointF>& intervals) {
        sort(intervals.begin(), intervals.end(),[] (PointF& a, PointF& b) ->bool {
            if(a.x < b.x) return true;
            return false;
        });
        std::vector<PointF> ans;
        for (int i = 0; i < intervals.size();) {
            float right = intervals[i].y;
            int j = i + 1;
            while (j < intervals.size() && intervals[j].x <= right) {
                right = std::max(right, intervals[j].y);
                j ++;
            }
            ans.push_back(PointF(intervals[i].x, right));
            i = j;
        }
        return ans;
    }

    // 点到线的投影点
    PointF point2line(const float& line_k, const float& line_b, const PointF& point) {
        PointF new_point;
        new_point.x = (line_k * (point.y - line_b) + point.x) / (line_k * line_k + 1);
        new_point.y = line_k * new_point.x + line_b;
        return new_point;
    }

} // namespace FLOW
