
#include <iterator>
#include <algorithm>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"

#include "violation_yichangtingche_v2.hpp"

#include "common/tad_internal.hpp"
#include "serving/violation_config.pb.h"

#include "violation/violation_util.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/conditions/line_condition.hpp"

namespace FLOW {

static const std::string GSYCTC_V2_NAME("gaosuyichangtingche_v2");
static const std::string GSYCTC_V2_CODE("2455");

// 通用模版
static const std::string GSYCTC_V2_PATTERN("^2455[0-9]{2}$");

inline bool is_highway(const std::string& code) {
    return code.substr(0,2) == "24";
}

//
// CoordinateTransform
//
class CoordinateTransform {
public:
    CoordinateTransform(float x1=0, float y1=0, float x2=0, float y2=0) {
        const float dx = x2-x1;
        const float dy = y2-y1;
        const float dd = dx*dx + dy*dy;
        const float d = sqrt(dd);
        if (d < 1e-6) {
            cos_ = 1;
            sin_ = 0;
        } else {
            sin_ = dy/d;
            cos_ = dx/d;
        }
        sin2x_ = 2*cos_*sin_;
        x_ = x1;
        y_ = y1;
    }
    float X(float x, float y) const {
        return (x-x_)*cos_ + (y-y_)*sin_;
    }
    float Y(float x, float y) const {
        return (y-y_)*cos_ - (x-x_)*sin_;
    }
    float Sin2x() const {
        return sin2x_;
    }
protected:
    float sin_;
    float cos_;
    float x_;
    float y_;
    float sin2x_;
};

//
// ViolationYichangtingcheV2Config
//
class ViolationYichangtingcheV2Config {
public:
    ViolationYichangtingcheV2Config(const std::string& json);
    bool ParseJson(const std::string& json);
    float PrevVehicleDistance(const BoxF& box, const ImageObjectsInfo& objs) const;
    float VehicleLength(const BoxF& box) const;
    bool IsFarthest(const BoxF& box) const;
    bool IsParking(const BoxF& box, const BoxF& box2) const;
    std::pair<const BoxF*, float> PrevVehicle(const BoxF& box, const ImageObjectsInfo& objs) const;
    bool BoxDynamicCenterInArea(const BoxF& box, const ImageObjectsInfo& frameInfo) const;
    bool BoxCenterInArea(const BoxF& box) const;
    int CarIntersectionCount(const ImageObjectsInfo& objs1, const ImageObjectsInfo& objs2) const;
public:
    typedef     std::vector<float> VecFloat;
    VecFloat    violate_box;
    int         parking_second;
    int         cooling_second;
    int         max_car_count;
    int         min_car_count;
    int         gaosu_limit_count;
    int         person_count;
    float       plate_available_box_percent;
    float       max_move_percent;
    bool        enable_output_picture;
    bool        enable_save_picture;
    bool        enable_use_pts;
    bool        enable_valid_box_check;
    std::string code;
    std::string name;
    spViolationConfig  violation_cfg;

    VecFloat        start_line;
    VecFloat        end_line;
    VecFloat        mid_line;
    CoordinateTransform mid_converter;
    fn_check_action start_line_checker;
    fn_check_action end_line_checker;
    float           distance_threshold;
};

ViolationYichangtingcheV2Config::ViolationYichangtingcheV2Config(const std::string& json)
    : violate_box()
    , parking_second(10)
    , cooling_second(-1)
    , max_car_count(-1)
    , min_car_count(-1)
    , gaosu_limit_count(4)
    , person_count(-1)
    , plate_available_box_percent(0.025f)
    , max_move_percent(0.1)
    , enable_output_picture(true)
    , enable_save_picture(false)
    , enable_use_pts(false)
    , enable_valid_box_check(true)
    , distance_threshold(3.0f)
{
    auto result=this->ParseJson(json);
    CHECK(result);
}

bool ViolationYichangtingcheV2Config::ParseJson(const std::string& json) {
    std::string err;
    violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }
    auto& cfg = *violation_cfg;
    name = cfg.name();
    code = cfg.code();
    cooling_second = cfg.has_cooling_second()?cfg.cooling_second():cooling_second;
    if (cfg.has_enable_valid_box_check()) {
        enable_valid_box_check = cfg.enable_valid_box_check();
    } else {
        enable_valid_box_check = is_highway(violation_cfg->code()) ? false : true;
    }
    const int MIN_SIZE = 2*3;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "start_line"){
            CHECK_GE(cond.data_size(), 4);
            std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(start_line));
            start_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
        }
        if (cond.name() == "stop_line" || cond.name() == "end_line"){
            CHECK_GE(cond.data_size(), 4);
            std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(end_line));
            end_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
        }
        if (cond.name() == "violate_box"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box));
            if (cond.has_parking_second()) {
                parking_second = cond.parking_second();
            }
            if (cond.has_car_count()) {
                max_car_count = cond.car_count();
            }else{
                max_car_count = 0xFFFF;
            }

            if (cond.has_min_car_count()) {
                min_car_count = cond.min_car_count();
            }else{
                min_car_count = 0;
            }
            if (cond.has_goasu_yongdu_count()) {
                gaosu_limit_count = cond.goasu_yongdu_count();
            }
            if (cond.has_person_count()) {
                person_count = cond.person_count();
            }
            if (cond.has_threshold()) {
                distance_threshold = cond.threshold();
            }
        }
    }
    if (start_line_checker && end_line_checker) {
        mid_line.push_back((start_line[0]+start_line[2])/2.0f);
        mid_line.push_back((start_line[1]+start_line[3])/2.0f);
        mid_line.push_back((end_line[0]+end_line[2])/2.0f);
        mid_line.push_back((end_line[1]+end_line[3])/2.0f);
        mid_converter = CoordinateTransform(mid_line[0], mid_line[1], mid_line[2], mid_line[3]);
        auto max_x = mid_converter.X(mid_line[2], mid_line[3]);
        auto max_y = mid_converter.Y(mid_line[2], mid_line[3]);
        mid_line.push_back(max_x);
        mid_line.push_back(max_y);
    }
    plate_available_box_percent = cfg.plate_available_box_percent();
    enable_output_picture = cfg.enable_output_picture();
    enable_save_picture = cfg.enable_save_debug_picture();
    return true;
}

bool ViolationYichangtingcheV2Config::IsFarthest(const BoxF& box) const {
    auto x0 = this->mid_converter.X(box.CenterFloat().x, box.CenterFloat().y);
    if (x0+VehicleLength(box) > mid_line[4]) {
        return true;
    }
    return false;
}

bool ViolationYichangtingcheV2Config::IsParking(const BoxF& box, const BoxF& box2) const {
    // 中心点位移
    // return valid_box_box_distance(box, box2, this->max_move_percent)

    // iou
    return Boxes::IoU(box, box2) > 0.7;
}

bool ViolationYichangtingcheV2Config::BoxDynamicCenterInArea(const BoxF& box, const ImageObjectsInfo& frameInfo) const {
    const auto height = frameInfo.sframe->height();
    // 动态中心点确定, 下边缘目标使用(0.5±0.33, 0.8), 其他使用 (0.5±0.33,0.95)
    auto x_scale = 0.5f + 1.0f/3.0f*this->mid_converter.Sin2x();
    auto y_scale = (box.ymax > (height*(1-plate_available_box_percent))) ? 0.85f : 0.95f;
    auto retv = valid_boxes_scale_center_in_polygon(box, x_scale, y_scale, violate_box.data(), violate_box.size());
    if (retv) {
        box.auto_center_x = box.xmin + (box.xmax-box.xmin)*x_scale;
        box.auto_center_y = box.ymin + (box.ymax-box.ymin)*y_scale;
    }
    return retv;
}

bool ViolationYichangtingcheV2Config::BoxCenterInArea(const BoxF& box) const {
    return valid_box_center_in_polygon(box, violate_box.data(), violate_box.size());
}

float ViolationYichangtingcheV2Config::PrevVehicleDistance(const BoxF& box, const ImageObjectsInfo& frameInfo) const {
    return PrevVehicle(box, frameInfo).second;
}

std::pair<const BoxF*, float> ViolationYichangtingcheV2Config::PrevVehicle(const BoxF& box, const ImageObjectsInfo& frameInfo) const {
    if (IsFarthest(box)){
        return {nullptr, -1.0f};
    }

    std::vector<float> box_x;
    box_x.push_back(this->mid_converter.X(box.xmin, box.ymin));
    box_x.push_back(this->mid_converter.X(box.xmax, box.ymax));
    box_x.push_back(this->mid_converter.X(box.xmin, box.ymax));
    box_x.push_back(this->mid_converter.X(box.xmax, box.ymin));
    auto x_max1 = *std::max_element(box_x.begin(), box_x.end());
    std::vector<std::pair<const BoxF*, float>> vec_x_min_max;
    for(auto& obj : frameInfo.objects) {
        if (obj.label != OBJECT_TYPE_VEHICLE) {
            continue;
        }
        if (obj.uid == box.uid) {
            continue;
        }
        
        if ( !BoxDynamicCenterInArea(obj, frameInfo) && // 本车道车辆
             !BoxCenterInArea(obj)) {                   // 临近车道遮挡车辆
            continue;
        }

        std::vector<float> vec_obj_x;
        vec_obj_x.push_back(this->mid_converter.X(obj.xmin, obj.ymin));
        vec_obj_x.push_back(this->mid_converter.X(obj.xmax, obj.ymax));
        vec_obj_x.push_back(this->mid_converter.X(obj.xmin, obj.ymax));
        vec_obj_x.push_back(this->mid_converter.X(obj.xmax, obj.ymin));
        auto min_max = std::minmax_element(vec_obj_x.begin(), vec_obj_x.end());
    
        // LOG(INFO) <<"from:"<<box.uid<< ", to="<<obj.uid
        //         << ", dis="<<x_max1<<"/"<<x_min2<<"/"<<x_max2;
        if (x_max1 > *min_max.second) {
            continue;
        };
        vec_x_min_max.push_back({&obj, *min_max.first});
        vec_x_min_max.push_back({&obj, *min_max.second});
    }
    std::pair<const BoxF*, float> closest{nullptr, std::numeric_limits<float>::max()};
    for(auto& x : vec_x_min_max) {
        auto distance = x.second-x_max1;
        if (closest.second > distance) {
            closest = {x.first, distance};
        }
    }
    // LOG(INFO) <<"closest: uid="<<box.uid<<" to:"<<closest.first<<", d="<<closest.second;
    return closest;
}

float ViolationYichangtingcheV2Config::VehicleLength(const BoxF& box) const {
    std::vector<float> vec_x;
    vec_x.push_back(this->mid_converter.X(box.xmin, box.ymin));
    vec_x.push_back(this->mid_converter.X(box.xmax, box.ymax));
    vec_x.push_back(this->mid_converter.X(box.xmin, box.ymax));
    vec_x.push_back(this->mid_converter.X(box.xmax, box.ymin));
    auto min_max = std::minmax_element(vec_x.begin(), vec_x.end());
    return std::abs(*min_max.first - *min_max.second);
}

int ViolationYichangtingcheV2Config::CarIntersectionCount(const ImageObjectsInfo& objs1, const ImageObjectsInfo& objs2) const {
    int count = 0;
    std::set<int> objs1_set;
    for(auto& obj : objs1.objects) {
        if (obj.label != OBJECT_TYPE_VEHICLE) {
            continue;
        }
        if (BoxDynamicCenterInArea(obj, objs1)) {
            objs1_set.insert(obj.uid);
        }
    }
    for(auto& obj : objs2.objects) {
        count += (objs1_set.find(obj.uid) != objs1_set.end());
    }
    return count;
}

//
// ViolationYichangtingcheV2
//
class ViolationYichangtingcheV2 : public ViolationBase
{
public:
    ViolationYichangtingcheV2(int object_id, const std::string& violation_id, const spViolationYichangtingcheV2Config& cfg);
    virtual ~ViolationYichangtingcheV2()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
    int update_out_count(const ImageObjectsInfo& frameInfo);
    int count_in_area_person(const ImageObjectsInfo& frameInfo) const;
    int count_in_area_car(const ImageObjectsInfo& frameInfo) const;
    std::set<int> count_enter_car(const ImageObjectsInfo& frameInfo);

protected:
    enum STATUS{
        eUNDEFINE,
        eENTER_VIEW,
        eMID_TIME_UP,
        eLAST_TIME_UP,
        eCOOL_TIME_UP,
        eEND,
        eFAILED,
    };

protected:
    spViolationYichangtingcheV2Config   cfg_;
    STATUS                              status_;
    std::map<int,BoxF>                  in_objs_;
    std::set<int>                       out_objs_;
    int                                 max_person_count_;
    bool                                first_enter_;
    std::map<int,BoxF>                  pre_objs_;
    std::map<int, std::pair<int64_t,BoxF>>  pre_car_history_;
};

ViolationYichangtingcheV2::ViolationYichangtingcheV2(int object_id, const std::string& violation_id, const spViolationYichangtingcheV2Config& cfg)
    : ViolationBase(object_id, violation_id, cfg->violation_cfg)
    , cfg_(cfg)
    , status_(eUNDEFINE)
    , max_person_count_(0)
    , first_enter_(false)
{
}

int ViolationYichangtingcheV2::update_out_count(const ImageObjectsInfo& frameInfo) {
    int count =0;
    for(auto& obj : frameInfo.objects) {
        if (obj.label != OBJECT_TYPE_VEHICLE) {
            continue;
        }
        if (out_objs_.count(obj.uid)) {
            continue;
        }
        if (in_objs_.count(obj.uid)) {
            if (!cfg_->BoxDynamicCenterInArea(obj, frameInfo)) {
                count++;
                out_objs_.insert(obj.uid);
            }
        } else if (cfg_->BoxDynamicCenterInArea(obj, frameInfo)) {
            in_objs_[obj.uid] = obj;
        } else {
            // nop
        }
    }
    return count;
}

int ViolationYichangtingcheV2::count_in_area_person(const ImageObjectsInfo& frameInfo) const {
    int count =0;
    for(auto& obj : frameInfo.objects) {
        if (obj.label != OBJECT_TYPE_PERSON) {
            continue;
        }
        if (valid_box_center_in_polygon(obj, cfg_->violate_box.data(), cfg_->violate_box.size())) {
            count++;
        }
    }
    return count;
}

int ViolationYichangtingcheV2::count_in_area_car(const ImageObjectsInfo& frameInfo) const {
    int count =0;
    for(auto& obj : frameInfo.objects) {
        if (obj.label != OBJECT_TYPE_VEHICLE) {
            continue;
        }
        if (valid_box_center_in_polygon(obj, cfg_->violate_box.data(), cfg_->violate_box.size())) {
            count++;
        }
    }
    return count;
}

std::set<int> ViolationYichangtingcheV2::count_enter_car(const ImageObjectsInfo& frameInfo) {
    std::set<int>  retv;
    std::map<int,BoxF>  in;
    std::map<int,BoxF>  out;
    for( const auto& obj : frameInfo.objects) {
        if (obj.label != OBJECT_TYPE_VEHICLE) {
            continue;
        }
        if (valid_box_center_in_polygon(obj, cfg_->violate_box.data(), cfg_->violate_box.size())) {
            in[obj.uid] = obj;
        } else {
            out[obj.uid] = obj;
        }
    }
    for( const auto& obj : in) {
        if(this->pre_objs_.count(obj.first)) {
            retv.insert(obj.first);
        }
    }
    this->pre_objs_ = out;
    return retv;
}

result_list_t ViolationYichangtingcheV2::check(BoxF& box, const ImageObjectsInfo& objs)
{
    result_list_t retv;

    switch (status_)
    {
    case eUNDEFINE: 
        if (cfg_->enable_valid_box_check &&
            !valid_box_in_range(box, objs.sframe->width(), objs.sframe->height(), cfg_->plate_available_box_percent)) {
                break;
        }
        if (cfg_->BoxDynamicCenterInArea(box, objs)){
            status_ = eENTER_VIEW;
            this->in_objs_.clear();
            this->out_objs_.clear();
            this->pre_objs_.clear();
            this->pre_car_history_.clear();
            this->max_person_count_=0;
            this->clear_snapshot();
            this->add_snapshot(box, objs);
            if (!first_enter_) {
                LOG(INFO)<<"==>enter view, "<<objs.channel_id<<","<<violation_id_<<","<<object_id_;
                first_enter_ = true;
            }
        }
        break;
    case eENTER_VIEW:
        if (cfg_->IsParking(box, snapshots_.front().box) &&
            cfg_->BoxDynamicCenterInArea(box, objs)){
            auto elapsed_time = this->get_elapsed_time(objs);
            if ( elapsed_time.count() >= (cfg_->parking_second*1000*3/10) &&
                 elapsed_time.count() < (cfg_->parking_second*1000*6/10) ) {
                const auto pre_car = cfg_->PrevVehicle(box, objs);
                const auto pre_max_distance = cfg_->VehicleLength(box)*cfg_->distance_threshold;
                if ( pre_car.second < pre_max_distance) {
                    status_ = eUNDEFINE;
                    break;
                }
                status_ = eMID_TIME_UP;
                this->add_snapshot(box, objs);
                LOG(INFO)<<"==>stage one ready, "<<objs.channel_id<<","<<violation_id_<<","<<object_id_
                        << ", pre_car=<"<<pre_car.first<<"/"<<pre_car.second<<"/"<<pre_max_distance<<">";
            }
        } else {
            status_ = eUNDEFINE;
        }
        break;
    case eMID_TIME_UP:
        if (cfg_->IsParking(box, snapshots_.front().box) &&
            cfg_->BoxDynamicCenterInArea(box, objs)){
            auto elapsed_time = this->get_elapsed_time(objs, 0);
            auto pre_car = cfg_->PrevVehicle(box, objs);
            const auto pre_max_distance = cfg_->VehicleLength(box)*cfg_->distance_threshold;
            // 计算前车停留时长
            if (pre_car.first != nullptr &&
                pre_car.second < pre_max_distance) {
                int pre_car_elapsed_time = 0;
                if (this->pre_car_history_.count(pre_car.first->uid)) {
                    pre_car_elapsed_time = elapsed_time.count() - this->pre_car_history_[pre_car.first->uid].first;
                } else {
                    this->pre_car_history_[pre_car.first->uid].first = elapsed_time.count(); 
                    this->pre_car_history_[pre_car.first->uid].second = *pre_car.first;
                }
                if (pre_car_elapsed_time >= cfg_->parking_second*1000*5/10 &&
                    cfg_->IsParking(*pre_car.first, this->pre_car_history_[pre_car.first->uid].second)) {
                    status_ = eUNDEFINE;
                    LOG(INFO)<<"==>stage two drop, "<<objs.channel_id
                        <<","<<violation_id_
                        <<","<<object_id_
                        <<", pre_car=<"<<pre_car.first
                        <<"/"<<pre_car.second
                        <<"/"<<pre_max_distance
                        <<"/"<<pre_car_elapsed_time/1000.0
                        <<"s>";
                    break;
                }
            }
            this->max_person_count_ = std::max(this->max_person_count_, this->count_in_area_person(objs));
            if ( elapsed_time.count() >= (cfg_->parking_second*1000) &&
                elapsed_time.count() < (cfg_->parking_second*1000*2.1f) ){
                const int paking_in_car_count = cfg_->CarIntersectionCount(objs, *(this->snapshots_.front().image));
                bool need_reset = false;
                // const auto pre_distance = cfg_->PrevVehicleDistance(box, objs);
                // const auto pre_max_distance = cfg_->VehicleLength(box)*cfg_->distance_threshold;
                // if ( pre_distance < pre_max_distance) {
                //     need_reset = true;
                // }else
                if (cfg_->max_car_count > 0 && paking_in_car_count > cfg_->max_car_count) {
                    need_reset = true;
                } else if (cfg_->min_car_count > 0 && paking_in_car_count < cfg_->min_car_count) {
                    need_reset = true;
                } else if (cfg_->person_count > 0 && this->max_person_count_ < cfg_->person_count) {
                    need_reset = true;
                } else {
                    // nop
                }
                if (need_reset) {
                    status_ = eUNDEFINE;
                    LOG(INFO)<<"==>stage two drop, "<<objs.channel_id
                        <<","<<violation_id_
                        <<","<<object_id_
                        //<<", pre_distance="<<pre_distance<<"/"<<pre_max_distance
                        <<", in_car="<<paking_in_car_count
                        <<", person="<<this->max_person_count_;
                    break;
                }
                if (cfg_->IsFarthest(box)) {
                    status_ = eFAILED;
                    LOG(INFO)<<"==>stage two failed, "<<objs.channel_id
                        <<","<<violation_id_
                        <<","<<object_id_
                        <<", too far away, stop check";
                    break;
                }
                status_ = eLAST_TIME_UP;
                this->add_snapshot(box, objs);
                LOG(INFO)<<"==>stage two ready, "<<objs.channel_id<<","<<violation_id_<<","<<object_id_;
                retv =  get_results();

                // for cooling_second 
                this->clear_snapshot();
                this->add_snapshot(box, ImageObjectsInfo());
            }
        } else {
            status_ = eUNDEFINE;
        }
        break;
    case eLAST_TIME_UP:
        if (cfg_->cooling_second > 0) {
            auto elapsed_time = this->get_elapsed_time(objs);
            if ( elapsed_time.count() >= (cfg_->cooling_second*1000) ) {
                status_ = eUNDEFINE;
            }
        } else {
            status_ = eEND;
        }
        break;
    case eEND:
    case eFAILED:
    default:
        break;
    }

    static int colors[]={0,0,2,3,3,3,0};
    if (status_ != eUNDEFINE) {
        box.violate_state = colors[status_];
    }
    return retv;
}

//
// ViolationYichangtingcheV2Factory
//
ViolationYichangtingcheV2Factory::ViolationYichangtingcheV2Factory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(std::make_shared<ViolationYichangtingcheV2Config>(cfg))
{
}

const std::string& ViolationYichangtingcheV2Factory::id()const
{
    return id_;
}

spIViolation ViolationYichangtingcheV2Factory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == OBJECT_TYPE_VEHICLE){
        return std::make_shared<ViolationYichangtingcheV2>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }

}

// REGISTER_VIOLATION(GSYCTC_V2_CODE, YichangtingcheV2);
// REGISTER_VIOLATION_PATTERN(GSYCTC_V2_PATTERN, YichangtingcheV2);

} // namespace FLOW
