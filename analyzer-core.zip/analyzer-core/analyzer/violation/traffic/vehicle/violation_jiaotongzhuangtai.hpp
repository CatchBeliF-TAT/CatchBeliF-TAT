#ifndef VSS_VIOLATION_JIAOTONGZHUANGTAI_HPP
#define VSS_VIOLATION_JIAOTONGZHUANGTAI_HPP

#include "violation/traffic/violation_common.hpp"
namespace FLOW {

    class ViolationJiaotongzhuangtaiConfig;
    typedef std::shared_ptr<ViolationJiaotongzhuangtaiConfig> spViolationJiaotongzhuangtaiConfig;

    class ViolationJiaotongzhuangtaiFactory : public ViolationCommonFactory
    {
    public:
        ViolationJiaotongzhuangtaiFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationJiaotongzhuangtaiFactory()=default;

    public:
        virtual const std::string&      id()const;
        virtual spIViolation            CreateIViolation(const BoxF& obj);

    protected:
        std::string                                  id_;
        spViolationJiaotongzhuangtaiConfig           cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_JIAOTONGZHUANGTAI_HPP
