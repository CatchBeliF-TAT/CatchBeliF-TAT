#ifndef VSS_VIOLATION_AVGSPEEDDOWN_HPP
#define VSS_VIOLATION_AVGSPEEDDOWN_HPP

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

    class ViolationAvgspeeddownConfig;
    typedef std::shared_ptr<ViolationAvgspeeddownConfig> spViolationAvgspeeddownConfig;

    class ViolationAvgspeeddownFactory : public ViolationCommonFactory
    {
    public:
        ViolationAvgspeeddownFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationAvgspeeddownFactory()=default;

    public:
        virtual const std::string&      id()const;
        virtual spIViolation            CreateIViolation(const BoxF& obj);

    protected:
        std::string                         id_;
        spViolationAvgspeeddownConfig       cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_AVGSPEEDDOWN_HPP
