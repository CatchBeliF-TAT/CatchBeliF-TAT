
#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"

#include "serving/violation_config.pb.h"
#include "common/tad_internal.hpp"
#include "violation/conditions/line_condition.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_jiasai.hpp"

namespace FLOW {

static const std::string JIASAI_CODE("2127");

//
// ViolationJiasaiConfig
//
class ViolationJiasaiConfig {
public:
    ViolationJiasaiConfig(const std::string& json);

protected:
    bool ParseJson(const std::string& json);

public:
    typedef std::vector<float> VecFloat;
    float start_line[4];
    float violate_line[4];
    float stop_line[4];
    VecFloat violate_box;
    int car_count;
    float cover_ratio;
    int parking_second;
    spViolationConfig  violation_cfg;

    fn_check_action     start_line_checker;
    fn_check_action     violate_line_checker;
    fn_check_action     end_line_checker;
};

ViolationJiasaiConfig::ViolationJiasaiConfig(const std::string& json)
    : start_line{0.0f}
    , violate_line{0.0f}
    , stop_line{0.0f}
    , violate_box()
    , car_count(-1)
    , cover_ratio(-1)
    , parking_second(-1)
    , violation_cfg(std::make_shared<inference::ViolationConfig>())
{
    auto result = this->ParseJson(json);
    CHECK(result);
}

bool ViolationJiasaiConfig::ParseJson(const std::string& json) {
    std::string err;
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }

    auto& cfg = *violation_cfg;
    const int MIN_SIZE = 4;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "start_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), MIN_SIZE, std::begin(start_line));
            start_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
        } else if (cond.name() == "violate_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), MIN_SIZE, std::begin(violate_line));
            violate_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
        } else if (cond.name() == "stop_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), MIN_SIZE, std::begin(stop_line));
            end_line_checker = CreateLineCondition(cond, false, google::protobuf::RepeatedField<float>());
        } else if (cond.name() =="violate_box") {
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box));
            car_count = cond.has_car_count() ? cond.car_count() : car_count;
            cover_ratio = cond.has_cover_ratio() ? cond.cover_ratio() : cover_ratio;
            parking_second = cond.has_parking_second() ? cond.parking_second() : parking_second;
        }
    }
    return true;
}

//
// ViolationJiasai
//
class ViolationJiasai : public ViolationBase
{
public:
    ViolationJiasai(int object_id, const std::string& violation_id, const spViolationJiasaiConfig& cfg);
    virtual ~ViolationJiasai()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

protected:
    std::map<int, BoxF> in_violate_box_cars(const ImageObjectsInfo& frameInfo) const;
    void in_violate_box_cars_min(const BoxF& box, const ImageObjectsInfo& frameInfo, 
                    std::pair<int, float>& min_values, std::pair<int, int>& counts) const;

protected:
    enum STATUS{
        eUNDEFINE,
        eENTER_VIEW,
        eCROSS_VIOLATE,
        eCROSS_ENDLINE,
        eEND,
    };

protected:
    spViolationJiasaiConfig         cfg_;
    STATUS                          status_;
    std::map<int, BoxF>             in_box_cars_;
    int                             min_car_count_;
    float                           min_cover_ratio_;
    BoxF                            last_box_;
};

ViolationJiasai::ViolationJiasai(int object_id, const std::string& violation_id, const spViolationJiasaiConfig& cfg)
    : ViolationBase(object_id, violation_id, cfg->violation_cfg)
    , cfg_(cfg)
    , status_(eUNDEFINE)
    , in_box_cars_()
    , min_car_count_(-1)
    , min_cover_ratio_(-1)
{
}

std::map<int, BoxF> ViolationJiasai::in_violate_box_cars(const ImageObjectsInfo& frameInfo) const {
    std::map<int, BoxF> in_objs;
    for(auto& obj : frameInfo.objects) {
        if (obj.label != OBJECT_TYPE_VEHICLE) {
            continue;
        }
        if (valid_box_center_in_polygon(obj, cfg_->violate_box.data(), cfg_->violate_box.size())) {
            in_objs[obj.uid] = obj;
        }
    }
    return std::move(in_objs);
}

void ViolationJiasai::in_violate_box_cars_min(
                const BoxF& box,
                const ImageObjectsInfo& frameInfo, 
                std::pair<int, float>& min_values, 
                std::pair<int, int>& counts) const{
    std::map<int, BoxF> in_objs = in_violate_box_cars(frameInfo);
    int merge_car_count=0;
    float cover_ratio=0;
    // min_car_count_
    for(auto& kv : in_objs) {
        if (in_box_cars_.count(kv.second.uid) == 0) {
            continue;
        }
        merge_car_count++;
    }
    if (cfg_->car_count > 0) {
        merge_car_count = (min_car_count_<0 || merge_car_count<min_car_count_)
            ? merge_car_count
            : min_car_count_;
    }

    // counts
    if (box.uid > 0) {
        const auto box_center = box.CenterFloat();
        auto base_value = get_foot_of_perpendicular(
            std::pair<float, float>{box_center.x, box_center.y},
            std::pair<float, float>{cfg_->violate_line[0],cfg_->violate_line[1]},
            std::pair<float, float>{cfg_->violate_line[2],cfg_->violate_line[3]},
            false
        );
        for(auto& kv : in_objs) {
            const auto box2_center = kv.second.CenterFloat();
            auto base2_value = get_foot_of_perpendicular(
                std::pair<float, float>{box2_center.x, box2_center.y},
                std::pair<float, float>{cfg_->violate_line[0],cfg_->violate_line[1]},
                std::pair<float, float>{cfg_->violate_line[2],cfg_->violate_line[3]},
                false
            );
            if (base2_value > base_value) {
                counts.first++;
            } else {
                counts.second++;
            }
        }
    }

    // cover_ratio
    if (cfg_->cover_ratio > 0) {
        std::vector<std::pair<float,float> > ranges;
        for(auto& kv : in_objs) {
            const std::vector<float> data{
                kv.second.xmin,kv.second.ymin,
                kv.second.xmax,kv.second.ymax,
                kv.second.xmin,kv.second.ymax,
                kv.second.xmax,kv.second.ymin,
            };
            std::vector<float> scale;
            for(int i=1; i<data.size(); i+=2) {
                auto foot = get_foot_of_perpendicular(
                    std::pair<float, float>{data[i-1], data[i]},
                    std::pair<float, float>{cfg_->violate_line[0],cfg_->violate_line[1]},
                    std::pair<float, float>{cfg_->violate_line[2],cfg_->violate_line[3]},
                    false
                );
                scale.push_back(foot.first);
            }
            auto minmax = std::minmax_element(scale.begin(), scale.end());
            ranges.push_back(std::pair<float,float>{*minmax.first,*minmax.second});
        }
        std::sort(ranges.begin(), ranges.end());
        std::vector<std::pair<float, float> > result;
        auto it = ranges.begin();
        if (it != ranges.end()) {
            result.push_back(*it);it++;
            while (it != ranges.end()) {
                if (result.back().second > it->first){ // you might want to change it to >=
                    result.back().second = std::max(result.back().second, it->second); 
                } else {
                    result.push_back(*it);
                }
                it++;
            }
        }
        float total=0;
        for(auto x:result) {
            total += (x.second-x.first);
        }
        cover_ratio = total/1.0f;

        cover_ratio = (min_cover_ratio_<0 || cover_ratio<min_cover_ratio_)
            ? cover_ratio
            : min_cover_ratio_;
    }
    // retv
    min_values = std::pair<int, float>(merge_car_count, cover_ratio);
}

result_list_t ViolationJiasai::check(BoxF& box, const ImageObjectsInfo& frame)
{
    result_list_t retv;

    // init last_box_
    if (last_box_.uid == -1) {
        last_box_ = box;
    }
    std::shared_ptr<void> update_last_box(nullptr,[&](void*){
        last_box_ = box;
    });

    switch (status_)
    {
    case eUNDEFINE:
        if (valid_box_in_range(box, frame.sframe->width(), frame.sframe->height(), cfg_->violation_cfg->plate_available_box_percent()) &&
            cfg_->start_line_checker(last_box_, box, frame)){
            status_ = eENTER_VIEW;
            in_box_cars_ = ViolationJiasai::in_violate_box_cars(frame);
            this->add_snapshot(box, frame);
            LOG(INFO)<<"==>enter view, "<< frame.channel_id<<","<<violation_id_<<","<<object_id_;
        }
        break;
    case eENTER_VIEW:
        if (cfg_->parking_second>0 && this->get_elapsed_time(frame).count() < cfg_->parking_second*1000){
            break;
        } else if (cfg_->violate_line_checker(last_box_, box, frame)){
            std::pair<int, float> min_values;
            std::pair<int, int> counts;
            this->in_violate_box_cars_min(box, frame, min_values, counts);
            std::tie(min_car_count_, min_cover_ratio_) = min_values;
            if (cfg_->car_count > 0 && min_car_count_ < cfg_->car_count) {
                status_ = eEND;
                LOG(INFO)<<"==> fail violate line min_car_count, "<< frame.channel_id<<","<<violation_id_<<","<<object_id_<<",i="<<min_car_count_;
                break;
            }
            if (cfg_->cover_ratio > 0 && min_cover_ratio_ < cfg_->cover_ratio) {
                status_ = eEND;
                LOG(INFO)<<"==> fail violate line min_cover_ratio, "<< frame.channel_id<<","<<violation_id_<<","<<object_id_<<",cv="<<min_cover_ratio_;
                break;
            }
            if (counts.first == 0 && counts.second == 0) {
                status_ = eEND;
                LOG(INFO)<<"==> fail violate line counts, "<< frame.channel_id<<","<<violation_id_<<","<<object_id_<<",pc="<<counts.first<<",ac="<<counts.second;
                break;
            }

            status_ = eCROSS_VIOLATE;
            this->add_snapshot(box, frame);
            LOG(INFO)<<"==>cross violate line, "<< frame.channel_id<<","<<violation_id_<<","<<object_id_;
        }
        break;
    case eCROSS_VIOLATE:
        if (cfg_->end_line_checker(last_box_, box, frame)){
            status_ = eCROSS_ENDLINE;
            LOG(INFO)<<"==>cross end line, "<< frame.channel_id<<","<<violation_id_<<","<<object_id_;
            this->add_snapshot(box, frame);
            retv = get_results();
        }

        break;
    case eCROSS_ENDLINE:
    case eEND:
    default:
        break;
    }

    // update violate state
    static int colors[]={0,0,2,3,0};
    if (status_ != eUNDEFINE) {
        box.violate_state = colors[status_];
    }
    return retv;
}

//
// ViolationJiasaiFactory
//
ViolationJiasaiFactory::ViolationJiasaiFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(std::make_shared<ViolationJiasaiConfig>(cfg))
{
}

const std::string& ViolationJiasaiFactory::id()const
{
    return id_;
}

spIViolation ViolationJiasaiFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == OBJECT_TYPE_VEHICLE){
        return std::make_shared<ViolationJiasai>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(JIASAI_CODE, Jiasai);

} // namespace FLOW
