
#include <iterator>
#include <map>
#include <vector>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"
#include "serving/violation_config.pb.h"


#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_avgloc.hpp"
#include "violation/traffic/locus/locus.hpp"


namespace FLOW {

    static const std::string PJWZ_NAME("AvgLoc");
    static const std::string PJWZ_CODE("2299");

//
// ViolationAvgLocConfig
//
    class ViolationAvgLocConfig {
    public:
        ViolationAvgLocConfig(const std::string& json)
                : violate_box()
        {
            auto result=this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json);
    public:
        typedef     std::vector<float> VecFloat;
        float       distance;
        VecFloat    start_line;
        VecFloat    end_line;
        VecFloat    violate_box;
        spViolationConfig  violation_cfg;
        std::string code;
        std::string name;
    };

    bool ViolationAvgLocConfig::ParseJson(const std::string& json) {
        std::string err;
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;
        name = cfg.name();
        code = cfg.code();

        const int MIN_SIZE = 2*3;
        for (int i=0; i<cfg.conditions_size(); i++) {
            const auto& cond = cfg.conditions(i);
            if (cond.name() == "violate_box"){
                CHECK_GE(cond.data_size(), MIN_SIZE);
                std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box));
                std::copy_n(cond.data().begin(), 4, std::back_inserter(start_line));
                std::copy_n(cond.data().begin()+6, 2, std::back_inserter(end_line));
                std::copy_n(cond.data().begin()+4, 2, std::back_inserter(end_line));
            }
        }
        return true;
    }
//
// ViolationAvgLoc
//
    class ViolationAvgLoc : public ViolationBase
    {
    public:
        ViolationAvgLoc(int object_id, const std::string& violation_id, const spViolationAvgLocConfig cfg);
        virtual ~ViolationAvgLoc()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

    protected:
        struct Cars_Info{
            std::chrono::milliseconds         car_start;
            std::chrono::milliseconds         car_end;
            bool                              car_sflag;
            bool                              car_eflag;
            FLOW::BoxF                        last_box;
        };

    protected:
        const spViolationAvgLocConfig              cfg_;
        float                                      sumavg_speed_;
        int                                        cars_cnt_;
        std::map<int, Cars_Info>                   cars_info_; 
        std::shared_ptr<Locus>                     locus_; 
    };

    ViolationAvgLoc::ViolationAvgLoc(int object_id, const std::string& violation_id, const spViolationAvgLocConfig cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
            , cars_cnt_(0)
            , sumavg_speed_(0.0)
            , locus_(std::make_shared<Locus>())
    {   
    }

    result_list_t ViolationAvgLoc::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;

        for (const auto& obj : objs.objects) {
            if (obj.uid < 0) {
                continue;
            }

            if (obj.label == OBJECT_TYPE_VEHICLE) {
                if (obj.delete_flag) {
                    if (cars_info_.find(obj.uid) != cars_info_.end()) {
                        cars_info_.erase(obj.uid);
                    }
                    continue;
                }


                if (cars_info_.find(obj.uid) == cars_info_.end()) {
                    cars_info_[obj.uid].car_sflag = false;
                    cars_info_[obj.uid].car_eflag = false;
                    // cars_info_[obj.uid].last_box = obj;
                    // obj.violate_state = 99;
                }

                if (cars_info_.find(obj.uid) != cars_info_.end() && valid_box_center_in_polygon(obj, cfg_->violate_box.data(), cfg_->violate_box.size())
                    && valid_boxes_center_across_lines(cars_info_[obj.uid].last_box, obj, cfg_->start_line.data())) {
                    cars_info_[obj.uid].car_sflag = true;
                    cars_info_[obj.uid].car_eflag = false;
                    obj.violate_state = 999;
                    locus_->Add(std::to_string(obj.uid),PointF{(obj.xmin  + obj.xmax)/2.0f, (obj.ymin  + obj.ymax)/2.0f});   
                    
                    continue;
                }

                if (cars_info_.find(obj.uid) != cars_info_.end() && 
                    cars_info_[obj.uid].car_sflag && !cars_info_[obj.uid].car_eflag) {
                    obj.violate_state = 999;
                    locus_->Add(std::to_string(obj.uid),PointF{(obj.xmin  + obj.xmax)/2.0f, (obj.ymin  + obj.ymax)/2.0f});   
                }

                if (cars_info_.find(obj.uid) != cars_info_.end() &&
                        cars_info_[obj.uid].car_sflag == true && 
                        cars_info_[obj.uid].car_eflag == false && 
                        !valid_box_center_in_polygon(obj, cfg_->violate_box.data(), cfg_->violate_box.size()) &&
                        valid_boxes_center_across_lines(cars_info_[obj.uid].last_box, obj, cfg_->end_line.data())) {
                    cars_info_[obj.uid].car_eflag = true;
                    obj.violate_state = 9999;
                    if (locus_->Check(std::to_string(obj.uid))){
                        this->add_snapshot(obj, objs);
                        retv = this->get_results();
                        this->clear_snapshot();
                    } 
                    locus_->Remove(std::to_string(obj.uid)); 
                } 

                if (cars_info_.find(obj.uid) != cars_info_.end() &&
                        cars_info_[obj.uid].car_sflag == true && 
                        cars_info_[obj.uid].car_eflag == false && 
                        !valid_box_center_in_polygon(obj, cfg_->violate_box.data(), cfg_->violate_box.size()) &&
                        !valid_boxes_center_across_lines(cars_info_[obj.uid].last_box, obj, cfg_->end_line.data())) {
                    cars_info_[obj.uid].car_eflag = true;
                    obj.violate_state = 99999;
                    locus_->Remove(std::to_string(obj.uid)); 
                    this->clear_snapshot();
                }
                cars_info_[obj.uid].last_box = obj;

            }  // end if (obj.label == OBJECT_TYPE_VEHICLE)
        }

        if (cars_info_.size()> 0) {
            // std::string violation_id = this-> violation_id_;
            objs.avg_path_map[this-> violation_id_] = locus_->AvgPath();
            objs.voilation_path_map[this-> violation_id_] = locus_->VoilationPath();
            objs.current_path_map[this-> violation_id_] = locus_->CorrectPath();
        }

        return retv;
    }

//
// ViolationAvgLocFactory
//
    ViolationAvgLocFactory::ViolationAvgLocFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationAvgLocConfig>(cfg))
    {
    }

    const std::string& ViolationAvgLocFactory::id()const {
        return id_;
    }

    spIViolation ViolationAvgLocFactory::CreateIViolation(const BoxF& obj){
        if (obj.label == -1){
            return std::make_shared<ViolationAvgLoc>(obj.uid, id_, cfg_);
        } else {
            return nullptr;
        }
    }

    REGISTER_VIOLATION(PJWZ_CODE, AvgLoc);

} // namespace FLOW