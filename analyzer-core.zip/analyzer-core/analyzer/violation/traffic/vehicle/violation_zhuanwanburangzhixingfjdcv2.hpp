#ifndef VSS_VIOLATION_ZHUANWANBURANGZHIXING_FJDC_V2_HPP
#define VSS_VIOLATION_ZHUANWANBURANGZHIXING_FJDC_V2_HPP

#include <memory>
#include <vector>
#include "violation/traffic/violation_common.hpp"

namespace FLOW {
class ViolationZhuanwanburangzhixingfjdcV2Config;
typedef std::shared_ptr<ViolationZhuanwanburangzhixingfjdcV2Config> spViolationZhuanwanburangzhixingfjdcV2Config;
class ViolationZhuanwanburangzhixingfjdcV2Factory : public ViolationCommonFactory 
{
public:
    ViolationZhuanwanburangzhixingfjdcV2Factory(const std::string& id, const std::string& cfg);
    virtual ~ViolationZhuanwanburangzhixingfjdcV2Factory()=default;

public:
    virtual const std::string&  id()const;
    virtual spIViolation        CreateIViolation(const BoxF& obj);

protected:
    std::string                                 id_;
    spViolationZhuanwanburangzhixingfjdcV2Config  cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_ZHUANWANBURANGZHIXING_FJDC_V2_HPP
