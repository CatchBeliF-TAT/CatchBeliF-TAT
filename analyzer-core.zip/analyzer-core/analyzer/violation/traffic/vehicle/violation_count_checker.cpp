
#include <map>
#include <iterator>
#include <functional>
#include <algorithm>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/helper.hpp"
#include "common/pbjson.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"
#include "common/tad_internal.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_count_checker.hpp"

namespace FLOW {

static const std::string FEIJIDONGCHEJUJI_CODE("2465");
static const std::string FEIJIDONGCHEPENGZHUANG_CODE("2466");
static const std::string RENCHEHUNLUAN_CODE("2467");
static const std::string RENCHEHUNLUAN_CODE_PATTERN("^2467[0-9]{2}$");

//
// ViolationCountCheckerConfig
//
ViolationCountCheckerConfig::ViolationCountCheckerConfig(const std::string& json)
    : violate_box()
    , parking_second(60)
    , cooling_second(600)
    , min_car_count(-1)
    , min_nonmotor_count(-1)
    , min_person_count(-1)
    , max_move_percent(-1)
    , min_nonmotor_with_person_count(-1)
    , distance(-1)
    , user_def_compare([](const BoxF& b1,const BoxF& b2){ return b1.uid == b2.uid; })
{
    auto result=this->ParseJson(json);
    CHECK(result);
    if (violation_cfg && 
        (violation_cfg->code()== FEIJIDONGCHEJUJI_CODE ||
         violation_cfg->code()== FEIJIDONGCHEPENGZHUANG_CODE)) {
        max_move_percent = (max_move_percent<0) ? 0.1 : max_move_percent;
    }
    if (max_move_percent > 0) {
        user_def_compare = [&](const BoxF &b1, const BoxF &b2){
            return b1.uid == b2.uid && valid_box_box_distance(b1, b2, max_move_percent);
        };
    }
}

bool ViolationCountCheckerConfig::ParseJson(const std::string& json) {
    std::string err;
    violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }
    auto& cfg = *violation_cfg;
    cooling_second = cfg.has_cooling_second()?cfg.cooling_second():cooling_second;
    const int MIN_SIZE = 2*3;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "violate_box"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box));
            if (cond.has_parking_second()) {
                parking_second = cond.parking_second();
            }
            if (cond.has_car_count()) {
                min_car_count = cond.car_count();
            }
            if (cond.has_nonmotor_count()) {
                if (cfg.code() == FEIJIDONGCHEJUJI_CODE) {
                    min_nonmotor_with_person_count = cond.nonmotor_count();
                } else {
                    min_nonmotor_count = cond.nonmotor_count();
                }
            }
            if (cond.has_person_count()) {
                min_person_count = cond.person_count();
            }
            if (cond.has_max_move_percent()) {
                max_move_percent = cond.max_move_percent();
            }
            if (cond.has_distance()) {
                distance = cond.distance();
            }
        }
    }
    return true;
}

VecBoxF intersection_n(const std::vector<float>& violate_box,
                    const ImageObjectsInfo& objs1,
                    const ImageObjectsInfo& objs2,
                    ViolationCountCheckerConfig::fn_compare_box fn,
                    int label=-1) {
    VecBoxF output;
    std::map<int, const BoxF*> objs1_map;
    for(auto& obj : objs1.objects) {
        if (label != -1 && obj.label!=label) {
            continue;
        }
        if (valid_box_center_in_polygon(obj, violate_box.data(), violate_box.size())) {
            objs1_map[obj.uid] = &obj;
        }
    }
    for(auto& obj : objs2.objects) {
        if ((objs1_map.count(obj.uid) > 0) && fn(*(objs1_map[obj.uid]), obj)) {
            output.push_back(obj);
        }
    }
    return output;
}

//
// ViolationCountChecker
//
class ViolationCountChecker : public ViolationBase
{
public:
    ViolationCountChecker(int object_id, const std::string& violation_id, const ViolationCountCheckerConfig& cfg);
    virtual ~ViolationCountChecker()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs) override;
    virtual result_list_t get_results() const override;

protected:
    enum STATUS{
        eUNDEFINE,
        eENTER_VIEW,
        eMID_TIME_UP,
        eLAST_TIME_UP,
        eCOOL_TIME_UP,
        eEND,
    };

protected:
    ViolationCountCheckerConfig    cfg_;
    STATUS                         status_;
    std::map<int,BoxF>             pre_objs;
};

ViolationCountChecker::ViolationCountChecker(int object_id, const std::string& violation_id, const ViolationCountCheckerConfig& cfg)
    : ViolationBase(object_id, violation_id, cfg.violation_cfg)
    , cfg_(cfg)
    , status_(eUNDEFINE)
{
}

result_list_t ViolationCountChecker::check(BoxF& box, const ImageObjectsInfo& info)
{
    result_list_t retv;

    size_t car_count = -1;
    size_t nonomotor_count = -1;
    size_t person_count = -1;
    VecBoxF in_objs;
    std::vector<VecInt> groups;

    static const auto to_map = 
        [](const VecBoxF& vb) {
            std::map<int,BoxF> out;
            std::for_each(vb.cbegin(), vb.cend(),[&](const BoxF& b){
                out[b.uid] = b;
            });
            return out;
        };
    static const auto uid_equal = 
        [](const BoxF& b1,const BoxF& b2) {
            return b1.uid == b2.uid;
        };
    static const auto uid_less = 
        [](const BoxF& b1,const BoxF& b2) {
            return b1.uid < b2.uid;
        };
    static const auto with_label = 
        [](const int label, const BoxF& b1) {
            return b1.label == label;
        };
    static const auto has_person_in_box =
        [](const BoxF& b) {
            return b.mergedBoxes.size() > 0;
        };
    struct Require{ int lable; int count; bool has_person;};
    const auto requires= std::vector<Require>{
        {OBJECT_TYPE_VEHICLE,   cfg_.min_car_count,false},
        {OBJECT_TYPE_NONMOTOR,  cfg_.min_nonmotor_count,false},
        {OBJECT_TYPE_PERSON,    cfg_.min_person_count,false},
        {OBJECT_TYPE_NONMOTOR,  cfg_.min_nonmotor_with_person_count,true},
    };

    static const auto match_requires = 
        [](const std::vector<Require>& requires,const VecBoxF& boxes)->VecInt {
            VecInt retv;
            for(const auto& req : requires) {
                if (req.count >= 0) {
                    VecInt temp;
                    for(int i=0; i< boxes.size(); i++) {
                        if (with_label(req.lable, boxes[i])) {
                            if (req.has_person &&
                                !has_person_in_box(boxes[i])) {
                                continue;
                            }
                            temp.push_back(i); 
                        }
                    }
                    if (temp.size() < req.count) { return VecInt{}; }
                    else { retv.insert(retv.end(), temp.begin(), temp.end()); }
                }
            }
            return retv;
        };
    
    // status process
    switch (status_)
    {
    case eUNDEFINE:
        std::copy_if(info.objects.cbegin(), info.objects.cend(), std::back_inserter(in_objs),
            [this](const BoxF& b){
                return valid_box_center_in_polygon(b, cfg_.violate_box.data(), cfg_.violate_box.size());
        });

        // group by distance
        if (cfg_.distance > 0) {
            auto max_distance = cfg_.distance * std::max(info.sframe->width(), info.sframe->height());
            max_distance = cfg_.distance > 1 ? cfg_.distance : max_distance;
            VecPointF centers(in_objs.size());
            std::transform(in_objs.begin(), in_objs.end(), centers.begin(),
                        [&](const BoxF& obj) { return obj.CenterFloat(); });
            groups = group_points_by_distance(centers, max_distance);
        } else {
            // set to one group
            groups.resize(1);
            groups[0].resize(in_objs.size());
            std::iota(groups[0].begin(), groups[0].end(), 0);
        }

        // check count requirements
        {
            bool pass=false;
            VecBoxF match_requires_box;
            for(const auto& group : groups) {
                VecBoxF group_box;
                for(const auto& v:group) { group_box.push_back(in_objs[v]); }
                auto match_indexes = match_requires(requires, group_box);
                if ( match_indexes.size() > 0) {
                    for( auto index : match_indexes) {
                        match_requires_box.push_back(group_box[index]);
                    }
                }
            }
            if (match_requires_box.empty()) {
                return retv;
            }
            in_objs.swap(match_requires_box);
        }

        status_ = eENTER_VIEW;
        pre_objs = to_map(in_objs);
        this->add_snapshot(box, info);
        this->snapshots_.back().image->objects = in_objs;
        LOG(INFO)<<"==>stage one ready, "<<info.channel_id<<", "<<violation_id_;
        break;
    case eENTER_VIEW:
        if (this->get_elapsed_time(info).count() < (cfg_.parking_second*1000)) {
            break;
        }
        std::copy_if(info.objects.cbegin(), info.objects.cend(), std::back_inserter(in_objs),
            [this](const BoxF& box){
                return pre_objs.count(box.uid) > 0 &&
                    cfg_.user_def_compare(pre_objs[box.uid], box) &&
                    valid_box_center_in_polygon(box, cfg_.violate_box.data(), cfg_.violate_box.size());
        });
        
        // group by distance
        if (cfg_.distance > 0) {
            auto max_distance = cfg_.distance * std::max(info.sframe->width(), info.sframe->height());
            VecPointF centers(in_objs.size());
            std::transform(in_objs.begin(), in_objs.end(), centers.begin(),
                        [&](const BoxF& obj) { return obj.CenterFloat(); });
            groups = group_points_by_distance(centers, max_distance);
        } else {
            // set to one group
            groups.resize(1);
            groups[0].resize(in_objs.size());
            std::iota(groups[0].begin(), groups[0].end(), 0);
        }

        // check count requirements
        {
            VecBoxF match_requires_box;
            for(const auto& group : groups) {
                VecBoxF group_box;
                for(const auto& v:group) { group_box.push_back(in_objs[v]); }
                auto match_indexes = match_requires(requires, group_box);
                if ( match_indexes.size() > 0) {
                    for( auto index : match_indexes) {
                        match_requires_box.push_back(group_box[index]);
                    }
                }
            }
            if (match_requires_box.empty()) {
                status_ = eUNDEFINE;
                this->clear_snapshot();
                LOG(INFO)<<"==>stage two dorp, "<<info.channel_id<<", "<<violation_id_;
                return retv;
            }
            pre_objs = to_map(in_objs);
            in_objs.swap(match_requires_box);
        }

        status_ = eLAST_TIME_UP;
        this->add_snapshot(box, info);
        this->snapshots_.back().image->objects = in_objs;
        LOG(INFO)<<"==>stage two ready, "<<info.channel_id<<", "<<violation_id_;
        retv =  get_results();
        // for cooling_second 
        this->clear_snapshot();
        this->add_snapshot(box, ImageObjectsInfo());
        break;
    case eLAST_TIME_UP:
        if (cfg_.cooling_second > 0) {
            auto elapsed_time = this->get_elapsed_time(info);
            if ( elapsed_time.count() >= (cfg_.cooling_second*1000) ) {
                status_ = eUNDEFINE;
                this->clear_snapshot();
            }
        } else {
            status_ = eEND;
        }
        break;
    case eEND:
    default:
        break;
    }

    return retv;
}

result_list_t ViolationCountChecker::get_results()const{
    result_list_t retv;
    const auto obj_id = object_id_;
    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = violation_cfg_->code();
    const auto violation_name = violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;
    const auto enable_output_picture = violation_cfg_->enable_output_picture();
    const auto enable_save_picture = violation_cfg_->enable_save_debug_picture();

    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event_with_type = *retv;
        event_with_type.set_event_type(get_event_type_form_code(violation_code));
        //warning
        inference::ViolationEvent& event = *(event_with_type.mutable_traffic_event());
        event.set_stream_id(stream_id);
        event.set_obj_id(obj_id);
        event.set_violation_id(violation_id);
        event.set_violation_code(violation_code);
        event.set_violation_name(violation_name);

        for(int i=0;i<snapshots.size();i++){
            auto& image = snapshots[i].image;
            auto snap1 = event.add_snapshots();
            snap1->set_now(snapshots[i].now.time_since_epoch().count());
            if (enable_output_picture){
                snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
            }
            // add objects
            for(auto& box : image->objects) {
                auto obj = snap1->add_objects();
                obj->set_type(std::to_string(box.label));
                obj->set_score(box.score);
                obj->add_box(box.xmin);
                obj->add_box(box.ymin);
                obj->add_box(box.xmax);
                obj->add_box(box.ymax);
            }
        }

        return retv;
    };
    retv.push_back(action);
    return retv;
}

//
// ViolationCountCheckerFactory
//
ViolationCountCheckerFactory::ViolationCountCheckerFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(cfg)
{
}

const std::string& ViolationCountCheckerFactory::id()const
{
    return id_;
}

spIViolation ViolationCountCheckerFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.uid == -1){
        return std::make_shared<ViolationCountChecker>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }

}

REGISTER_VIOLATION(FEIJIDONGCHEJUJI_CODE, CountChecker);
REGISTER_VIOLATION(FEIJIDONGCHEPENGZHUANG_CODE, CountChecker);
REGISTER_VIOLATION(RENCHEHUNLUAN_CODE, CountChecker);

REGISTER_VIOLATION_PATTERN(RENCHEHUNLUAN_CODE_PATTERN, CountChecker);

} // namespace FLOW
