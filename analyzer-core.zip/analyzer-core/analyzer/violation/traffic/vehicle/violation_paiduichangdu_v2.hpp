#ifndef VSS_VIOLATION_PAIDUICHANGDU_V2_HPP
#define VSS_VIOLATION_PAIDUICHANGDU_V2_HPP

#include "violation/traffic/violation_common.hpp"
namespace FLOW {

    class ViolationPaiduichangduV2Config;
    typedef std::shared_ptr<ViolationPaiduichangduV2Config> spViolationPaiduichangduV2Config;

    class ViolationPaiduichangduV2Factory : public ViolationCommonFactory
    {
    public:
        ViolationPaiduichangduV2Factory(const std::string& id, const std::string& cfg);
        virtual ~ViolationPaiduichangduV2Factory()=default;

    public:
        virtual const std::string&      id()const;
        virtual spIViolation            CreateIViolation(const BoxF& obj);

    protected:
        std::string                                  id_;
        spViolationPaiduichangduV2Config             cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_PAIDUICHANGDU_V2_HPP
