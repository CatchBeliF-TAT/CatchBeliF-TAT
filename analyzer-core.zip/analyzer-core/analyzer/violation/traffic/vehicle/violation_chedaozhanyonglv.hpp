#ifndef VSS_VIOLATION_CHEDAOZHANYONGLV_HPP
#define VSS_VIOLATION_CHEDAOZHANYONGLV_HPP

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

    class ViolationChedaozhanyonglvConfig;
    typedef std::shared_ptr<ViolationChedaozhanyonglvConfig> spViolationChedaozhanyonglvConfig;

    class ViolationChedaozhanyonglvFactory : public ViolationCommonFactory
    {
    public:
        ViolationChedaozhanyonglvFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationChedaozhanyonglvFactory()=default;

    public:
        virtual const std::string& id()const;
        virtual spIViolation CreateIViolation(const BoxF& obj);

    protected:
        std::string                         id_;
        spViolationChedaozhanyonglvConfig   cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_CHEDAOZHANYONGLV_HPP
