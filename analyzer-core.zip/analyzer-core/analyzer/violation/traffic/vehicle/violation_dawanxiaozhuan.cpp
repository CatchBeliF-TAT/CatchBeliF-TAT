
#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"

#include "algorithm/vehicleattribute/vehicle_attr.hpp"
#include "serving/violation_config.pb.h"
#include "common/tad_internal.hpp"
#include "violation/traffic/violation_base.hpp"
#include "violation/violation_util.hpp"
#include "violation_dawanxiaozhuan.hpp"

namespace FLOW {

static const std::string DAWANXIAOZHUAN_NAME("dawanxiaozhuan");
static const std::string DAWANXIAOZHUAN_CODE("2101");

//
// ViolationDawanxiaozhuanConfig
//
ViolationDawanxiaozhuanConfig::ViolationDawanxiaozhuanConfig(const std::string& json)
    : violate_line{0.0f,0.0f,0.0f,0.0f}
    , stop_line{0.0f,0.0f,0.0f,0.0f}
    , plate_available_box_percent(0.025f)
    , enable_output_picture(true)
    , enable_save_picture(false)
{
    auto result=this->ParseJson(json);
    if (!result) {
        result=this->ParseJsonV2(json);
    }
    CHECK(result);
    if (nullptr == violation_cfg) {
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        violation_cfg->set_code(code);
        violation_cfg->set_name(name);
        violation_cfg->set_enable_output_picture(enable_output_picture);
        violation_cfg->set_enable_save_debug_picture(enable_save_picture);
    }
}

bool ViolationDawanxiaozhuanConfig::ParseJson(const std::string& json) {
    const auto& root = get_document(json);
    code = get_string(root, "code", DAWANXIAOZHUAN_CODE);
    name = get_string(root, "name", DAWANXIAOZHUAN_NAME);
    if ( ! try_get_array(root, "start_line", start_line)) {
        return false;
    }
    if ( ! try_get_array(root, "violate_line", violate_line)) {
        return false;
    }
    // []
    stop_line = get_array<float>(root, "stop_line");
    // [[],[],[]]
    if (stop_line.empty()) {
        const auto& lines = get_value(root, "stop_line");
        if (lines.IsArray()) {
            for(const auto& line : lines.GetArray()) {
                if (line.IsArray() && line.Size()>=4 &&
                    line[0].IsNumber() && line[1].IsNumber() &&
                    line[2].IsNumber() && line[3].IsNumber() ){
                    stop_line.push_back(line[0].GetFloat());
                    stop_line.push_back(line[1].GetFloat());
                    stop_line.push_back(line[2].GetFloat());
                    stop_line.push_back(line[3].GetFloat());
                }
            }
        }
    }
    plate_available_box_percent=get_float(root, "plate_available_box_percent", plate_available_box_percent);
    enable_output_picture = get_bool(root,"enable_output_picture", enable_output_picture);
    enable_save_picture = get_bool(root,"enable_save_picture", enable_save_picture);
    return true;
}

bool ViolationDawanxiaozhuanConfig::ParseJsonV2(const std::string& json) {
    std::string err;
    violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }
    auto& cfg = *violation_cfg;
    name = cfg.name();
    code = cfg.code();
    const int MIN_SIZE = 4;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "start_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), MIN_SIZE, std::begin(start_line));
        } else if (cond.name() == "violate_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), MIN_SIZE, std::begin(violate_line));
        } else if (cond.name() == "stop_line"){
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(stop_line));
        }
    }
    plate_available_box_percent = cfg.plate_available_box_percent();
    enable_output_picture = cfg.enable_output_picture();
    enable_save_picture = cfg.enable_save_debug_picture();
    return true;
}

//
// ViolationDawanxiaozhuan
//
class ViolationDawanxiaozhuan : public ViolationBase
{
public:
    ViolationDawanxiaozhuan(int object_id, const std::string& id, const ViolationDawanxiaozhuanConfig& cfg);
    virtual ~ViolationDawanxiaozhuan()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);

protected:
    enum STATUS{
        eUNDEFINE,
        eENTER_VIEW,
        eCROSS_VIOLATE,
        eCROSS_ENDLINE,
        eEND,
    };

protected:
    ViolationDawanxiaozhuanConfig   cfg_;
    STATUS                          status_;
};

ViolationDawanxiaozhuan::ViolationDawanxiaozhuan(int object_id, const std::string& violation_id, const ViolationDawanxiaozhuanConfig& cfg)
    : ViolationBase(object_id, violation_id, cfg.violation_cfg)
    , cfg_(cfg)
    , status_(eUNDEFINE)
{
}

result_list_t ViolationDawanxiaozhuan::check(BoxF& box, const ImageObjectsInfo& objs)
{
    const BoxF& revised_box = (box.label == OBJECT_TYPE_VEHICLE && helperIsLargeVehicle((Attribute::VehicleType)box.attr_type.type)) ?
                                BoxF(box.xmin, (box.ymin+box.ymax)/2, box.xmax, box.ymax) : box;
    result_list_t retv;
    switch (status_)
    {
    case eUNDEFINE:
        if (valid_box_in_range(box, objs.sframe->width(), objs.sframe->height(), cfg_.plate_available_box_percent) &&
             valid_box_across_lines(revised_box, &cfg_.start_line[0], 0.75f)){
            status_ = eENTER_VIEW;
            this->add_snapshot(box, objs);
            LOG(INFO)<<"==>enter view, "<<violation_id_<<","<<object_id_;
        }
        break;
    case eENTER_VIEW:
        if ((box.attr_direction.type == Attribute::Vehicle_Front && 
                valid_box_across_lines_v1(revised_box, cfg_.violate_line, 0.75f)) || 
            (box.attr_direction.type != Attribute::Vehicle_Front &&
                valid_box_across_lines_v2(revised_box, cfg_.violate_line, 0.75f))) {
            status_ = eCROSS_VIOLATE;
            this->add_snapshot(box, objs);
            LOG(INFO)<<"==>cross violate line, "<<violation_id_<<","<<object_id_;
        }
        break;
    case eCROSS_VIOLATE:
        for(int i=0;i<cfg_.stop_line.size();i+=4){
            if (valid_box_across_lines(revised_box, &cfg_.stop_line[i], 0.75f)){
                status_ = eCROSS_ENDLINE;
                this->add_snapshot(box, objs);
                LOG(INFO)<<"==>cross end line, "<<violation_id_<<","<<object_id_;
                retv = get_results();
            }
        }
        break;
    case eCROSS_ENDLINE:
    case eEND:
    default:
        break;
    }
    static int colors[]={0,0,2,3,2};
    if (status_ != eUNDEFINE) {
        box.violate_state = colors[status_];
    }
    return retv;
}

//
// ViolationDawanxiaozhuanFactory
//
ViolationDawanxiaozhuanFactory::ViolationDawanxiaozhuanFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(cfg)
{
}

const std::string& ViolationDawanxiaozhuanFactory::id()const
{
    return id_;
}

spIViolation ViolationDawanxiaozhuanFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == OBJECT_TYPE_VEHICLE){
        return std::make_shared<ViolationDawanxiaozhuan>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }
}

//REGISTER_VIOLATION(DAWANXIAOZHUAN_CODE, Dawanxiaozhuan);

} // namespace FLOW
