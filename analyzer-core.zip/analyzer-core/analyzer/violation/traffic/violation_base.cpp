#include "violation_base.hpp"

#include <fstream>
#include <sys/stat.h>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"
#include "common/make_traffic_light_more_red.hpp"

#include "core/alg_engine/alg_engine_interface.hpp"

#include "serving/violation_event.pb.h"

#include "algorithm/plate/vehicle_plate.hpp"
#include "algorithm/vehicleattribute/vehicle_attr.hpp"
#include "algorithm/vehicleattribute/behaviour_attr.hpp"
#include "algorithm/vehicleattribute/construct_attr.hpp"
#include "algorithm/traffic_light/traffic_light_recog.hpp"

namespace FLOW {

void cover_ratio_setter(const ViolationSnapshot& snapshots,const BoxF& box, inference::ObjectInfo* pb_obj);

int check_plate_number_same(const std::string& s1, const std::string& s2) {
    int pos1=s1.size()-1,pos2=s2.size()-1,retv=0;
    while (pos1 >=0 && pos2 >=0)   {retv+=(s1[pos1--]==s2[pos2--]);}
    return retv;
}

void ViolationBase::clear_all_img(inference::ViolationEvent* event) {
    if (event) {
        for( auto& snapshot : *event->mutable_snapshots() ) {
            if (snapshot.has_image()) snapshot.set_image("...");
        }
    }
}

ViolationBase::ViolationBase(const BoxF& box, const std::string& violation_id, const spViolationConfig& violation_cfg)
    : snapshots_()
    , object_id_(box.uid)
    , violation_id_(violation_id)
    , violation_cfg_(violation_cfg)
    , box_(box)
{
}

ViolationBase::ViolationBase(int object_id, const std::string& violation_id, const spViolationConfig& violation_cfg)
    : snapshots_()
    , object_id_(object_id)
    , violation_id_(violation_id)
    , violation_cfg_(violation_cfg)
{
}

ViolationBase::ViolationBase(const BoxF& box, const std::string& violation_id, const spMassiveflowViolationConfig& violation_cfg)
        : snapshots_()
        , object_id_(box.uid)
        , violation_id_(violation_id)
        , mf_violation_cfg_(violation_cfg)
        , box_(box)
{
}

ViolationBase::ViolationBase(int object_id, const std::string& violation_id, const spMassiveflowViolationConfig& violation_cfg)
        : snapshots_()
        , object_id_(object_id)
        , violation_id_(violation_id)
        , mf_violation_cfg_(violation_cfg)
{
}


const std::string& ViolationBase::id() const{
    return violation_id_;
}

bool ViolationBase::check_ptz(const ImageObjectsInfo& image) const {
    static const std::vector<float> EMPTY_DATA_VECTOR{-1,-1,-1};
    static const ::google::protobuf::RepeatedField< float > EMPTY_DATA(EMPTY_DATA_VECTOR.begin(), EMPTY_DATA_VECTOR.end());
    if(!violation_cfg_){
        return true;
    }
    if (violation_cfg_->ptz_pos_size() < 3 ||
        std::equal(EMPTY_DATA.begin(), EMPTY_DATA.end(), violation_cfg_->ptz_pos().begin())) {
        return true;
    }
    PosInfo ACQ_PTZ;
    ACQ_PTZ.angle_x = violation_cfg_->ptz_pos(0);
    ACQ_PTZ.angle_y = violation_cfg_->ptz_pos(1);
    ACQ_PTZ.scale = violation_cfg_->ptz_pos(2);
    const bool ok = Helper::is_same_postion(ACQ_PTZ, image.ptz_pos);
    return ok;
}

size_t ViolationBase::add_snapshot(const BoxF& box, const ImageObjectsInfo& objs){
    const auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
    ViolationSnapshot sn;
    sn.box = box; sn.image = std::make_shared<ImageObjectsInfo>(objs); sn.now = now;
    snapshots_.push_back(sn);
    return snapshots_.size();
}

size_t ViolationBase::add_snapshot(const int traffic_light_color, const BoxF& box, const ImageObjectsInfo& objs){
    const auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
    ViolationSnapshot sn;
    sn.box = box; sn.image = std::make_shared<ImageObjectsInfo>(objs); sn.now = now;
    sn.traffic_light_color_while_violate_ = traffic_light_color;
    snapshots_.push_back(sn);
    return snapshots_.size();
}

size_t ViolationBase::add_snapshot(const BoxF& box, const ImageObjectsInfo& objs, const int index){
    const auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
    if (snapshots_.size() < index + 1)
        snapshots_.resize(index+1);
    ViolationSnapshot sn;
    sn.box = box; sn.image = std::make_shared<ImageObjectsInfo>(objs); sn.now = now;
    snapshots_[index] = sn;
    return snapshots_.size();
}

void ViolationBase::clear_snapshot() {
    snapshots_.clear();
}

std::chrono::milliseconds ViolationBase::get_elapsed_time(const ImageObjectsInfo& frame, size_t since) const {
    if (snapshots_.empty()) {
        return std::chrono::milliseconds(0);
    }
    size_t last = snapshots_.size()-1;
    size_t index = since<0 ? last : std::min(since,last);
    if (violation_cfg_->enable_use_pts()){
        auto now = frame.pts;
        return std::chrono::milliseconds(now - snapshots_[index].image->pts);
    } else {
        auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
        return now - snapshots_[index].now;
    }
}

std::chrono::milliseconds ViolationBase::get_time_point(const ImageObjectsInfo& frame) const {
    if (violation_cfg_->enable_use_pts()){
        return std::chrono::milliseconds(frame.pts);
    } else {
        auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
        return std::chrono::milliseconds(now.time_since_epoch().count());
    }
}

const std::string& ViolationBase::get_event_type_form_code(const std::string& code) {
    static const std::string TadTypeVehicle      = "vehicle";
	static const std::string TadTypeNonMotor     = "nonmotor";
	static const std::string TadTypeConstruction = "construction";
	static const std::string TadTypeHighway      = "highway";
	static const std::string TadTypeTrafficRate  = "lltj";
	static const std::string TadTypeUNDEFINE     = "UNDEFINE";

    if (code.substr(0,2) == "21") {
        return TadTypeVehicle;
    } else if  (code.substr(0,2) == "22") {
        return TadTypeNonMotor;
    } else if  (code.substr(0,2) == "23") {
        return TadTypeConstruction;
    } else if  (code.substr(0,2) == "24") {
        return TadTypeHighway;
    } else if  (code.substr(0,2) == "27") {
        return TadTypeTrafficRate;
    } else if  (code.substr(0,2) == "28") {
        return TadTypeTrafficRate;
    } else if  (code.substr(0,2) == "29") {
        return TadTypeTrafficRate;
    }
    return TadTypeUNDEFINE;
}

result_list_t ViolationBase::get_results()const{
    result_list_t retv;
    const auto obj_id = object_id_;
    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = violation_cfg_->code();
    const auto violation_name = violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;
    const auto enable_output_picture = violation_cfg_->enable_output_picture();
    const auto enable_save_picture = violation_cfg_->enable_save_debug_picture();
    const auto enable_make_traffic_more_red = violation_cfg_->enable_make_light_more_red();
    std::vector<float> traffic_light_roi;
    for ( int i = 0; i < violation_cfg_->traffic_light_box().size(); ++i) {
        traffic_light_roi.push_back(violation_cfg_->traffic_light_box(i));
    }
    const auto violation = this->shared_from_this();
    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event_with_type = *retv;
        event_with_type.set_event_type(get_event_type_form_code(violation_code));
        inference::ViolationEvent& event = *(event_with_type.mutable_traffic_event());
        event.set_stream_id(stream_id);
        event.set_obj_id(obj_id);
        event.set_violation_id(violation_id);
        event.set_violation_code(violation_code);
        event.set_violation_name(violation_name);
        for(int i=0;i<snapshots.size();i++){
            auto& box = snapshots[i].box;
            auto& image = snapshots[i].image;
            auto& minor_boxes = snapshots[i].minor_boxes;
            auto snap1 = event.add_snapshots();
            snap1->set_pts(snapshots[i].image->pts);
            snap1->set_now(snapshots[i].now.time_since_epoch().count());
            snap1->set_revolve_status(image->jitter_status == 2);
            if(snapshots[i].traffic_light_color_while_violate_!=TrafficLight::kColorEmpty){
                snap1->set_traffic_light_status(TrafficLight::helperGetStringTrafficLightColor((TrafficLight::TrafficLightColor)snapshots[i].traffic_light_color_while_violate_));
            }
            if ( enable_make_traffic_more_red  && traffic_light_roi.size() >= 4) { 
                BoxF traffic_light_box;
                get_traffic_light_box_config(traffic_light_roi, &traffic_light_box);
                make_traffic_light_more_red(*(image->sframe->getMat()), traffic_light_box);
            }
            if (enable_output_picture && image->sframe != nullptr){
                snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
            }
            if (image->ntp_time_stamp > 0) {
               snap1->set_ntp_time_stamp(image->ntp_time_stamp);
            }
            for(const auto& box : minor_boxes) {
                auto obj = snap1->add_minor_objects();
                obj->set_id(box.uid);
                obj->set_type(std::to_string(box.label));
                obj->set_score(box.score);
                obj->add_box(box.xmin);
                obj->add_box(box.ymin);
                obj->add_box(box.xmax);
                obj->add_box(box.ymax);
            }
            if (snapshots[i].direction_angle_min_max.size() >=2) {
                snap1->set_direction_angle_min(snapshots[i].direction_angle_min_max[0]);
                snap1->set_direction_angle_max(snapshots[i].direction_angle_min_max[1]);
            }
            if (snapshots[i].image->ptz_pos.angle_x >= 0) {
                const auto& ptz_pos = snapshots[i].image->ptz_pos;
                snap1->add_ptz_pos(ptz_pos.angle_x);
                snap1->add_ptz_pos(ptz_pos.angle_y);
                snap1->add_ptz_pos(ptz_pos.scale);
            }
            if(box.uid == -1) {
                continue;
            }
            auto obj = snap1->add_objects();
            cover_ratio_setter(snapshots[i], box, obj);
            std::stringstream buff; buff<<box.label;
            obj->set_id(box.uid);
            obj->set_type(buff.str());
            obj->set_score(box.score);
            obj->add_box(box.xmin);
            obj->add_box(box.ymin);
            obj->add_box(box.xmax);
            obj->add_box(box.ymax);

            if (!image->sframe) {
                continue;
            }
            VecBoxF car_boxes({box});
            engine->ProcessByName("post", image->sframe, car_boxes);
            if (!car_boxes[0].plates.empty() && !car_boxes[0].plates[0].content.empty()) {
                const auto& palte_info = car_boxes[0].plates[0];
                auto plate = obj->mutable_plate();
                plate->set_number(palte_info.content);
                plate->set_score(palte_info.score);
                auto x_pair = std::minmax_element(palte_info.points.begin(),palte_info.points.end(),
                    [](const PlateInfo<float>::PointT& p1, const PlateInfo<float>::PointT& p2){
                        return p1.x < p2.x;
                    });
                auto y_pair = std::minmax_element(palte_info.points.begin(),palte_info.points.end(),
                    [](const PlateInfo<float>::PointT& p1, const PlateInfo<float>::PointT& p2){
                        return p1.y < p2.y;
                    });
                plate->add_box(x_pair.first->x);
                plate->add_box(y_pair.first->y);
                plate->add_box(x_pair.second->x);
                plate->add_box(y_pair.second->y);
                if (palte_info.label != -1) {
                    plate->set_plate_type(Plate::helperGetStringPlateType(palte_info.label));
                }
                std::copy(palte_info.score_by_character.begin(), palte_info.score_by_character.end(), 
                            google::protobuf::RepeatedFieldBackInserter(plate->mutable_score_by_character()));
            }

            if( car_boxes[0].attr_type.type != -1) {
                if (box.label == OBJECT_TYPE_VEHICLE){
                    obj->set_sub_type(Attribute::helperGetStringVehicleType(
                        (Attribute::VehicleType)car_boxes[0].attr_type.type));
                } else {
                    obj->set_sub_type(Attribute::helperGetStringWaimaiType(
                        (Attribute::WaimaiType)car_boxes[0].attr_type.type));
                }
                obj->set_sub_type_score(car_boxes[0].attr_type.score);
            }

            if (car_boxes[0].special_car_type.type != -1) {
                obj->set_special_car_type(Attribute::helperGetStringVehicleSpecialType(
                    (Attribute::VehicleSpecialType)car_boxes[0].special_car_type.type));
                obj->set_special_car_type_score(car_boxes[0].special_car_type.score);
            }

            if (car_boxes[0].traffic_person_type.type != -1) {
                obj->set_person_type(Attribute::helperGetStringConstructionCLSType(
                        (Attribute::ConstructionCLSType)car_boxes[0].traffic_person_type.type));
                obj->set_person_type_score(car_boxes[0].traffic_person_type.score);
            }

            if (car_boxes[0].attr_direction.type != -1) {
                obj->set_direction(Attribute::helperGetStringVehicleDirectionType(
                        (Attribute::VehicleDirectionType)car_boxes[0].attr_direction.type));
                obj->set_direction_score(car_boxes[0].attr_direction.score);
            }

            for_each(car_boxes[0].behaviour_types.begin(), car_boxes[0].behaviour_types.end(), [&](const Attr attr) {
                obj->add_nonmotor_behaviour(Attribute::helperGetStringNoMotorBehaviourType(
                        (Attribute::NoMotorBehaviourType)attr.type));
                obj->add_nonmotor_behaviour_score(attr.score);
            });

            if (car_boxes[0].nonmotor_type.type != -1) {
                obj->set_nonmotor_type(Attribute::helperGetStringNoMotorType(
                        (Attribute::NonMotorType)car_boxes[0].nonmotor_type.type));
                obj->set_nonmotor_type_score(car_boxes[0].nonmotor_type.score);
            }

            if (enable_save_picture){
                std::stringstream buff;
                buff <<stream_id <<"/pic_" << violation_id << "_" << obj_id <<"_" << i <<".jpg";
                auto fname = buff.str();
                std::ofstream of;
                mkdir(stream_id.c_str(),0755);
                of.open(fname);
                std::vector<unsigned char> im_data;
                cv::imencode(".jpg", *(image->sframe->getMat()), im_data);
                of.write((const char*)im_data.data(),im_data.size());
                LOG(INFO)<<"==>pic result "<<fname <<","<<of.is_open()<<","<<of.tellp();
                of.close();
            }
        }

        // status
        inference::TrafficStats stats;
        for(int i=0;i<snapshots.size();i++){
            if (snapshots[i].count != -1) {
                stats.set_count(snapshots[i].count);
                stats.set_avg_speed(snapshots[i].avgspeed);
            }
            if (snapshots[i].speed_standard_deviation != -1) {
                stats.set_speed_standard_deviation(snapshots[i].speed_standard_deviation);
            }
            if (snapshots[i].ratio != -1.0f){
                stats.set_cars_ratio(snapshots[i].ratio);
            }
            if (snapshots[i].time_interval != -1.0f) {
                stats.set_time_interval(snapshots[i].time_interval);
            }
            if (snapshots[i].distance_interval != -1.0f) {
                stats.set_distance_interval(snapshots[i].distance_interval);
            }
            if (snapshots[i].traffic_status != -1) {
                stats.set_traffic_status(snapshots[i].traffic_status);
            }
            if (snapshots[i].time_ratio != -1.0f) {
                stats.set_time_ratio(snapshots[i].time_ratio);
            }
            if (snapshots[i].space_ratio != -1.0f) {
                stats.set_space_ratio(snapshots[i].space_ratio);
            }
            if (snapshots[i].vehicle_queue != -1.0f) {
                stats.set_vehicle_queue(snapshots[i].vehicle_queue);
            }
            if (snapshots[i].cars_count_by_type.size()) {
                for(auto& kv : snapshots[i].cars_count_by_type) {
                    stats.add_cars_types(
                        Attribute::helperGetStringVehicleType((Attribute::VehicleType)kv.first)
                    );
                    stats.add_cars_counts(kv.second);
                }
            }
            // check has data
            if (stats.ByteSizeLong() > 0) {
                stats.set_now(snapshots[i].now.time_since_epoch().count());
                *(event.mutable_stats()) = stats;
                break;
            }
        }

        // set snapshotidx
        violation->snapshotidx_setter(event);

        // filter event
        if (violation->results_filter(event)) {
            std::string log_result_json;
            pb2json_option option;
            option.ignore_bytes = true;
            option.large_obj_array_limit = 5;
            pb2json_with_option(option, &event, &log_result_json);
            LOG(WARNING) <<"==>drop result,"<<stream_id<<","<<violation_id<<","<<log_result_json;
            return nullptr;
        }
        return retv;
    };
    retv.push_back(action);
    return retv;
}

void cover_ratio_setter(const ViolationSnapshot& snapshot,const BoxF& box, inference::ObjectInfo* pb_obj) {
    if (box.uid == -1) {
        return;
    }
    const auto& uid = box.uid;
    const auto& objs = snapshot.image->objects;
    auto current_obj_itr = std::find_if(objs.begin(), objs.end(), [uid](const BoxF& box){
        return box.uid == uid;
    });
    if (current_obj_itr == objs.end()) {
        return;
    }
    std::vector<double> cover_rates(objs.size());
    std::transform(objs.begin(), objs.end(), cover_rates.begin(), [current_obj_itr](const BoxF& box)->double{
        return current_obj_itr->uid == box.uid ? \
                0 : Boxes::Intersection(*current_obj_itr, box) / Boxes::Size(*current_obj_itr);
    });

    const auto max_cover_rate_itr = std::max_element(cover_rates.begin(), cover_rates.end());
    const auto index = std::distance(cover_rates.begin(), max_cover_rate_itr);
    const auto size_ratio = Boxes::Size(objs[index]) / Boxes::Size(box);

    if (*max_cover_rate_itr > 0.0f) {
        pb_obj->set_cover_ratio(*max_cover_rate_itr);
        pb_obj->set_cover_size_ratio(size_ratio);
    }
}

bool ViolationBase::results_filter(const inference::ViolationEvent& e) const{
    return false;
}

static int max_size_selecter(inference::ViolationEvent& e) {
    int retv=-1;
    float size=0.0f;
    for (int i=0; i<e.snapshots_size(); i++) {
        const auto& snapshot = e.snapshots(i);
        if (snapshot.objects_size()>0) {
            const auto&obj = snapshot.objects(0);
            if (obj.box_size() >= 4) {
                int box_size_tmp = std::abs((obj.box(0)-obj.box(2))*(obj.box(1)-obj.box(3)));
                if (box_size_tmp > size) {
                    size = box_size_tmp;
                    retv = i;
                }
            }
        }
    }
    return retv;
}

static int max_plate_size_selecter(inference::ViolationEvent& e) {
    int retv=-1;
    float size=0.0f;
    bool has_plate=false;
    for (int i=0; i<e.snapshots_size(); i++) {
        const auto& snapshot = e.snapshots(i);
        if (snapshot.objects_size()>0) {
            const auto&obj = snapshot.objects(0);
            if (obj.has_plate()) {
                has_plate = true;
                break;
            }
        }
    }
    if (! has_plate) {
        return max_size_selecter(e);
    }
    for (int i=0; i<e.snapshots_size(); i++) {
        const auto& snapshot = e.snapshots(i);
        if (snapshot.objects_size()>0) {
            const auto&obj = snapshot.objects(0);
            if (obj.has_plate() && obj.plate().box_size() >= 4) {
                int box_size_tmp = std::abs((obj.plate().box(0)-obj.plate().box(2))*(obj.plate().box(1)-obj.plate().box(3)));
                if (box_size_tmp > size) {
                    size = box_size_tmp;
                    retv = i;
                }
            }
        }
    }
    return retv;
}

static int max_plate_score_selecter(inference::ViolationEvent& e) {
    int retv=-1;
    float score=0.0f;
    bool has_plate=false;
    for (int i=0; i<e.snapshots_size(); i++) {
        const auto& snapshot = e.snapshots(i);
        if (snapshot.objects_size()>0) {
            const auto&obj = snapshot.objects(0);
            if (obj.has_plate()) {
                has_plate = true;
                break;
            }
        }
    }
    if (! has_plate) {
        return max_size_selecter(e);
    }
    for (int i=0; i<e.snapshots_size(); i++) {
        const auto& snapshot = e.snapshots(i);
        if (snapshot.objects_size()>0) {
            const auto&obj = snapshot.objects(0);
            if (obj.has_plate() && obj.plate().score() > score) {
                score = obj.plate().score();
                retv = i;
            }
        }
    }
    return retv;
}

void ViolationBase::snapshotidx_setter(inference::ViolationEvent& e)const {
    e.clear_snapshotidx();
    std::function<int(inference::ViolationEvent&)> selecter = max_plate_score_selecter;
    if (violation_cfg_->has_snapshot_selecter()) {
        if (violation_cfg_->snapshot_selecter() == "max_size") {
            selecter = max_size_selecter;
        } else if (violation_cfg_->snapshot_selecter() == "max_plate_size") {
            selecter = max_plate_size_selecter;
        } else if (violation_cfg_->snapshot_selecter() == "max_plate_score") {
            selecter = max_plate_score_selecter;
        } else {
            LOG(WARNING) <<"snapshot_selecter not found, "<<violation_id_<<","<< violation_cfg_->snapshot_selecter();
        }
    }
    auto index = selecter(e);
    if (index >=0 ) {
        e.set_snapshotidx(index);
    }
}
} // namespace FLOW
