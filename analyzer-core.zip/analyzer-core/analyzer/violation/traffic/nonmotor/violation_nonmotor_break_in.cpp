
#include <iterator>
#include <unordered_map>
#include <algorithm>
#include <set>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "violation_nonmotor_break_in.hpp"
#include "violation/violation_util.hpp"
#include "violation/traffic/violation_base.hpp"
#include "algorithm/vehicleattribute/construct_attr.hpp"
#include "algorithm/vehicleattribute/behaviour_attr.hpp"

namespace FLOW {

static const std::string PERSON_BREAKIN_NAME("xingrenchuangru");
static const std::string PERSON_BREAKIN_CODE("2234");
static const std::string NON_MOTOR_BREAKIN_NAME("feijidongchechuangru");
static const std::string NON_MOTOR_BREAKIN_CODE("2236");

// 通用模版
static const std::string PERSON_BREAKIN_PATTERN("^2234[0-9]{2}$");
static const std::string NON_MOTOR_BREAKIN_PATTERN("^2236[0-9]{2}$");

inline bool person_box_not_in(const BoxF& box, const VecBoxF& vec_boxs, const float iou_threthod) {
  const float box_area = Boxes::Size(box);
  const auto itr = std::find_if(vec_boxs.begin(), vec_boxs.end(), [&](const BoxF& filter_box){
      return (Boxes::Intersection(box, filter_box)/box_area >= iou_threthod);
  });
  return itr == vec_boxs.end();
}

// ViolationNonmotorBreakInConfig
class ViolationNonmotorBreakInConfig {
public:
    ViolationNonmotorBreakInConfig(const std::string& json)
        : person_number_thresh_(1)
        , cooling_second_(60)
        , threshold_(0)
        , parking_second_(0)
        , max_cover_ratio_(1.0f)
    {
        auto result = this->ParseJson(json);
        CHECK(result);
    }
    bool ParseJson(const std::string& json) {
        std::string err;
        auto violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;
        name_ = cfg.name();
        code_ = cfg.code();
        cooling_second_ = cfg.has_cooling_second() ? cfg.cooling_second() : cooling_second_;
        const int MIN_SIZE = 2*3;
        for (int i=0; i<cfg.conditions_size(); i++) {
            const auto& cond = cfg.conditions(i);
            if (cond.name() == "violate_box"){
                CHECK_GE(cond.data_size(), MIN_SIZE);
                std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box_));
                if (cond.has_person_count()) {
                    person_number_thresh_ = cond.person_count();
                }
                if (cond.has_threshold()) {
                    threshold_ = cond.threshold();
                }
                if (cond.has_parking_second()) {
                    parking_second_ = cond.parking_second();
                }
                if (cond.has_cover_ratio()) {
                    max_cover_ratio_ = cond.cover_ratio();
                }
            }
            if (cond.person_type_size() > 0) {
                std::copy(cond.person_type().begin(),
                        cond.person_type().end(),
                        std::inserter(person_type_withe_list_, person_type_withe_list_.end()));
            }
            if (cond.nonmotor_type_size() > 0) {
                std::copy(cond.nonmotor_type().begin(),
                        cond.nonmotor_type().end(),
                        std::inserter(nonmotor_type_withe_list_, nonmotor_type_withe_list_.end()));
            }
        }
        data_ = violation_cfg;
        return true;
    }
    bool MatchPersonType(Attribute::ConstructionCLSType type) {
        return person_type_withe_list_.empty() ||
            person_type_withe_list_.count(Attribute::helperGetStringConstructionCLSType(type));
    }
    bool MatchNonmotorType(Attribute::NonMotorType type) {
        return nonmotor_type_withe_list_.empty() ||
            nonmotor_type_withe_list_.count(Attribute::helperGetStringNoMotorType(type));
    }
public:
  std::shared_ptr<inference::ViolationConfig> data_;
  std::string                                 code_;
  std::string                                 name_;
  bool                                        enable_output_picture_;
  std::vector<float>                          violate_box_;
  int                                         person_number_thresh_;
  int                                         cooling_second_;
  float                                       threshold_;
  int                                         parking_second_;
  float                                       max_cover_ratio_;
  std::set<std::string>                       person_type_withe_list_;
  std::set<std::string>                       nonmotor_type_withe_list_;
};

// ViolationNonmotorBreakIn
class ViolationNonmotorBreakIn : public ViolationBase
{
public:
    ViolationNonmotorBreakIn(int object_id, const std::string& violation_id, const spViolationNonmotorBreakInConfig& cfg);
    virtual ~ViolationNonmotorBreakIn() = default;

public:
    virtual result_list_t check(BoxF&, const ImageObjectsInfo&);

protected:
    typedef std::chrono::milliseconds milliseconds;
    typedef milliseconds offset_time_point;
    void update_alive_box(const ImageObjectsInfo& objs) {
        auto now = this->get_time_point(objs);
        for (auto box : objs.objects) {
            if (box.uid == -1) {
                continue;
            }
            if (box.delete_flag) {
                alive_box_.erase(box.uid);
                continue;
            }
            if (alive_box_.count(box.uid) == 0) {
                alive_box_[box.uid] = now;
            }
        }
    }
    milliseconds alive_time(const BoxF& box, const offset_time_point& current) {
        if (alive_box_.count(box.uid) == 0) {
            return milliseconds(0);
        }
        auto start = alive_box_[box.uid];
        return current - start;
    }

protected:
    spViolationNonmotorBreakInConfig    cfg_;
    const int                           violation_box_type_;
    std::map<int, offset_time_point>    alive_box_;
};

ViolationNonmotorBreakIn::ViolationNonmotorBreakIn(int object_id, const std::string& violation_id, const spViolationNonmotorBreakInConfig& cfg)
    : ViolationBase(object_id, violation_id, cfg->data_)
    , cfg_(cfg)
    , violation_box_type_((cfg->code_.substr(0,PERSON_BREAKIN_CODE.size()) == PERSON_BREAKIN_CODE) ? OBJECT_TYPE_PERSON : OBJECT_TYPE_NONMOTOR)
{
}

result_list_t ViolationNonmotorBreakIn::check(BoxF& box, const ImageObjectsInfo& objs)
{
    update_alive_box(objs);
    result_list_t retv;
    // check objs
    if (! snapshots_.empty() && this->get_elapsed_time(objs).count() < cfg_->cooling_second_*1000){
        snapshots_.back().image = CloneWithoutImage(this->snapshots_.back().image);
        box.violate_state = 2;
        return retv;
    }

    auto current = this->get_time_point(objs);
    VecBoxF inBoxes;
    if (violation_box_type_ == ObjectType::OBJECT_TYPE_PERSON) {
        VecBoxF not_person_boxes;
        std::copy_if(objs.objects.begin(), objs.objects.end(),
                        std::back_inserter(not_person_boxes), [&](const BoxF& one){
            return one.label != ObjectType::OBJECT_TYPE_PERSON;
        });
        std::copy_if(objs.objects.begin(), objs.objects.end(),
                        std::back_inserter(inBoxes), [&](const BoxF& one){
            return one.label == ObjectType::OBJECT_TYPE_PERSON &&
                    one.score >= cfg_->threshold_ &&
                    cfg_->MatchPersonType(Attribute::ConstructionCLSType(one.traffic_person_type.type)) &&
                    alive_time(one, current).count() >= cfg_->parking_second_*1000 &&
                    valid_box_center_in_polygon(one, cfg_->violate_box_.data(), cfg_->violate_box_.size()) &&
                    person_box_not_in(one, not_person_boxes, cfg_->max_cover_ratio_);
        });
    } else if (violation_box_type_ == ObjectType::OBJECT_TYPE_NONMOTOR) {
        std::copy_if(objs.objects.begin(), objs.objects.end(),
                        std::back_inserter(inBoxes), [&](const BoxF& one){
            return one.label == ObjectType::OBJECT_TYPE_NONMOTOR &&
                    one.score >= cfg_->threshold_ &&
                    cfg_->MatchNonmotorType(Attribute::NonMotorType(one.traffic_person_type.type)) &&
                    alive_time(one, current).count() >= cfg_->parking_second_*1000 &&
                    valid_box_center_in_polygon(one, cfg_->violate_box_.data(), cfg_->violate_box_.size());
        });
    }
    
    if (inBoxes.size() >= cfg_->person_number_thresh_) {
        auto first_box = inBoxes.empty() ? box : inBoxes.front();
        this->clear_snapshot();
        this->add_snapshot(first_box, objs);
        this->snapshots_.back().image->objects = inBoxes;
        return get_results();
    }

    return retv;
}

// ViolationNonmotorBreakInFactory
ViolationNonmotorBreakInFactory::ViolationNonmotorBreakInFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(std::make_shared<ViolationNonmotorBreakInConfig>(cfg))
{
}

const std::string& ViolationNonmotorBreakInFactory::id()const
{
    return id_;
}

spIViolation ViolationNonmotorBreakInFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationNonmotorBreakIn>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(PERSON_BREAKIN_CODE, NonmotorBreakIn);
REGISTER_VIOLATION_PATTERN(PERSON_BREAKIN_PATTERN, NonmotorBreakIn);

REGISTER_VIOLATION(NON_MOTOR_BREAKIN_CODE, NonmotorBreakIn);
REGISTER_VIOLATION_PATTERN(NON_MOTOR_BREAKIN_PATTERN, NonmotorBreakIn);

} // namespace FLOW
