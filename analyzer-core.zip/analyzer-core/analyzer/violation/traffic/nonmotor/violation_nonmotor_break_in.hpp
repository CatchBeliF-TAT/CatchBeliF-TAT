#ifndef VSS_VIOLATION_BREAK_IN_HPP
#define VSS_VIOLATION_BREAK_IN_HPP

#include <vector>
#include <memory>

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

class ViolationNonmotorBreakInConfig;
typedef std::shared_ptr<ViolationNonmotorBreakInConfig> spViolationNonmotorBreakInConfig;

class ViolationNonmotorBreakInFactory : public ViolationCommonFactory 
 {
public:
    ViolationNonmotorBreakInFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationNonmotorBreakInFactory()=default;

public:
    virtual const std::string& id()const;
    virtual spIViolation CreateIViolation(const BoxF& obj);

protected:
    std::string                 id_;
    spViolationNonmotorBreakInConfig    cfg_;
 };

} // namespace FLOW
#endif // VSS_VIOLATION_BREAK_IN_HPP
