#ifndef VSS_VIOLATION_NONMOTOR_YUEXIANTINGCHE_HPP
#define VSS_VIOLATION_NONMOTOR_YUEXIANTINGCHE_HPP

#include "violation/traffic/violation_common.hpp"

namespace FLOW {

    class ViolationNonmotorYuexiantingcheConfig;
    typedef std::shared_ptr<ViolationNonmotorYuexiantingcheConfig> spViolationNonmotorYuexiantingcheConfig;

    class ViolationNonmotorYuexiantingcheFactory : public ViolationCommonFactory
    {
    public:
        ViolationNonmotorYuexiantingcheFactory(const std::string& id, const std::string& cfg);
        virtual ~ViolationNonmotorYuexiantingcheFactory()=default;

    public:
        virtual const std::string&      id()const;
        virtual spIViolation            CreateIViolation(const BoxF& obj);

    protected:
        std::string                                 id_;
        spViolationNonmotorYuexiantingcheConfig     cfg_;
    };

} // namespace FLOW
#endif // VSS_VIOLATION_NONMOTOR_YUEXIANTINGCHE_HPP
