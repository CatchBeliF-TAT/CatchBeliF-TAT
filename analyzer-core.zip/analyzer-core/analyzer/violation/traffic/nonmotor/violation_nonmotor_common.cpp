#include <iostream>

#include "algorithm/vehicleattribute/behaviour_attr.hpp"
#include "violation_nonmotor_common.hpp"
#include "violation/violation_registry.hpp"

namespace FLOW {

    static const std::string CHUANGHONGDENG_CODE("2201");
    static const std::string NINING_CODE("2202");
    static const std::string ZHANYONGJIDONGCHEDAO_CODE("2204");
    static const std::string HENGDAOXIANQIXING_CODE("2205");
    static const std::string WEIFANJINLINGBIAOZHI_CODE("2206");
    static const std::string BUDAITOUKUI_CODE("2209");
    static const std::string FEIJIDONGCHEZAIREN_CODE("2210");
    static const std::string PERSON_BREAKIN_NAME_V3("xingrenchuangru_v3");
    static const std::string PERSON_BREAKIN_CODE_V3("2499");
    static const std::string PERSON_CHUANGHONGDENG("2230");

    static const std::string MOTOR_CHUANGJINLING_CODE("2221");
    static const std::string MOTOR_NIXING_CODE("2222");
    static const std::string MOTOR_WEIDAITOUKUI_CODE("2223");
    static const std::string MOTOR_ZANYONGFEIJIDONGCHEDAO_CODE("2224");
    static const std::string MOTOR_ZANYONGREXINGDAO_CODE("2225");
    static const std::string MOTOR_CHUANGHONGDENG_CODE("2226");
    static const std::string MOTOR_ZHUAPAI_CODE("2228");

    static const std::string TRICYCLE_ZHUAPAI_CODE("2211");

    static const std::string NONMOTOR_TRAFFIC_INFO_PATTERN("^28[0-9]{2}$");
    static const std::string PERSION_TRAFFIC_INFO_PATTERN("^29[0-9]{2}$");

    ViolationNonmotorCommonFactory::ViolationNonmotorCommonFactory(
            const std::string& violation_id, const std::string& cfg)
            : ViolationCommonFactory(violation_id, cfg) {

    }

    spIViolation ViolationNonmotorCommonFactory::CreateIViolation(const BoxF& obj)
    {
        if (obj.label == OBJECT_TYPE_NONMOTOR)
            return ViolationCommonFactory::CreateIViolation(obj);
        else
            return nullptr;
    }

    ViolationPersonCommonFactory::ViolationPersonCommonFactory(
            const std::string& violation_id, const std::string& cfg)
            : ViolationCommonFactory(violation_id, cfg) {

    }

    spIViolation ViolationPersonCommonFactory::CreateIViolation(const BoxF& obj)
    {
        if (obj.label == OBJECT_TYPE_PERSON)
            return ViolationCommonFactory::CreateIViolation(obj);
        else
            return nullptr;
    }

    ViolationMotorCommonFactory::ViolationMotorCommonFactory(
            const std::string& violation_id, const std::string& cfg)
            : ViolationCommonFactory(violation_id, cfg) {

    }

    // only add, no use
    spIViolation ViolationMotorCommonFactory::CreateIViolation(const BoxF& obj)
    {
        if (obj.label == OBJECT_TYPE_NONMOTOR &&
            obj.nonmotor_type.type == Attribute::NonMotorType::NonMotor_Motor)
            return ViolationCommonFactory::CreateIViolation(obj);
        else
            return nullptr;
    }

    ViolationTricycleCommonFactory::ViolationTricycleCommonFactory(
            const std::string& violation_id, const std::string& cfg)
            : ViolationCommonFactory(violation_id, cfg) {

    }

    spIViolation ViolationTricycleCommonFactory::CreateIViolation(const BoxF& obj)
    {
        if (obj.label == OBJECT_TYPE_TRICYCLE)
            return ViolationCommonFactory::CreateIViolation(obj);
        else
            return nullptr;
    }

    REGISTER_VIOLATION(CHUANGHONGDENG_CODE, NonmotorCommon);
    REGISTER_VIOLATION(NINING_CODE, NonmotorCommon);
    REGISTER_VIOLATION(ZHANYONGJIDONGCHEDAO_CODE, NonmotorCommon);
    REGISTER_VIOLATION(HENGDAOXIANQIXING_CODE, NonmotorCommon);
    REGISTER_VIOLATION(WEIFANJINLINGBIAOZHI_CODE, NonmotorCommon);
    REGISTER_VIOLATION(BUDAITOUKUI_CODE, NonmotorCommon);
    REGISTER_VIOLATION(FEIJIDONGCHEZAIREN_CODE, NonmotorCommon);
    REGISTER_VIOLATION(PERSON_BREAKIN_CODE_V3, PersonCommon);
    REGISTER_VIOLATION_PATTERN(PERSON_CHUANGHONGDENG, PersonCommon);

    REGISTER_VIOLATION(MOTOR_CHUANGJINLING_CODE,            NonmotorCommon);
    REGISTER_VIOLATION(MOTOR_NIXING_CODE,                   NonmotorCommon);
    REGISTER_VIOLATION(MOTOR_WEIDAITOUKUI_CODE,             NonmotorCommon);
    REGISTER_VIOLATION(MOTOR_ZANYONGFEIJIDONGCHEDAO_CODE,   NonmotorCommon);
    REGISTER_VIOLATION(MOTOR_ZANYONGREXINGDAO_CODE,         NonmotorCommon);
    REGISTER_VIOLATION(MOTOR_CHUANGHONGDENG_CODE,           NonmotorCommon);
    REGISTER_VIOLATION(MOTOR_ZHUAPAI_CODE,                  NonmotorCommon);

    // tricycle
    REGISTER_VIOLATION(TRICYCLE_ZHUAPAI_CODE,               TricycleCommon);

    REGISTER_VIOLATION_PATTERN(NONMOTOR_TRAFFIC_INFO_PATTERN, NonmotorCommon);
    REGISTER_VIOLATION_PATTERN(PERSION_TRAFFIC_INFO_PATTERN, PersonCommon);
}
