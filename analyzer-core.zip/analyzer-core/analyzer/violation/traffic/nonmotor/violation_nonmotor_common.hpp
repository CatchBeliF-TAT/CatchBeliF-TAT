#ifndef TAD_VIOLATION_NIXING_HPP
#define TAD_VIOLATION_NIXING_HPP

#include "violation/traffic/violation_common.hpp"

namespace FLOW {
    class ViolationNonmotorCommonFactory : public ViolationCommonFactory {
    public:
        ViolationNonmotorCommonFactory(const std::string& violation_id, const std::string& cfg);
        virtual ~ViolationNonmotorCommonFactory()=default;

    public:
        spIViolation CreateIViolation(const BoxF& obj);
    };

    class ViolationPersonCommonFactory : public ViolationCommonFactory {
    public:
        ViolationPersonCommonFactory(const std::string& violation_id, const std::string& cfg);
        virtual ~ViolationPersonCommonFactory()=default;

    public:
        spIViolation CreateIViolation(const BoxF& obj);
    };

    class ViolationMotorCommonFactory : public ViolationCommonFactory {
    public:
        ViolationMotorCommonFactory(const std::string& violation_id, const std::string& cfg);
        virtual ~ViolationMotorCommonFactory()=default;

    public:
        spIViolation CreateIViolation(const BoxF& obj);
    };

    class ViolationTricycleCommonFactory : public ViolationCommonFactory {
    public:
        ViolationTricycleCommonFactory(const std::string& violation_id, const std::string& cfg);
        virtual ~ViolationTricycleCommonFactory()=default;

    public:
        spIViolation CreateIViolation(const BoxF& obj);
    };
}

#endif //TAD_VIOLATION_NIXING_HPP
