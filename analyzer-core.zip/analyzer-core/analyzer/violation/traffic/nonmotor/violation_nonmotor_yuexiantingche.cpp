
#include <iterator>
#include <vector>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "violation_nonmotor_yuexiantingche.hpp"

#include "algorithm/traffic_light/traffic_light_recog.hpp"
#include "serving/violation_config.pb.h"
#include "violation/traffic/violation_base.hpp"
#include "violation/conditions/nonmotor_type_condition.hpp"
#include "violation/violation_util.hpp"

namespace FLOW {

    static const std::string FJDC_YXTC_NAME("FJDC_yuexiantingche");
    static const std::string FJDC_YXTC_CODE("2208");
    static const std::string FJDC_MOTOR_YXTC_NAME("FJDC_motor_yuexiantingche");
    static const std::string FJDC_MOTOR_YXTC_CODE("2227");

//
// ViolationNonmotorYuexiantingcheConfig
//
    class ViolationNonmotorYuexiantingcheConfig {
    public:
        ViolationNonmotorYuexiantingcheConfig(const std::string& json)
                : violate_box()
                , parking_second(10)
                , max_move_percent(0.1)
        {
            auto result=this->ParseJson(json);
            CHECK(result);
        }
        bool ParseJson(const std::string& json);
    public:
        typedef     std::function<bool(const inference::ViolationEvent& e)> fn_filter_action;
        typedef     struct {int index; fn_filter_action fun;} filter_action;
        typedef     std::vector<float> VecFloat;
        VecFloat    start_line;
        VecFloat    violate_box;
        int         parking_second;
        float       max_move_percent;
        std::shared_ptr<filter_action> nonmotor_type_condition_;
        spViolationConfig  violation_cfg;
    };

    bool ViolationNonmotorYuexiantingcheConfig::ParseJson(const std::string& json) {
        std::string err;
        violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(json, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< json;
            return false;
        }
        auto& cfg = *violation_cfg;
        const int MIN_SIZE = 2*3;
        for (int i=0; i<cfg.conditions_size(); i++) {
            const auto& cond = cfg.conditions(i);
            if (cond.name() == "start_line"){
                CHECK_GE(cond.data_size(), 4);
                std::copy_n(cond.data().begin(), cond.data_size()/4*4, std::back_inserter(start_line));
            }
            if (cond.name() == "violate_box"){
                CHECK_GE(cond.data_size(), MIN_SIZE);
                std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box));
                if (cond.has_parking_second()) {
                    parking_second = cond.parking_second();
                }
            }
        }
        nonmotor_type_condition_ = std::make_shared<filter_action>();
        nonmotor_type_condition_->fun = CreateNonmotorTypeCondition(violation_cfg.get());
        return true;
    }
//
// ViolationNonmotorYuexiantingche
//
    class ViolationNonmotorYuexiantingche : public ViolationBase
    {
    public:
        ViolationNonmotorYuexiantingche(int object_id, const std::string& violation_id, const spViolationNonmotorYuexiantingcheConfig cfg);
        virtual ~ViolationNonmotorYuexiantingche()=default;

    public:
        virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
        virtual bool results_filter(const inference::ViolationEvent& e)const;

    protected:
        enum STATUS{
            eUNDEFINE,
            eENTER_VIEW,
            eENTER_AREA,
            eEND,
        };

    protected:
        const spViolationNonmotorYuexiantingcheConfig     cfg_;
        STATUS                                            status_;
    };

    ViolationNonmotorYuexiantingche::ViolationNonmotorYuexiantingche(int object_id, const std::string& violation_id, const spViolationNonmotorYuexiantingcheConfig cfg)
            : ViolationBase(object_id, violation_id, cfg->violation_cfg)
            , cfg_(cfg)
            , status_(eUNDEFINE)
    {
    }

    result_list_t ViolationNonmotorYuexiantingche::check(BoxF& box, const ImageObjectsInfo& objs)
    {
        result_list_t retv;
        auto i = objs.tlc.find(violation_id_);
        auto color = TrafficLight::kColorEmpty;
        if(i!=objs.tlc.end()){
            color = i->second.color;
        }
        switch (status_)
        {
            case eUNDEFINE:
                if (color == TrafficLight::kColorRed &&
                    valid_box_in_range(box, objs.sframe->width(), objs.sframe->height(), cfg_->violation_cfg->plate_available_box_percent()) &&
                    valid_box_across_lines(box, cfg_->start_line.data(), 0.75f)){
                    status_ = eENTER_VIEW;
                    this->add_snapshot(box, objs);
                    LOG(INFO)<<"==>enter view, "<<violation_id_<<","<<object_id_;
                }
                break;
            case eENTER_VIEW:
                if (color != TrafficLight::kColorRed){
                    // nop
                } else if ( valid_box_center_in_polygon(box, cfg_->violate_box.data(), cfg_->violate_box.size()) ){
                    status_ = eENTER_AREA;
                    this->add_snapshot(box, objs);
                    LOG(INFO)<<"==>stage one ready, "<<violation_id_<<","<<object_id_;
                }
                break;
            case eENTER_AREA:
                if (color != TrafficLight::kColorRed){
                    // nop
                } else if (valid_box_box_distance(box, snapshots_.back().box, cfg_->max_move_percent)){
                    if ( valid_box_center_in_polygon(box, cfg_->violate_box.data(), cfg_->violate_box.size()) &&
                         this->get_elapsed_time(objs) >= std::chrono::milliseconds(cfg_->parking_second*1000*10/10) ) {
                        this->add_snapshot(box, objs);
                        LOG(INFO)<<"==>stage two ready, "<<violation_id_<<","<<object_id_;
                        retv =  get_results();
                        status_ = eEND;
                        this->clear_snapshot();
                    }
                } else {
                    // update
                    this->add_snapshot(box, objs, 1);
                }
                break;
            case eEND:
            default:
                break;
        }

        static int colors[]={0,0,2,3};
        if (status_ != eUNDEFINE) {
            box.violate_state = colors[status_];
        }
        return retv;
    }

    bool ViolationNonmotorYuexiantingche::results_filter(const inference::ViolationEvent& e) const {
        if (ViolationBase::results_filter(e)) {
            return true;
        }
        if (! cfg_->nonmotor_type_condition_->fun(e) ) {
            LOG(INFO) << "==>match filter: " << "nonmotor_type" << ", "
                    << e.stream_id() << "," 
                    << e.violation_id() << ","
                    << e.obj_id()<< ","
                    << e.violation_code();
            return true;
        }
        return false;
    }
//
// ViolationNonmotorYuexiantingcheFactory
//
    ViolationNonmotorYuexiantingcheFactory::ViolationNonmotorYuexiantingcheFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationNonmotorYuexiantingcheConfig>(cfg))
    {
    }

    const std::string& ViolationNonmotorYuexiantingcheFactory::id()const {
        return id_;
    }

    spIViolation ViolationNonmotorYuexiantingcheFactory::CreateIViolation(const BoxF& obj){
        if (obj.label == OBJECT_TYPE_NONMOTOR){
            return std::make_shared<ViolationNonmotorYuexiantingche>(obj.uid, id_, cfg_);
        } else {
            return nullptr;
        }
    }

    class ViolationNonmotorMotorYuexiantingcheFactory : public ViolationCommonFactory
    {
    public:
        ViolationNonmotorMotorYuexiantingcheFactory(const std::string& id, const std::string& cfg)
            : ViolationCommonFactory(id, cfg)
            , id_(id)
            , cfg_(std::make_shared<ViolationNonmotorYuexiantingcheConfig>(cfg))
        {
        }
        virtual ~ViolationNonmotorMotorYuexiantingcheFactory()=default;

    public:
        virtual const std::string& id() const { 
            return id_;
        }
        virtual spIViolation CreateIViolation(const BoxF& obj) {
            if (obj.label == OBJECT_TYPE_NONMOTOR){
                return std::make_shared<ViolationNonmotorYuexiantingche>(obj.uid, id_, cfg_);
            } else {
                return nullptr;
            }
        }

    protected:
        std::string                                 id_;
        spViolationNonmotorYuexiantingcheConfig     cfg_;
    };

    REGISTER_VIOLATION(FJDC_YXTC_CODE, NonmotorYuexiantingche);
    REGISTER_VIOLATION(FJDC_MOTOR_YXTC_CODE, NonmotorMotorYuexiantingche);

} // namespace FLOW
