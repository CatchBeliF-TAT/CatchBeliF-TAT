#include "violation_common.hpp"

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "core/alg_engine/helper.hpp"
#include "serving/violation_event.pb.h"
#include "serving/violation_config.pb.h"

#include "violation/violation_util.hpp"
#include "violation/conditions/line_condition.hpp"
#include "violation/conditions/polygon_condition.hpp"
#include "violation/conditions/time_condition.hpp"
#include "violation/conditions/plate_condition.hpp"
#include "violation/conditions/behaviour_condition.hpp"
#include "violation/conditions/nonmotor_type_condition.hpp"
#include "violation/conditions/sub_type_condition.hpp"
#include "violation/conditions/direction_condition.hpp"
#include "violation/conditions/special_car_type_condition.hpp"
#include "violation/conditions/person_type_condition.hpp"
#include "violation/conditions/angle_condition.hpp"
#include "violation/conditions/plate_type_condition.hpp"

namespace FLOW {

using namespace std;
//
// ViolationCommonConfig
//
class ViolationCommonConfig {
public:
    ViolationCommonConfig(const std::string& json, const std::string& violation_id);
    bool PraseJson(const std::string& json);
public:
    typedef std::function<bool(const BoxF&)> fn_pre_check_action;
    typedef std::function<bool(sys_milliseconds)> fn_filter_time;
    typedef struct {int index; fn_filter_time fun;} filter_time;
    typedef std::function<bool(const inference::ViolationEvent& e)> fn_filter_action;
    typedef struct {int index; fn_filter_action fun;} filter_action;
    typedef std::function<bool(const BoxF& last_box, const BoxF& current_box, const ImageObjectsInfo& objs)> fn_check_action;
    typedef std::function<bool(const BoxF& last_box, const BoxF& current_box, const ImageObjectsInfo& objs, spIConditionData& data)> fn_check_action_withdata;
    typedef struct {int index; fn_check_action fun;} check_action;
    typedef struct {int index; fn_check_action_withdata fun;} check_action_withdata;
    typedef std::vector<check_action>           check_action_vec;
    typedef std::vector<check_action_withdata>  check_action_withdata_vec;

    std::shared_ptr<fn_pre_check_action>        pre_condition_;
    std::shared_ptr<inference::ViolationConfig> data_;
    std::shared_ptr<filter_time>                time_condition_;
    std::shared_ptr<check_action_withdata_vec>  conditions_;
    std::shared_ptr<check_action_withdata_vec>  drop_conditions_;
    std::shared_ptr<filter_action>              plate_condition_;
    std::shared_ptr<filter_action>              nonmotor_type_condition_;
    std::shared_ptr<filter_action>              nonmotor_behaviour_condition_;
    std::shared_ptr<filter_action>              direction_condition_;
    std::shared_ptr<filter_action>              special_car_type_condition_;
    std::shared_ptr<filter_action>              sub_type_condition_;
    std::shared_ptr<filter_action>              person_type_condition_;
    std::shared_ptr<filter_action>              angle_condition_;
    std::shared_ptr<filter_action>              plate_type_condition_;
    std::string                                 err_;
};

ViolationCommonConfig::ViolationCommonConfig(const std::string& json, const std::string& violation_id)
{
    auto config_data = std::make_shared<inference::ViolationConfig>();
    json2pb(json, config_data.get(), &err_);
    LOG_IF(FATAL, !err_.empty()) << "err: " << err_
        << ", violation_id: " << violation_id
        << ", violation_cfg: " << json;
    data_ = config_data;

    bool has_traffic_light_box = data_->traffic_light_box_size();
    auto violation_code = data_->code();
    auto& conditions = *data_->mutable_conditions();
    auto& roi_data = data_->roi();

    BoxF box;
    parse_traffic_light_box_config(json, &box);

    TimeConditionMap time_condition_data = CreateTimeConditionMap(*config_data);
    // add time_condition_
    time_condition_ = std::make_shared<filter_time>();
    time_condition_->fun = [time_condition_data](sys_milliseconds now)->bool {
        if(time_condition_data.empty()) {
            return true;
        }
        auto itr = find_if(time_condition_data.begin(), time_condition_data.end(), [&](const TimeConditionMap::value_type one){
            return one.second.TimeMatch(now);
        });
        return itr!=time_condition_data.end();
    };

    // add plate_condition_
    TimeConditionMap plate_condition_data = CreatePlateConditionMap(config_data.get());
    
    plate_condition_= std::make_shared<filter_action>();
    plate_condition_->fun = [plate_condition_data](const inference::ViolationEvent& e)->bool {
        if(plate_condition_data.empty()) {
            return true;
        }
        for (const auto& snapshot : e.snapshots()) {
            if (snapshot.objects_size() == 0 ||
                !snapshot.objects(0).has_plate()) {
                continue;
            }
            const auto& number = snapshot.objects(0).plate().number();
            sys_milliseconds now{std::chrono::milliseconds{snapshot.now()}};
            for (const auto& value : plate_condition_data) {
                if (value.second.TimeMatch(now) && value.second.PlateMatch(number)) {
                    return true;
                }
            }
        }
        return false;
    };

    // add nonmotor_type_condition_
    nonmotor_type_condition_ = std::make_shared<filter_action>();
    nonmotor_type_condition_->fun = CreateNonmotorTypeCondition(config_data.get());

    // add nonmotor_behaviour_condition_
    nonmotor_behaviour_condition_ = std::make_shared<filter_action>();
    nonmotor_behaviour_condition_->fun = CreateBehaviourCondition(config_data.get());

    // add direction_condition_
    direction_condition_ = std::make_shared<filter_action>();
    direction_condition_->fun = CreateDirectionCondition(config_data.get());

    // add special_car_type_condition_
    special_car_type_condition_ = std::make_shared<filter_action>();
    special_car_type_condition_->fun = CreateSpecialCarTypeCondition(config_data.get());

    // add sub_type_condition_
    sub_type_condition_ = std::make_shared<filter_action>();
    sub_type_condition_->fun = CreateSubTypeCondition(config_data.get());

    // add person_type_condition_
    person_type_condition_ = std::make_shared<filter_action>();
    person_type_condition_->fun = CreatePersonTypeCondition(config_data.get());

    // add angle_condition_
    angle_condition_ = std::make_shared<filter_action>();
    angle_condition_->fun = CreateAngleCondition(config_data.get());

    // add plate_type_condition_
    plate_type_condition_ = std::make_shared<filter_action>();
    plate_type_condition_->fun = CreatePlateTypeCondition(config_data.get());

    // add conditions_ && drop_conditions_
    conditions_ = std::make_shared<check_action_withdata_vec>();
    drop_conditions_ = std::make_shared<check_action_withdata_vec>();
    bool after_violate_line = false;
    for(int i=0; i<conditions.size(); i++){
        const auto& current_condition = conditions.Get(i);
        if (current_condition.name()== "violate_line" || 
            current_condition.name()== "violate_box") {
            after_violate_line = true;
        }
        conditions.Mutable(i)->set_enable_draw(after_violate_line);
        check_action_withdata action;
        if (auto fun = CreateLineConditionV2(current_condition, has_traffic_light_box, roi_data, violation_id)) {
            action = check_action_withdata{i, fun};
        } else if(auto fun = CreatePolygonConditionV2(current_condition, has_traffic_light_box, violation_id)){
            action = check_action_withdata{i, fun};
        } else {
            //LOG(WARNING) << "condition not support, ignore, name=" << current_condition.name() << ", type=" << current_condition.type();
            continue;
        }
        // add by action
        if (current_condition.action() == "record") {
            conditions_->push_back(action);
        } else if (current_condition.action() == "drop") {
            drop_conditions_->push_back(action);
        }
    }
}

//
// ViolationCommon
//
class ViolationCommon : public ViolationBase
{
public:
    ViolationCommon(BoxF object,
                    const std::string& violation_id,
                    const ViolationCommonConfig& violation_cfg)
    : ViolationBase(object, violation_id, violation_cfg.data_)
    , violation_cfg_(violation_cfg)
    , current_(0)
    , need_enable_draw_(false)
    , cross_line_flags_(violation_cfg_.data_->conditions_size(), false)
    , condition_data_(violation_cfg_.data_->conditions_size(), nullptr)
    {
    }
    virtual ~ViolationCommon()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
    virtual bool          results_filter(const inference::ViolationEvent& e)const;

protected:
    typedef spIConditionData spData;
    const ViolationCommonConfig  violation_cfg_;
    int                    current_;
    bool                   need_enable_draw_;
    vector<bool>           cross_line_flags_;
    vector<spData>         condition_data_;
    BoxF                   last_box_;
};

result_list_t ViolationCommon::check(BoxF& box, const ImageObjectsInfo& objs)
{
    const auto& cfg = *(violation_cfg_.data_);
    const auto& conditions = *(violation_cfg_.conditions_);
    if (current_ == -1 ||
        current_ >= conditions.size()) {
        if (need_enable_draw_) {
            box.violate_state = current_;
        }
        return result_list_t();
    }

    if(cfg.enable_valid_box_check()){
        if ( 0 == current_ &&
            ! valid_box_in_range(box, objs.sframe->width(), objs.sframe->height(), cfg.plate_available_box_percent())) {
            return result_list_t();
        }
    }

    if (violation_cfg_.pre_condition_ && !(*(violation_cfg_.pre_condition_))(box)) {
        return result_list_t();
    }

    // init last_box_
    if (last_box_.uid == -1) {
        last_box_ = box;
    }

    const auto& drop_conditions = *(violation_cfg_.drop_conditions_);
    for( auto& drop_condition : drop_conditions ) {
        if (drop_condition.fun(last_box_, box, objs, condition_data_[drop_condition.index])) {
            current_ = -1;
            box.violate_state = 0;
            need_enable_draw_ = false;
            this->clear_snapshot();
            LOG(INFO) << "==>enter drop " << current_ << ", "
                    << objs.channel_id << "," 
                    << violation_id_ << ","
                    << object_id_<< ","
                    << box.attr_type.type;
            return result_list_t();
        }
    }

    if (cfg.condition_order()) {
        const auto &condition = conditions.at(current_);
        if (condition.fun(last_box_, box, objs, condition_data_[condition.index])) {
            this->add_snapshot(box, objs);
            if (condition_data_[condition.index]) {
                condition_data_[condition.index]->UpdateSnapshotReuslt(&this->snapshots_.back());
            }
            need_enable_draw_ = cfg.conditions(condition.index).enable_draw();
            current_++;
            LOG(INFO) << "==>enter state " << current_ << ", "
                    << objs.channel_id << "," 
                    << violation_id_ << ","
                    << object_id_<< ","
                    << box.attr_type.type;
        }
    }
    else {
        for (auto& condition : conditions ) {
            if (!cross_line_flags_[condition.index] &&
                condition.fun(last_box_, box, objs, condition_data_[condition.index])) {
                this->add_snapshot(box, objs);
                if (condition_data_[condition.index]) {
                    condition_data_[condition.index]->UpdateSnapshotReuslt(&this->snapshots_.back());
                }
                need_enable_draw_ = cfg.conditions(condition.index).enable_draw();
                cross_line_flags_[condition.index] = true;
                current_++;
                LOG(INFO) << "==>enter state " << current_ << ", "
                    << objs.channel_id << "," 
                    << violation_id_ << ","
                    << object_id_<< ","
                    << box.attr_type.type;
            }
        }
    }

    if (need_enable_draw_) {
        box.violate_state = current_;
    }
    if (current_ >= conditions.size()) {
        return get_results();
    }
    // update last_box_
    last_box_ = box;
    return result_list_t();
}

bool ViolationCommon::results_filter(const inference::ViolationEvent& e)const{
    if (ViolationBase::results_filter(e)) {
        return true;
    }
    if (! violation_cfg_.nonmotor_type_condition_->fun(e) ) {
        LOG(INFO) << "==>match filter: " << "nonmotor_type" << ", "
                << e.stream_id() << "," 
                << e.violation_id() << ","
                << e.obj_id()<< ","
                << e.violation_code();
        return true;
    }
    if (! violation_cfg_.nonmotor_behaviour_condition_->fun(e)) {
        LOG(INFO) << "==>match filter: " << "nonmotor_behaviour" << ", "
                << e.stream_id() << "," 
                << e.violation_id() << ","
                << e.obj_id()<< ","
                << e.violation_code();
        return true;
    }
    if (! violation_cfg_.plate_condition_->fun(e)) {
        LOG(INFO) << "==>match filter: " << "plate" << ", "
                << e.stream_id() << "," 
                << e.violation_id() << ","
                << e.obj_id()<< ","
                << e.violation_code();
        return true;
    }
    if (! violation_cfg_.direction_condition_->fun(e)) {
        LOG(INFO) << "==>match filter: " << "direction" << ", "
                << e.stream_id() << "," 
                << e.violation_id() << ","
                << e.obj_id()<< ","
                << e.violation_code();
        return true;
    }
    if (! violation_cfg_.special_car_type_condition_->fun(e)) {
        LOG(INFO) << "==>match filter: " << "special_car_type" << ", "
                << e.stream_id() << "," 
                << e.violation_id() << ","
                << e.obj_id()<< ","
                << e.violation_code();
        return true;
    }
    if (! violation_cfg_.sub_type_condition_->fun(e)) {
        LOG(INFO) << "==>match filter: " << "sub_type" << ", "
                << e.stream_id() << "," 
                << e.violation_id() << ","
                << e.obj_id()<< ","
                << e.violation_code();
        return true;
    }
    if (! violation_cfg_.person_type_condition_->fun(e)) {
        LOG(INFO) << "==>match filter: " << "person_type" << ", "
                << e.stream_id() << "," 
                << e.violation_id() << ","
                << e.obj_id()<< ","
                << e.violation_code();
        return true;
    }
    if (! violation_cfg_.angle_condition_->fun(e)) {
        LOG(INFO) << "==>match filter: " << "angle" << ", "
                << e.stream_id() << "," 
                << e.violation_id() << ","
                << e.obj_id()<< ","
                << e.violation_code();
        return true;
    }
    if (! violation_cfg_.plate_type_condition_->fun(e)) {
        LOG(INFO) << "==>match filter: " << "plate_type" << ", "
                << e.stream_id() << "," 
                << e.violation_id() << ","
                << e.obj_id()<< ","
                << e.violation_code();
        return true;
    }
    return false;
}

//
// ViolationCommonFactory
//
ViolationCommonFactory::ViolationCommonFactory(
                    const std::string& violation_id,
                    const std::string& violation_cfg)
    : IViolationFactory()
    , violation_id_(violation_id)
    , violation_cfg_(std::make_shared<ViolationCommonConfig>(violation_cfg, violation_id))
{
}

ViolationCommonFactory::ViolationCommonFactory(
                    const std::string& violation_id,
                    const std::string& violation_cfg,
                    fn_pre_check_action fn)
    : IViolationFactory()
    , violation_id_(violation_id)
    , violation_cfg_(std::make_shared<ViolationCommonConfig>(violation_cfg, violation_id))
{
    violation_cfg_->pre_condition_ = std::make_shared<fn_pre_check_action>(fn);;
}
const std::string& ViolationCommonFactory::id()const
{
    return violation_id_;
}

spIViolation ViolationCommonFactory::CreateIViolation(const BoxF& obj)
{
   auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
    if (this->check_time(now)) {
        return std::make_shared<ViolationCommon>(obj, violation_id_, *violation_cfg_);
    }
    return nullptr;
}

bool ViolationCommonFactory::check_time(time_point_milliseconds now) {
    return violation_cfg_->time_condition_->fun(now);
}

} // namespace FLOW
