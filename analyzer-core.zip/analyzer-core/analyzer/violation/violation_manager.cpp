
#include "violation_manager.hpp"

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/json.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"

#include "violation_event.hpp"
#include "stream_violation.hpp"
#include "violation_patches.hpp"
#include "violation_util_config_merge.hpp"

namespace FLOW {

CViolationManager::CViolationManager(wpViolationEventProcesser event, const std::string& config)
    : violation_evenv_manager_(event)
    , config_patch_map_(parse_patch(config))
    , analyzer_cfg_(
        [config](){
            inference::AnalyzerConfig cfg;
            std::string err;
            auto code = json2pb(config, &cfg, &err);
            LOG_IF(FATAL, code!=0);
            return cfg; 
        }()
    )
{
}

int CViolationManager::AddViolation(const std::string& channel_or_task_id, const std::string& violation_id, const std::string& config)
{
    std::unique_lock<std::mutex> lock{lock_};
    auto find_result = channel_or_task_violation_map_.find(channel_or_task_id);
    if (find_result == channel_or_task_violation_map_.end()) {
       channel_or_task_violation_map_[channel_or_task_id] = std::make_shared<CStreamViolation>();
       find_result = channel_or_task_violation_map_.find(channel_or_task_id);
    }
    auto patch_global_config    = this->patch_global_config(config);
    auto patch_usr_config       = this->try_patch(config_patch_map_, patch_global_config);
    if ( !patch_usr_config.empty() ) {
        LOG(INFO) << "AddViolation: patch after, cfg=" << patch_usr_config;
    }
    auto last_config = (patch_usr_config.empty()) ? patch_global_config : patch_usr_config;
    return find_result->second->AddViolation(violation_id, last_config);
}

int CViolationManager::AddStreamToTask(const std::string& task_id, const std::string& channel_id)
{
    std::unique_lock<std::mutex> lock{lock_};
    channel_task_map_[channel_id] = task_id;

    return 0;
}

// allways ok
int CViolationManager::RemoveViolation(const std::string& channel_or_task_id, const std::string& violation_id)
{
    std::unique_lock<std::mutex> lock{lock_};
    auto find_result = channel_or_task_violation_map_.find(channel_or_task_id);
    if (find_result == channel_or_task_violation_map_.end()) {
        return 0;
    }
    return find_result->second->RemoveViolation(violation_id);
}

// allways ok
int CViolationManager::RemoveViolationAll(const std::string& channel_or_task_id)
{
    std::unique_lock<std::mutex> lock{lock_};
    auto find_result = channel_or_task_violation_map_.find(channel_or_task_id);
    if (find_result == channel_or_task_violation_map_.end()) {
        return 0;
    }
    channel_or_task_violation_map_.erase(find_result);
    for (auto iter = channel_task_map_.begin(); iter != channel_task_map_.end();){
        if (iter->second == channel_or_task_id){
            iter = channel_task_map_.erase(iter);
        } else {
            iter++;
        }
    }
    return 0;
}

void CViolationManager::Process(const VecImage& images)
{
    std::unique_lock<std::mutex> lock{lock_};
    for(const auto& image : images){
        const auto& info = *image;

        // try find by channel id
        auto find_reuslt = channel_or_task_violation_map_.find(info.channel_id);
        if (find_reuslt == channel_or_task_violation_map_.end()) {
            // try find by task id
            auto task_id = channel_task_map_[info.channel_id];
            find_reuslt = channel_or_task_violation_map_.find(task_id);
            if (find_reuslt == channel_or_task_violation_map_.end()) {
                continue;
            }
        }
        auto results = find_reuslt->second->Check(info);
        auto reporter = violation_evenv_manager_.lock();
        if (reporter) {
            for(auto&r:results){
                reporter->Post(r);
            }
        }
    }
}

std::string CViolationManager::patch_global_config(const std::string& config) const{
    std::string err, new_config(config);
    inference::ViolationConfig base_msg;
    // set snapshot_selecter type
    if (analyzer_cfg_.general_config().has_snapshot_selecter()) {
        auto err_code = json2pb(new_config, &base_msg, &err);
        LOG_IF(FATAL, err_code != 0) << err;
        if (!base_msg.has_snapshot_selecter()) {
            base_msg.set_snapshot_selecter(analyzer_cfg_.general_config().snapshot_selecter());
        }
        new_config.clear();
        pb2json(&base_msg, &new_config);
    }
    // enable_use_pts
    if (analyzer_cfg_.stream_config().has_enable_use_pts()) {
        auto err_code = json2pb(new_config, &base_msg, &err);
        LOG_IF(FATAL, err_code != 0) << err;
        if (!base_msg.has_enable_use_pts()) {
            base_msg.set_enable_use_pts(analyzer_cfg_.stream_config().enable_use_pts());
        }
        for( auto& cond : *base_msg.mutable_conditions()) {
            if (!cond.has_enable_use_pts()) {
                cond.set_enable_use_pts(base_msg.has_enable_use_pts());
            }
        }
        // result
        new_config.clear();
        pb2json(&base_msg, &new_config);
        return new_config;
    }
    return new_config;
}

std::string CViolationManager::try_patch(const std::map<std::string, std::string>& all_patch, const std::string& config) {
    auto root = get_document(config);
    auto code = get_string(root, "code", "");
    if (code == "" || all_patch.count(code) == 0) {
        return "";
    }
    std::string err, new_config;
    inference::ViolationConfig patch, base_msg;
    auto err_code = json2pb(all_patch.find(code)->second, &patch, &err);
    LOG_IF(FATAL, err_code != 0) << "parse patch failed, "<< err <<", json=" << all_patch.find(code)->second;
    err_code = json2pb(config, &base_msg, &err);
    LOG_IF(FATAL, err_code != 0) << "parse config failed, "<< err <<", json=" << config;
    // true为强制修改 false为追加
    merge_violation_cfg(patch, &base_msg, true);
    pb2json(&base_msg, &new_config);
    return new_config;
}

std::map<std::string, std::string> CViolationManager::parse_patch(const std::string& config) {
    std::map<std::string, std::string>  config_patch_map;
    const auto& root = get_document(config);
    if (root.HasMember("violation_patch")) {
        const auto& code_structs = get_value(root, "violation_patch");
        for (rapidjson::Value::ConstMemberIterator itr = code_structs.MemberBegin(); itr != code_structs.MemberEnd(); itr ++) {
            config_patch_map[itr->name.GetString()] = value_as_string(itr->value);;
        }
    }
    add_static_patch(config_patch_map);
    return config_patch_map;
}

int CViolationManager::add_static_patch(std::map<std::string, std::string>& config_patch_map) {
    static const std::map<std::string, std::string> patchs = get_static_voilation_patches();
    int retv = 0;
    for (auto& kv : patchs) {
        if (config_patch_map.count( kv.first ) == 0) {
            config_patch_map[kv.first] = kv.second;
            retv ++;
        } else {
            LOG(INFO) << "Skip load static patch, code=" << kv.first;
        }
    }
    return retv;
}

} // namespace FLOW
