#include "violation_empty.hpp"

#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "ducha_violation_base.hpp"

namespace FLOW {

//
// ViolationEmpty
//
class ViolationEmpty : public DuchaViolationClassifyBase
{
public:
    ViolationEmpty(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg);
    virtual ~ViolationEmpty()=default;

public:
    virtual FrameResult get_frame_result(const ChannelId2ImageMap& infos);
    
protected:
    const spDuchaViolationConfig    cfg_;
};

ViolationEmpty::ViolationEmpty(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg)
    : DuchaViolationClassifyBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
}

FrameResult ViolationEmpty::get_frame_result(const ChannelId2ImageMap& infos)
{
    FrameResult result;
    result.violative = false;
    return result;
}

//
// ViolationEmptyFactory
//
ViolationEmptyFactory::ViolationEmptyFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<DuchaViolationConfig>(cfg))
{
}

const std::string& ViolationEmptyFactory::id()const
{
    return id_;
}

spIViolation ViolationEmptyFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationEmpty>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

// 因客户演示需要，以下模型需要能够布控，但内部逻辑不实现，无预警
// 待二期需求确定后实现

REGISTER_VIOLATION(DUCHA_RENZHENGDUIZHAO_CODE, Empty);
REGISTER_VIOLATION(DUCHA_CHUTUJINGLIZAIWEI_CODE, Empty);
REGISTER_VIOLATION(DUCHA_XUNCHAJINGLIZAIWEI_CODE, Empty);
REGISTER_VIOLATION(DUCHA_RENTOUJISHU_CODE, Empty);

} // namespace FLOW
