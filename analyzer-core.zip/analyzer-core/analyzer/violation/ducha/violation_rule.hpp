#ifndef VSS_DUCHA_VIOLATION_RULE_HPP
#define VSS_DUCHA_VIOLATION_RULE_HPP

#include <vector>
#include <string>

#include "ducha_const.hpp"

namespace FLOW {

class DuchaViolationRule 
{
public:
    DuchaViolationRule(const std::string& id, const std::string& area);
    DuchaViolationRule(const std::string& id);
    virtual ~DuchaViolationRule()=default;

public:
    void SetIdentities(const std::vector<Identity>& identities);
    void SetExceptIdentities(const std::vector<Identity>& all, const std::vector<Identity>& identities);
    void SetBehaviors(const std::vector<Behavior>& behaviors);
    void SetExceptBehaviors(const std::vector<Behavior>& all, const std::vector<Behavior>& behaviors);
    void SetSexes(const std::vector<Sex>& sexes);
    void SetMasks(const std::vector<Mask>& masks);
    void SetIdentityScore(float identity_score);
    void SetBehaviorScore(float behavior_score);
    void SetMaleScore(float male_score);
    void SetFemaleScore(float female_score);
    void SetMaskScore(float mask_score);


    std::string Id();
    bool CheckArea(const std::string& area);
    bool CheckIdentity(Identity identity, float identity_score);
    bool CheckBehavior(Behavior behavior, float behavior_score);
    bool CheckSex(Sex sex, float sex_score);
    bool CheckMask(Mask mask, float mask_score);

protected:
    std::string             id_;
    std::string             area_;
    std::vector<Identity>   identities_;
    std::vector<Behavior>   behaviors_;
    std::vector<Sex>        sexes_;
    std::vector<Mask>       masks_;
    float                   identity_score_;
    float                   behavior_score_;
    float                   male_score_;
    float                   female_score_;
    float                   mask_score_;
};

} // namespace FLOW
#endif // VSS_DUCHA_VIOLATION_RULE_HPP
