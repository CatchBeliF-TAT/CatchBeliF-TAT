#ifndef VSS_DUCHA_VIOLATION_BASE_HPP
#define VSS_DUCHA_VIOLATION_BASE_HPP

#include <chrono>
#include <vector>
#include <list>

#include "serving/violation_config.pb.h"

#include "violation/violation_interface.hpp"
#include "violation/violation_registry.hpp"

#include "violation_rule.hpp"

namespace FLOW {

typedef std::unordered_map<std::string, spImageObjectsInfo> ChannelId2ImageMap;
typedef std::shared_ptr<inference::DuchaViolationConfig>    spDuchaViolationConfiguration;

using sys_milliseconds = std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds>;

struct DuchaViolationArea
{
    std::string         id;
    std::string         name;
    std::vector<float>  scope;          
};
struct DuchaViolationCamera
{
    std::string                     id;
    std::vector<DuchaViolationArea> areas;          
};
struct FrameResult
{
    FrameResult(){
        violative = false;
    }
    bool                                    violative;  // for related cameras
    std::unordered_map<std::string, bool>   violatives; // for non-related cameras
    sys_milliseconds                        time;       
};

typedef std::unordered_map<std::string, DuchaViolationCamera> ChannelId2ViolationCameraMap;
typedef std::shared_ptr<DuchaViolationRule> spDuchaViolationRule;

class DuchaViolationConfig {
public:
    DuchaViolationConfig(const std::string& json);
    bool ParseJson(const std::string& json);

public:
    spDuchaViolationConfiguration   violation_cfg_;
    ChannelId2ViolationCameraMap    cameras_;
};
typedef std::shared_ptr<DuchaViolationConfig> spDuchaViolationConfig;

// 督查Violation基类，内部处理多摄像头数据并交给process
// 具体Violation类实现process
class DuchaViolationBase : public IViolation, public std::enable_shared_from_this<DuchaViolationBase>
{
public:
    DuchaViolationBase(int object_id, const std::string& violation_id, const spDuchaViolationConfiguration& violation_cfg);
    virtual ~DuchaViolationBase()=default;

public:
    virtual const std::string&              id()const;
    virtual result_list_t                   check(BoxF&, const ImageObjectsInfo&);

protected:
    virtual result_list_t                   process(BoxF&, const ChannelId2ImageMap&)=0;
    virtual bool                            filter(const ImageObjectsInfo&)=0;

protected:
    const std::string                       violation_id_;
    const spDuchaViolationConfiguration     violation_cfg_;
    ChannelId2ImageMap                      channel_image_map_;
    std::vector<std::string>                channel_ids_;
    float                                   threshold_;
};

// 基于帧数据处理的基类，内部实现帧结果队列的处理、预警发送的判断、冷却时间等的处理
// 具体Violation类实现get_frame_result返回帧处理结果
// 支持摄像头相关和不相关两种处理模式
class DuchaViolationFrameProcessBase : public DuchaViolationBase
{
public:
    DuchaViolationFrameProcessBase(int object_id, const std::string& violation_id, const spDuchaViolationConfiguration& violation_cfg);
    virtual ~DuchaViolationFrameProcessBase()=default;

protected:
    virtual result_list_t                   process(BoxF&, const ChannelId2ImageMap&);
    virtual FrameResult                     get_frame_result(const ChannelId2ImageMap&)=0;
    virtual result_list_t                   get_results(const ChannelId2ImageMap&)=0;
    virtual bool                            filter(const ImageObjectsInfo&)=0;

    bool                                    filter_static(const ChannelId2ImageMap&);

protected:
    std::list<FrameResult>                  frame_result_;
    sys_milliseconds                        last_alarm_time_;
    bool                                    is_camera_related_;
    bool                                    need_filter_static_;
    ChannelId2ImageMap                      last_alarm_infos_;
    ChannelId2ImageMap                      snapshots_;
};

// 属性类violation的基类，内部实现count方法按rule条件计算个数
// rule可指定负责的区域、行为、服饰、性别、口罩及相关score
// Note：使用template可进一步简化
class DuchaViolationClassifyBase : public DuchaViolationFrameProcessBase
{
public:
    DuchaViolationClassifyBase(int object_id, const std::string& violation_id, const spDuchaViolationConfiguration& violation_cfg);
    virtual ~DuchaViolationClassifyBase()=default;

protected:
    std::unordered_map<std::string, int>    count(const ChannelId2ImageMap&, ChannelId2ViolationCameraMap&);
    virtual FrameResult                     get_frame_result(const ChannelId2ImageMap&)=0;
    virtual result_list_t                   get_results(const ChannelId2ImageMap&);
    virtual bool                            filter(const ImageObjectsInfo&);

protected:
    std::vector<spDuchaViolationRule>            rules_;
};

} // namespace FLOW
#endif // VSS_DUCHA_VIOLATION_BASE_HPP
