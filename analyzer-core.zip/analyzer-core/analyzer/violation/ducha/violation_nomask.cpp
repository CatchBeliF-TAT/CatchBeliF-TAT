#include "violation_nomask.hpp"

#include <iterator>
#include <memory>
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"
#include "ducha_violation_base.hpp"
#include "violation/violation_util.hpp"

namespace FLOW {

//
// ViolationNomask
//
class ViolationNomask : public DuchaViolationClassifyBase
{
public:
    ViolationNomask(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg);
    virtual ~ViolationNomask()=default;

public:
    virtual FrameResult     get_frame_result(const ChannelId2ImageMap& infos);
    
protected:
    const spDuchaViolationConfig   cfg_;
};

ViolationNomask::ViolationNomask(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg)
    : DuchaViolationClassifyBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    is_camera_related_ = false;

    auto& scene = cfg_->violation_cfg_->scene_id();
    if (scene == BJ_LKHJ_CODE) {
        LOG(FATAL) << "invalid scene id : " << scene << " for model : " << violation_id;
    } else {
        auto no_mask = std::make_shared<DuchaViolationRule>("no_mask", OFFICE_AREA);
        no_mask->SetMasks({NO_MASK});
        rules_.push_back(no_mask);
    }
}

FrameResult ViolationNomask::get_frame_result(const ChannelId2ImageMap& infos)
{
    FrameResult result;
    for (auto& info : infos){
        auto camera_count = count({{info.first, info.second}}, cfg_->cameras_);
        if (camera_count["no_mask"] > 0 ) {
            result.violatives[info.first] = true;
        }
    }

    return result;
}

//
// ViolationNomaskFactory
//
ViolationNomaskFactory::ViolationNomaskFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<DuchaViolationConfig>(cfg))
{
}

const std::string& ViolationNomaskFactory::id()const
{
    return id_;
}

spIViolation ViolationNomaskFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationNomask>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(DUCHA_NOMASK_CODE, Nomask);

} // namespace FLOW
