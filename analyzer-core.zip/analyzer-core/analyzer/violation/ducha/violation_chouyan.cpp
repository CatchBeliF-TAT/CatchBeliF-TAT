#include "violation_chouyan.hpp"

#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "ducha_violation_base.hpp"

namespace FLOW {

//
// ViolationChouyan
//
class ViolationChouyan : public DuchaViolationClassifyBase
{
public:
    ViolationChouyan(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg);
    virtual ~ViolationChouyan()=default;

public:
    virtual FrameResult get_frame_result(const ChannelId2ImageMap& infos);
    
protected:
    const spDuchaViolationConfig    cfg_;
};

ViolationChouyan::ViolationChouyan(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg)
    : DuchaViolationClassifyBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    is_camera_related_ = false;

    auto& scene = cfg_->violation_cfg_->scene_id();
    std::string detect_area;
    if (scene == HWS_CODE) {
        detect_area = SUSPECT_AREA;
    } else if (scene == FWCK_CODE || scene == HWSJYJKQ_CODE || scene == JKS_CODE
                || scene == XWS_CODE || scene == QXS_CODE) {
        detect_area = POLICE_AREA;
    } else if (scene == BJ_JKS_CODE || scene == BJ_BZCK_CODE || scene == BJ_RSXLWPJCS_CODE
                || scene == BJ_XWSLS_CODE || scene == BJ_JGCS_CODE || scene == BJ_LSJGQY_CODE) {
        detect_area = OFFICE_AREA;
    } else {
        LOG(FATAL) << "invalid scene id : " << scene << " for model : " << violation_id;
    }

    auto police = std::make_shared<DuchaViolationRule>("police", detect_area);
    police->SetBehaviors({BEHAVIOR_SMOKE});
    rules_.push_back(police);
}

FrameResult ViolationChouyan::get_frame_result(const ChannelId2ImageMap& infos)
{
    FrameResult result;
    for (auto& info : infos){
        auto camera_count = count({{info.first, info.second}}, cfg_->cameras_);
        if (camera_count["police"] > 0 ) {
            result.violatives[info.first] = true;
        }
    }
    
    return result;
}

//
// ViolationChouyanFactory
//
ViolationChouyanFactory::ViolationChouyanFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<DuchaViolationConfig>(cfg))
{
}

const std::string& ViolationChouyanFactory::id()const
{
    return id_;
}

spIViolation ViolationChouyanFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationChouyan>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(DUCHA_CHOUYAN_CODE, Chouyan);

} // namespace FLOW
