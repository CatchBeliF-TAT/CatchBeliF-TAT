#ifndef VSS_VIOLATION_WEICHUANZHIFU_HPP
#define VSS_VIOLATION_WEICHUANZHIFU_HPP

#include "violation/violation_interface.hpp"

namespace FLOW {

class DuchaViolationConfig;
typedef std::shared_ptr<DuchaViolationConfig> spDuchaViolationConfig;

class ViolationWeichuanzhifuFactory : public IViolationFactory 
{
public:
    ViolationWeichuanzhifuFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationWeichuanzhifuFactory()=default;

public:
    virtual const std::string&  id()const;
    virtual spIViolation        CreateIViolation(const BoxF& obj);

protected:
    std::string                 id_;
    spDuchaViolationConfig      cfg_;
    
};

} // namespace FLOW
#endif // VSS_VIOLATION_WEICHUANZHIFU_HPP
