#ifndef VSS_VIOLATION_EMPTY_HPP
#define VSS_VIOLATION_EMPTY_HPP

#include "violation/violation_interface.hpp"

namespace FLOW {

class DuchaViolationConfig;
typedef std::shared_ptr<DuchaViolationConfig> spDuchaViolationConfig;

class ViolationEmptyFactory : public IViolationFactory 
{
public:
    ViolationEmptyFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationEmptyFactory()=default;

public:
    virtual const std::string&  id()const;
    virtual spIViolation        CreateIViolation(const BoxF& obj);

protected:
    std::string                 id_;
    spDuchaViolationConfig      cfg_;
    
};

} // namespace FLOW
#endif // VSS_VIOLATION_EMPTY_HPP
