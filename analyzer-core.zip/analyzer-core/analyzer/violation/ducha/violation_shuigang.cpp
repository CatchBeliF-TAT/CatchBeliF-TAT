#include "violation_shuigang.hpp"

#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "ducha_violation_base.hpp"

namespace FLOW {

//
// ViolationShuigang
//
class ViolationShuigang : public DuchaViolationClassifyBase
{
public:
    ViolationShuigang(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg);
    virtual ~ViolationShuigang()=default;

public:
    virtual FrameResult get_frame_result(const ChannelId2ImageMap& infos);
    
protected:
    const spDuchaViolationConfig    cfg_;
};

ViolationShuigang::ViolationShuigang(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg)
    : DuchaViolationClassifyBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    is_camera_related_ = true;

    auto& scene = cfg_->violation_cfg_->scene_id();
    if (scene == XWS_CODE || scene == HWSJYJKQ_CODE ) {
        auto people = std::make_shared<DuchaViolationRule>("people", SUSPECT_AREA);
        people->SetIdentities({IDENTITY_PEOPLE});
        rules_.push_back(people);

        auto police_non_sleep1 = std::make_shared<DuchaViolationRule>("police_non_sleep", POLICE_AREA);
        police_non_sleep1->SetExceptBehaviors(ALL_DUCHA_BEHAVIORS, {BEHAVIOR_SLEEP});
        rules_.push_back(police_non_sleep1);

        auto police_non_sleep2 = std::make_shared<DuchaViolationRule>("police_non_sleep", SUSPECT_AREA);
        police_non_sleep2->SetExceptIdentities(ALL_DUCHA_IDENTITIES, {IDENTITY_PEOPLE});
        police_non_sleep2->SetExceptBehaviors(ALL_DUCHA_BEHAVIORS, {BEHAVIOR_SLEEP});
        rules_.push_back(police_non_sleep2);

        auto police_sleep1 = std::make_shared<DuchaViolationRule>("police_sleep", POLICE_AREA);
        police_sleep1->SetBehaviors({BEHAVIOR_SLEEP});
        rules_.push_back(police_sleep1);

        auto police_sleep2 = std::make_shared<DuchaViolationRule>("police_sleep", SUSPECT_AREA);
        police_sleep2->SetExceptIdentities(ALL_DUCHA_IDENTITIES, {IDENTITY_PEOPLE});
        police_sleep2->SetBehaviors({BEHAVIOR_SLEEP});
        rules_.push_back(police_sleep2);
    } else {
        LOG(FATAL) << "invalid scene id : " << scene << " for model : " << violation_id;
    }
}

FrameResult ViolationShuigang::get_frame_result(const ChannelId2ImageMap& infos)
{
    FrameResult result;
    result.violative = false;

    auto frame_count = count(infos, cfg_->cameras_);
    auto police_sleep_count = frame_count["police_sleep"];
    auto police_count = frame_count["police_non_sleep"] + police_sleep_count;
    
    if (police_sleep_count > 0 && police_sleep_count == police_count && frame_count["people"] > 0) {
        result.violative = true;
    }

    return result;
}

//
// ViolationShuigangFactory
//
ViolationShuigangFactory::ViolationShuigangFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<DuchaViolationConfig>(cfg))
{
}

const std::string& ViolationShuigangFactory::id()const
{
    return id_;
}

spIViolation ViolationShuigangFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationShuigang>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(DUCHA_SHUIGANG_CODE, Shuigang);

} // namespace FLOW
