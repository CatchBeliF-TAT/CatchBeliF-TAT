#include "violation_danren.hpp"

#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "ducha_violation_base.hpp"

namespace FLOW {

//
// ViolationDanren
//
class ViolationDanren : public DuchaViolationClassifyBase
{
public:
    ViolationDanren(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg);
    virtual ~ViolationDanren()=default;

public:
    virtual FrameResult get_frame_result(const ChannelId2ImageMap& infos);
    
protected:
    const spDuchaViolationConfig    cfg_;
};

ViolationDanren::ViolationDanren(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg)
    : DuchaViolationClassifyBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    is_camera_related_ = true;
    need_filter_static_ = true;

    std::string detect_area;
    auto& scene = cfg_->violation_cfg_->scene_id();
    if (scene == QXS_CODE) {
        detect_area = POLICE_AREA;
    } else if (scene == BJ_QK_CODE) {
        detect_area = OFFICE_AREA;
    } else {
        LOG(FATAL) << "invalid scene id : " << scene << " for model : " << violation_id;
    }

    auto person = std::make_shared<DuchaViolationRule>("person", detect_area);
    rules_.push_back(person); 
}

FrameResult ViolationDanren::get_frame_result(const ChannelId2ImageMap& infos)
{
    FrameResult result;
    auto frame_count = count(infos, cfg_->cameras_);
    result.violative = false;
    if (frame_count["person"] == 1 ) {
        result.violative = true;
    }

    return result;
}

//
// ViolationDanrenFactory
//
ViolationDanrenFactory::ViolationDanrenFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<DuchaViolationConfig>(cfg))
{
}

const std::string& ViolationDanrenFactory::id()const
{
    return id_;
}

spIViolation ViolationDanrenFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationDanren>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(DUCHA_DANREN_CODE, Danren);

} // namespace FLOW
