#include "violation_tongxingbieshenxu.hpp"

#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "ducha_violation_base.hpp"
#include "violation_rule.hpp"

namespace FLOW {

//
// ViolationTongxingbieshenxu
//
class ViolationTongxingbieshenxu : public DuchaViolationClassifyBase
{
public:
    ViolationTongxingbieshenxu(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg);
    virtual ~ViolationTongxingbieshenxu()=default;

public:
    virtual FrameResult get_frame_result(const ChannelId2ImageMap& infos);
    
protected:
    const spDuchaViolationConfig    cfg_;
};

ViolationTongxingbieshenxu::ViolationTongxingbieshenxu(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg)
    : DuchaViolationClassifyBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    is_camera_related_ = true;

    auto& scene = cfg_->violation_cfg_->scene_id();
    if (scene == BJ_XWSLS_CODE) {
        auto people_male = std::make_shared<DuchaViolationRule>("people_male", MASS_AREA);
        people_male->SetIdentities({IDENTITY_PEOPLE});
        people_male->SetSexes({SEX_MALE});
        people_male->SetMaleScore(cfg_->violation_cfg_->male_score());
        rules_.push_back(people_male);

        auto people_female = std::make_shared<DuchaViolationRule>("people_female", MASS_AREA);
        people_female->SetIdentities({IDENTITY_PEOPLE});
        people_female->SetSexes({SEX_FEMALE});
        people_female->SetFemaleScore(cfg_->violation_cfg_->female_score());
        rules_.push_back(people_female);

        auto police_male_1 = std::make_shared<DuchaViolationRule>("police_male", OFFICE_AREA);
        police_male_1->SetSexes({SEX_MALE});
        police_male_1->SetMaleScore(cfg_->violation_cfg_->male_score());
        rules_.push_back(police_male_1);

        auto police_female_1 = std::make_shared<DuchaViolationRule>("police_female", OFFICE_AREA);
        police_female_1->SetSexes({SEX_FEMALE});
        police_female_1->SetFemaleScore(cfg_->violation_cfg_->female_score());
        rules_.push_back(police_female_1);

        auto police_male_2 = std::make_shared<DuchaViolationRule>("police_male", MASS_AREA);
        police_male_2->SetExceptIdentities(ALL_DUCHA_IDENTITIES, {IDENTITY_PEOPLE});
        police_male_2->SetSexes({SEX_MALE});
        police_male_2->SetMaleScore(cfg_->violation_cfg_->male_score());
        rules_.push_back(police_male_2);

        auto police_female_2 = std::make_shared<DuchaViolationRule>("police_female", MASS_AREA);
        police_female_2->SetExceptIdentities(ALL_DUCHA_IDENTITIES, {IDENTITY_PEOPLE});
        police_female_2->SetSexes({SEX_FEMALE});
        police_female_2->SetFemaleScore(cfg_->violation_cfg_->female_score());
        rules_.push_back(police_female_2);
    } else if (scene == BJ_RSXLWPJCS_CODE ) {
        auto people_male = std::make_shared<DuchaViolationRule>("people_male", OFFICE_AREA);
        people_male->SetIdentities({IDENTITY_PEOPLE});
        people_male->SetSexes({SEX_MALE});
        people_male->SetMaleScore(cfg_->violation_cfg_->male_score());
        rules_.push_back(people_male);

        auto people_female = std::make_shared<DuchaViolationRule>("people_female", OFFICE_AREA);
        people_female->SetIdentities({IDENTITY_PEOPLE});
        people_female->SetSexes({SEX_FEMALE});
        people_female->SetFemaleScore(cfg_->violation_cfg_->female_score());
        rules_.push_back(people_female);

        auto police_male = std::make_shared<DuchaViolationRule>("police_male", OFFICE_AREA);
        police_male->SetExceptIdentities(ALL_DUCHA_IDENTITIES, {IDENTITY_PEOPLE});
        police_male->SetSexes({SEX_MALE});
        people_male->SetMaleScore(cfg_->violation_cfg_->male_score());
        rules_.push_back(police_male);

        auto police_female = std::make_shared<DuchaViolationRule>("police_female", OFFICE_AREA);
        police_female->SetExceptIdentities(ALL_DUCHA_IDENTITIES, {IDENTITY_PEOPLE});
        police_female->SetSexes({SEX_FEMALE});
        people_female->SetFemaleScore(cfg_->violation_cfg_->female_score());
        rules_.push_back(police_female);
    } else {
        LOG(FATAL) << "invalid scene id : " << scene << " for model : " << violation_id;
    }
}

FrameResult ViolationTongxingbieshenxu::get_frame_result(const ChannelId2ImageMap& infos)
{
    FrameResult result;
    auto frame_count = count(infos, cfg_->cameras_);
    result.violative = false;

    int male_people_policy = cfg_->violation_cfg_->male_people_policy();
    int female_people_policy = cfg_->violation_cfg_->female_people_policy();

    if ((frame_count["police_male"] + frame_count["police_female"] > 0) && (frame_count["people_male"] + frame_count["people_female"] > 0)) {
        // 群众区为男性
        if (frame_count["people_male"] > 0) {
            switch (male_people_policy) {
            case REPORT:
                result.violative = true;
                break;
            case NO_REPORT:
                result.violative = false;
                break;
            case UNION_POLICE:
                if (frame_count["police_female"] > 0) {
                    result.violative = true;
                }
                break;
            default:
                LOG(FATAL) << "invalid male people policy : " << male_people_policy;
                break;
            }
        }

        // 群众区为女性
        if (frame_count["people_female"] > 0) {
            switch (female_people_policy) {
            case REPORT:
                result.violative = true;
                break;
            case NO_REPORT:
                result.violative = false;
                break;
            case UNION_POLICE:
                if (frame_count["police_male"] > 0) {
                    result.violative = true;
                }
                break;
            default:
                LOG(FATAL) << "invalid female people policy : " << female_people_policy;
                break;
            }
        }
    }

    return result;
}

//
// ViolationTongxingbieshenxuFactory
//
ViolationTongxingbieshenxuFactory::ViolationTongxingbieshenxuFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<DuchaViolationConfig>(cfg))
{
}

const std::string& ViolationTongxingbieshenxuFactory::id()const
{
    return id_;
}

spIViolation ViolationTongxingbieshenxuFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationTongxingbieshenxu>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(DUCHA_TONGXINGBIESHENXUN_CODE, Tongxingbieshenxu);

} // namespace FLOW
