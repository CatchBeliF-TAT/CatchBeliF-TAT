#include "violation_fight.hpp"

#include <iterator>
#include <memory>
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"
#include "ducha_violation_base.hpp"

namespace FLOW {

//
// ViolationFight
//
class ViolationFight : public DuchaViolationFrameProcessBase
{
public:
    ViolationFight(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg);
    virtual ~ViolationFight()=default;

public:
    virtual FrameResult     get_frame_result(const ChannelId2ImageMap& infos);
    virtual result_list_t   get_results(const ChannelId2ImageMap&);
    virtual bool            filter(const ImageObjectsInfo&);
    
protected:
    const spDuchaViolationConfig    cfg_;
};

ViolationFight::ViolationFight(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg)
    : DuchaViolationFrameProcessBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    is_camera_related_ = false;

    auto& scene = cfg_->violation_cfg_->scene_id();
    if (scene != BJ_BZCK_CODE && scene != BJ_XWSLS_CODE && scene != BJ_RSXLWPJCS_CODE
                && scene != BJ_JGCS_CODE && scene != BJ_LSJGQY_CODE) {
        LOG(FATAL) << "invalid scene id : " << scene << " for model : " << violation_id;
    }
}

FrameResult ViolationFight::get_frame_result(const ChannelId2ImageMap& infos)
{
    FrameResult result;
    for (auto& info : infos){
        if (info.second->ducha_fight_event.is_bk_fighting) {
            result.violatives[info.first] = true;
        }
    }

    return result;
}

bool ViolationFight::filter(const ImageObjectsInfo& objs) {
    return objs.type & DUCHA_FIGHT_TYPE;
}

result_list_t ViolationFight::get_results(const ChannelId2ImageMap& infos){
    result_list_t retv;

    const auto task_id = violation_cfg_->task_id();
    const auto violation_id = violation_id_;
    const auto scene_id = violation_cfg_->scene_id();
    const auto threshold = threshold_;
    const auto image_infos = infos;
    const auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());

    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event = *retv;
        event.set_event_type(DUCHA_FIGHT);
        auto fight_event = event.mutable_ducha_fight_event();
        fight_event->set_task_id(task_id);
        fight_event->set_model_id(violation_id);
        fight_event->set_scene_id(scene_id);
        fight_event->set_threshold(threshold);
        fight_event->set_now(now.time_since_epoch().count());

        for(auto& image_info : image_infos){
            auto& task_id = image_info.first;
            auto& image = image_info.second;
            auto snapshot = fight_event->add_snapshots();
            snapshot->set_camera_id(task_id);
            snapshot->set_image(Helper::get_pic(*image->sframe->getMat()));
            snapshot->set_is_fight(image->ducha_fight_event.is_bk_fighting);
            snapshot->set_score(image->ducha_fight_event.predict_score);
        }

        return retv;
    };

    retv.push_back(action);
    return retv;
}

//
// ViolationFightFactory
//
ViolationFightFactory::ViolationFightFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<DuchaViolationConfig>(cfg))
{
}

const std::string& ViolationFightFactory::id()const
{
    return id_;
}

spIViolation ViolationFightFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationFight>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(DUCHA_FIGHT_CODE, Fight);

} // namespace FLOW
