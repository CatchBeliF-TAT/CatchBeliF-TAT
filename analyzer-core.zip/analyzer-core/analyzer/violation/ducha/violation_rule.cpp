#include "violation_rule.hpp"

#include "common/log.hpp"

namespace FLOW {

//
// DuchaViolationRule
//
DuchaViolationRule::DuchaViolationRule(const std::string& id, const std::string& area)
    : id_(id)
    , area_(area)
    , identity_score_(-1)
    , behavior_score_(-1)
    , male_score_(-1)
    , female_score_(-1)
    , mask_score_(-1)
{
}

DuchaViolationRule::DuchaViolationRule(const std::string& id)
    : id_(id)
    , identity_score_(-1)
    , behavior_score_(-1)
    , male_score_(-1)
    , female_score_(-1)
    , mask_score_(-1)
{
}


void DuchaViolationRule::SetIdentities(const std::vector<Identity>& identities)
{
    identities_ = identities;
}

void DuchaViolationRule::SetExceptIdentities(const std::vector<Identity>& all, const std::vector<Identity>& identities)
{
    identities_ = {};
    for (auto& val : all) {
        bool find = false;
        for (auto& val2 : identities) {
            if (val == val2) {
                find = true;
                break;
            }
        }
        if (!find) {
            identities_.push_back(val);
        }
    }
}

void DuchaViolationRule::SetBehaviors(const std::vector<Behavior>& behaviors)
{
    behaviors_ = behaviors;
}

void DuchaViolationRule::SetExceptBehaviors(const std::vector<Behavior>& all, const std::vector<Behavior>& behaviors)
{
    behaviors_ = {};
    for (auto& val : all) {
        bool find = false;
        for (auto& val2 : behaviors) {
            if (val == val2) {
                find = true;
                break;
            }
        }
        if (!find) {
            behaviors_.push_back(val);
        }
    }
}

void DuchaViolationRule::SetSexes(const std::vector<Sex>& sexes)
{
    sexes_ = sexes;
}

void DuchaViolationRule::SetMasks(const std::vector<Mask>& masks)
{
    masks_ = masks;
}

void DuchaViolationRule::SetIdentityScore(float identity_score)
{
    identity_score_ = identity_score;
}

void DuchaViolationRule::SetBehaviorScore(float behavior_score)
{
    behavior_score_ = behavior_score;
}

void DuchaViolationRule::SetMaleScore(float male_score)
{
    male_score_ = male_score;
}

void DuchaViolationRule::SetFemaleScore(float female_score)
{
    female_score_ = female_score;
}

void DuchaViolationRule::SetMaskScore(float mask_score)
{
    mask_score_ = mask_score;
}

std::string DuchaViolationRule::Id()
{
    return id_;
}

bool DuchaViolationRule::CheckArea(const std::string& area)
{
    return area_ == area;
}

bool DuchaViolationRule::CheckIdentity(Identity identity, float identity_score)
{
    if (identities_.empty()) return true;
    if (identity_score_ > 0 && identity_score < identity_score_ ) {
        return false;
    }

    for(auto const& val : identities_) {
        if (val == identity) {
            return true;
        }
    }
    return false;
}

bool DuchaViolationRule::CheckBehavior(Behavior behavior, float behavior_score)
{
    if (behaviors_.empty()) return true;
    if (behavior_score_ > 0 && behavior_score < behavior_score_ ) {
        return false;
    }

    for(auto const& val : behaviors_) {
        if (val == behavior) {
            return true;
        }
    }
    return false;
}

bool DuchaViolationRule::CheckSex(Sex sex, float sex_score)
{
    if (sexes_.empty()) return true;
    if (male_score_ > 0 && sex_score < male_score_ ) {
        return false;
    }
    if (female_score_ > 0 && sex_score < female_score_ ) {
        return false;
    }

    for(auto const& val : sexes_) {
        if (val == sex) {
            return true;
        }
    }
    return false;
}

bool DuchaViolationRule::CheckMask(Mask mask, float mask_score)
{
    if (masks_.empty()) return true;
    if (mask_score_ > 0 && mask_score < mask_score_ ) {
        return false;
    }

    for(auto const& val : masks_) {
        if (val == mask) {
            return true;
        }
    }
    return false;
}

} // namespace FLOW