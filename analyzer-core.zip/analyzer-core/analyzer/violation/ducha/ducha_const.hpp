#ifndef DUCHA_CONST_HPP
#define DUCHA_CONST_HPP

#include <string>
#include <unordered_map>
#include <vector>
#include <unordered_set>

namespace FLOW {

enum Identity
{
    IDENTITY_PEOPLE = 0,
    IDENTITY_LIGHT_BLUE = 1,
    IDENTITY_DARK_BLUE = 2,
    IDENTITY_MAJIA = 3,
    IDENTITY_BLACK = 4,
};

enum Behavior
{
    BEHAVIOR_NORMAL = 0,
    BEHAVIOR_PHONE = 1,
    BEHAVIOR_CALL = 2,
    BEHAVIOR_SMOKE = 3,
    BEHAVIOR_SLEEP = 4,
    BEHAVIOR_CHECK = 5,
};

enum Sex
{
    SEX_MALE = 0,
    SEX_FEMALE = 1,
};

enum Mask
{
    NO_MASK = 0,
    MASK = 1,
    UNKNOWN = 2
};

enum Policy
{
    REPORT = 0,
    NO_REPORT = 1,
    UNION_POLICE = 2
};

static const std::string HWS_CODE("1010");          // 候问室
static const std::string HWSJYJKQ_CODE("1020");     // 候问室警员监控区
static const std::string XWS_CODE("1030");          // 询问室
static const std::string QXS_CODE("1040");          // 枪械室
static const std::string FWCK_CODE("1050");         // 服务窗口
static const std::string JKS_CODE("1060");          // 监控室
static const std::string XXCJS_CODE("1070");        // 信息采集室
static const std::string BJ_QTYZ_CODE("2010");      // 前台验证
static const std::string BJ_ZXGW_CODE("2020");      // 咨询岗位
static const std::string BJ_PWGW_CODE("2030");      // 派位岗位
static const std::string BJ_ZZJQ_CODE("2040");      // 自助检前
static const std::string BJ_ZZJH_CODE("2050");      // 自助检后
static const std::string BJ_QWDDT_CODE("2060");     // 勤务督导台
static const std::string BJ_GZRYTD_CODE("2070");    // 工作人员通道
static const std::string BJ_QZZWCJ_CODE("2080");    // 前置指纹采集
static const std::string BJ_LKHJ_CODE("2090");      // 旅客候检
static const std::string BJ_XLQY_CODE("2100");      // 巡逻区域
static const std::string BJ_JKS_CODE("2110");       // 监控室
static const std::string BJ_BZCK_CODE("2120");      // 办证窗口
static const std::string BJ_MTXC_CODE("2130");      // 码头巡查
static const std::string BJ_XWSLS_CODE("2140");     // 询问审理室
static const std::string BJ_RSXLWPJCS_CODE("2150"); // 人身行李物品检查室
static const std::string BJ_JGCS_CODE("2160");      // 监管场所
static const std::string BJ_LSJGQY_CODE("2170");    // 临时监管区域
static const std::string BJ_QK_CODE("2180");        // 枪库

static const std::string COLLECT_AREA("2010");  // 采集区
static const std::string SUSPECT_AREA("2020");  // 嫌犯区
static const std::string POLICE_AREA("2030");   // 警察区
static const std::string OFFICE_AREA("2040");   // 办公区
static const std::string MASS_AREA("2050");     // 群众区

static const std::string DUCHA_CLASSIFY("ducha_classify"); // 行为服饰type
static const std::string DUCHA_FIGHT("ducha_fight"); // 打架type

static const std::string DUCHA_FIGHT_CODE("3010");
static const std::string DUCHA_WURENJIANGUAN_CODE("3020");
static const std::string DUCHA_SHUIGANG_CODE("3030");
static const std::string DUCHA_DANRENJIANGUAN_CODE("3040");
static const std::string DUCHA_DANREN_CODE("3050");
static const std::string DUCHA_LIGANG_CODE("3060");
static const std::string DUCHA_WEICHUANZHIFU_CODE("3070");
static const std::string DUCHA_SHUIJIAO_CODE("3080");
static const std::string DUCHA_WANSHOUJI_CODE("3090");
static const std::string DUCHA_WANSHOUJIQUNZHONG_CODE("3091");
static const std::string DUCHA_CHOUYAN_CODE("3100");
static const std::string DUCHA_TUOGANG_CODE("3110");
static const std::string DUCHA_YOUREN_CODE("3120");
static const std::string DUCHA_TONGXINGBIESHENXUN_CODE("3130");
static const std::string DUCHA_RENZHENGDUIZHAO_CODE("3930");
static const std::string DUCHA_CHUTUJINGLIZAIWEI_CODE("3940");
static const std::string DUCHA_XUNCHAJINGLIZAIWEI_CODE("3950");
static const std::string DUCHA_RENTOUJISHU_CODE("3960");
static const std::string DUCHA_NOMASK_CODE("3970");

static const std::vector<Identity> ALL_DUCHA_IDENTITIES = {IDENTITY_PEOPLE, IDENTITY_LIGHT_BLUE, IDENTITY_DARK_BLUE, IDENTITY_MAJIA, IDENTITY_BLACK};
static const std::vector<Behavior> ALL_DUCHA_BEHAVIORS = {BEHAVIOR_NORMAL, BEHAVIOR_PHONE, BEHAVIOR_CALL, BEHAVIOR_SMOKE, BEHAVIOR_SLEEP};

static const std::unordered_map<int, std::string> DUCHA_IDENTITY_NAME_MAP{{IDENTITY_PEOPLE,"people"},
                                                                          {IDENTITY_LIGHT_BLUE,"lightBlue"},
                                                                          {IDENTITY_DARK_BLUE,"darkBlue"},
                                                                          {IDENTITY_MAJIA,"maJia"},
                                                                          {IDENTITY_BLACK,"black"}};
static const std::unordered_map<int, std::string> DUCHA_BEHAVIOR_NAME_MAP{{BEHAVIOR_NORMAL,"normal"},
                                                                          {BEHAVIOR_PHONE,"phone"},
                                                                          {BEHAVIOR_CALL,"call"},
                                                                          {BEHAVIOR_SMOKE,"smoke"},
                                                                          {BEHAVIOR_SLEEP,"sleep"},
                                                                          {BEHAVIOR_CHECK,"check"}};
static const std::unordered_map<int, std::string> DUCHA_SEX_NAME_MAP{{SEX_MALE,"male"},
                                                                     {SEX_FEMALE, "female"}};                                                                          
static const std::unordered_map<int, std::string> DUCHA_MASK_NAME_MAP{{NO_MASK,"no_mask"},
                                                                      {MASK,"mask"},
                                                                      {UNKNOWN, "unknown"}};
static const std::unordered_set<std::string> BJ_OFFICE_AREA_SCENE{BJ_QTYZ_CODE, BJ_ZXGW_CODE, BJ_PWGW_CODE, BJ_ZZJQ_CODE, BJ_ZZJH_CODE,
                                                                  BJ_QWDDT_CODE, BJ_GZRYTD_CODE, BJ_QZZWCJ_CODE, BJ_XLQY_CODE, BJ_JKS_CODE,
                                                                  BJ_BZCK_CODE, BJ_MTXC_CODE, BJ_XWSLS_CODE, BJ_RSXLWPJCS_CODE, BJ_JGCS_CODE,
                                                                  BJ_LSJGQY_CODE, BJ_QK_CODE};
}
#endif //DUCHA_CONST_HPP
