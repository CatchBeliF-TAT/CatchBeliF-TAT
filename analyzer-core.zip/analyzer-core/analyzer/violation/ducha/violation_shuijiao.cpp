#include "violation_shuijiao.hpp"

#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "ducha_violation_base.hpp"

namespace FLOW {

//
// ViolationShuijiao
//
class ViolationShuijiao : public DuchaViolationClassifyBase
{
public:
    ViolationShuijiao(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg);
    virtual ~ViolationShuijiao()=default;

public:
    virtual FrameResult get_frame_result(const ChannelId2ImageMap& infos);
    
protected:
    const spDuchaViolationConfig    cfg_;
};

ViolationShuijiao::ViolationShuijiao(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg)
    : DuchaViolationClassifyBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    is_camera_related_ = false;

    auto& scene = cfg_->violation_cfg_->scene_id();
    std::string detect_area;
    if (scene == FWCK_CODE || scene == JKS_CODE) {
        detect_area = POLICE_AREA;
    } else if (scene == BJ_JKS_CODE || scene == BJ_GZRYTD_CODE || scene == BJ_RSXLWPJCS_CODE
                || scene == BJ_XWSLS_CODE || scene == BJ_JGCS_CODE || scene == BJ_LSJGQY_CODE) {
        detect_area = OFFICE_AREA;
    } else {
        LOG(FATAL) << "invalid scene id : " << scene << " for model : " << violation_id;
    }

    auto police = std::make_shared<DuchaViolationRule>("police", detect_area);
    police->SetBehaviors({BEHAVIOR_SLEEP});
    rules_.push_back(police);
}

FrameResult ViolationShuijiao::get_frame_result(const ChannelId2ImageMap& infos)
{
    FrameResult result;
    for (auto& info : infos){
        auto camera_count = count({{info.first, info.second}}, cfg_->cameras_);
        if (camera_count["police"] > 0 ) {
            result.violatives[info.first] = true;
        }
    }

    return result;
}

//
// ViolationShuijiaoFactory
//
ViolationShuijiaoFactory::ViolationShuijiaoFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<DuchaViolationConfig>(cfg))
{
}

const std::string& ViolationShuijiaoFactory::id()const
{
    return id_;
}

spIViolation ViolationShuijiaoFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationShuijiao>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(DUCHA_SHUIJIAO_CODE, Shuijiao);

} // namespace FLOW
