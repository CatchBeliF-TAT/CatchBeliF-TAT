#include "ducha_violation_base.hpp"

#include <memory>

#include "common/log.hpp"
#include "common/helper.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_event.pb.h"

#include "violation_rule.hpp"
#include "violation/violation_util.hpp"

namespace FLOW {

class ICAlgEngine;

//
// DuchaViolationConfig
//
DuchaViolationConfig::DuchaViolationConfig(const std::string& json)
{
    auto result = this->ParseJson(json);
    CHECK(result);
}

bool DuchaViolationConfig::ParseJson(const std::string& json) {
    std::string err;
    violation_cfg_ = std::make_shared<inference::DuchaViolationConfig>();
    LOG(INFO) << "json: " << json;
    json2pb(json, violation_cfg_.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }

    // validate config
    const auto& cfg = *violation_cfg_;
    if (cfg.task_id().empty()) {
        LOG(WARNING) << "empty task id";
        return false;
    }
    if (cfg.scene_id().empty()) {
        LOG(WARNING) << "empty scene id";
        return false;
    }

    // 最新需求20210914，引擎不再对行为时长和冷却时间进行校验
    // if (cfg.duration() < 10 || cfg.duration() > 3600) {
    //     LOG(WARNING) << "duration should between [10, 3600]";
    //     return false;
    // }
    // if (cfg.postpone() < 10 || cfg.postpone() > 3600) {
    //     LOG(WARNING) << "postpone should between [10, 3600]";
    //     return false;
    // }
    // if (cfg.duration() > cfg.postpone()) {
    //     LOG(WARNING) << "duration must <= postpone";
    //     return false;
    // }

    cameras_.clear();
    if (cfg.cameras_size() <= 0) {
        LOG(WARNING) << "empty cameras";
        return false;       
    }
    for (int i=0; i<cfg.cameras_size(); i++) {
        const auto& cam = cfg.cameras(i);
        DuchaViolationCamera camera;
        camera.id = cam.id();
        if (camera.id.empty()) {
            LOG(WARNING) << "empty camera id";
            return false;
        }
        
        for (int j=0; j<cam.areas_size(); j++) {
            const auto& area = cam.areas(j);
            DuchaViolationArea v_area;
            v_area.id = area.id();
            v_area.name = area.name();
            if (v_area.id.empty()) {
                LOG(WARNING) << "empty area id";
                return false;
            }

            // TODO!!! check all needed areas base on different scene id

            auto scope_size = area.scope_size();
            if (scope_size %2 !=0 || scope_size < 6) {
                LOG(WARNING) << "scope length should be even and >= 6";
                return false;
            }
            std::copy_n(area.scope().begin(), scope_size, std::back_inserter(v_area.scope));
            camera.areas.push_back(v_area);
        }
        cameras_[camera.id] = camera;
    }
    return true;
}

//
// DuchaViolationBase
//
DuchaViolationBase::DuchaViolationBase(int object_id, const std::string& violation_id, const spDuchaViolationConfiguration& violation_cfg)
    : violation_id_(violation_id)
    , violation_cfg_(violation_cfg)
{
    for (int i=0; i<violation_cfg_->cameras_size(); i++) {
        channel_ids_.push_back(violation_cfg_->cameras(i).id());
    }

    threshold_ = violation_cfg_->threshold();
    if (threshold_ <= 0) {
        threshold_ = 0.8;
    }
}

const std::string& DuchaViolationBase::id() const{
    return violation_id_;
}

result_list_t DuchaViolationBase::check(BoxF& box, const ImageObjectsInfo& objs)
{
    if (!filter(objs)) {
        return result_list_t();
    }

    if (channel_ids_.size() > 0) {
        // 数据齐了就推理，然后清空，之后可用更好方案取代
        channel_image_map_[objs.channel_id] = std::make_shared<ImageObjectsInfo>(objs);
        if (channel_image_map_.size() != channel_ids_.size()){
            return result_list_t();
        }
        for(auto& id : channel_ids_){
            if (channel_image_map_.find(id) == channel_image_map_.end()) {
                return result_list_t();
            }
        }

        auto retv = process(box, channel_image_map_);
        channel_image_map_.clear();
        return std::move(retv);
    }

    return result_list_t();
}

void clear_expired_frame_result(std::list<FrameResult>& result, int duration) {
    if (result.size() <= 0) {
        return;
    }
    auto last = result.back().time;
    for (auto iter = result.begin(); iter != result.end();) {
        auto diff = last - iter->time;
        if (diff.count() > duration){
            iter = result.erase(iter);
        } else {
            // no need go through all data because it is sorted by time
            // the rest data will surely in duration
            break;
        }
    }
}

//
// DuchaViolationFrameBase
//
DuchaViolationFrameProcessBase::DuchaViolationFrameProcessBase(int object_id, const std::string& violation_id, const spDuchaViolationConfiguration& violation_cfg)
    : DuchaViolationBase(object_id, violation_id, violation_cfg)
    , is_camera_related_(false)
    , need_filter_static_(false)
{
}

result_list_t DuchaViolationFrameProcessBase::process(BoxF& box, const ChannelId2ImageMap& infos)
{
    auto result = get_frame_result(infos);
    auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
    result.time = now;
    frame_result_.push_back(result);

    if (is_camera_related_) {
        if (result.violative) {
            snapshots_ = infos;
        }
    } else {
        for (auto& violative : result.violatives) {
            if (violative.second) {
                snapshots_ = infos;
                break;
            }
        }
    }

    auto diff = now - frame_result_.front().time;
    if (diff.count() < violation_cfg_->duration()*1000) {
        return result_list_t();
    }

    diff = now - last_alarm_time_;
    if (diff.count() < violation_cfg_->postpone()*1000) {
        clear_expired_frame_result(frame_result_, violation_cfg_->duration()*1000);
        return result_list_t();
    }

    bool send_alarm = false;
    if (is_camera_related_) {
        float count = 0;
        for (auto& res : frame_result_) {
            if (res.violative) {
                count++;
            }
        }
        LOG(INFO) << "task : " << violation_cfg_->task_id()
                  << ", model : " << violation_cfg_->code()
                  << ", count : " << count << " / " << frame_result_.size()
                  << ", ratio : " << count/frame_result_.size()
                  << ", threshold : " << threshold_;
        if (count/frame_result_.size() > threshold_) {
            send_alarm = true;
        }
    } else {
        std::unordered_map<std::string, float> counts;
        for (auto& res : frame_result_) {
            for (auto& violative : res.violatives) {
                if (violative.second) {
                    counts[violative.first]++;
                }
            }
        }

        for (auto& channel : channel_ids_) {
            LOG(INFO) << "task : " << violation_cfg_->task_id()
                      << ", model : " << violation_cfg_->code()
                      << ", stream : " << channel
                      << ", count : " << counts[channel] << " / " << frame_result_.size()
                      << ", ratio : " << counts[channel]/frame_result_.size()
                      << ", threshold : " << threshold_;
            if (counts[channel]/frame_result_.size() > threshold_) {
                send_alarm = true;
                break;
            }
        }
    }

    clear_expired_frame_result(frame_result_, violation_cfg_->duration()*1000);

    if (send_alarm){
        if (need_filter_static_ && filter_static(infos)) {
            LOG(INFO) << "try to send alarm for : " << violation_cfg_->task_id()
                      << ", at " << now.time_since_epoch().count()
                      << ", but ignored due to static filter";
            return result_list_t();
        }

        LOG(INFO) << "send alarm for task : " << violation_cfg_->task_id()
                  << ", at " << now.time_since_epoch().count();
        last_alarm_time_ = now;
        return get_results(snapshots_);
    }
    return result_list_t();
}

//
// DuchaViolationClassifyBase
//
DuchaViolationClassifyBase::DuchaViolationClassifyBase(int object_id, const std::string& violation_id, const spDuchaViolationConfiguration& violation_cfg)
    : DuchaViolationFrameProcessBase(object_id, violation_id, violation_cfg)
{
}

std::unordered_map<std::string, int> DuchaViolationClassifyBase::count(const ChannelId2ImageMap& infos, ChannelId2ViolationCameraMap& cameras)
{
    std::unordered_map<std::string, int> retv;
    for (const auto& cam : cameras) {
        auto image_info = infos.find(cam.first);
        if (image_info == infos.end()) {
            continue;
        }

        for (const auto& detection : image_info->second->ducha_objects) {
            for (const auto& area : cam.second.areas) {
                bool found = false;
                for (const auto& rule : rules_) {
                    if (!rule->CheckArea(area.id)) {
                        continue;
                    }
                    if (!valid_box_center_bottom_in_polygon(detection, area.scope.data(), area.scope.size())) {
                        continue;
                    }
                    if (!rule->CheckIdentity(Identity(detection.ducha_colour.type), detection.ducha_colour.score)) {
                        continue;
                    }
                    if (!rule->CheckBehavior(Behavior(detection.ducha_action.type), detection.ducha_action.score)) {
                        continue;
                    }
                    if (!rule->CheckSex(Sex(detection.ducha_sex.type), detection.ducha_sex.score)) {
                        continue;
                    }
                    if (!rule->CheckMask(Mask(detection.ducha_mask.type), detection.ducha_mask.score)) {
                        continue;
                    }
                    found = true;
                    retv[rule->Id()]++;
                    break;
                }

                if (found) {
                    break;
                }
            }
        }
    }
    return retv;
}

bool DuchaViolationFrameProcessBase::filter_static(const ChannelId2ImageMap& infos)
{
    auto last_infos = last_alarm_infos_;
    last_alarm_infos_ = infos;

    if (last_infos.size() <= 0 || infos.size() <= 0) {
        return false;
    }

    for (auto& info : infos) {
        auto cam_id = info.first;
        auto res = last_infos.find(cam_id);
        if (res == last_infos.end()) {
            return false;
        }

        if (info.second->ducha_objects.size() != 1 && res->second->ducha_objects.size() != 1) {
            return false;
        }

        float average_perimeter = info.second->ducha_objects[0].xmax - info.second->ducha_objects[0].xmin
                                + info.second->ducha_objects[0].ymax - info.second->ducha_objects[0].ymin
                                + res->second->ducha_objects[0].xmax - res->second->ducha_objects[0].xmin
                                + res->second->ducha_objects[0].ymax - res->second->ducha_objects[0].ymin;

        float center1_x = (info.second->ducha_objects[0].xmax + info.second->ducha_objects[0].xmin)/2.0f;
        float center1_y = (info.second->ducha_objects[0].ymax + info.second->ducha_objects[0].ymin)/2.0f;
        float center2_x = (res->second->ducha_objects[0].xmax + res->second->ducha_objects[0].xmin)/2.0f;
        float center2_y = (res->second->ducha_objects[0].ymax + res->second->ducha_objects[0].ymin)/2.0f;

        float distance_x = center2_x-center1_x;
        float distance_y = center2_y-center1_y;
        float distance = sqrt(distance_x*distance_x + distance_y*distance_y);

        if (distance/average_perimeter >= 0.06) {
            return false;
        }
    }

    return true;
}

bool DuchaViolationClassifyBase::filter(const ImageObjectsInfo& objs) {
    return objs.type & DUCHA_DETECT_TYPE;
}

result_list_t DuchaViolationClassifyBase::get_results(const ChannelId2ImageMap& infos) {
    result_list_t retv;

    const auto task_id = violation_cfg_->task_id();
    const auto violation_id = violation_id_;
    const auto scene_id = violation_cfg_->scene_id();
    const auto threshold = threshold_;
    const auto image_infos = infos;
    const auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());

    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event = *retv;
        event.set_event_type(DUCHA_CLASSIFY);
        auto classify_event = event.mutable_ducha_classify_event();
        classify_event->set_task_id(task_id);
        classify_event->set_model_id(violation_id);
        classify_event->set_scene_id(scene_id);
        classify_event->set_threshold(threshold);
        classify_event->set_now(now.time_since_epoch().count());

        for(auto& image_info : image_infos){
            auto& camera_id = image_info.first;
            auto& image = image_info.second;
            auto snapshot = classify_event->add_snapshots();
            snapshot->set_camera_id(camera_id);
            snapshot->set_image(Helper::get_pic(*image->sframe->getMat()));
            
            for(auto& obj : image->ducha_objects){
                auto object = snapshot->add_objects();
                object->set_identity(obj.ducha_colour.type);
                auto identity_name = DUCHA_IDENTITY_NAME_MAP.find(obj.ducha_colour.type);
                if (identity_name != DUCHA_IDENTITY_NAME_MAP.end()) {
                    object->set_identity_name(identity_name->second);
                }
                object->set_identity_score(obj.ducha_colour.score);

                object->set_behavior(obj.ducha_action.type);
                auto behavior_name = DUCHA_BEHAVIOR_NAME_MAP.find(obj.ducha_action.type);
                if (behavior_name != DUCHA_BEHAVIOR_NAME_MAP.end()) {
                    object->set_behavior_name(behavior_name->second);
                }
                object->set_behavior_score(obj.ducha_action.score);

                object->set_sex(obj.ducha_sex.type);
                auto sex_name = DUCHA_SEX_NAME_MAP.find(obj.ducha_sex.type);
                if (sex_name != DUCHA_SEX_NAME_MAP.end()) {
                    object->set_sex_name(sex_name->second);
                }
                object->set_sex_score(obj.ducha_sex.score);

                object->set_mask(obj.ducha_mask.type);
                auto mask_name = DUCHA_MASK_NAME_MAP.find(obj.ducha_mask.type);
                if (mask_name != DUCHA_MASK_NAME_MAP.end()) {
                    object->set_mask_name(mask_name->second);
                }
                object->set_mask_score(obj.ducha_mask.score);

                object->add_box(obj.xmin);
                object->add_box(obj.ymin);
                object->add_box(obj.xmax);
                object->add_box(obj.ymax);
            }
        }

        return retv;
    };

    retv.push_back(action);
    return retv;
}

} // namespace FLOW
