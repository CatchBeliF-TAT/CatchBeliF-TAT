#include "violation_wurenjianguan.hpp"

#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "ducha_violation_base.hpp"

namespace FLOW {

//
// ViolationWurenjianguan
//
class ViolationWurenjianguan : public DuchaViolationClassifyBase
{
public:
    ViolationWurenjianguan(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg);
    virtual ~ViolationWurenjianguan()=default;

public:
    virtual FrameResult get_frame_result(const ChannelId2ImageMap& infos);
    
protected:
    const spDuchaViolationConfig    cfg_;
};

ViolationWurenjianguan::ViolationWurenjianguan(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg)
    : DuchaViolationClassifyBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    is_camera_related_ = true;

    auto& scene = cfg_->violation_cfg_->scene_id();
    if (scene == XWS_CODE || scene == HWSJYJKQ_CODE ) {
        auto people = std::make_shared<DuchaViolationRule>("people", SUSPECT_AREA);
        people->SetIdentities({IDENTITY_PEOPLE});
        rules_.push_back(people);

        auto police1 = std::make_shared<DuchaViolationRule>("police", POLICE_AREA);
        rules_.push_back(police1);

        auto police2 = std::make_shared<DuchaViolationRule>("police", SUSPECT_AREA);
        police2->SetExceptIdentities(ALL_DUCHA_IDENTITIES, {IDENTITY_PEOPLE});
        rules_.push_back(police2);
    } else if (scene == BJ_JGCS_CODE || scene == BJ_LSJGQY_CODE ) {
        auto people = std::make_shared<DuchaViolationRule>("people", MASS_AREA);
        people->SetIdentities({IDENTITY_PEOPLE});
        rules_.push_back(people);

        auto police1 = std::make_shared<DuchaViolationRule>("police", OFFICE_AREA);
        rules_.push_back(police1);

        auto police2 = std::make_shared<DuchaViolationRule>("police", MASS_AREA);
        police2->SetExceptIdentities(ALL_DUCHA_IDENTITIES, {IDENTITY_PEOPLE});
        rules_.push_back(police2);
    } else if (scene == BJ_RSXLWPJCS_CODE ) {
        auto people = std::make_shared<DuchaViolationRule>("people", OFFICE_AREA);
        people->SetIdentities({IDENTITY_PEOPLE});
        rules_.push_back(people);

        auto police = std::make_shared<DuchaViolationRule>("police", OFFICE_AREA);
        police->SetExceptIdentities(ALL_DUCHA_IDENTITIES, {IDENTITY_PEOPLE});
        rules_.push_back(police);
    } else {
        LOG(FATAL) << "invalid scene id : " << scene << " for model : " << violation_id;
    }
}

FrameResult ViolationWurenjianguan::get_frame_result(const ChannelId2ImageMap& infos)
{
    FrameResult result;
    auto frame_count = count(infos, cfg_->cameras_);
    result.violative = false;
    if (frame_count["police"] == 0 && frame_count["people"] > 0) {
        result.violative = true;
    }

    return result;
}

//
// ViolationWurenjianguanFactory
//
ViolationWurenjianguanFactory::ViolationWurenjianguanFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<DuchaViolationConfig>(cfg))
{
}

const std::string& ViolationWurenjianguanFactory::id()const
{
    return id_;
}

spIViolation ViolationWurenjianguanFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationWurenjianguan>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(DUCHA_WURENJIANGUAN_CODE, Wurenjianguan);

} // namespace FLOW
