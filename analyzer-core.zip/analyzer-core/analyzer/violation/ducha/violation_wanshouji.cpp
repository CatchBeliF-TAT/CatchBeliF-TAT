#include "violation_wanshouji.hpp"

#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "ducha_violation_base.hpp"

namespace FLOW {

//
// ViolationWanshouji
//
class ViolationWanshouji : public DuchaViolationClassifyBase
{
public:
    ViolationWanshouji(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg);
    virtual ~ViolationWanshouji()=default;

public:
    virtual FrameResult get_frame_result(const ChannelId2ImageMap& infos);
    
protected:
    const spDuchaViolationConfig    cfg_;
    bool                            conditionnal_wanshouji_;
};

ViolationWanshouji::ViolationWanshouji(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg)
    : DuchaViolationClassifyBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    is_camera_related_ = false;
    conditionnal_wanshouji_ = false;

    auto& scene = cfg_->violation_cfg_->scene_id();
    if (scene == HWS_CODE) {
        auto police = std::make_shared<DuchaViolationRule>("police", SUSPECT_AREA);
        police->SetBehaviors({BEHAVIOR_PHONE});
        rules_.push_back(police);
    } else if (scene == FWCK_CODE) {
        is_camera_related_ = true;
        conditionnal_wanshouji_ = true;

        auto police = std::make_shared<DuchaViolationRule>("police", POLICE_AREA);
        police->SetBehaviors({BEHAVIOR_PHONE});
        rules_.push_back(police);

        auto people = std::make_shared<DuchaViolationRule>("people", MASS_AREA);
        people->SetIdentities({IDENTITY_PEOPLE});
        rules_.push_back(people);
    } else if (scene == HWSJYJKQ_CODE || scene == JKS_CODE
                || scene == XWS_CODE || scene == QXS_CODE) {
        auto police = std::make_shared<DuchaViolationRule>("police", POLICE_AREA);
        police->SetBehaviors({BEHAVIOR_PHONE});
        rules_.push_back(police);
    } else if (scene == BJ_RSXLWPJCS_CODE ) {
        auto police = std::make_shared<DuchaViolationRule>("police", OFFICE_AREA);
        police->SetExceptIdentities(ALL_DUCHA_IDENTITIES, {IDENTITY_PEOPLE});
        police->SetBehaviors({BEHAVIOR_PHONE});
        rules_.push_back(police);
    } else if (scene == BJ_QTYZ_CODE || scene == BJ_QWDDT_CODE || scene == BJ_GZRYTD_CODE
                || scene == BJ_JKS_CODE || scene == BJ_XWSLS_CODE || scene == BJ_JGCS_CODE
                || scene == BJ_BZCK_CODE) {
        auto police = std::make_shared<DuchaViolationRule>("police", OFFICE_AREA);
        police->SetBehaviors({BEHAVIOR_PHONE});
        rules_.push_back(police);
    } else {
        LOG(FATAL) << "invalid scene id : " << scene << " for model : " << violation_id;
    }
}

bool is_violative(std::unordered_map<std::string, int>& data, bool conditionnal){
    if (conditionnal) {
        if (data["police"] > 0 && data["people"] > 0) {
            return true;
        }
    } else {
        if (data["police"] > 0 ) {
            return true;
        }
    }
    return false;
}

FrameResult ViolationWanshouji::get_frame_result(const ChannelId2ImageMap& infos)
{
    FrameResult result;
    if (is_camera_related_) {
        auto frame_count = count(infos, cfg_->cameras_);
        result.violative = is_violative(frame_count, conditionnal_wanshouji_);
    } else {
        for (auto& info : infos){
            auto camera_count = count({{info.first, info.second}}, cfg_->cameras_);
            result.violatives[info.first] = is_violative(camera_count, conditionnal_wanshouji_);
        }
    }
    
    return result;
}

//
// ViolationWanshoujiFactory
//
ViolationWanshoujiFactory::ViolationWanshoujiFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<DuchaViolationConfig>(cfg))
{
}

const std::string& ViolationWanshoujiFactory::id()const
{
    return id_;
}

spIViolation ViolationWanshoujiFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationWanshouji>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(DUCHA_WANSHOUJI_CODE, Wanshouji);

} // namespace FLOW
