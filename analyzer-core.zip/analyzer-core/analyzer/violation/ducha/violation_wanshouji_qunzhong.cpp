#include "violation_wanshouji_qunzhong.hpp"

#include <iterator>

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "ducha_violation_base.hpp"

namespace FLOW {

//
// ViolationWanshoujiqunzhong
//
class ViolationWanshoujiqunzhong : public DuchaViolationClassifyBase
{
public:
    ViolationWanshoujiqunzhong(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg);
    virtual ~ViolationWanshoujiqunzhong()=default;

public:
    virtual FrameResult get_frame_result(const ChannelId2ImageMap& infos);
    
protected:
    const spDuchaViolationConfig    cfg_;
};

ViolationWanshoujiqunzhong::ViolationWanshoujiqunzhong(int object_id, const std::string& violation_id, const spDuchaViolationConfig& cfg)
    : DuchaViolationClassifyBase(object_id, violation_id, cfg->violation_cfg_)
    , cfg_(cfg)
{
    is_camera_related_ = false;

    auto& scene = cfg_->violation_cfg_->scene_id();
    if (scene == BJ_XWSLS_CODE || scene == BJ_JGCS_CODE || scene == BJ_LSJGQY_CODE ) {
        auto people = std::make_shared<DuchaViolationRule>("people", OFFICE_AREA);
        people->SetBehaviors({BEHAVIOR_PHONE});
        rules_.push_back(people);
    } else if (scene == BJ_RSXLWPJCS_CODE ) {
        auto people = std::make_shared<DuchaViolationRule>("people", OFFICE_AREA);
        people->SetIdentities({IDENTITY_PEOPLE});
        people->SetBehaviors({BEHAVIOR_PHONE});
        rules_.push_back(people);
    } else {
        LOG(FATAL) << "invalid scene id : " << scene << " for model : " << violation_id;
    }
}

FrameResult ViolationWanshoujiqunzhong::get_frame_result(const ChannelId2ImageMap& infos)
{
    FrameResult result;
    for (auto& info : infos){
        auto camera_count = count({{info.first, info.second}}, cfg_->cameras_);
        if (camera_count["people"] > 0 ) {
            result.violatives[info.first] = true;
        }
    }
    
    return result;
}

//
// ViolationWanshoujiqunzhongFactory
//
ViolationWanshoujiqunzhongFactory::ViolationWanshoujiqunzhongFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<DuchaViolationConfig>(cfg))
{
}

const std::string& ViolationWanshoujiqunzhongFactory::id()const
{
    return id_;
}

spIViolation ViolationWanshoujiqunzhongFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationWanshoujiqunzhong>(obj.uid, id_, cfg_);
    } else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(DUCHA_WANSHOUJIQUNZHONG_CODE, Wanshoujiqunzhong);

} // namespace FLOW
