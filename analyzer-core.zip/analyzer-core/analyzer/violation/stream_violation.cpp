#include <set>
#include <memory>

#include "common/log.hpp"
#include "common/tad_internal.hpp"
#include "object_violation_factory.hpp"
#include "stream_violation.hpp"

using namespace std;
namespace FLOW {

int CStreamViolation::AddViolation(const std::string& violation_id, const std::string& config)
{
    if (factory_.get()==NULL) {
        factory_ = std::make_shared<ObjectViolationsFactory>();
    }
    factory_->AddViolation(violation_id, config);
    BoxF pic;
    auto x = factory_->CreateViolations(pic, violation_id);
    if (!x->GetViolations().empty()) {
        pic_violations_[violation_id] = x;
    }
    return 0;
}

int CStreamViolation::RemoveViolation(const std::string& violation_id)
{
    if (factory_.get()) {
        factory_->RemoveViolation(violation_id);
    }
    pic_violations_.erase(violation_id);
    return 0;
}

result_list_t CStreamViolation::Check(const ImageObjectsInfo& info)
{
//    LOG(INFO) << info.channel_id;
    result_list_t retv;
    // process pic violation
    auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
    for (auto& pic_violation : pic_violations_){
        // skip
        if (nullptr == pic_violation.second.get()) {
            continue;
        }
        const auto& violation_id = pic_violation.first;
        // check ptz
        if (info.ptz_pos.changed) {
            // recrate all pic violations
            pic_violation.second = factory_->CreateViolations(violation_id);
            continue;
        }
        if (info.fake_objects) {
            continue;
        }
        // check active time
        auto& violationVec = pic_violation.second->GetViolations();
        if (factory_->CheckActiveTime(violation_id, now)) {
            if (violationVec.empty()) {
                violationVec.swap(factory_->CreateViolations(violation_id)->GetViolations());
            }
        } else {
            if (!violationVec.empty()) {
                violationVec.clear();
            }
        }
        // check
        BoxF empty_box;
        for (auto& sub_violation : violationVec) {
            // check ptz
            if (!sub_violation->check_ptz(info)) {
                continue;
            }
            auto results = sub_violation->check(empty_box, info);
            retv.insert(retv.end(), results.begin(), results.end());
        }
    }

    // check ptz
    if (info.ptz_pos.changed) {
        cars_.clear();
    }
    // skip fake objects frames
    if (info.fake_objects) {
        return std::move(retv);
    }
    // process object violation
    for (auto &obj : info.objects){
        if (obj.delete_flag) {
            cars_.erase(obj.uid);
            continue;
        }
        if (obj.uid == -1) {
            continue;
        }
        auto objInfo = cars_.find(obj.uid);
        if (objInfo == cars_.end()){
            // appear new object
            cars_[obj.uid] = factory_->CreateViolations(obj, now);
            objInfo = cars_.find(obj.uid);
        }
        // process check
        for (auto violation : objInfo->second->GetViolations()) {
            if (!violation)
                continue;
            if (!violation->check_ptz(info)) {
                continue;
            }
            auto results = violation->check(const_cast<BoxF&>(obj), info);
            retv.insert(retv.end(), results.begin(), results.end());
        }
    }

    return std::move(retv);
}

} // namespace FLOW
