#ifndef VSS_VIOLATION_GUARDRAIL_GUARDRAIL_HPP
#define VSS_VIOLATION_GUARDRAIL_GUARDRAIL_HPP

#include <serving/violation_config.pb.h>
#include "violation/traffic/violation_common.hpp"

namespace inference {
class ViolationConfig;
}

namespace FLOW {

class ViolationGuardrailConfig {
 public:
  ViolationGuardrailConfig(const std::string& json);
  bool ParseJson(const std::string& json);

 public:
  std::shared_ptr<inference::ViolationConfig> data_;
  std::string code_;
  bool enable_output_picture_;
  std::vector<float> violate_box_;
  int cooling_second_;
  int parking_second_;
  float guardrail_thresh_;
};

typedef std::shared_ptr<ViolationGuardrailConfig> spViolationGuardrailConfig;

class ViolationGuardrailFactory : public ViolationCommonFactory {
 public:
  ViolationGuardrailFactory(const std::string& id, const std::string& cfg);
  virtual ~ViolationGuardrailFactory() = default;

 public:
  virtual const std::string& id() const;
  virtual spIViolation CreateIViolation(const BoxF& obj);

 protected:
  std::string id_;
  spViolationGuardrailConfig cfg_;
};

}  // namespace FLOW
#endif  // VSS_VIOLATION_DEBUG_HPP
