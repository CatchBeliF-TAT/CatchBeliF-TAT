#include "violation_guardrail.hpp"

#include <memory>
#include <unordered_map>

#include "common/helper.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation/violation_util.hpp"
#include "violation_guardrail_base.hpp"

namespace FLOW {

using namespace std;
static const std::string FLOW_GUARDRAIL_CODE("2460");
static const std::string FLOW_GUARDRAIL2_CODE("2461");

ViolationGuardrailConfig::ViolationGuardrailConfig(const std::string& json)
    : guardrail_thresh_(0.5)
    , cooling_second_(600)
    , parking_second_(60)
{
  std::string err;
  auto violation_cfg = std::make_shared<inference::ViolationConfig>();
  json2pb(json, violation_cfg.get(), &err);
  if (!err.empty()) {
    LOG(WARNING) << err << ", json= " << json;
    return;
  }
  auto& cfg = *violation_cfg;
  const int MIN_SIZE = 2 * 3;
  cooling_second_ =
      cfg.has_cooling_second() ? cfg.cooling_second() : cooling_second_;
  for (int i = 0; i < cfg.conditions_size(); i++) {
    const auto& cond = cfg.conditions(i);
    if (cond.name() == "violate_box") {
      CHECK_GE(cond.data_size(), MIN_SIZE);
      std::copy_n(cond.data().begin(), cond.data_size() / 2 * 2,
                  std::back_inserter(violate_box_));
      if (cond.has_threshold()) { // get guardrail thresh
          guardrail_thresh_ = cond.threshold();
      }
      if (cond.has_parking_second()) { // get parking_second
          parking_second_ = cond.parking_second();
      }
    }
  }
  enable_output_picture_ = cfg.enable_output_picture();
  data_ = violation_cfg;
}

class ViolationGuardrailClassify : public ViolationGuardrailBase {
 public:
  ViolationGuardrailClassify(int object_id, const std::string& violation_id,
                              const spViolationGuardrailConfig cfg)
      : ViolationGuardrailBase(object_id, violation_id, cfg->data_)
      , cfg_(cfg)
      , is_cooling_(false)
  {}
  virtual ~ViolationGuardrailClassify() = default;

 public:
  virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
  virtual result_list_t get_results() const;

 protected:
  const spViolationGuardrailConfig cfg_;
  bool is_cooling_;
  std::string stream_id_;
  VecFloat    max_scores_;
};

class ICAlgEngine;

result_list_t ViolationGuardrailClassify::get_results() const {
  result_list_t retv;
  const auto obj_id = object_id_;
  const auto stream_id = snapshots_[0].image->channel_id;
  const auto violation_code = cfg_->data_->code();
  const auto violation_name = cfg_->data_->name();
  const auto violation_id = violation_id_;
  const auto snapshots = snapshots_;
  const auto enable_output_picture = cfg_->enable_output_picture_;
  // const auto enable_save_picture = cfg_->data_->enable_save_debug_picture();
  auto action = [=](ICAlgEngine* engine) -> spEventProto {
    auto retv = std::make_shared<inference::Event>();
    inference::Event& event_with_type = *retv;
    event_with_type.set_event_type(get_event_type_form_code(violation_code));
    inference::ViolationEvent& guardrailEvent =
        *(event_with_type.mutable_traffic_event());
    guardrailEvent.set_stream_id(stream_id);
    guardrailEvent.set_violation_id(violation_id);
    guardrailEvent.set_violation_code(violation_code);
    for (int i = 0; i < snapshots.size(); i++) {
      auto& image = snapshots[i].image;
      auto snap1 = guardrailEvent.add_snapshots();
      snap1->set_now(snapshots[i].now.time_since_epoch().count());
      if (enable_output_picture) {
        snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
      }

      for (auto& box : image->objects) {
        auto obj = snap1->add_objects();
        std::stringstream buff;
        buff << "guardrail";
        obj->set_type(buff.str());
        obj->set_score(box.score);
        obj->add_box(box.xmin);
        obj->add_box(box.ymin);
        obj->add_box(box.xmax);
        obj->add_box(box.ymax);
      }
    }

    return retv;
  };
  retv.push_back(action);
  return retv;
}

result_list_t ViolationGuardrailClassify::check(BoxF& box,
                                                const ImageObjectsInfo& objs) {
  // set violate_state
  if (objs.guardrails.guardrails.count(violation_id_) == 0) {
    return result_list_t{};
  }
  const auto& guardrails = objs.guardrails.guardrails.find(violation_id_)->second;
  std::for_each(guardrails.cbegin(),
                guardrails.cend(),
                [this](const BoxF& one){
                  if (one.score < 0){
                    one.violate_state = 0;
                  } else if (one.score < cfg_->guardrail_thresh_) {
                    one.violate_state = 2;
                  } else {
                    one.violate_state = 1;
                  }
                }
  );

  result_list_t retv;
  if (this->is_cooling_) {
    if (get_elapsed_time(objs).count() < cfg_->cooling_second_ * 1000) {
      return retv;
    } else {
      this->is_cooling_ = false;
      this->clear_snapshot();
    }
  }
  if (this->snapshots_.empty()) {
      this->add_snapshot(BoxF(), objs);
  }
  // update max_scores
  this->max_scores_.resize(guardrails.size());
  std::transform(guardrails.cbegin(),
                guardrails.cend(),
                this->max_scores_.cbegin(),
                this->max_scores_.begin(),
                [this](const BoxF& one, const float max_score)->float{
                    return std::max(max_score, one.score);
                }
  );
  // calculate on parking_second_
  if (get_elapsed_time(objs).count() > cfg_->parking_second_ * 1000) {
    VecBoxF inBoxes;
    std::transform(guardrails.cbegin(),
                  guardrails.cend(),
                  this->max_scores_.cbegin(),
                  std::back_inserter(inBoxes),
                  [this](const BoxF& one, const float max_score)->BoxF {
                    BoxF copyOne(one);
                    copyOne.score = max_score;
                    return std::move(copyOne);
                  }
    );
    // clear max_scores_
    this->max_scores_.clear();

    VecBoxF outBoxes;
    std::copy_if(inBoxes.cbegin(),
                inBoxes.cend(),
                std::back_inserter(outBoxes), [this](const BoxF& one) {
                  return one.score > 0 && one.score < cfg_->guardrail_thresh_;
                }
    );
    this->clear_snapshot();
    this->add_snapshot(BoxF(), objs);
    if (outBoxes.size() > 0) {
      this->is_cooling_ = true;
      this->snapshots_.back().image->objects = outBoxes;
      return get_results();
    } else {
      this->snapshots_.back().image->objects.clear();
      this->snapshots_.back().image = CloneWithoutImage(this->snapshots_.back().image);
    }
  }

  return retv;
}

ViolationGuardrailFactory::ViolationGuardrailFactory(const std::string& id,
                                                       const std::string& cfg)
    : ViolationCommonFactory(id, cfg),
      id_(id),
      cfg_(std::make_shared<ViolationGuardrailConfig>(cfg)) {}

const std::string& ViolationGuardrailFactory::id() const { return id_; }

spIViolation ViolationGuardrailFactory::CreateIViolation(const BoxF& obj) {
  if (obj.label == -1) {
    return std::make_shared<ViolationGuardrailClassify>(obj.uid, id_, cfg_);
  } else {
    return nullptr;
  }
}

REGISTER_VIOLATION(FLOW_GUARDRAIL_CODE, Guardrail);
REGISTER_VIOLATION(FLOW_GUARDRAIL2_CODE, Guardrail);

}  // namespace FLOW
