/*
 * @Author: your name
 * @Date: 2021-01-06 16:05:43
 * @LastEditTime: 2021-03-24 16:27:55
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /analyzer-flow/analyzer/violation/sharedbike/violation_sharedbike.hpp
 */
#ifndef VSS_VIOLATION_SHAREDBIKE_HPP
#define VSS_VIOLATION_SHAREDBIKE_HPP

#include <vector>
#include <unordered_map>
#include "violation/traffic/violation_common.hpp"
#include "violation_sharedbike_base.hpp"

namespace inference {
    class ViolationConfig;
}

namespace FLOW {

class ViolationSharedBikeConfig {
public:
    ViolationSharedBikeConfig(const std::string& json);
    bool ParseJson(const std::string& json);

public:
    std::shared_ptr<inference::ViolationConfig> data_;
    int                                         cooling_time_;
    int                                         parking_second_;
    int                                         count_;
    float                                       threshold_;

    std::vector<float>                          sharedbike_areas_;
    std::vector<int>                            sharedbike_areas_offset_;

};
typedef std::shared_ptr<ViolationSharedBikeConfig> spViolationSharedBikeConfig;


class ViolationSharedBikeFactory : public ViolationCommonFactory 
{
public:
    ViolationSharedBikeFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationSharedBikeFactory()=default;

public:
    virtual const std::string&  id()const;
    virtual spIViolation        CreateIViolation(const BoxF& obj);

protected:
    std::string                                 id_;
    spViolationSharedBikeConfig                cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_SHAREDBIKE_HPP