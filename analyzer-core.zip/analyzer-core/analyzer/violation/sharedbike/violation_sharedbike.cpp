#include "violation_sharedbike.hpp"

#include <chrono>
#include <iterator>
#include <numeric>
#include <vector>
#include <fstream>
#include <sys/stat.h>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation/violation_util.hpp"


namespace FLOW {



ViolationSharedBikeConfig::ViolationSharedBikeConfig(const std::string& json)
    : cooling_time_(600)
    , parking_second_(60)
    , count_(1)
    , threshold_(0.0f)
{
    auto result = this->ParseJson(json);
    CHECK(result);
}

bool ViolationSharedBikeConfig::ParseJson(const std::string& json) {
    std::string err;
    auto violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }

    const auto& cfg = *violation_cfg;
    const double MIN_AREA_SIZE = 100;
    cooling_time_ = cfg.has_cooling_second() ? cfg.cooling_second() : cooling_time_;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "violate_box"){
            //parse "data"
            const int MIN_SIZE = 3*2;
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data().size()/2*2, std::back_inserter(sharedbike_areas_));
            std::copy_n(cond.data_offset().begin(), cond.data_offset().size()/2*2, std::back_inserter(sharedbike_areas_offset_));
            if (sharedbike_areas_offset_.empty() && !sharedbike_areas_.empty()) {
                sharedbike_areas_offset_.push_back(sharedbike_areas_.size());
            }
            if (cond.has_nonmotor_count()){
                count_ = cond.nonmotor_count();
            }
            if (cond.has_threshold()){
                threshold_ = cond.threshold();
            }
            if (cond.has_parking_second()) {
                parking_second_ = cond.parking_second();
            }
        }
    }
    
    data_ = violation_cfg;
    return true;
}

class ViolationSharedBike : public ViolationSharedBikeBase {
public:
    ViolationSharedBike(int object_id, const std::string& violation_id, const spViolationSharedBikeConfig cfg);
    virtual ~ViolationSharedBike()=default;
    
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
    virtual result_list_t get_results()const;
    void                  log_info(const ImageObjectsInfo& objs) const;
    int                   calculate_sharedbike_number(const VecBoxF& objs)const;
    VecBoxF               filter_sharedbike(const VecBoxF& objs)const;

protected:
    const spViolationSharedBikeConfig                   cfg_;
};

ViolationSharedBike::ViolationSharedBike(int object_id, const std::string& violation_id, const spViolationSharedBikeConfig cfg)
    : ViolationSharedBikeBase(object_id, violation_id, cfg->data_)
    , cfg_(cfg)
{
}


int ViolationSharedBike::calculate_sharedbike_number(const VecBoxF& objs) const{
    int number_in_area = 0;
    for(auto obj: objs){
        for (size_t i=0, offset=0; i<cfg_->sharedbike_areas_offset_.size(); offset+=cfg_->sharedbike_areas_offset_[i],i++) {
            const size_t offset_end = cfg_->sharedbike_areas_offset_[i];
            if (valid_box_center_in_polygon(obj, &cfg_->sharedbike_areas_[offset], offset_end-offset) &&
                obj.score >= cfg_->threshold_) {
                number_in_area++;
                break;
            }
        }
    }
    return number_in_area;
}

VecBoxF ViolationSharedBike::filter_sharedbike(const VecBoxF& objs) const{
    VecBoxF out;
    for(auto obj: objs){
        for (size_t i=0, offset=0; i<cfg_->sharedbike_areas_offset_.size(); offset+=cfg_->sharedbike_areas_offset_[i],i++) {
            const size_t offset_end = cfg_->sharedbike_areas_offset_[i];
            if (valid_box_center_in_polygon(obj, &cfg_->sharedbike_areas_[offset], offset_end-offset) &&
                obj.score >= cfg_->threshold_) {
                out.push_back(obj);
                break;
            }
        }
    }
    return std::move(out);
}


result_list_t ViolationSharedBike::check(BoxF& box, const ImageObjectsInfo& objs)
{
    result_list_t retv;
    auto diff = get_elapsed_time(objs);
    if (snapshots_.empty()) {
        auto count = calculate_sharedbike_number(objs.sharedbike_objs.objs);
        if (count >= cfg_->count_) {
            snapshots_.clear();
            log_info(objs);
            this->add_snapshot(BoxF(), objs);
            this->snapshots_.back().image->objects = filter_sharedbike(objs.sharedbike_objs.objs);
        }
    } else if (snapshots_.size() == 1){
        auto count = calculate_sharedbike_number(objs.sharedbike_objs.objs);
        if (count < cfg_->count_) {
            snapshots_.clear();
        } else if (diff.count()>=cfg_->parking_second_*1000) {
            log_info(objs);
            this->add_snapshot(BoxF(), objs);
            this->snapshots_.back().image->objects = filter_sharedbike(objs.sharedbike_objs.objs);
            retv = get_results();
        } else {
            // waiting
        }
    } else { // coooling
        if (diff.count() >= cfg_->cooling_time_*1000) {
            snapshots_.clear();
        }
    }
    return retv;
}

void ViolationSharedBike::log_info(const ImageObjectsInfo& objs) const{
    LOG(INFO) <<"==> violation_id: " << this->violation_id_ 
                <<", violation code: "<< violation_cfg_->code()
                <<", stream_id: " << objs.channel_id
                <<", status: " << snapshots_.size()
                <<", SharedBike_total_number: "<< objs.sharedbike_objs.objs.size();
}

result_list_t ViolationSharedBike::get_results()const{
    result_list_t retv;
    const auto obj_id = object_id_;
    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = violation_cfg_->code();
    const auto violation_name = violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;
    const auto enable_output_picture = violation_cfg_->enable_output_picture();
    const auto enable_save_picture = violation_cfg_->enable_save_debug_picture();
    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event_with_type = *retv;
        event_with_type.set_event_type(get_event_type_form_code(violation_code));
        //warning
        inference::ViolationEvent& event = *(event_with_type.mutable_traffic_event());
        event.set_stream_id(stream_id);
        event.set_obj_id(obj_id);
        event.set_violation_id(violation_id);
        event.set_violation_code(violation_code);
        event.set_violation_name(violation_name);

        for(int i=0;i<snapshots.size();i++){
            auto& image = snapshots[i].image;
            auto snap1 = event.add_snapshots();
            snap1->set_now(snapshots[i].now.time_since_epoch().count());
            if (enable_output_picture){
                snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
            }
            // add objects
            for(auto& box : image->objects) {
                auto obj = snap1->add_objects();
                obj->set_type(std::to_string(box.label));
                obj->set_score(box.score);
                obj->add_box(box.xmin);
                obj->add_box(box.ymin);
                obj->add_box(box.xmax);
                obj->add_box(box.ymax);
            }

            if (enable_save_picture){
                std::stringstream buff;
                buff <<stream_id <<"/pic_" << violation_id << "_" << obj_id <<"_" << i <<".jpg";
                auto fname = buff.str();
                std::ofstream of;
                mkdir(stream_id.c_str(),0755);
                of.open(fname);
                std::vector<unsigned char> im_data;
                cv::imencode(".jpg", *(image->sframe->getMat()), im_data);
                of.write((const char*)im_data.data(),im_data.size());
                LOG(INFO)<<"==>pic result "<<fname <<","<<of.is_open()<<","<<of.tellp();
                of.close();
            }
        }

        return retv;
    };
    retv.push_back(action);
    return retv;
}

//
// ViolationSharedBikeFactory
//
ViolationSharedBikeFactory::ViolationSharedBikeFactory(const std::string& id, const std::string& cfg)
    : ViolationCommonFactory(id, cfg)
    , id_(id)
    , cfg_(std::make_shared<ViolationSharedBikeConfig>(cfg))
{
}

const std::string& ViolationSharedBikeFactory::id()const
{
    return id_;
}

spIViolation ViolationSharedBikeFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationSharedBike>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(XHGXDC_CODE, SharedBike);


} // namespace FLOW
