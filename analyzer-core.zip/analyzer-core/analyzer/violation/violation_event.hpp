#ifndef VSS_VIOLATION_EVENTPROCESS_HPP
#define VSS_VIOLATION_EVENTPROCESS_HPP

#include <string>
#include <memory>
#include <functional>

#include "core/metric.hpp"
#include "violation_interface.hpp"
#include "common/ThreadPool.h"
#include "common/Queue.h"

#include "serving/violation_event.pb.h"
#include "core/stream/stream_manager.hpp"

namespace FLOW {

    class ICAlgEngine;
    typedef std::shared_ptr<ICAlgEngine> spICAlgEngine;
    typedef std::shared_ptr<CStreamManager> spCStreamManager;

    class ViolationEventProcesser{
    private:
        ViolationEventProcesser(const ViolationEventProcesser&);
    public:
        ViolationEventProcesser(spICAlgEngine engine, spCStreamManager streamManger, int thread_num)
            : engine_(engine)
            , streamManger_(streamManger)
            , result_queue_(new Queue<spEventProto>())
            , task_pool_(std::max(thread_num, 1), "EventProc")
        {
        }
        ~ViolationEventProcesser(){
            result_queue_->clear();
        }

    public:
        typedef std::function<spEventProto(ICAlgEngine*)>  task_t;
        void Post(task_t t) {
            if (!t) {
                return;
            }
            Metric::Instance().event_counter->Add({{"type", "total"}}).Increment();
            auto engine = engine_;
            auto result_queue = result_queue_;
            auto streamManger = streamManger_;
            task_pool_.enqueue([t, engine, streamManger, result_queue](){
                auto result = t(engine.get());
                if (result == nullptr ) {
                    Metric::Instance().event_counter->Add({{"type", "drop"}}).Increment();
                    return;
                } else {
                    Metric::Instance().event_counter->Add({{"type", "push"}}).Increment();
                    if (streamManger) { // save video
                        auto event = result;
                        if (event
                            && event->has_traffic_event()
                            && event->traffic_event().snapshots_size() > 0) {
                            static std::atomic<int> UUID(0);
                            auto stream_id = event->traffic_event().stream_id();
                            auto violation_id = event->traffic_event().violation_id();
                            auto uuid = stream_id+violation_id+std::to_string(UUID.fetch_add(1));
                            auto size = event->traffic_event().snapshots_size();
                            auto start = event->traffic_event().snapshots(0).pts();
                            auto end = event->traffic_event().snapshots(size-1).pts();
                            auto path = streamManger->WriteRecordStream(stream_id, start, end, uuid);
                            if (path != "") {
                                event->mutable_traffic_event()->set_video_path(path);
                            }
                        }
                    }
                    result_queue->push(result);
                }
            });
        }

        bool Pop(int timeout, spEventProto& event) {
            if (result_queue_->empty()) {
                return false;
            }
            event.reset();
            if (timeout <0) {
                event = result_queue_->pop();
            }
            else {
                event = result_queue_->pop(timeout);
            }
            if (event != nullptr) {
                Metric::Instance().event_counter->Add({{"type", "pop"}}).Increment();
            }
            return event != nullptr;
        }

    protected:
        typedef Queue<spEventProto>                 ResultEventQueue;
        typedef std::shared_ptr<ResultEventQueue>   spResultEventQueue;

    protected:
        spICAlgEngine                   engine_;
        spCStreamManager                streamManger_;
        spResultEventQueue              result_queue_;
        ThreadPool                      task_pool_;
    };
    typedef std::shared_ptr<ViolationEventProcesser> spViolationEventProcesser;
    typedef std::weak_ptr<ViolationEventProcesser> wpViolationEventProcesser;
} // namespace FLOW
#endif // VSS_VIOLATION_EVENTPROCESS_HPP
