#ifndef VSS_VIOLATION_CONSTRUCTION_BASE_HPP
#define VSS_VIOLATION_CONSTRUCTION_BASE_HPP

#include <memory>
#include <chrono>
#include <vector>
#include <memory>

#include "serving/violation_config.pb.h"
#include "violation/violation_interface.hpp"
#include "violation/violation_registry.hpp"

namespace inference{
    class ViolationConfig;
}

namespace FLOW {

typedef std::shared_ptr<inference::ViolationConfig> spViolationConfig;

class ViolationConstructionBase : public IViolation, public std::enable_shared_from_this<ViolationConstructionBase>
{
public:
    ViolationConstructionBase(int object_id, const std::string& violation_id, const spViolationConfig& violation_cfg)
        : snapshots_()
        , object_id_(object_id)
        , violation_id_(violation_id)
        , violation_cfg_(violation_cfg)
    {}

    virtual ~ViolationConstructionBase()=default;

public:
    virtual const std::string&  id()const { return violation_id_; }
    virtual result_list_t       check(BoxF& box, const ImageObjectsInfo& objs)=0;

protected:
    typedef std::shared_ptr<ImageObjectsInfo> spImageObjectsInfo;
    typedef std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds> sys_milliseconds;
    struct ViolationSnapshot{
        BoxF                box;
        spImageObjectsInfo  image;
        sys_milliseconds    now;
    };

protected:
    virtual size_t          add_snapshot(const BoxF& box, const ImageObjectsInfo& objs) { 
                                const auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
                                snapshots_.push_back(ViolationSnapshot{box, std::make_shared<ImageObjectsInfo>(objs), now});
                                return snapshots_.size();
                            }
    virtual void            clear_snapshot() { snapshots_.clear(); }

protected:
    static void clear_all_img(inference::ViolationEvent* event) {
        if (event) {
            for( auto& snapshot : *event->mutable_snapshots() ) {
                if (snapshot.has_image()) snapshot.set_image("...");
            }
        }
    }

protected:
    const int                             object_id_;
    const std::string                     violation_id_;
    const spViolationConfig               violation_cfg_;
    std::vector<ViolationSnapshot>        snapshots_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_CONSTRUCTION_BASE_HPP
