#include "violation_shigong.hpp"

#include <chrono>
#include <iterator>
#include <numeric>
#include <vector>
#include <fstream>
#include <sys/stat.h>
#include <queue>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation/violation_util.hpp"
#include "violation_construction_base.hpp"
#include "algorithm/construction/construction.hpp"
#include "algorithm/vehicleattribute/vehicle_attr.hpp"
#include "violation/conditions/time_condition.hpp"

#include "core/alg_engine/alg_shigong_engine.hpp"
#define DEFAULT_PERIOD_SECOND 30
#define DEFAULT_COVER_RATIO 0.5
namespace FLOW {

static const std::string XHSGCQ_CODE("2304"); //徐汇施工超期
static const std::string XHSGCQY_CODE("2305"); //徐汇施工超区域
static const std::string XHSGCSD_CODE("2306"); //徐汇施工超时段
static const std::string XHZDSG_CODE("2307"); //徐汇占道施工
static const std::string XHCQYSG_CODE("2308"); //徐汇超区域施工
static const std::string SHIGONG_DEBUG_CODE("2399"); //施工调试

const float DEFAULT_THRESHOLD                 =10;  // 10是所有threshold默认值，可以设置
const float DEFAULT_WORKER_SCORE              =1;   // 下面四个值都是写死的，没法设置
const float DEFAULT_NOWORKER_SCORE            =0;   //非施工人员不计入
const float DEFAULT_LANDMARK_SCORE            =1;
const float DEFAULT_VEHICLE_SCORE             =1;

//有多少种目标
const float TYPE_SIZE                               =8;

ViolationShigongConfig::ViolationShigongConfig(const std::string& json)
    : shigong_areas_threshold_(DEFAULT_THRESHOLD)
    , cooling_time_(10)
    , cooling_interval_(1)
    , report_interval_(0)
    , available_times_()
    , start_time_(0)
    , end_time_(0)
    , score_map_()
    , score_max_map_()
    , score_map_cache_()
    , score_max_map_cache_()
{
    auto result = this->ParseJson(json);

    auto config_data = std::make_shared<inference::ViolationConfig>();
    json2pb(json, config_data.get(), &err_);
    TimeConditionMap time_condition_data = CreateTimeConditionMap(*config_data);
    // add time_condition_
    time_condition_ = std::make_shared<filter_time>();
    time_condition_->fun = [time_condition_data](sys_milliseconds now)->bool {
        if(time_condition_data.empty()) {
            return true;
        }
        auto itr = find_if(time_condition_data.begin(), time_condition_data.end(), [&](const TimeConditionMap::value_type one){
            return one.second.TimeMatch(now);
        });
        return itr!=time_condition_data.end();
    };
    CHECK(result);
}

float ViolationShigongConfig::GetScoreByType(int type, int count) const{
    if (score_map_cache_.count(type) == 0) {
        const auto type_str = Construction::helperConstructionType((Construction::ConstructionType)(type));
        if (score_map_.count(type_str)) {
            score_map_cache_[type] = score_map_.find(type_str)->second;
        } else {
            score_map_cache_[type] = 0.0f;
        }
        if (score_max_map_.count(type_str)) {
            score_max_map_cache_[type] = score_max_map_.find(type_str)->second;
        } else {
            score_max_map_cache_[type] = -1.0f;
        }
    }
    const auto score = score_map_cache_[type]*count;
    return score_max_map_cache_[type]<0 ? score : std::min(score, score_max_map_cache_[type]);
}

bool ViolationShigongConfig::InAreas(const BoxF& box) const{
    for (size_t i=0, offset=0; i<shigong_areas_offset_.size(); offset+=shigong_areas_offset_[i],i++) {
        const size_t offset_end = shigong_areas_offset_[i];
        if (valid_box_center_in_polygon(box, &shigong_areas_[offset], offset_end-offset)) {
            return true;
        }
    }
    return false;
}

bool ViolationShigongConfig::ParseJson(const std::string& json) {
    std::string err;
    auto violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }

    const auto& cfg = *violation_cfg;
    const double MIN_AREA_SIZE = 100;
    cooling_time_ = cfg.cooling_second();
    if(cfg.has_cooling_interval()){
        cooling_interval_ = cfg.cooling_interval();
    }

    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "violate_box" || cond.name() == "shigong_areas" || cond.name() == "shigong_out_areas"){
            //parse "data"
            const int MIN_SIZE = 3*2;
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data().size()/2*2, std::back_inserter(shigong_areas_));
            std::copy_n(cond.data_offset().begin(), cond.data_offset().size()/2*2, std::back_inserter(shigong_areas_offset_));
            if (shigong_areas_offset_.empty() && !shigong_areas_.empty()) {
                shigong_areas_offset_.push_back(shigong_areas_.size());
            }
            int offset=0;
            for(const auto& offset_end : shigong_areas_offset_) {
                shigong_areas_value_.push_back(
                    std::max(get_polygon_area(&shigong_areas_[offset], offset_end-offset), MIN_AREA_SIZE));
                offset = offset_end;
            }
            //parse "threshold"
            shigong_areas_threshold_ = cond.has_threshold() ? cond.threshold() : shigong_areas_threshold_;
            //parse "period_second_"
            period_second_ = cond.has_period_second() ? cond.period_second() : DEFAULT_PERIOD_SECOND;
            //parse "threshold"
            cover_ratio_ = cond.has_cover_ratio() ? cond.cover_ratio() : DEFAULT_COVER_RATIO;

            //parse "weight&weight_label"
            CHECK(cond.weight_size()==cond.weight_label_size());
            for(int i=0; i<std::min(cond.weight_size(),cond.weight_label_size()); i++){
                score_map_[cond.weight_label(i)] = cond.weight(i);
            }
            for(int i=0; i<std::min(cond.weight_max_size(),cond.weight_label_size()); i++){
                score_max_map_[cond.weight_label(i)] = cond.weight_max(i);
            }

        }       
        if (cond.name() == "available_times"){
            CHECK_GE(cond.data_size(), 2);
            std::copy_n(cond.data().begin(), cond.data().size()/2*2, std::back_inserter(available_times_));
        }
        if (cond.name() == "start_time"){
            CHECK(cond.has_data_number());
            start_time_ = cond.data_number();
        }
        if (cond.name() == "end_time"){
            CHECK(cond.has_data_number());
            end_time_ = cond.data_number();
        }
        if (cond.name() == "report_interval"){
            CHECK(cond.has_data_number());
            report_interval_ = cond.data_number();
        }
    }
    
    data_ = violation_cfg;
    return true;
}

class ViolationShigong : public ViolationConstructionBase
{
public:
    ViolationShigong(int object_id, const std::string& violation_id, const spViolationShigongConfig cfg);
    virtual ~ViolationShigong()=default;
    
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
    virtual result_list_t get_results()const;
    virtual result_list_t get_debug_results()const;
    void                  log_info(const ImageObjectsInfo& objs) const;
    result_list_t         try_get_alarm(const ImageObjectsInfo& objs);
    float                 calculate_score(const VecBoxF& objs, std::map<int,float>* score_per_type=nullptr) const;

protected:
    static const std::string& get_event_type_form_code(const std::string& code) {
        static const std::string TadTypeShigong = "shigong";
        return TadTypeShigong;
    }

protected:
    const spViolationShigongConfig                      cfg_;
    std::vector<float>                                  shigong_areas_score_;
    float                                               shigong_areas_total_score_;
    VecBoxF                                             objects_vec_; //检测目标
    Construction_Event                                  shigong_objs_;
    bool                                                is_violation_;
    std::chrono::time_point<std::chrono::system_clock>  last_alert_time_;
    std::chrono::time_point<std::chrono::system_clock>  last_report_time_;
    //统计周期内check次数
    std::queue<std::chrono::time_point<std::chrono::system_clock>>  already_check_times_;
    //统计周期内每个满足占道施工的帧当时的时间组成的queue
    std::queue<std::chrono::time_point<std::chrono::system_clock>>  fit_queue_;
};

ViolationShigong::ViolationShigong(int object_id, const std::string& violation_id, const spViolationShigongConfig cfg)
    : ViolationConstructionBase(object_id, violation_id, cfg->data_)
    , cfg_(cfg)
    , shigong_areas_score_(cfg_->shigong_areas_offset_.size(), 0)
    , shigong_areas_total_score_(0)
    , is_violation_(false)
{
    last_alert_time_;
    last_report_time_ = std::chrono::system_clock::now();
}

inline float ViolationShigong::calculate_score(const VecBoxF& objs, std::map<int,float>* score_per_type) const {
    float total=0;
    std::unordered_map<int,int> count_by_type;
    for(const auto obj:objs) {
        if (cfg_->InAreas(obj)){
            count_by_type[obj.label]++;
        }
    }
    for(const auto kv:count_by_type) {
        const auto value = cfg_->GetScoreByType(kv.first, kv.second);
        if (score_per_type) {
            (*score_per_type)[kv.first] = value;
        }
        total += value;
    }
    return total;
}

result_list_t ViolationShigong::check(BoxF& box, const ImageObjectsInfo& objs)
{
    result_list_t retv;
    if(objs.shigong_objects.processed == false){
        return retv;
    }
    if(violation_cfg_->code().substr(0,4) == SHIGONG_DEBUG_CODE){
        if(objs.count % cfg_->cooling_interval_){
            return retv;
        }
        objects_vec_ = objs.shigong_objects.objs;
        shigong_objs_ = objs.shigong_objects;
        const auto message = try_get_alarm(objs);
        return message;
    }

    std::chrono::time_point<std::chrono::system_clock> now = std::chrono::system_clock::now();

    //step0 跳过的帧直接返回
    if(objs.shigong_objects.processed == false){
        return retv;
    }
    //step1 计算score
    shigong_areas_total_score_= calculate_score(objs.shigong_objects.objs);
    const auto is_working = shigong_areas_total_score_>=cfg_->shigong_areas_threshold_;
    //step2 总共计算次数+1
    already_check_times_.push(now);
    //step3 这一帧如果施工，施工次数+1
    if(is_working){
        fit_queue_.push(now);
    }else{
        //当前帧没施工,返回
        return retv;
    }

    // 计算
    std::chrono::duration<double> total_time = already_check_times_.back()-already_check_times_.front();
    double ratio = (double)fit_queue_.size()/(double)already_check_times_.size();

    //step4 统计周期之前的结果清除掉
    while(!fit_queue_.empty()){
        std::chrono::duration<double> diff = now - fit_queue_.front();
        if(diff.count() >= (double)cfg_->period_second_){
            fit_queue_.pop();
        }else{
            break;
        }
    }
    //step4 统计周期之前的结果清除掉
    while(!already_check_times_.empty()){
        std::chrono::duration<double> diff = now - already_check_times_.front();
        if(diff.count() >= (double)cfg_->period_second_){
            already_check_times_.pop();
        }else{
            break;
        }
    }    
    //step5 判断fit_queue_是否满足施工
    if(fit_queue_.empty()){
        return retv;
    }

    //=========这条log可能会比较多=========
    //LOG(INFO)<<"shigong: ratio is "<<ratio<<", cover_ratio_ is "<<cfg_->cover_ratio_<<" queue size: "<<(float)fit_queue_.size()<<" buffer size: "<<(float)already_check_times_.size();
    if(ratio*total_time.count() >= cfg_->cover_ratio_*cfg_->period_second_){
        //step6 判断冷却
        std::chrono::duration<double> diff = now - last_alert_time_;
        if(diff.count() >= (double)cfg_->cooling_time_){
            const auto message = try_get_alarm(objs);
            return message;
        }
    }

    return retv;
}
void ViolationShigong::log_info(const ImageObjectsInfo& objs) const{
    LOG(INFO) <<"==> violation_id: " << this->violation_id_ 
                <<", violation code: "<< violation_cfg_->code()
                <<", violation name: "<< violation_cfg_->name()
                <<", stream_id: " << objs.channel_id
                <<", shigong_areas_total_score: "<<shigong_areas_total_score_;
}

result_list_t ViolationShigong::try_get_alarm(const ImageObjectsInfo& objs) {
    is_violation_ = false;
    this->clear_snapshot();
    //step0, 首先判断是不是debug模式
    if (violation_cfg_->code().substr(0,4) == SHIGONG_DEBUG_CODE){
        is_violation_ = true;
        this->add_snapshot(BoxF(), objs);
        last_alert_time_ = std::chrono::system_clock::now();
        return get_debug_results();
    }

    objects_vec_.clear();
    for(auto obj : objs.shigong_objects.objs) {
        if (cfg_->InAreas(obj)) {
            objects_vec_.push_back(obj);
        }
    }
    result_list_t retv;
    //if(shigong_areas_total_score_>=cfg_->shigong_areas_threshold_){
        const auto now = std::chrono::system_clock::now();
        const auto now_ms = std::chrono::time_point_cast<std::chrono::milliseconds>(now);
        auto tt = std::chrono::system_clock::to_time_t(now);
        auto ptm = std::localtime(&tt);
        if ( violation_cfg_->code().substr(0,4) == XHSGCQ_CODE &&
             (cfg_->start_time_ >0 || cfg_->end_time_ >0)){
            if (cfg_->start_time_ >0 && cfg_->start_time_ > now_ms.time_since_epoch().count()) {
                is_violation_ = true;
                this->add_snapshot(BoxF(), objs);
                last_alert_time_ = std::chrono::system_clock::now();
                return get_results();
            }
            if (cfg_->end_time_ >0 && cfg_->end_time_ < now_ms.time_since_epoch().count()) {
                is_violation_ = true;
                this->add_snapshot(BoxF(), objs);
                last_alert_time_ = std::chrono::system_clock::now();
                return get_results();
            }
        }

        const auto& available_times = cfg_->available_times_;
        const int count = available_times.size()/2*2;
        bool bAvailable = false;
        int iNow =  ptm->tm_hour * 100 +  ptm->tm_min;
        for (int i=0; i<count; i+=2) {
            if ( (iNow > available_times[i] && iNow< available_times[i+1]) ||
                 (available_times[i] > available_times[i+1] &&
                     (iNow > available_times[i] || iNow < available_times[i+1]))) {
                bAvailable = true;
            }
        }
        if ( violation_cfg_->code().substr(0,4) == XHSGCSD_CODE &&
             !available_times.empty() ) {
            if ( !bAvailable ) {
                is_violation_ = true;
                this->add_snapshot(BoxF(), objs);
                last_alert_time_ = std::chrono::system_clock::now();
                return get_results();
            }
        }
        if (violation_cfg_->code().substr(0,4) == XHSGCQY_CODE){
            is_violation_ = true;
            this->add_snapshot(BoxF(), objs);
            last_alert_time_ = std::chrono::system_clock::now();
            return get_results();
        }
        if (violation_cfg_->code().substr(0,4) == XHZDSG_CODE ||
            violation_cfg_->code().substr(0,4) == XHCQYSG_CODE){
            is_violation_ = true;
            this->add_snapshot(BoxF(), objs);
            last_alert_time_ = std::chrono::system_clock::now();
            return get_results();
        }   
    //}

    if(cfg_->report_interval_!=0){
        std::chrono::time_point<std::chrono::system_clock> now = std::chrono::system_clock::now();
        std::chrono::duration<double> diff = now - last_report_time_;
        if(diff.count() >= cfg_->report_interval_){
            last_report_time_ = now;
            this->add_snapshot(BoxF(), objs);
            return get_results();        
        }
    }
    return retv;
}

result_list_t ViolationShigong::get_debug_results()const{
    result_list_t retv;
    const auto obj_id = object_id_;
    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = violation_cfg_->code();
    const auto violation_name = violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;
    const auto shigong_objs = shigong_objs_;
    
    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event_with_type = *retv;
        event_with_type.set_event_type(get_event_type_form_code(violation_code));
        //warning
        inference::ViolationEvent& event = *(event_with_type.mutable_traffic_event());
        event.set_stream_id(stream_id);
        event.set_obj_id(obj_id);
        event.set_violation_id(violation_id);
        event.set_violation_code(violation_code);
        event.set_violation_name(violation_name);
        event.set_is_violation(is_violation_);

        for(int i=0;i<snapshots.size();i++){
            auto snap1 = event.add_snapshots();
            snap1->set_now(snapshots[i].now.time_since_epoch().count());

            VecBoxF final_objs = shigong_objs.objs_vehicle;
            final_objs.insert(final_objs.end(), shigong_objs.objs_nomotor.begin(), shigong_objs.objs_nomotor.end());
            final_objs.insert(final_objs.end(), shigong_objs.objs_person.begin(), shigong_objs.objs_person.end());
            final_objs.insert(final_objs.end(), shigong_objs.objs_sign.begin(), shigong_objs.objs_sign.end());
            // add objects
            for(auto& box:final_objs){
                auto obj = snap1->add_objects();
                obj->add_box(box.xmin);
                obj->add_box(box.ymin);
                obj->add_box(box.xmax);
                obj->add_box(box.ymax);
                if(box.label!= -1){
                    std::string name="error";
                    if(box.label==1){
                        name = "person";
                    }else if(box.label==2){
                        name = "jdc";
                    }else if(box.label==3){
                        name = "fjdc";
                    }else{
                        //不知道为什么有时候不是-1 就先打个patch吧
                        box.uid = -1;
                    }
                    obj->set_type(name);
                    obj->set_score(box.score);
                }
                
                if(box.shigong_attr.type!= -1){
                    obj->set_shigong_type(helperGetShigongAttrTypeString(box.shigong_attr.type));
                    obj->set_shigong_type_score(box.shigong_attr.score);
                }
                if(box.attr_type.type!= -1){
                    obj->set_sub_type(Attribute::helperGetStringVehicleType(
                        (Attribute::VehicleType)box.attr_type.type));
                    obj->set_sub_type_score(box.attr_type.score);
                }
                if(box.special_car_type.type!= -1){
                    obj->set_special_car_type(Attribute::helperGetStringVehicleSpecialType(
                                                (Attribute::VehicleSpecialType)box.special_car_type.type));
                    obj->set_special_car_type_score(box.special_car_type.score);
                }
                if(box.uid!= -1){
                    obj->set_uid(box.uid);
                }
            }
        }
       return retv;
    };
    retv.push_back(action);
    return retv;
}

result_list_t ViolationShigong::get_results()const{
    result_list_t retv;
    const auto obj_id = object_id_;
    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = violation_cfg_->code();
    const auto violation_name = violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;
    const auto enable_output_picture = violation_cfg_->enable_output_picture();
    const auto enable_save_picture = violation_cfg_->enable_save_debug_picture();
    const auto objects = objects_vec_;
    
    log_info(*(snapshots_[0].image));
    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event_with_type = *retv;
        event_with_type.set_event_type(get_event_type_form_code(violation_code));
        //warning
        inference::ViolationEvent& event = *(event_with_type.mutable_traffic_event());
        event.set_stream_id(stream_id);
        event.set_obj_id(obj_id);
        event.set_violation_id(violation_id);
        event.set_violation_code(violation_code);
        event.set_violation_name(violation_name);
        event.set_is_violation(is_violation_);

        for(int i=0;i<snapshots.size();i++){
            auto& image = snapshots[i].image;
            auto snap1 = event.add_snapshots();
            snap1->set_now(snapshots[i].now.time_since_epoch().count());
            if (enable_output_picture){
                snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
            }
            // add objects
            for(auto& box:objects){
                auto obj = snap1->add_objects();
                obj->set_type(std::to_string(box.label));
                obj->set_score(box.score);
                obj->add_box(box.xmin);
                obj->add_box(box.ymin);
                obj->add_box(box.xmax);
                obj->add_box(box.ymax);
            }

            if (enable_save_picture){
                std::stringstream buff;
                buff <<stream_id <<"/pic_" << violation_id << "_" << obj_id <<"_" << i <<".jpg";
                auto fname = buff.str();
                std::ofstream of;
                mkdir(stream_id.c_str(),0755);
                of.open(fname);
                std::vector<unsigned char> im_data;
                cv::imencode(".jpg", *(image->sframe->getMat()), im_data);
                of.write((const char*)im_data.data(),im_data.size());
                LOG(INFO)<<"==>pic result "<<fname <<","<<of.is_open()<<","<<of.tellp();
                of.close();
            }
        }

       return retv;
    };
    retv.push_back(action);
    return retv;
}

//
// ViolationShigongFactory
//
ViolationShigongFactory::ViolationShigongFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<ViolationShigongConfig>(cfg))
{
}

const std::string& ViolationShigongFactory::id()const
{
    return id_;
}

bool ViolationShigongFactory::check_time(time_point_milliseconds now) {
    return cfg_->time_condition_->fun(now);
}

spIViolation ViolationShigongFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationShigong>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(XHSGCQ_CODE, Shigong);
REGISTER_VIOLATION(XHSGCQY_CODE, Shigong);
REGISTER_VIOLATION(XHSGCSD_CODE, Shigong);
REGISTER_VIOLATION(XHZDSG_CODE, Shigong);
REGISTER_VIOLATION(XHCQYSG_CODE, Shigong);
REGISTER_VIOLATION(SHIGONG_DEBUG_CODE, Shigong);
} // namespace FLOW
