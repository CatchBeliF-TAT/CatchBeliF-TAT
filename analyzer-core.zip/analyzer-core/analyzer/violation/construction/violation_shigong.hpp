#ifndef VSS_VIOLATION_SHIGONG_HPP
#define VSS_VIOLATION_SHIGONG_HPP

#include <vector>
#include <unordered_map>
#include <chrono>
#include "violation/violation_interface.hpp"

namespace inference {
    class ViolationConfig;
}

namespace FLOW {

using sys_milliseconds = std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds>;
class ViolationShigongConfig {
public:
    ViolationShigongConfig(const std::string& json);
    bool ParseJson(const std::string& json);
    float GetScoreByType(int type, int count) const;
    bool InAreas(const BoxF& box) const;
protected:
    typedef std::function<bool(sys_milliseconds)> fn_filter_time;
    typedef struct {int index; fn_filter_time fun;} filter_time;
public:
    std::shared_ptr<inference::ViolationConfig> data_;
    std::string                                 err_;

    std::vector<float>                          shigong_areas_;
    std::vector<int>                            shigong_areas_offset_;
    std::vector<double>                         shigong_areas_value_;
    float                                       shigong_areas_threshold_;
    float                                       period_second_;
    float                                       cover_ratio_;
    int                                         cooling_time_;
    int                                         cooling_interval_;
    int                                         report_interval_;
    std::vector<int>                            available_times_;
    int64_t                                     start_time_;
    int64_t                                     end_time_;

    std::shared_ptr<filter_time>                time_condition_;
    
    std::unordered_map<std::string, float>      score_map_; 
    std::unordered_map<std::string, float>      score_max_map_;
    mutable std::unordered_map<int, float>      score_map_cache_; 
    mutable std::unordered_map<int, float>      score_max_map_cache_; 
};
typedef std::shared_ptr<ViolationShigongConfig> spViolationShigongConfig;


class ViolationShigongFactory : public IViolationFactory 
{
public:
    ViolationShigongFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationShigongFactory()=default;

public:
    virtual const std::string&  id()const;
    virtual spIViolation        CreateIViolation(const BoxF& obj);
    virtual bool                check_time(time_point_milliseconds now) override;
protected:
    std::string                             id_;
    spViolationShigongConfig                cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_SHIGONG_HPP