#include "violation_construction.hpp"

#include <iterator>
#include <chrono>
#include <numeric>
#include <fstream>
#include <sys/stat.h>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"
#include "violation_construction_base.hpp"
#include "violation/violation_util.hpp"

namespace FLOW {

static const std::string SGCS_CODE("2301");
static const std::string SGCQ_CODE("2302");
static const std::string SGCQY_CODE("2303");
//
// ViolationConstructionConfig
//
ViolationConstructionConfig::ViolationConstructionConfig(const std::string& json)
    : alarm_frequency_(3600)
    , snapshot_frequency_(3600/60)
    , min_passing_vehicle_count_(3)
    , ratio_(0.5f)
    , available_times_()
    , start_time_(0)
    , end_time_(0)
{
    auto result = this->ParseJson(json);
    CHECK(result);
}

bool ViolationConstructionConfig::ParseJson(const std::string& json) {
    std::string err;
    auto violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return false;
    }

    const auto& cfg = *violation_cfg;
    const int PARAM_COUNT = 5;
    const double MIN_AREA_SIZE = 100;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "shigong_areas"){
            const int MIN_SIZE = 3*2;
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data().size()/2*2, std::back_inserter(shigong_areas_));
            std::copy_n(cond.data_offset().begin(), cond.data_offset().size()/2*2, std::back_inserter(shigong_areas_offset_));
            if (shigong_areas_offset_.empty() && !shigong_areas_.empty()) {
                shigong_areas_offset_.push_back(shigong_areas_.size());
            }
            int offset=0;
            for(const auto& offset_end : shigong_areas_offset_) {
                shigong_areas_value_.push_back(
                    std::max(get_polygon_area(&shigong_areas_[offset], offset_end-offset), MIN_AREA_SIZE));
                offset = offset_end;
            }
        }
        if (cond.name() == "shigong_out_areas"){
            const int MIN_SIZE = 3*2;
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data().size()/2*2, std::back_inserter(shigong_out_areas_));
            std::copy_n(cond.data_offset().begin(), cond.data_offset().size()/2*2, std::back_inserter(shigong_out_areas_offset_));
            if (shigong_out_areas_offset_.empty() && !shigong_out_areas_.empty()) {
                shigong_out_areas_offset_.push_back(shigong_out_areas_.size());
            }
            int offset=0;
            for(const auto& offset_end : shigong_out_areas_offset_) {
                shigong_out_areas_value_.push_back(
                    std::max(get_polygon_area(&shigong_out_areas_[offset], offset_end-offset), MIN_AREA_SIZE));
                offset = offset_end;
            }
        }
        if (cond.name() == "non_shigong_areas"){
            const int MIN_SIZE = 3*2;
            CHECK_GE(cond.data_size(), MIN_SIZE);
            std::copy_n(cond.data().begin(), cond.data().size()/2*2, std::back_inserter(non_shigong_areas_));
            std::copy_n(cond.data_offset().begin(), cond.data_offset().size()/2*2, std::back_inserter(non_shigong_areas_offset_));
            if (non_shigong_areas_offset_.empty() && !non_shigong_areas_.empty()) {
                non_shigong_areas_offset_.push_back(non_shigong_areas_.size());
            }
            int offset=0;
            for(const auto& offset_end : non_shigong_areas_offset_) {
                non_shigong_areas_value_ += (get_polygon_area(&non_shigong_areas_[offset], offset_end-offset));
                offset = offset_end;
            }
            non_shigong_areas_value_ = std::max(non_shigong_areas_value_, MIN_AREA_SIZE);
        }
        
        if (cond.name() == "alarm_frequency"){
            CHECK(cond.has_data_number());
            alarm_frequency_ = cond.data_number();
        }
        if (cond.name() == "snapshot_frequency"){
            CHECK(cond.has_data_number());
            snapshot_frequency_ = cond.data_number();
        }
        if (cond.name() == "ratio" ){
            CHECK(cond.has_data_number());
            ratio_ = cond.data_number();
        }
        if (cond.name() == "min_passing_vehicle_count" ){
            CHECK(cond.has_data_number());
            min_passing_vehicle_count_ = cond.data_number();
        }

        if (cond.name() == "available_times"){
            CHECK_GE(cond.data_size(), 2);
            std::copy_n(cond.data().begin(), cond.data().size()/2*2, std::back_inserter(available_times_));
        }
        if (cond.name() == "start_time"){
            CHECK(cond.has_data_number());
            start_time_ = cond.data_number();
        }
        if (cond.name() == "end_time"){
            CHECK(cond.has_data_number());
            end_time_ = cond.data_number();
        }
    }
    
    data_ = violation_cfg;
    return true;
}

//
// ViolationConstruction
//
class ViolationConstruction : public ViolationConstructionBase
{
public:
    ViolationConstruction(int object_id, const std::string& violation_id, const spViolationConstructionConfig cfg);
    virtual ~ViolationConstruction()=default;

public:
    virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
    virtual result_list_t get_results() const;
    void                  log_info(const ImageObjectsInfo& objs) const;
    result_list_t         try_get_alarm(const ImageObjectsInfo& objs);
protected:
    static const std::string& get_event_type_form_code(const std::string& code) {
        static const std::string TadTypeConstruction = "construction";
	    static const std::string TadTypeUNDEFINE     = "UNDEFINE";
        if  (code.size() >=4 && code.substr(0,2) == "23") {
            return TadTypeConstruction;
        }
        return TadTypeUNDEFINE;
    }
    static void clear_all_object(inference::ViolationEvent* event) {
        if (event) {
            for( auto& snapshot : *event->mutable_snapshots() ) {
                auto count = snapshot.objects_size();
                snapshot.mutable_objects()->Clear();
                snapshot.add_objects()->set_type(std::to_string(count));
            }
        }
    }
    
protected:
    enum STATUS{
        eUNDEFINE,
        eSHIGONG,
        eNON_SHIGONG,
    };
    const spViolationConstructionConfig     cfg_;
    int                                     count_;
    STATUS                                  status_;
    STATUS                                  status2_;
    VecBoxF                                 pre_data_;
    std::vector<int>                        shigong_areas_car_count_;
    std::vector<int>                        shigong_out_areas_car_count_;
    std::vector<int>                        non_shigong_areas_car_count_;
    bool                                    is_violation_;
    VecBoxF                                 cars_;
};

ViolationConstruction::ViolationConstruction(int object_id, const std::string& violation_id, const spViolationConstructionConfig cfg)
    : ViolationConstructionBase(object_id, violation_id, cfg->data_)
    , cfg_(cfg)
    , count_(0)
    , status_(eUNDEFINE)
    , status2_(eUNDEFINE)
    , pre_data_()
    , shigong_areas_car_count_(cfg_->shigong_areas_offset_.size(), 0)
    , shigong_out_areas_car_count_(cfg_->shigong_out_areas_offset_.size(), 0)
    , non_shigong_areas_car_count_(cfg_->non_shigong_areas_offset_.size(), 0)
    , is_violation_(false)
    , cars_()
{
}

int find_same_car(const VecBoxF& pre, const BoxF& current) {
    for (size_t i = 0; i < pre.size(); i++) {
        const double x1 = (pre[i].xmin + pre[i].xmax) / 2;
        const double y1 = (pre[i].ymin + pre[i].ymax) / 2;
        const double x2 = x1;
        const double y2 = (4*y1 + current.ymax) / 5; // hight * 1/10
        const double x3 = (current.xmin + current.xmax) / 2;
        const double y3 = (current.ymin + current.ymax) / 2;
        const double d1_sqr = (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1);
        const double d2_sqr = (x3-x1)*(x3-x1) + (y3-y1)*(y3-y1);
        if (d2_sqr < d1_sqr) {
            return i;
        }
    }
    return -1;
}

result_list_t ViolationConstruction::check(BoxF& box, const ImageObjectsInfo& objs)
{
    for (const auto& obj : objs.objects) {
        if (obj.label == OBJECT_TYPE_PERSON) {
            continue;
        }
        if (obj.label == OBJECT_TYPE_VEHICLE && find_same_car(pre_data_, obj)<0) {
            cars_.push_back(obj);
            for (size_t i=0, offset=0; i<cfg_->shigong_areas_offset_.size(); offset+=cfg_->shigong_areas_offset_[i],i++) {
                const size_t offset_end = cfg_->shigong_areas_offset_[i];
                if (valid_box_center_in_polygon(obj, &cfg_->shigong_areas_[offset], offset_end-offset)) {
                    shigong_areas_car_count_[i]++;
                    break;
                }
            }
            for (size_t i=0, offset=0; i<cfg_->shigong_out_areas_offset_.size(); offset+=cfg_->shigong_out_areas_offset_[i],i++) {
                const size_t offset_end = cfg_->shigong_out_areas_offset_[i];
                if (valid_box_center_in_polygon(obj, &cfg_->shigong_out_areas_[offset], offset_end-offset)) {
                    shigong_out_areas_car_count_[i]++;
                    break;
                }
            }
            for (size_t i=0, offset=0; i<cfg_->non_shigong_areas_offset_.size(); offset+=cfg_->non_shigong_areas_offset_[i],i++) {
                const size_t offset_end = cfg_->non_shigong_areas_offset_[i];
                if (valid_box_center_in_polygon(obj, &cfg_->non_shigong_areas_[offset], offset_end-offset)) {
                    non_shigong_areas_car_count_[i]++;
                    break;
                }
            }
        }
    }

    if ( (count_ % cfg_->snapshot_frequency_) == 0) {
        // update pre_data
        pre_data_ = objs.objects;
    }

    if ( (++count_ % cfg_->alarm_frequency_) == 0) {
        // check
        const auto shigong_objs = std::accumulate(shigong_areas_car_count_.begin(), shigong_areas_car_count_.end(), 0);
        const auto shigong_out_objs = std::accumulate(shigong_out_areas_car_count_.begin(), shigong_out_areas_car_count_.end(), 0);
        const auto non_shigong_objs = std::accumulate(non_shigong_areas_car_count_.begin(), non_shigong_areas_car_count_.end(), 0);
        if ( (shigong_objs+shigong_out_objs+non_shigong_objs) < cfg_->min_passing_vehicle_count_) {
            // np, 车流太少不确定, 保持旧状态
        } else { // 车流密度比
            const auto non_shigong_areas_value = cfg_->non_shigong_areas_value_;
            const auto min_ratio = cfg_->ratio_;

            // status 1
            std::vector<double> sub_ratio(shigong_areas_car_count_.size(), 0);
            std::transform(shigong_areas_car_count_.begin(), shigong_areas_car_count_.end(), cfg_->shigong_areas_value_.begin(), sub_ratio.begin(),
                [non_shigong_objs, non_shigong_areas_value](double shigong_objs, double shigong_area){
                    return (shigong_objs / std::max<double>(non_shigong_objs, 1.0f)) / (shigong_area / std::max<double>(non_shigong_areas_value, 100));
                });
            std::vector<STATUS> shigong_status(shigong_areas_car_count_.size(), eUNDEFINE);
            std::transform(sub_ratio.begin(), sub_ratio.end(), shigong_status.begin(),
                        [min_ratio](double ratio)->STATUS{ return (ratio < min_ratio) ? eSHIGONG : eNON_SHIGONG; });
            bool bShigong = std::any_of(shigong_status.begin(), shigong_status.end(),[](STATUS status)->bool{ return status==eSHIGONG; });
            status_ = (bShigong) ? eSHIGONG : eNON_SHIGONG;

            // status2
            std::vector<double> sub_ratio2(shigong_out_areas_car_count_.size(), 0);
            std::transform(shigong_out_areas_car_count_.begin(), shigong_out_areas_car_count_.end(), cfg_->shigong_out_areas_value_.begin(), sub_ratio2.begin(),
                [non_shigong_objs, non_shigong_areas_value](double shigong_objs, double shigong_area){
                    return (shigong_objs / std::max<double>(non_shigong_objs, 1.0f)) / (shigong_area / std::max<double>(non_shigong_areas_value, 100));
                });
            std::vector<STATUS> shigong_status2(shigong_out_areas_car_count_.size(), eUNDEFINE);
            std::transform(sub_ratio2.begin(), sub_ratio2.end(), shigong_status2.begin(),
                        [min_ratio](double ratio)->STATUS{ return (ratio < min_ratio) ? eSHIGONG : eNON_SHIGONG; });
            bool bShigong2 = std::any_of(shigong_status2.begin(), shigong_status2.end(),[](STATUS status)->bool{ return status==eSHIGONG; });
            status2_ = (bShigong2) ? eSHIGONG : eNON_SHIGONG;
        }
        //log
        log_info(objs);

        // process alarm
        const auto message = try_get_alarm(objs);

        //clear
        std::fill(shigong_areas_car_count_.begin(), shigong_areas_car_count_.end(), 0);
        std::fill(shigong_out_areas_car_count_.begin(), shigong_out_areas_car_count_.end(), 0);
        std::fill(non_shigong_areas_car_count_.begin(), non_shigong_areas_car_count_.end(), 0);
        cars_.clear();

        return message;
    }
    result_list_t retv;
    return retv;
}

void ViolationConstruction::log_info(const ImageObjectsInfo& objs) const{
    LOG(INFO) <<"==> violation_id: " << this->violation_id_ 
                << ", stream_id: " << objs.channel_id 
                << ", status: " << this->status_;
    std::stringstream oss;
    std::copy(shigong_areas_car_count_.begin(), shigong_areas_car_count_.end(),std::ostream_iterator<int>(oss, ","));
    LOG(INFO) <<"shigong_area: ["     << oss.str() << "]";

    oss.str("");
    std::copy(non_shigong_areas_car_count_.begin(), non_shigong_areas_car_count_.end(),std::ostream_iterator<int>(oss, ","));
    LOG(INFO) <<"non_shigong_area: [" << oss.str()<<"]" ;

    oss.str("");
    std::copy(shigong_out_areas_car_count_.begin(), shigong_out_areas_car_count_.end(),std::ostream_iterator<int>(oss, ","));
    LOG(INFO) <<"shigong_out_area: [" << oss.str()<<"]" ;
}

result_list_t ViolationConstruction::try_get_alarm(const ImageObjectsInfo& objs) {
    is_violation_ = false;
    this->clear_snapshot();
    if (status_ == eSHIGONG && !shigong_areas_car_count_.empty()) {
        const auto now = std::chrono::system_clock::now();
        const auto now_ms = std::chrono::time_point_cast<std::chrono::milliseconds>(now);
        auto tt = std::chrono::system_clock::to_time_t(now);
        auto ptm = std::localtime(&tt);
        if ( violation_cfg_->code() == SGCQ_CODE &&
             (cfg_->start_time_ >0 || cfg_->end_time_ >0)) {
            if (cfg_->start_time_ >0 && cfg_->start_time_ > now_ms.time_since_epoch().count()) {
                is_violation_ = true;
            }
            if (cfg_->end_time_ >0 && cfg_->end_time_ < now_ms.time_since_epoch().count()) {
                is_violation_ = true;
            }
            this->add_snapshot(BoxF(), objs);
            return get_results();
        }

        const auto& available_times = cfg_->available_times_;
        const int count = available_times.size()/2*2;
        bool bAvailable = false;
        int iNow =  ptm->tm_hour * 100 +  ptm->tm_min;
        for (int i=0; i<count; i+=2) {
            if ( (iNow > available_times[i] && iNow< available_times[i+1]) ||
                 (available_times[i] > available_times[i+1] &&
                     (iNow > available_times[i] || iNow < available_times[i+1]))) {
                bAvailable = true;
            }
        }
        if ( violation_cfg_->code() == SGCS_CODE &&
             !available_times.empty() ) {
            if ( !bAvailable ) {
                is_violation_ = true;
            }
            this->add_snapshot(BoxF(), objs);
            return get_results();
        }
    }
    if ( violation_cfg_->code() == SGCQY_CODE &&
         !shigong_out_areas_car_count_.empty() &&
         status2_ == eSHIGONG) {
        is_violation_ = true;
        this->add_snapshot(BoxF(), objs);
        return get_results();
    } else {
        // nop
    }
    this->add_snapshot(BoxF(), objs);
    return get_results();
}

class ICAlgEngine;

result_list_t ViolationConstruction::get_results()const{
    result_list_t retv;
    const auto obj_id = object_id_;
    const auto stream_id = snapshots_[0].image->channel_id;
    const auto violation_code = violation_cfg_->code();
    const auto violation_name = violation_cfg_->name();
    const auto violation_id = violation_id_;
    const auto snapshots = snapshots_;
    const auto enable_output_picture = violation_cfg_->enable_output_picture();
    const auto enable_save_picture = violation_cfg_->enable_save_debug_picture();
    const auto is_violation = is_violation_;
    const auto cars = cars_;
    auto action = [=](ICAlgEngine* engine) -> spEventProto {
        auto retv = std::make_shared<inference::Event>();
        inference::Event& event_with_type = *retv;
        event_with_type.set_event_type(get_event_type_form_code(violation_code));
        inference::ViolationEvent& event = *(event_with_type.mutable_traffic_event());
        event.set_stream_id(stream_id);
        event.set_obj_id(obj_id);
        event.set_violation_id(violation_id);
        event.set_violation_code(violation_code);
        event.set_violation_name(violation_name);
        event.set_is_violation(is_violation);
        for(int i=0;i<snapshots.size();i++){
            auto& image = snapshots[i].image;
            auto snap1 = event.add_snapshots();
            snap1->set_now(snapshots[i].now.time_since_epoch().count());
            if (enable_output_picture){
                snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
            }
            // add objects
            for(auto& box:cars){
                auto obj = snap1->add_objects();
                obj->set_type(std::to_string(box.label));
                obj->set_score(box.score);
                obj->add_box(box.xmin);
                obj->add_box(box.ymin);
                obj->add_box(box.xmax);
                obj->add_box(box.ymax);
            }

            if (enable_save_picture){
                std::stringstream buff;
                buff <<stream_id <<"/pic_" << violation_id << "_" << obj_id <<"_" << i <<".jpg";
                auto fname = buff.str();
                std::ofstream of;
                mkdir(stream_id.c_str(),0755);
                of.open(fname);
                std::vector<unsigned char> im_data;
                cv::imencode(".jpg", *(image->sframe->getMat()), im_data);
                of.write((const char*)im_data.data(),im_data.size());
                LOG(INFO)<<"==>pic result "<<fname <<","<<of.is_open()<<","<<of.tellp();
                of.close();
            }
        }

       return retv;
    };
    retv.push_back(action);
    return retv;
}

//
// ViolationConstructionFactory
//
ViolationConstructionFactory::ViolationConstructionFactory(const std::string& id, const std::string& cfg)
    : IViolationFactory()
    , id_(id)
    , cfg_(std::make_shared<ViolationConstructionConfig>(cfg))
{
}

const std::string& ViolationConstructionFactory::id()const
{
    return id_;
}

spIViolation ViolationConstructionFactory::CreateIViolation(const BoxF& obj)
{
    if (obj.label == -1){
        return std::make_shared<ViolationConstruction>(obj.uid, id_, cfg_);
    }
    else { 
        return nullptr;
    }
}

REGISTER_VIOLATION(SGCS_CODE, Construction);
REGISTER_VIOLATION(SGCQ_CODE, Construction);
REGISTER_VIOLATION(SGCQY_CODE, Construction);

} // namespace FLOW
