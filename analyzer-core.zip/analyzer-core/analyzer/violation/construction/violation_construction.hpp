#ifndef VSS_VIOLATION_CONSTRUCTION_HPP
#define VSS_VIOLATION_CONSTRUCTION_HPP

#include <vector>
#include "violation/violation_interface.hpp"

namespace inference {
    class ViolationConfig;
}

namespace FLOW {

class ViolationConstructionConfig {
public:
    ViolationConstructionConfig(const std::string& json);
    bool ParseJson(const std::string& json);

public:
    std::shared_ptr<inference::ViolationConfig> data_;
    std::string                                 err_;

    std::vector<float>                          shigong_areas_;
    std::vector<int>                            shigong_areas_offset_;
    std::vector<double>                         shigong_areas_value_;
    std::vector<float>                          shigong_out_areas_;
    std::vector<int>                            shigong_out_areas_offset_;
    std::vector<double>                         shigong_out_areas_value_;
    std::vector<float>                          non_shigong_areas_;
    std::vector<int>                            non_shigong_areas_offset_;
    double                                      non_shigong_areas_value_;
    int                                         alarm_frequency_;
    int                                         snapshot_frequency_;
    int                                         min_passing_vehicle_count_;
    float                                       ratio_;
    std::vector<int>                            available_times_;
    int64_t                                     start_time_;
    int64_t                                     end_time_;
};
typedef std::shared_ptr<ViolationConstructionConfig> spViolationConstructionConfig;


class ViolationConstructionFactory : public IViolationFactory 
{
public:
    ViolationConstructionFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationConstructionFactory()=default;

public:
    virtual const std::string&  id()const;
    virtual spIViolation        CreateIViolation(const BoxF& obj);

protected:
    std::string                             id_;
    spViolationConstructionConfig           cfg_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_CONSTRUCTION_HPP
