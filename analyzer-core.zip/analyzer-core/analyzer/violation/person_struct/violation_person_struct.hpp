//
// Created by yankai on 2020/6/3.
//

#ifndef ANALYZER_FLOW_VIOLATION_FACE_STRUCT_HPP
#define ANALYZER_FLOW_VIOLATION_FACE_STRUCT_HPP

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"
#include "violation/violation_interface.hpp"

namespace FLOW {

struct personQualityBuff {
  ImageObjectsInfo objs;
  int count=0;
  std::string address;
  BoxF box;
};

typedef std::unordered_map<int,personQualityBuff> personQualityBuffMap;

class ViolationPersonStructConfig {
 public:
  ViolationPersonStructConfig(const std::string& json);
  bool ParseJson(const std::string& json);

 public:
  std::shared_ptr<inference::ViolationConfig> data_;
  std::string code_;
  bool enable_output_picture_;
  int cooling_second_;
  int quality_buff_size_;
};

typedef std::shared_ptr<ViolationPersonStructConfig> spViolationPersonStructConfig;

class ViolationPersonStructFactory : public IViolationFactory {
 public:
  ViolationPersonStructFactory(const std::string& id, const std::string& cfg);
  virtual ~ViolationPersonStructFactory() = default;

 public:
  virtual const std::string& id() const;
  virtual spIViolation CreateIViolation(const BoxF& obj);

 protected:
  std::string id_;
  spViolationPersonStructConfig cfg_;
};

}  // namespace FLOW

#endif  // ANALYZER_FLOW_VIOLATION_FACE_STRUCT_HPP
