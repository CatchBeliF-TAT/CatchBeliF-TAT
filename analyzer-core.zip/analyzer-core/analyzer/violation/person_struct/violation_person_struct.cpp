//
// Created by yankai on 2020/6/3.
//

#include "violation_person_struct.hpp"

#include <memory>
#include <unordered_map>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"
#include "common/file_server.hpp"
#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation/violation_interface.hpp"
#include "violation/violation_registry.hpp"
#include "violation/violation_util.hpp"

namespace FLOW {

using namespace std;
static const std::string FLOW_PERSON_STRUCT_CODE("5200");
static const std::string FLOW_PERSON_STRUCT_EVENT_TYPE("person_struct");

ViolationPersonStructConfig::ViolationPersonStructConfig(const std::string& json)
    : quality_buff_size_(1), cooling_second_(600) {
  std::string err;
  auto violation_cfg = std::make_shared<inference::ViolationConfig>();
  json2pb(json, violation_cfg.get(), &err);
  if (!err.empty()) {
    LOG(WARNING) << err << ", json= " << json;
    return;
  }
  enable_output_picture_ = violation_cfg->enable_output_picture();
  data_ = violation_cfg;
  for (const auto& condition:violation_cfg->conditions()){
    quality_buff_size_ = condition.quality_buff_size();
  }

}

class ViolationPersonStruct : public IViolation {
 public:
  ViolationPersonStruct(BoxF box, const std::string& violation_id,
                      const spViolationPersonStructConfig cfg)
      
      : object_id_(box.uid)
      , violation_id_(violation_id)
      , cfg_(cfg)
      , snapshots_()
      , upload_client_(cfg_->data_->file_server_address())
  {}

  virtual ~ViolationPersonStruct() = default;

 public:
  virtual const std::string& id() const{ return violation_id_; }
  virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
  virtual result_list_t get_results() const;
  void log_info(const ImageObjectsInfo& objs) const;
  result_list_t try_get_alarm(const ImageObjectsInfo& objs);
  void report(personQualityBuff& person_quality_buff, result_list_t& retv);
  std::chrono::milliseconds get_elapsed_time(const ImageObjectsInfo& objs);

protected:
    typedef std::shared_ptr<ImageObjectsInfo> spImageObjectsInfo;
    typedef std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds> sys_milliseconds;
    struct ViolationSnapshot{
        BoxF                box;
        spImageObjectsInfo  image;
        sys_milliseconds    now;
    };

protected:
    virtual size_t          add_snapshot(const BoxF& box, const ImageObjectsInfo& objs) {
                                const auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
                                snapshots_.push_back(ViolationSnapshot{box, std::make_shared<ImageObjectsInfo>(objs), now});
                                return snapshots_.size();
                            }
    virtual void            clear_snapshot() { snapshots_.clear(); }

 protected:
  const int                             object_id_;
  const std::string                     violation_id_;
  const spViolationPersonStructConfig   cfg_;
  std::vector<ViolationSnapshot>        snapshots_;
  std::string                           upload_address_;
  FileServer::UploadClient              upload_client_;
  personQualityBuffMap                  person_quality_buff_map_;

  VecString total_attr_type{"gender", "direction", "age", "hat", "shoulderbag", "backpack", "handtrunk", "ub_color", "lb_color"};

  std::vector<VecString> total_attr_info{
      {"man", "female"},
      {"forward", "backward", "sideward"},
      {"child", "adult"},
      {"no_hat", "hat"},
      {"no_shoulderbag", "shoulderbag"},
      {"no_backpack", "backpack"},
      {"no_handtrunk", "handtrunk"},
      {"ub_green", "ub_blue", "ub_black", "ub_gray", "ub_white", "ub_purple", "ub_yellow", "ub_red", "ub_brown", "ub_pink",
       "ub_orange", "ub_darkblue", "ub_multi", "ub_other"},
      {"lb_orange", "lb_black", "lb_white", "lb_gray", "lb_red", "lb_green", "lb_blue", "lb_yellow", "lb_brown", "lb_shorts", "two_piece", "lb_other"}
  };

  VecString total_quality_type{"clarity","occlusion","Integrity","single","center"};;

  std::vector<VecString> total_quality_info{
      {"clear", "blur", "invalid"},
      {"no_occlusion", "occlusion"},
      {"complete", "incomplete"},
      {"single", "multi"},
      {"center", "no_center"}
  };
};

class ICAlgEngine;

static void clear_all_img(inference::PersonStructObjEvent* event) {
  if (event) {
    if (event->has_image()) event->set_image("...");
  }
}

std::chrono::milliseconds ViolationPersonStruct::get_elapsed_time(
    const ImageObjectsInfo& objs) {
  if (cfg_->data_->enable_use_pts()) {
    auto now = objs.pts;
    return std::chrono::milliseconds(now - snapshots_.back().image->pts);
  } else {
    auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now());
    return now - snapshots_.back().now;
  }
}

result_list_t ViolationPersonStruct::get_results() const {
  result_list_t retv;
  // if (object_id_ == -1) return retv;
  // const auto obj_id = object_id_;
  const auto stream_id = snapshots_[0].image->channel_id;
  const auto violation_code = cfg_->data_->code();
  const auto violation_name = cfg_->data_->name();
  const auto violation_id = violation_id_;
  const auto snapshots = snapshots_;
  const auto enable_output_picture = cfg_->enable_output_picture_;
  const auto uri = upload_address_;
  // const auto enable_save_picture = cfg_->data_->enable_save_debug_picture();

  auto action = [=](ICAlgEngine* engine) -> spEventProto {
    auto retv = std::make_shared<inference::Event>();
    inference::Event& event = *retv;
    event.set_event_type(FLOW_PERSON_STRUCT_EVENT_TYPE);

    auto& snapshots_box = snapshots.back().box;
    inference::PersonStructObjEvent& person_event = *(event.mutable_person_struct_obj_event());
    person_event.set_stream_id(stream_id);
    auto uuid = stream_id  + "_" + std::to_string(snapshots.back().now.time_since_epoch().count()) + "_" + std::to_string(snapshots_box.uid);
    person_event.set_obj_uuid(uuid);
    person_event.set_violation_id(violation_id);
    person_event.set_violation_code(violation_code);
    person_event.set_violation_name(violation_name);
    person_event.add_box(snapshots_box.xmin);
    person_event.add_box(snapshots_box.ymin);
    person_event.add_box(snapshots_box.xmax);
    person_event.add_box(snapshots_box.ymax);

    for (int i = 0; i < (snapshots_box.person_attr).size(); i++) {
      auto person_attr = person_event.add_person_attrs();
      person_attr->set_attr_type(total_attr_type[i]);
      person_attr->set_attr_name(total_attr_info[i][(snapshots_box.person_attr)[i].type]);
      person_attr->set_attr_value((snapshots_box.person_attr)[i].score);
    }

    for (int i = 0; i < (snapshots_box.person_quality).size(); i++) {
      auto person_quality = person_event.add_person_qualitys();
      person_quality->set_attr_type(total_quality_type[i]);
      person_quality->set_attr_name(total_quality_info[i][(snapshots_box.person_quality)[i].type]);
      person_quality->set_attr_value((snapshots_box.person_quality)[i].score);
    }

    auto person_feature = person_event.mutable_person_feature();
    person_feature->Resize((snapshots_box.person_feature).size(), 0.f);
    memcpy(person_feature->mutable_data(), (snapshots_box.person_feature).data(), (snapshots_box.person_feature).size() * sizeof(float));

    auto& image = snapshots.back().image;
    person_event.set_now(snapshots.back().now.time_since_epoch().count());
    person_event.set_pts(image->pts);
    if (enable_output_picture) {
        person_event.set_image(uri);
    }

    return retv;
  };
  retv.push_back(action);
  return retv;
}

result_list_t ViolationPersonStruct::check(BoxF& box,
                                         const ImageObjectsInfo& objs) {
  result_list_t retv;
  if (objs.person_objects.empty()) {
    return retv;
  }
  for (auto &person_box:objs.person_objects){
    // person_box quality satisfy the condition
    if (!person_box.person_feature.empty()){
      // person_box_id has been in buff
      if (person_quality_buff_map_.count(person_box.uid)){
        // update person buff info
        auto &person_quality_buff = person_quality_buff_map_.at(person_box.uid);
        if (person_quality_buff.count >= cfg_->quality_buff_size_) continue;
        person_quality_buff.count++;
        person_quality_buff.objs = objs;
        person_quality_buff.box = person_box;
        person_quality_buff.address = upload_address_;
        // person_box_id has been in buff more than C times, so report event
        if (person_quality_buff.count == cfg_->quality_buff_size_){
          report(person_quality_buff, retv);
        }
      }
      else {
        personQualityBuff person_quality_buff;
        person_quality_buff.objs = objs;
        person_quality_buff.count++;
        person_quality_buff.box = person_box;
        person_quality_buff.address = upload_address_;
        if (person_quality_buff.count == cfg_->quality_buff_size_){
          report(person_quality_buff, retv);
        }
        person_quality_buff_map_[person_box.uid] = person_quality_buff;
      }
    }

    if (person_box.delete_flag && person_quality_buff_map_.count(person_box.uid)){
      string cur_upload_address = upload_address_;
      auto &person_quality_buff = person_quality_buff_map_.at(person_box.uid);
      if (person_quality_buff.count < cfg_->quality_buff_size_) {
        report(person_quality_buff, retv);
      }
      upload_address_ = cur_upload_address;
      person_quality_buff_map_.erase(person_box.uid);
    }
  }
  upload_address_.clear();
  return retv;
}

void ViolationPersonStruct::report(personQualityBuff& person_quality_buff, result_list_t& retv) {
  if (person_quality_buff.address.empty() && cfg_->enable_output_picture_){
    fileserver::StoreRequest request;
    fileserver::StorageObject response;
    std::vector<u_char> buff;
    cv::imencode(".jpg", *(person_quality_buff.objs.sframe->getMat()), buff);
    auto size = buff.size();
    char *memblock = new char[size];
    memcpy(memblock, (char *) &buff[0], size);
    request.set_data(memblock, size);
    upload_address_ = upload_client_.UploadFile(request, response);
    person_quality_buff.address = upload_address_;
    delete[] memblock;

    for(auto & iter : person_quality_buff_map_){
      if (iter.second.objs.pts == person_quality_buff.objs.pts){
        iter.second.address = upload_address_;
      }
    }
  }
  upload_address_ = person_quality_buff.address;
  this->add_snapshot(person_quality_buff.box, person_quality_buff.objs);
  auto results = get_results();
  this->clear_snapshot();
  retv.insert(retv.end(), results.begin(), results.end());
}

ViolationPersonStructFactory::ViolationPersonStructFactory(const std::string& id,
                                                       const std::string& cfg)
    : IViolationFactory(),
      id_(id),
      cfg_(std::make_shared<ViolationPersonStructConfig>(cfg)) {}

const std::string& ViolationPersonStructFactory::id() const { return id_; }

spIViolation ViolationPersonStructFactory::CreateIViolation(const BoxF& obj) {
  if (obj.label == -1) {
    return std::make_shared<ViolationPersonStruct>(obj, id_, cfg_);
  }
  else{
    return nullptr;
  }
}

REGISTER_VIOLATION(FLOW_PERSON_STRUCT_CODE, PersonStruct);

}  // namespace FLOW
