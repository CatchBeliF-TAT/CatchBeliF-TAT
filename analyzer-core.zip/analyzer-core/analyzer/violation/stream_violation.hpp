#ifndef VSS_STREAM_VIOLATION_HPP
#define VSS_STREAM_VIOLATION_HPP

#include <memory>
#include <unordered_map>
#include "violation_interface.hpp"

namespace FLOW {

class ObjectViolationsFactory;
typedef std::shared_ptr<ObjectViolationsFactory> spObjectViolationsFactory;

class ObjectViolations;
typedef std::shared_ptr<ObjectViolations> spObjectViolations;


class CStreamViolation
{
public:
    CStreamViolation() = default;
    ~CStreamViolation() = default;

public:
    int AddViolation(const std::string& violation_id, const std::string& config);
    int RemoveViolation(const std::string& violation_id);

public:
    result_list_t Check(const ImageObjectsInfo&);

private:
    typedef std::unordered_map<int, spObjectViolations> ObjectMap;
    typedef std::unordered_map<std::string, spObjectViolations> PicObjectMap;
    ObjectMap                 cars_;
    PicObjectMap              pic_violations_;
    spObjectViolationsFactory factory_;
};

typedef std::shared_ptr<CStreamViolation> spCStreamViolation;

}

#endif //VSS_STREAM_VIOLATION_HPP
