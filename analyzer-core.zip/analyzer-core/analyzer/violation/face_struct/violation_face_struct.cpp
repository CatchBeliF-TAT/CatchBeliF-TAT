//
// Created by yankai on 2020/6/3.
//

#include "violation_face_struct.hpp"

#include <memory>
#include <unordered_map>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"
#include "common/file_server.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation/violation_interface.hpp"
#include "violation/violation_registry.hpp"
#include "violation/violation_util.hpp"
namespace FLOW {

using namespace std;
static const std::string FLOW_FACE_STRUCT_CODE("5100");
static const std::string FLOW_FACE_STRUCT_EVENT_TYPE("face_struct");

ViolationFaceStructConfig::ViolationFaceStructConfig(const std::string& json)
    : quality_buff_size_(1), cooling_second_(600) {
  std::string err;
  auto violation_cfg = std::make_shared<inference::ViolationConfig>();
  json2pb(json, violation_cfg.get(), &err);
  if (!err.empty()) {
    LOG(WARNING) << err << ", json= " << json;
    return;
  }
  enable_output_picture_ = violation_cfg->enable_output_picture();
  data_ = violation_cfg;
  for (const auto& condition:violation_cfg->conditions()){
    quality_buff_size_ = condition.quality_buff_size();
  }
}

class ViolationFaceStruct : public IViolation {
 public:
  ViolationFaceStruct(BoxF box, const std::string& violation_id,
                      const spViolationFaceStructConfig cfg)
      : object_id_(box.uid)
      , violation_id_(violation_id)
      , cfg_(cfg)
      , snapshots_()
      , upload_client_(cfg_->data_->file_server_address())
  {}

  virtual ~ViolationFaceStruct() = default;

 public:
  virtual const std::string& id() const{ return violation_id_; }
  virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
  virtual result_list_t get_results() const;
  void log_info(const ImageObjectsInfo& objs) const;
  void report(faceQualityBuff& face_quality_buff, result_list_t& retv);
  result_list_t try_get_alarm(const ImageObjectsInfo& objs);
  std::chrono::milliseconds get_elapsed_time(const ImageObjectsInfo& objs);

protected:
    typedef std::shared_ptr<ImageObjectsInfo> spImageObjectsInfo;
    typedef std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds> sys_milliseconds;
    struct ViolationSnapshot{
        BoxF                box;
        spImageObjectsInfo  image;
        sys_milliseconds    now;
    };

protected:
    virtual size_t          add_snapshot(const BoxF& box, const ImageObjectsInfo& objs) { 
                                const auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
                                snapshots_.push_back(ViolationSnapshot{box, std::make_shared<ImageObjectsInfo>(objs), now});
                                return snapshots_.size();
                            }
    virtual void            clear_snapshot() { snapshots_.clear(); }

 protected:
  const int                             object_id_;
  const std::string                     violation_id_;
  const spViolationFaceStructConfig     cfg_;
  std::vector<ViolationSnapshot>        snapshots_;
  std::string                           upload_address_;
  FileServer::UploadClient              upload_client_;
  faceQualityBuffMap                    face_quality_buff_map_;
  
  bool is_violation_;
  VecString total_type{"gender", "age",   "mask",  "glasses", "expression",
                       "race",   "beard", "weizu", "quality"};
  std::vector<VecString> total_info{
      {"female", "male"},
      {"age"},
      {"no_mask", "mask"},
      {"no_glasses", "normal_glasses", "sun_glasses"},
      {"neutral", "happy", "sad", "angry", "fearful", "surprise", "disgusted"},
      {"white", "black", "yellow"},
      {"o_clock_Shadow", "goatee", "mustache", "sideburns", "no_Beard"},
      {"no_weizu", "weizu"},
      {"pos", "neg", "blur", "pose", "cover"}};
  
};

class ICAlgEngine;

static void clear_all_img(inference::FaceStructObjEvent* event) {
  if (event) {
    if (event->has_image()) event->set_image("...");
  }
}

std::chrono::milliseconds ViolationFaceStruct::get_elapsed_time(
    const ImageObjectsInfo& objs) {
  if (cfg_->data_->enable_use_pts()) {
    auto now = objs.pts;
    return std::chrono::milliseconds(now - snapshots_.back().image->pts);
  } else {
    auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now());
    return now - snapshots_.back().now;
  }
}

result_list_t ViolationFaceStruct::get_results() const {
  result_list_t retv;
  // if (object_id_ == -1) return retv;
  // const auto obj_id = object_id_;
  const auto stream_id = snapshots_[0].image->channel_id;
  const auto violation_code = cfg_->data_->code();
  const auto violation_name = cfg_->data_->name();
  const auto violation_id = violation_id_;
  const auto snapshots = snapshots_;
  const auto enable_output_picture = cfg_->enable_output_picture_;
  const auto uri = upload_address_;

  auto action = [=](ICAlgEngine* engine) -> spEventProto {
    auto retv = std::make_shared<inference::Event>();
    inference::Event& event = *retv;
    event.set_event_type(FLOW_FACE_STRUCT_EVENT_TYPE);

    auto& snapshots_box = snapshots.back().box;
    inference::FaceStructObjEvent& face_event = *(event.mutable_face_struct_obj_event());
    face_event.set_stream_id(stream_id);
    auto uuid = stream_id  + "_" + std::to_string(snapshots.back().now.time_since_epoch().count()) + "_" + std::to_string(snapshots_box.uid);
    face_event.set_obj_uuid(uuid);
    face_event.set_violation_id(violation_id);
    face_event.set_violation_code(violation_code);
    face_event.set_violation_name(violation_name);
    face_event.add_box(snapshots_box.xmin);
    face_event.add_box(snapshots_box.ymin);
    face_event.add_box(snapshots_box.xmax);
    face_event.add_box(snapshots_box.ymax);

    face_event.add_key_point(snapshots_box.face_point.x1);
    face_event.add_key_point(snapshots_box.face_point.y1);
    face_event.add_key_point(snapshots_box.face_point.x2);
    face_event.add_key_point(snapshots_box.face_point.y2);
    face_event.add_key_point(snapshots_box.face_point.x3);
    face_event.add_key_point(snapshots_box.face_point.y3);
    face_event.add_key_point(snapshots_box.face_point.x4);
    face_event.add_key_point(snapshots_box.face_point.y4);
    face_event.add_key_point(snapshots_box.face_point.x5);
    face_event.add_key_point(snapshots_box.face_point.y5);

    for (int i = 0; i < (snapshots_box.face_attr).size(); i++) {
      auto face_attr = face_event.add_face_attrs();
      face_attr->set_attr_type(total_type[i]);
      face_attr->set_attr_name(total_info[i][(snapshots_box.face_attr)[i].type]);
      face_attr->set_attr_value((snapshots_box.face_attr)[i].score);
    }
    auto face_quality = face_event.add_face_attrs();
    face_quality->set_attr_type(total_type[8]);
    face_quality->set_attr_name(total_info[8][(snapshots_box.face_quality).type]);
    face_quality->set_attr_value((snapshots_box.face_quality).score);

    auto face_feature = face_event.mutable_face_feature();
    face_feature->Resize((snapshots_box.face_feature).size(), 0.f);
    memcpy(face_feature->mutable_data(), (snapshots_box.face_feature).data(), (snapshots_box.face_feature).size() * sizeof(float));

    auto& image = snapshots.back().image;
    face_event.set_now(snapshots.back().now.time_since_epoch().count());
    face_event.set_pts(image->pts);

    if (enable_output_picture) {
        face_event.set_image(uri);
    }


    return retv;
  };
  retv.push_back(action);
  return retv;
}

result_list_t ViolationFaceStruct::check(BoxF& box,
                                         const ImageObjectsInfo& objs) {
  result_list_t retv;
  if (objs.face_objects.empty()) {
    return retv;
  }
  for (auto &face_box:objs.face_objects){
    // face_box quality satisfy the condition
    if (!face_box.face_feature.empty()){
      // face_box_id has been in buff
      if (face_quality_buff_map_.count(face_box.uid)){
        // update face buff info
        auto &face_quality_buff = face_quality_buff_map_.at(face_box.uid);
        if (face_quality_buff.count >= cfg_->quality_buff_size_) continue;
        face_quality_buff.count++;
        face_quality_buff.objs = objs;
        face_quality_buff.box = face_box;
        face_quality_buff.address = upload_address_;
        // face_box_id has been in buff more than C times, so report event
        if (face_quality_buff.count == cfg_->quality_buff_size_){
            report(face_quality_buff, retv);
        }
      }
      else {
        faceQualityBuff face_quality_buff;
        face_quality_buff.objs = objs;
        face_quality_buff.count++;
        face_quality_buff.box = face_box;
        face_quality_buff.address = upload_address_;
        if (face_quality_buff.count == cfg_->quality_buff_size_){
          report(face_quality_buff, retv);
        }
        face_quality_buff_map_[face_box.uid] = face_quality_buff;
      }
    }

    if (face_box.delete_flag && face_quality_buff_map_.count(face_box.uid)){
      string cur_upload_address = upload_address_;
      auto &face_quality_buff = face_quality_buff_map_.at(face_box.uid);
      if (face_quality_buff.count < cfg_->quality_buff_size_) {
        report(face_quality_buff, retv);
      }
      upload_address_ = cur_upload_address;
      face_quality_buff_map_.erase(face_box.uid);
    }
  }
  upload_address_.clear();
  return retv;
}

void ViolationFaceStruct::report(faceQualityBuff& face_quality_buff, result_list_t& retv) {
  if (face_quality_buff.address.empty() && cfg_->enable_output_picture_){
    fileserver::StoreRequest request;
    fileserver::StorageObject response;
    std::vector<u_char> buff;
    cv::imencode(".jpg", *(face_quality_buff.objs.sframe->getMat()), buff);
    auto size = buff.size();
    char *memblock = new char[size];
    memcpy(memblock, (char *) &buff[0], size);
    request.set_data(memblock, size);
    upload_address_ = upload_client_.UploadFile(request, response);
    delete[] memblock;
    face_quality_buff.address = upload_address_;
    for(auto & iter : face_quality_buff_map_){
      if (iter.second.objs.pts == face_quality_buff.objs.pts){
        iter.second.address = upload_address_;
      }
    }
  }
  upload_address_ = face_quality_buff.address;
  this->add_snapshot(face_quality_buff.box, face_quality_buff.objs);
  auto results = get_results();
  this->clear_snapshot();
  retv.insert(retv.end(), results.begin(), results.end());
}

ViolationFaceStructFactory::ViolationFaceStructFactory(const std::string& id,
                                                       const std::string& cfg)
    : IViolationFactory(),
      id_(id),
      cfg_(std::make_shared<ViolationFaceStructConfig>(cfg)) {}

const std::string& ViolationFaceStructFactory::id() const { return id_; }

spIViolation ViolationFaceStructFactory::CreateIViolation(const BoxF& obj) {
  if (obj.label == -1) {
    return std::make_shared<ViolationFaceStruct>(obj, id_, cfg_);
  }
  else{
    return nullptr;
  }
}

REGISTER_VIOLATION(FLOW_FACE_STRUCT_CODE, FaceStruct);

}  // namespace FLOW
