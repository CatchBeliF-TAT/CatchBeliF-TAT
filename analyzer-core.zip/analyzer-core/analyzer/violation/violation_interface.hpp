#ifndef VSS_VIOLATION_INTERFACE_HPP
#define VSS_VIOLATION_INTERFACE_HPP

#include <chrono>
#include <string>
#include <memory>
#include <list>
#include <functional>
#include "common/tad_internal.hpp"

namespace inference{
    class Event;
}

namespace FLOW {
    class ICAlgEngine;
    typedef std::shared_ptr<inference::Event> spEventProto;
    typedef std::function<spEventProto(ICAlgEngine*)> result_t;
    typedef std::list<result_t> result_list_t;
    typedef std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds> time_point_milliseconds;

    class IViolation
    {
    public:
        IViolation()=default;
        virtual ~IViolation(){}
    public:
        virtual const std::string&  id()const=0;
        virtual result_list_t       check(BoxF&, const ImageObjectsInfo&)=0;
        virtual bool                check_ptz(const ImageObjectsInfo&)const { return true; }
    };
    typedef std::shared_ptr<IViolation> spIViolation;
    typedef std::vector<spIViolation>   ViolationList;

    class IViolationFactory
    {
    public:
        virtual ~IViolationFactory(){}
    public:
        virtual const std::string&  id()const=0;
        virtual spIViolation        CreateIViolation(const BoxF& obj)=0;
        virtual bool                check_time(time_point_milliseconds now) { return true; }
    };
    typedef std::shared_ptr<IViolationFactory> spIViolationFactory;
} // namespace FLOW
#endif // VSS_VIOLATION_INTERFACE_HPP
