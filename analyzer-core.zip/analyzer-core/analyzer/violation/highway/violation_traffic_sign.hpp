#ifndef VSS_VIOLATION_HIGHWAY_TRAFFIC_SIGN_HPP
#define VSS_VIOLATION_HIGHWAY_TRAFFIC_SIGN_HPP

#include <serving/violation_config.pb.h>
#include "violation/traffic/violation_common.hpp"

namespace inference {
    class ViolationConfig;
}

namespace FLOW {

class ViolationTrafficSignConfig {
 public:
  ViolationTrafficSignConfig(const std::string& json);
  bool ParseJson(const std::string& json);

 public:
  std::shared_ptr<inference::ViolationConfig> data_;
  std::string code_;
  bool enable_output_picture_;
  float detect_thresh_;
  int cooling_second_;
  int interval_second_;
  int traffic_sign_count_;
  std::vector<VecFloat> violate_polygons_;
  std::vector<BoxF>     violate_box_borders_;
};

typedef std::shared_ptr<ViolationTrafficSignConfig>
    spViolationTrafficSignConfig;

class ViolationTrafficSignFactory : public ViolationCommonFactory {
 public:
  ViolationTrafficSignFactory(const std::string& id, const std::string& cfg);
  virtual ~ViolationTrafficSignFactory() = default;

 public:
  virtual const std::string& id() const;
  virtual spIViolation CreateIViolation(const BoxF& obj);

 protected:
  std::string id_;
  spViolationTrafficSignConfig cfg_;
};

}  // namespace FLOW
#endif  // VSS_VIOLATION_DEBUG_HPP
