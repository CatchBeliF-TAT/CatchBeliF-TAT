#ifndef VSS_VIOLATION_HIGHWAY_BASE_HPP
#define VSS_VIOLATION_HIGHWAY_BASE_HPP

#include <memory>
#include <chrono>
#include <vector>
#include <memory>

#include "common/helper.hpp"
#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"
#include "violation/violation_interface.hpp"
#include "violation/violation_registry.hpp"

namespace inference{
    class ViolationConfig;
}

namespace FLOW {

typedef std::shared_ptr<inference::ViolationConfig> spViolationConfig;

class ViolationHighwayBase : public IViolation, public std::enable_shared_from_this<ViolationHighwayBase>
{
public:
    ViolationHighwayBase(int object_id, const std::string& violation_id, const spViolationConfig& violation_cfg)
        : snapshots_()
        , object_id_(object_id)
        , violation_id_(violation_id)
        , violation_cfg_(violation_cfg)
    {}

    virtual ~ViolationHighwayBase()=default;

public:
    virtual const std::string&  id()const { return violation_id_; }
    virtual result_list_t       check(BoxF& box, const ImageObjectsInfo& objs)=0;

    virtual bool check_ptz(const ImageObjectsInfo& image) const {
        static const std::vector<float> EMPTY_DATA_VECTOR{-1,-1,-1};
        static const ::google::protobuf::RepeatedField< float > EMPTY_DATA(EMPTY_DATA_VECTOR.begin(), EMPTY_DATA_VECTOR.end());
        if(!violation_cfg_){
            return true;
        }
        if (violation_cfg_->ptz_pos_size() < 3 ||
            std::equal(EMPTY_DATA.begin(), EMPTY_DATA.end(), violation_cfg_->ptz_pos().begin())) {
            return true;
        }
        PosInfo ACQ_PTZ;
        ACQ_PTZ.angle_x = violation_cfg_->ptz_pos(0);
        ACQ_PTZ.angle_y = violation_cfg_->ptz_pos(1);
        ACQ_PTZ.scale = violation_cfg_->ptz_pos(2);
        const bool ok = Helper::is_same_postion(ACQ_PTZ, image.ptz_pos);
        return ok;
    }

protected:
    typedef std::shared_ptr<ImageObjectsInfo> spImageObjectsInfo;
    typedef std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds> sys_milliseconds;
    struct ViolationSnapshot{
        BoxF                box;
        spImageObjectsInfo  image;
        sys_milliseconds    now;
    };

protected:
    virtual size_t          add_snapshot(const BoxF& box, const ImageObjectsInfo& objs) { 
                                const auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
                                snapshots_.push_back(ViolationSnapshot{box, std::make_shared<ImageObjectsInfo>(objs), now});
                                return snapshots_.size();
                            }
    virtual void            clear_snapshot() { snapshots_.clear(); }
    std::chrono::milliseconds get_elapsed_time(const ImageObjectsInfo& objs) {
        if (snapshots_.empty()) {
            return std::chrono::milliseconds(0);
        }
        if (violation_cfg_->enable_use_pts()) {
            auto now = objs.pts;
            return std::chrono::milliseconds(now - snapshots_.back().image->pts);
        } else {
            auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now());
            return now - snapshots_.back().now;
        }
    }

protected:
    static const std::string& get_event_type_form_code(const std::string& code) {
        static const std::string TadTypeHighway      = "highway";
        static const std::string TadTypeUNDEFINE     = "UNDEFINE";
        if  (code.size() >=4 && code.substr(0,2) == "24") {
            return TadTypeHighway;
        }
        return TadTypeUNDEFINE;
    }
    static void clear_all_img(inference::ViolationEvent* event) {
        if (event) {
            for( auto& snapshot : *event->mutable_snapshots() ) {
                if (snapshot.has_image()) snapshot.set_image("...");
            }
        }
    }

protected:
    const int                             object_id_;
    const std::string                     violation_id_;
    const spViolationConfig               violation_cfg_;
    std::vector<ViolationSnapshot>        snapshots_;
};

} // namespace FLOW
#endif // VSS_VIOLATION_HIGHWAY_BASE_HPP
