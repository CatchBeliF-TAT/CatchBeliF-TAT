#include "violation_foggy.hpp"

#include <memory>
#include <unordered_map>

#include "common/helper.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation/violation_util.hpp"
#include "violation_highway_base.hpp"

namespace FLOW {

using namespace std;
static const std::string FLOW_FOGGY_CODE("2435");
static const int FLOW_FOGGY_INDEX(1);
static const std::string FLOW_FOGGY_STRING("foggy");
static const int FLOW_SUSPECTED_FOGGY_INDEX(2);
static const std::string FLOW_SUSPECTED_FOGGY_STRING("suspected_foggy");

ViolationFoggyConfig::ViolationFoggyConfig(const std::string& json)
    : foggy_score_thresh_(0.5), cooling_second_(600) {
  std::string err;
  auto violation_cfg = std::make_shared<inference::ViolationConfig>();
  json2pb(json, violation_cfg.get(), &err);
  if (!err.empty()) {
    LOG(WARNING) << err << ", json= " << json;
    return;
  }
  auto& cfg = *violation_cfg;
  cooling_second_ =
      cfg.has_cooling_second() ? cfg.cooling_second() : cooling_second_;
  for (int i = 0; i < cfg.conditions_size(); i++) {
    const auto& cond = cfg.conditions(i);
    if (cond.name() == "violate_box") {
      if (cond.has_threshold()) {
        foggy_score_thresh_ = cond.threshold();
      } else if (cond.has_foggy_score_thresh()) {  // 兼容旧配置, 暂时保留
        foggy_score_thresh_ = cond.foggy_score_thresh();
      }
    }
  }
  enable_output_picture_ = cfg.enable_output_picture();
  data_ = violation_cfg;
}

class ViolationFoggyClassify : public ViolationHighwayBase {
 public:
  ViolationFoggyClassify(int object_id, const std::string& violation_id,
                         const spViolationFoggyConfig cfg)
      : ViolationHighwayBase(object_id, violation_id, cfg->data_), cfg_(cfg) {}

  virtual ~ViolationFoggyClassify() = default;

 public:
  virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
  virtual result_list_t get_results() const;
  void log_info(const ImageObjectsInfo& objs) const;
  result_list_t try_get_alarm(const ImageObjectsInfo& objs);

 protected:
  const spViolationFoggyConfig cfg_;
  std::vector<int> shigong_areas_car_count_;
  std::vector<int> shigong_out_areas_car_count_;
  std::vector<int> non_shigong_areas_car_count_;
  bool is_violation_;
  VecBoxF cars_;
};

class ICAlgEngine;

result_list_t ViolationFoggyClassify::get_results() const {
  result_list_t retv;
  const auto obj_id = object_id_;
  const auto stream_id = snapshots_[0].image->channel_id;
  const auto violation_code = cfg_->data_->code();
  const auto violation_name = cfg_->data_->name();
  const auto violation_id = violation_id_;
  const auto snapshots = snapshots_;
  const auto enable_output_picture = cfg_->enable_output_picture_;
  // const auto enable_save_picture = cfg_->data_->enable_save_debug_picture();
  const auto is_violation = is_violation_;
  const auto cars = cars_;
  auto action = [=](ICAlgEngine* engine) -> spEventProto {
    auto retv = std::make_shared<inference::Event>();
    inference::Event& event_with_type = *retv;
    event_with_type.set_event_type(get_event_type_form_code(violation_code));
    inference::ViolationEvent& highWayEvent =
        *(event_with_type.mutable_traffic_event());
    highWayEvent.set_stream_id(stream_id);
    highWayEvent.set_obj_id(obj_id);
    highWayEvent.set_violation_id(violation_id);
    highWayEvent.set_violation_code(violation_code);
    highWayEvent.set_violation_name(violation_name);
    for (int i = 0; i < snapshots.size(); i++) {
      auto& image = snapshots[i].image;
      auto snap1 = highWayEvent.add_snapshots();
      snap1->set_now(snapshots[i].now.time_since_epoch().count());
      if (enable_output_picture) {
        snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
      }

      // corp whole picture, need fix
      if (snapshots[i].box.label > 0) {
        const auto box = snapshots[i].box;
        const auto type = (snapshots[i].box.label==FLOW_FOGGY_INDEX) ? FLOW_FOGGY_STRING
                        : (snapshots[i].box.label==FLOW_SUSPECTED_FOGGY_INDEX) ? FLOW_SUSPECTED_FOGGY_STRING
                        : std::string("undefine");
        auto obj = snap1->add_objects();
        obj->set_type(type);
        obj->set_score(box.score);
        obj->add_box(box.xmin);
        obj->add_box(box.ymin);
        obj->add_box(box.xmax);
        obj->add_box(box.ymax);
      }
    }

    return retv;
  };
  retv.push_back(action);
  return retv;
}

result_list_t ViolationFoggyClassify::check(BoxF& box,
                                            const ImageObjectsInfo& objs) {
  result_list_t retv;
  if (!snapshots_.empty() &&
      get_elapsed_time(objs).count() < cfg_->cooling_second_ * 1000) {
    return retv;
  }
  if (objs.highways.weather_event.predict_foggy_score >
          cfg_->foggy_score_thresh_ &&
      objs.highways.weather_event.predict_foggy_name == FLOW_FOGGY_STRING) {
    this->clear_snapshot();
    BoxF box(0,0,objs.sframe->width(),objs.sframe->height());
    box.label = FLOW_FOGGY_INDEX;
    box.score = objs.highways.weather_event.predict_foggy_score;
    this->add_snapshot(box, objs);
    return get_results();
  } else if (objs.highways.weather_event.predict_suspected_score > cfg_->foggy_score_thresh_ &&
             objs.highways.weather_event.predict_suspected_name == FLOW_SUSPECTED_FOGGY_STRING ) {
    this->clear_snapshot();
    BoxF box(0,0,objs.sframe->width(),objs.sframe->height());
    box.label = FLOW_SUSPECTED_FOGGY_INDEX;
    box.score = objs.highways.weather_event.predict_suspected_score;
    this->add_snapshot(box, objs);
    return get_results();
  }

  return retv;
}

ViolationFoggyFactory::ViolationFoggyFactory(const std::string& id,
                                             const std::string& cfg)
    : ViolationCommonFactory(id, cfg),
      id_(id),
      cfg_(std::make_shared<ViolationFoggyConfig>(cfg)) {}

const std::string& ViolationFoggyFactory::id() const { return id_; }

spIViolation ViolationFoggyFactory::CreateIViolation(const BoxF& obj) {
  if (obj.label == -1) {
    return std::make_shared<ViolationFoggyClassify>(obj.uid, id_, cfg_);
  } else {
    return nullptr;
  }
}

REGISTER_VIOLATION(FLOW_FOGGY_CODE, Foggy);

}  // namespace FLOW
