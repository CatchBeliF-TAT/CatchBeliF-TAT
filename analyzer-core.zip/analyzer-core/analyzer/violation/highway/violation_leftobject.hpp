#ifndef VSS_VIOLATION_HIGHWAY_LEFTOBJECT_HPP
#define VSS_VIOLATION_HIGHWAY_LEFTOBJECT_HPP

#include <serving/violation_config.pb.h>
#include "violation/traffic/violation_common.hpp"

namespace inference {
    class ViolationConfig;
}

namespace FLOW {

class ViolationLeftobjectConfig {
 public:
  ViolationLeftobjectConfig(const std::string& json);
  bool ParseJson(const std::string& json);

 public:
  std::shared_ptr<inference::ViolationConfig> data_;
  std::string                                 code_;
  bool                                        enable_output_picture_;
  std::vector<float>                          violate_box_;
  int                                         cooling_second_;
  float                                       leftobject_classify_score_thresh_;
};

typedef std::shared_ptr<ViolationLeftobjectConfig> spViolationLeftobjectConfig;


 class ViolationLeftobjectFactory : public ViolationCommonFactory
 {
public:
   ViolationLeftobjectFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationLeftobjectFactory()=default;

public:
    virtual const std::string& id()const;
    virtual spIViolation CreateIViolation(const BoxF& obj);

protected:
    std::string                                id_;
    spViolationLeftobjectConfig                   cfg_;
 };

} // namespace FLOW
#endif // VSS_VIOLATION_DEBUG_HPP

