#ifndef VSS_VIOLATION_HIGHWAY_TRAFFIC_LIGHT_HPP
#define VSS_VIOLATION_HIGHWAY_TRAFFIC_LIGHT_HPP

#include <serving/violation_config.pb.h>
#include "violation/traffic/violation_common.hpp"

namespace inference {
    class ViolationConfig;
}

namespace FLOW {

class ViolationTrafficLightConfig {
 public:
  ViolationTrafficLightConfig(const std::string& json);
  bool ParseJson(const std::string& json);

 public:
  std::shared_ptr<inference::ViolationConfig> data_;
  std::string code_;
  bool enable_output_picture_;
  float detect_thresh_;
  int cooling_second_;
  int interval_second_;
  int interval2_second_;
  std::vector<VecFloat> violate_polygons_;
  std::vector<BoxF>     violate_box_borders_;
};

typedef std::shared_ptr<ViolationTrafficLightConfig>
    spViolationTrafficLightConfig;

class ViolationTrafficLightFactory : public ViolationCommonFactory {
 public:
  ViolationTrafficLightFactory(const std::string& id, const std::string& cfg);
  virtual ~ViolationTrafficLightFactory() = default;

 public:
  virtual const std::string& id() const;
  virtual spIViolation CreateIViolation(const BoxF& obj);

 protected:
  std::string id_;
  spViolationTrafficLightConfig cfg_;
};

}  // namespace FLOW
#endif  // VSS_VIOLATION_HIGHWAY_TRAFFIC_LIGHT_HPP
