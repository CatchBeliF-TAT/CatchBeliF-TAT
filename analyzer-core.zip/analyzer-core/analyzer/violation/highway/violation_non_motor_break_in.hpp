#ifndef VSS_VIOLATION_HIGHWAY_NON_MOTOR_BREAKIN
#define VSS_VIOLATION_HIGHWAY_NON_MOTOR_BREAKIN

#include <serving/violation_config.pb.h>
#include "violation/traffic/violation_common.hpp"
#include "violation_person_break_in.hpp"

namespace inference {
    class ViolationConfig;
}

namespace FLOW {

 class ViolationBreakInNonMotorFactory : public ViolationCommonFactory
 {
public:
   ViolationBreakInNonMotorFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationBreakInNonMotorFactory()=default;

public:
    virtual const std::string& id()const;
    virtual spIViolation CreateIViolation(const BoxF& obj);

protected:
    std::string                                id_;
    spViolationBreakInConfig                   cfg_;
 };

} // namespace FLOW
#endif // VSS_VIOLATION_DEBUG_HPP

