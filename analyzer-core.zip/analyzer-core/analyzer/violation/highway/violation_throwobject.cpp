#include "violation_throwobject.hpp"

#include <memory>
#include <unordered_map>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_event.pb.h"
#include "serving/violation_config.pb.h"

#include "violation_highway_base.hpp"
#include "violation/violation_util.hpp"
//extern std::string video_file_extern;

namespace FLOW {

using namespace std;
static const std::string FLOW_THROWOBJECT_CODE("2438");

ViolationThrowobjectConfig::ViolationThrowobjectConfig(const std::string& json)
        : cooling_second_(600)
        , detect_thresh_(0.0)
        , still_time_(4)
{
    std::string err;
    auto violation_cfg = std::make_shared<inference::ViolationConfig>();
    json2pb(json, violation_cfg.get(), &err);
    if (!err.empty()){
        LOG(WARNING) << err <<", json= "<< json;
        return;
    }
    auto& cfg = *violation_cfg;
    const int MIN_SIZE = 2*3;
    cooling_second_ = cfg.has_cooling_second()?cfg.cooling_second():cooling_second_;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "violate_box"){
          if (cond.has_threshold()) {
              detect_thresh_ = cond.threshold();
          }
          still_time_ = cond.has_parking_second()?cond.parking_second():still_time_;
          CHECK_GE(cond.data_size(), MIN_SIZE);
          std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(violate_box_));
        }
    }
    enable_output_picture_ = cfg.enable_output_picture();
    data_ = violation_cfg;
}

static void remove_throw_box_center_in_car_box(VecBoxF &throw_objects, const VecBoxF& vehicles) {
    for ( auto obj_it = throw_objects.begin(); obj_it != throw_objects.end(); ) {
        for ( const auto &vec_box : vehicles ) {
           std::vector<float>  box_vec{vec_box.xmin, vec_box.ymin, vec_box.xmax, vec_box.ymin,
                 vec_box.xmax, vec_box.ymax, vec_box.xmin,vec_box.ymax};
            if ( valid_box_center_in_polygon(*obj_it, box_vec.data(), box_vec.size())) {
                obj_it = throw_objects.erase(obj_it);
                obj_it--;
                break;
            }
        }
        ++obj_it;
    }
}

inline double IOU(const BoxF& r1, const BoxF& r2) {
    int x1 = std::max(r1.xmin, r2.xmin);
    int y1 = std::max(r1.ymin, r2.ymin);
    int x2 = std::min(r1.xmax, r2.xmax);
    int y2 = std::min(r1.ymax, r2.ymax);
    int w = std::max(0, (x2-x1+1));
    int h = std::max(0, (y2-y1+1));
    double inter = w * h;
    double r1_area = (r1.xmax - r1.xmin) * (r1.ymax - r1.ymin);
    double r2_area = (r2.xmax - r2.xmin) * (r2.ymax - r2.ymin);
    double o = inter / (r1_area + r2_area - inter);
    return (o >= 0) ? o : 0;
}

static bool has_intersect_with_boxes( VecBoxF &throw_objects, const VecBoxF &refer_throw_objects, VecBoxF& refer_cross_objects) {
    VecBoxF tmp_obj;
    for ( auto throw_object : throw_objects ) {
        for ( auto refer_throw : refer_throw_objects) {
            if (IOU(throw_object, refer_throw) > 0 ) {
                tmp_obj.push_back(throw_object);
                refer_cross_objects.push_back(refer_throw);
                break;
            }
        }
    }
    throw_objects.swap(tmp_obj);
    return throw_objects.size();
}
class ViolationThrowobjectClassify : public ViolationHighwayBase {
 public:
  ViolationThrowobjectClassify(int object_id, const std::string& violation_id,
                           const spViolationThrowobjectConfig cfg)
      : ViolationHighwayBase(object_id, violation_id, cfg->data_), 
      cfg_(cfg),
      status_(eUNDEFINE) 
  {
  }

  virtual ~ViolationThrowobjectClassify() = default;

 public:
  virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
  virtual result_list_t get_results() const;
  void log_info(const ImageObjectsInfo& objs) const;
  result_list_t try_get_alarm(const ImageObjectsInfo& objs);

 protected:
  enum STATUS{
        eUNDEFINE,
        eENTER_VIEW,
        eLAST_TIME_UP,
        eCOOL_TIME_UP,
    };
 protected:
  const spViolationThrowobjectConfig cfg_;
  STATUS                             status_;
  VecBoxF                            refer_throw_object_inBoxes_;
};

class ICAlgEngine;

result_list_t ViolationThrowobjectClassify::get_results() const {
  result_list_t retv;
  const auto obj_id = object_id_;
  const auto stream_id = snapshots_[0].image->channel_id;
  const auto violation_code = cfg_->data_->code();
  const auto violation_name = cfg_->data_->name();
  const auto violation_id = violation_id_;
  const auto snapshots = snapshots_;
  const auto enable_output_picture = cfg_->enable_output_picture_;
  // const auto enable_save_picture = cfg_->data_->enable_save_debug_picture();
  auto action = [=](ICAlgEngine* engine) -> spEventProto {
    auto retv = std::make_shared<inference::Event>();
    inference::Event& event_with_type = *retv;
    event_with_type.set_event_type(get_event_type_form_code(violation_code));
    inference::ViolationEvent& highWayEvent = *(event_with_type.mutable_traffic_event());
    highWayEvent.set_stream_id(stream_id);
    highWayEvent.set_obj_id(obj_id);
    highWayEvent.set_violation_id(violation_id);
    highWayEvent.set_violation_code(violation_code);
    highWayEvent.set_violation_name(violation_name);
    for (int i = 0; i < snapshots.size(); i++) {
      auto& image = snapshots[i].image;
      auto snap1 = highWayEvent.add_snapshots();
      snap1->set_now(snapshots[i].now.time_since_epoch().count());
      if (enable_output_picture) {
        snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
      }

      for (auto& box : image->objects) {
        auto obj = snap1->add_objects();
        std::stringstream buff;
        buff << "throwobject";
        obj->set_type(buff.str());
        obj->set_score(box.score);
        obj->add_box(box.xmin);
        obj->add_box(box.ymin);
        obj->add_box(box.xmax);
        obj->add_box(box.ymax);
      }
    }

    return retv;
  };
  retv.push_back(action);
  return retv;
}

result_list_t ViolationThrowobjectClassify::check(BoxF& box,
                                              const ImageObjectsInfo& objs) {
    result_list_t retv;
    if ( !objs.highways.throw_object_event.need_detect_flag) {
        return retv;
    }

    VecBoxF throw_object_inBoxes;
    const VecBoxF& car_boxes = objs.highways.throw_object_event.vehicle_objects;
    std::copy_if(objs.highways.throw_object_event.throw_objects.begin(), objs.highways.throw_object_event.throw_objects.end(),
                    std::back_inserter(throw_object_inBoxes), [this](const BoxF& one){
            return one.score >= cfg_->detect_thresh_ &&
                valid_box_center_in_polygon(one, cfg_->violate_box_.data(), cfg_->violate_box_.size());});

    remove_throw_box_center_in_car_box( throw_object_inBoxes, car_boxes);
    VecBoxF cross_refer_objects;
    auto elapsed_time = this->get_elapsed_time(objs);
    switch (status_) {
        case eUNDEFINE:
            if (throw_object_inBoxes.empty()) {
                break;
            }
            LOG(INFO)<<"==>stage one ready, "<<objs.channel_id
                        <<","<<violation_id_;
            status_ = eENTER_VIEW;
            this->clear_snapshot();
            VecBoxF().swap(refer_throw_object_inBoxes_);
            this->add_snapshot(BoxF(), objs);
            refer_throw_object_inBoxes_ = throw_object_inBoxes;
            break;
        case eENTER_VIEW:
            if ( throw_object_inBoxes.empty() || 
                !has_intersect_with_boxes( throw_object_inBoxes, refer_throw_object_inBoxes_, cross_refer_objects)) {
                LOG(INFO)<<"==>stage two drop, "<<objs.channel_id
                            <<","<<violation_id_;
                status_ = eUNDEFINE;
                break;
            }
            if( elapsed_time.count() >= cfg_->still_time_*1000 ) {
                this->add_snapshot(BoxF(), objs);
                this->snapshots_.back().image->objects = throw_object_inBoxes;
                this->snapshots_.front().image->objects = cross_refer_objects;
                status_ = eLAST_TIME_UP;

                LOG(INFO)<<"==>stage two ready, "<<objs.channel_id
                        <<","<<violation_id_;
                retv =  get_results();

                this->clear_snapshot();
                this->add_snapshot(box, ImageObjectsInfo());
            }
            break;
        case eLAST_TIME_UP:
            if (cfg_->cooling_second_ > 0) {
                auto elapsed_time = this->get_elapsed_time(objs);
                if ( elapsed_time.count() >= (cfg_->cooling_second_*1000) ) {
                    status_ = eUNDEFINE;
                }
            } else {
                status_ = eUNDEFINE;
            }
            break;
        default:
            break;
    }
    return retv;
}

ViolationThrowobjectFactory::ViolationThrowobjectFactory(const std::string& id,
                                                 const std::string& cfg)
    : ViolationCommonFactory(id, cfg),
      id_(id),
      cfg_(std::make_shared<ViolationThrowobjectConfig>(cfg)) {}

const std::string& ViolationThrowobjectFactory::id() const { return id_; }

spIViolation ViolationThrowobjectFactory::CreateIViolation(const BoxF& obj) {
  if (obj.label == -1) {
    return std::make_shared<ViolationThrowobjectClassify>(obj.uid, id_, cfg_);
  } else {
    return nullptr;
  }
}

REGISTER_VIOLATION(FLOW_THROWOBJECT_CODE, Throwobject);

}  // namespace FLOW
