#ifndef VSS_VIOLATION_HIGHWAY_THROWOBJECT_HPP
#define VSS_VIOLATION_HIGHWAY_THROWOBJECT_HPP

#include <serving/violation_config.pb.h>
#include "violation/traffic/violation_common.hpp"

namespace inference {
    class ViolationConfig;
}

namespace FLOW {

class ViolationThrowobjectConfig {
 public:
  ViolationThrowobjectConfig(const std::string& json);
  bool ParseJson(const std::string& json);

 public:
  std::shared_ptr<inference::ViolationConfig> data_;
  std::string                                 code_;
  bool                                        enable_output_picture_;
  std::vector<float>                          violate_box_;
  int                                         cooling_second_;
  float                                       detect_thresh_;
  int                                         still_time_;
};

typedef std::shared_ptr<ViolationThrowobjectConfig> spViolationThrowobjectConfig;


 class ViolationThrowobjectFactory : public ViolationCommonFactory
 {
public:
   ViolationThrowobjectFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationThrowobjectFactory()=default;

public:
    virtual const std::string& id()const;
    virtual spIViolation CreateIViolation(const BoxF& obj);

protected:
    std::string                                id_;
    spViolationThrowobjectConfig                   cfg_;
 };

} // namespace FLOW
#endif // VSS_VIOLATION_DEBUG_HPP

