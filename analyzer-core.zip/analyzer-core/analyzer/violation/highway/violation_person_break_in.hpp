#ifndef VSS_VIOLATION_HIGHWAY_BREAKIN_HPP
#define VSS_VIOLATION_HIGHWAY_BREAKIN_HPP

#include <serving/violation_config.pb.h>
#include "violation/traffic/violation_common.hpp"

namespace inference {
    class ViolationConfig;
}

namespace FLOW {

class ViolationBreakInConfig {
 public:
  ViolationBreakInConfig(const std::string& json);
  bool ParseJson(const std::string& json);

 public:
  std::shared_ptr<inference::ViolationConfig> data_;
  std::string                                 code_;
  bool                                        enable_output_picture_;
  std::vector<float>                          violate_box_;
  int                                         person_number_thresh_;
  int                                         non_motor_number_thresh_;
  int                                         cooling_second_;
};

typedef std::shared_ptr<ViolationBreakInConfig> spViolationBreakInConfig;


 class ViolationBreakInFactory : public ViolationCommonFactory
 {
public:
   ViolationBreakInFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationBreakInFactory()=default;

public:
    virtual const std::string& id()const;
    virtual spIViolation CreateIViolation(const BoxF& obj);

protected:
    std::string                                id_;
    spViolationBreakInConfig                   cfg_;
 };

} // namespace FLOW
#endif // VSS_VIOLATION_DEBUG_HPP

