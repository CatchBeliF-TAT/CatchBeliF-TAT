#ifndef VSS_VIOLATION_FLOW_FIRE_SMOKE_HPP
#define VSS_VIOLATION_FLOW_FIRE_SMOKE_HPP

#include "violation/traffic/violation_common.hpp"

namespace inference {
    class ViolationConfig;
}

namespace FLOW {

class ViolationFireConfig {
 public:
  ViolationFireConfig(const std::string& json);
  bool ParseJson(const std::string& json);

 public:
  std::shared_ptr<inference::ViolationConfig> data_;
  std::string                                 code_;
  bool                                        enable_output_picture_;
  int                                         cooling_second_;
  float                                       fire_score_thresh_;
  int                                         last_for_second_;
};

typedef std::shared_ptr<ViolationFireConfig> spViolationFireConfig;


 class ViolationFireFactory : public ViolationCommonFactory
 {
public:
   ViolationFireFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationFireFactory()=default;

public:
    virtual const std::string& id()const;
    virtual spIViolation CreateIViolation(const BoxF& obj);

protected:
    std::string                              id_;
    spViolationFireConfig                   cfg_;
 };

} // namespace FLOW
#endif // VSS_VIOLATION_DEBUG_HPP

