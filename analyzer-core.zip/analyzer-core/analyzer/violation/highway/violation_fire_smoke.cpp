#include "violation_fire_smoke.hpp"

#include <memory>
#include <unordered_map>

#include "common/helper.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

#include "violation/violation_util.hpp"
#include "violation_highway_base.hpp"

namespace FLOW {

using namespace std;
static const std::string FLOW_FIRE_CODE("2437");
static const int FLOW_FIRE_INDEX(1);
static const std::string FLOW_FIRE_STRING("fire");
static const int FLOW_SMOKE_INDEX(2);
static const std::string FLOW_SMOKE_STRING("smoke");

ViolationFireConfig::ViolationFireConfig(const std::string& json)
    : fire_score_thresh_(0.6)
    , cooling_second_(0)
    , last_for_second_(0) {
  std::string err;
  auto violation_cfg = std::make_shared<inference::ViolationConfig>();
  json2pb(json, violation_cfg.get(), &err);
  if (!err.empty()) {
    LOG(WARNING) << err << ", json= " << json;
    return;
  }
  auto& cfg = *violation_cfg;
  cooling_second_ =
      cfg.has_cooling_second() ? cfg.cooling_second() : cooling_second_;
  for (int i = 0; i < cfg.conditions_size(); i++) {
    const auto& cond = cfg.conditions(i);
    if (cond.name() == "violate_box") {
      if (cond.has_threshold()) {
        fire_score_thresh_ = cond.threshold();
      } else if (cond.has_fire_score_thresh()) {  // 兼容旧配置, 暂时保留
        fire_score_thresh_ = cond.fire_score_thresh();
      }
      if (cond.has_parking_second()) {
        last_for_second_ = cond.parking_second();
      }
    }
  }
  enable_output_picture_ = cfg.enable_output_picture();
  data_ = violation_cfg;
}

class ViolationFireClassify : public ViolationHighwayBase {
 public:
  ViolationFireClassify(int object_id, const std::string& violation_id,
                        const spViolationFireConfig cfg)
      : ViolationHighwayBase(object_id, violation_id, cfg->data_)
      , cfg_(cfg)
      , last_for_millisconds_(-1)
      {}

  virtual ~ViolationFireClassify() = default;

 public:
  virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
  virtual result_list_t get_results() const;

 protected:
  static BoxF make_event_box(const Fire_Event& fire_events, Mat_Ptr pMat);

 protected:
  const spViolationFireConfig cfg_;
  int                         last_for_millisconds_;
};

class ICAlgEngine;

result_list_t ViolationFireClassify::get_results() const {
  result_list_t retv;
  const auto obj_id = object_id_;
  const auto stream_id = snapshots_[0].image->channel_id;
  const auto violation_code = cfg_->data_->code();
  const auto violation_name = cfg_->data_->name();
  const auto violation_id = violation_id_;
  const auto snapshots = snapshots_;
  const auto enable_output_picture = cfg_->enable_output_picture_;
  // const auto enable_save_picture = cfg_->data_->enable_save_debug_picture();
  auto action = [=](ICAlgEngine* engine) -> spEventProto {
    auto retv = std::make_shared<inference::Event>();
    inference::Event& event_with_type = *retv;
    event_with_type.set_event_type(get_event_type_form_code(violation_code));
    inference::ViolationEvent& highWayEvent =
        *(event_with_type.mutable_traffic_event());
    highWayEvent.set_stream_id(stream_id);
    highWayEvent.set_obj_id(obj_id);
    highWayEvent.set_violation_id(violation_id);
    highWayEvent.set_violation_code(violation_code);
    highWayEvent.set_violation_name(violation_name);
    for (int i = 0; i < snapshots.size(); i++) {
      auto& image = snapshots[i].image;
      auto snap1 = highWayEvent.add_snapshots();
      snap1->set_now(snapshots[i].now.time_since_epoch().count());
      if (enable_output_picture) {
        snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
      }
      
      // corp whole picture, need fix
      if (snapshots[i].box.label > 0) {
        const auto box = snapshots[i].box;
        const auto type = (box.label==FLOW_FIRE_INDEX) ? FLOW_FIRE_STRING
                        : (box.label==FLOW_SMOKE_INDEX) ? FLOW_SMOKE_STRING
                        : std::string("undefine");
        auto obj = snap1->add_objects();
        obj->set_type(type);
        obj->set_score(box.score);
        obj->add_box(box.xmin);
        obj->add_box(box.ymin);
        obj->add_box(box.xmax);
        obj->add_box(box.ymax);
      }
    }

    return retv;
  };
  retv.push_back(action);
  return retv;
}

BoxF ViolationFireClassify::make_event_box(const Fire_Event& fire_events, Mat_Ptr pMat) {
    BoxF box(0,0,pMat->cols,pMat->rows);
    box.label = (fire_events.predict_fire_score >= fire_events.predict_smoke_score)
              ? FLOW_FIRE_INDEX : FLOW_SMOKE_INDEX;
    box.score = std::max(fire_events.predict_fire_score, fire_events.predict_smoke_score);
    return std::move(box);
}

result_list_t ViolationFireClassify::check(BoxF& box,
                                           const ImageObjectsInfo& objs) {
  result_list_t retv;
  if (!snapshots_.empty() &&
      this->last_for_millisconds_ < 0 &&
      get_elapsed_time(objs).count() < cfg_->cooling_second_ * 1000) {
    return retv;
  }

  const auto& fire_events = objs.highways.fire_event;
  if (! fire_events.processed) {
    return retv;
  }

  if ( fire_events.predict_fire_score >= cfg_->fire_score_thresh_ ||
       fire_events.predict_smoke_score >= cfg_->fire_score_thresh_) {
    if (this->last_for_millisconds_ < 0) {
      LOG(INFO) << "==>fire start"
                << ", stream_id= "    << objs.channel_id
                << ", violation_id="  << violation_id_
                << ", score="         << fire_events.predict_fire_score<<","<<fire_events.predict_smoke_score;
      this->last_for_millisconds_ = 0;
      this->clear_snapshot();
      this->add_snapshot(make_event_box(fire_events, objs.sframe->getMat()), objs);
    } else if (this->last_for_millisconds_ < this->cfg_->last_for_second_*1000) {
      this->last_for_millisconds_ = get_elapsed_time(objs).count();
    } else { // (this->last_for_millisconds_ >= this->cfg_->last_for_second_*1000)
      LOG(INFO) << "==>fire keep end"
                << ", stream_id= "    << objs.channel_id
                << ", violation_id="  << violation_id_
                << ", score="         << fire_events.predict_fire_score<<","<<fire_events.predict_smoke_score;
      this->last_for_millisconds_ = -1;
      this->add_snapshot(make_event_box(fire_events, objs.sframe->getMat()), objs);
      return get_results();
    }
  } else {
    this->last_for_millisconds_ = -1;
    this->clear_snapshot();
  }

  return retv;
}

ViolationFireFactory::ViolationFireFactory(const std::string& id,
                                           const std::string& cfg)
    : ViolationCommonFactory(id, cfg),
      id_(id),
      cfg_(std::make_shared<ViolationFireConfig>(cfg)) {}

const std::string& ViolationFireFactory::id() const { return id_; }

spIViolation ViolationFireFactory::CreateIViolation(const BoxF& obj) {
  if (obj.uid == -1) {
    return std::make_shared<ViolationFireClassify>(obj.uid, id_, cfg_);
  } else {
    return nullptr;
  }
}

REGISTER_VIOLATION(FLOW_FIRE_CODE, Fire);

}  // namespace FLOW
