#include "violation_traffic_sign.hpp"

#include <memory>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_event.pb.h"
#include "serving/violation_config.pb.h"

#include "violation_highway_base.hpp"
#include "violation/violation_util.hpp"

namespace FLOW {

using namespace std;
static const std::string FLOW_TRAFFIC_SIGN_CODE("2441");

ViolationTrafficSignConfig::ViolationTrafficSignConfig(const std::string& json)
    : detect_thresh_(0.0)
    , cooling_second_(600)
    , interval_second_(60)
    , traffic_sign_count_(1)
{
  std::string err;
  auto violation_cfg = std::make_shared<inference::ViolationConfig>();
  json2pb(json, violation_cfg.get(), &err);
  if (!err.empty()) {
    LOG(WARNING) << err << ", json= " << json;
    return;
  }
  auto& cfg = *violation_cfg;
  const int MIN_SIZE = 2 * 3;
  cooling_second_ =
      cfg.has_cooling_second() ? cfg.cooling_second() : cooling_second_;
  for (int i = 0; i < cfg.conditions_size(); i++) {
    const auto& cond = cfg.conditions(i);
    if (cond.name() == "violate_box") {
      if (cond.has_threshold()) {
          detect_thresh_ = cond.threshold();
      }
      if (cond.has_parking_second()) {
          interval_second_ = cond.parking_second();
      }
      if (cond.has_car_count()) {
          traffic_sign_count_ = cond.car_count();
      }
      CHECK_GE(cond.data_size(), MIN_SIZE);
      VecFloat violate_data;
      std::copy_n(cond.data().begin(), cond.data_size() / 2 * 2,
                  std::back_inserter(violate_data));
      VecInt data_offset;
      std::copy_n(cond.data_offset().begin(), cond.data_offset_size(),
                  std::back_inserter(data_offset));
      if (data_offset.size() == 0) {
        data_offset.push_back(violate_data.size());
      }
      for (size_t i=0,start_pz=0; i < data_offset.size(); i++) {
        auto end_pz = std::min<int>(data_offset[i], violate_data.size());
        if (end_pz-start_pz >= 2*2) {
          violate_polygons_.resize(violate_polygons_.size()+1);
          violate_box_borders_.resize(violate_box_borders_.size()+1);
          BoxF& violate_box_border = violate_box_borders_.back();
          VecFloat& violate_polygon = violate_polygons_.back();
          // copy data
          violate_polygon.insert(violate_polygon.end(), &violate_data[start_pz], &violate_data[end_pz]);
          start_pz += violate_polygon.size();
          // cal border
          violate_box_border.xmin = violate_polygon[0];
          violate_box_border.xmax = violate_polygon[0];
          violate_box_border.ymin = violate_polygon[1];
          violate_box_border.ymax = violate_polygon[1];
          for (size_t j=2; j<violate_polygon.size(); j+=2){
            violate_box_border.xmin = std::min(violate_polygon[j], violate_box_border.xmin);
            violate_box_border.xmax = std::max(violate_polygon[j], violate_box_border.xmax);
            violate_box_border.ymin = std::min(violate_polygon[j+1], violate_box_border.ymin);
            violate_box_border.ymax = std::max(violate_polygon[j+1], violate_box_border.ymax);
          }
        }
      }
    }
  }
  enable_output_picture_ = cfg.enable_output_picture();
  data_ = violation_cfg;
}

class ViolationTrafficSignClassify : public ViolationHighwayBase {
 public:
  ViolationTrafficSignClassify(int object_id, const std::string& violation_id,
                               const spViolationTrafficSignConfig cfg)
      : ViolationHighwayBase(object_id, violation_id, cfg->data_)
      , cfg_(cfg)
      , is_cooling_(false)
 {}

  virtual ~ViolationTrafficSignClassify() = default;

 public:
  virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
  virtual result_list_t get_results() const;
  void log_info(const ImageObjectsInfo& objs) const;
  result_list_t try_get_alarm(const ImageObjectsInfo& objs);

 protected:
  const spViolationTrafficSignConfig cfg_;
  bool is_cooling_;
  std::vector<VecBoxF> backBoxesVec_;
};

class ICAlgEngine;

result_list_t ViolationTrafficSignClassify::get_results() const {
  result_list_t retv;
  const auto obj_id = object_id_;
  const auto stream_id = snapshots_[0].image->channel_id;
  const auto violation_code = cfg_->data_->code();
  const auto violation_name = cfg_->data_->name();
  const auto violation_id = violation_id_;
  const auto snapshots = snapshots_;
  const auto enable_output_picture = cfg_->enable_output_picture_;
  // const auto enable_save_picture = cfg_->data_->enable_save_debug_picture();
  auto action = [=](ICAlgEngine* engine) -> spEventProto {
    auto retv = std::make_shared<inference::Event>();
    inference::Event& event_with_type = *retv;
    event_with_type.set_event_type(get_event_type_form_code(violation_code));
    inference::ViolationEvent& highWayEvent = *(event_with_type.mutable_traffic_event());
    highWayEvent.set_stream_id(stream_id);
    // highWayEvent.set_obj_id(obj_id);
    highWayEvent.set_violation_id(violation_id);
    highWayEvent.set_violation_code(violation_code);
    highWayEvent.set_violation_name(violation_name);
    for (int i = 0; i < snapshots.size(); i++) {
      auto& image = snapshots[i].image;
      auto snap1 = highWayEvent.add_snapshots();
      snap1->set_now(snapshots[i].now.time_since_epoch().count());
      if (enable_output_picture) {
        snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
      }

      auto obj = snap1->add_objects();
      obj->set_type("violation_box");
      obj->set_score(1);
      obj->add_box(snapshots[i].box.xmin);
      obj->add_box(snapshots[i].box.ymin);
      obj->add_box(snapshots[i].box.xmax);
      obj->add_box(snapshots[i].box.ymax);
      for (auto& box : image->objects) {
        auto obj = snap1->add_objects();
        std::stringstream buff;
        buff << "traffic_sign";
        obj->set_type(buff.str());
        obj->set_score(box.score);
        obj->add_box(box.xmin);
        obj->add_box(box.ymin);
        obj->add_box(box.xmax);
        obj->add_box(box.ymax);
      }
    }

    return retv;
  };
  retv.push_back(action);
  return retv;
}

result_list_t ViolationTrafficSignClassify::check(
    BoxF& box, const ImageObjectsInfo& objs) {
  result_list_t retv;
  if (is_cooling_) {
      if (get_elapsed_time(objs).count() <= cfg_->cooling_second_ * 1000) {
        return retv;
      } else {
        this->is_cooling_ = false;
        this->clear_snapshot();
        this->backBoxesVec_.clear();
      }
  }
//  LOG(INFO) << "violatiion traffic sign: pts = " << objs.pts;

  std::vector<VecBoxF> inBoxesVec(cfg_->violate_polygons_.size(), VecBoxF());
  std::transform(cfg_->violate_polygons_.begin(), cfg_->violate_polygons_.end(), inBoxesVec.begin(),
      [this, &objs](const VecFloat& polygon)->VecBoxF {
          VecBoxF out;
          std::copy_if(objs.highways.traffic_sign_event.traffic_signs.begin(),
                      objs.highways.traffic_sign_event.traffic_signs.end(),
                      std::back_inserter(out), [this, &polygon](const BoxF& one) {
                          return one.score >= cfg_->detect_thresh_ &&
                                  valid_box_center_in_polygon(one, polygon.data(), polygon.size());
          });
          return std::move(out);
  });

  // update backBoxesVec_
  backBoxesVec_.resize(inBoxesVec.size());
  for(size_t i=0; i<backBoxesVec_.size(); i++ ){
    if (inBoxesVec[i].size() > backBoxesVec_[i].size()) {
      backBoxesVec_[i].swap(inBoxesVec[i]);
    }
  }

  // check
  if (this->get_elapsed_time(objs).count() >= cfg_->interval_second_*1000) {
    for(size_t i=0; i<backBoxesVec_.size(); i++ ){
      if ( backBoxesVec_[i].size() < cfg_->traffic_sign_count_ ) {
        this->is_cooling_ = true;
        this->clear_snapshot();
        this->add_snapshot(cfg_->violate_box_borders_[i], objs);
        this->snapshots_.back().image->objects.clear();
        this->snapshots_.back().image->objects.swap( backBoxesVec_[i] );
        this->backBoxesVec_.clear();
        return get_results();
      }  else {
        LOG(INFO) << "==>violation_id=" << objs.channel_id 
                  <<", backBoxesVec_["<< i <<"].size()=" <<backBoxesVec_[i].size()
                  <<", backBoxesVec_["<< i <<"][0]=["
                  << backBoxesVec_[i][0].xmin << ", "
                  << backBoxesVec_[i][0].ymin << ", "
                  << backBoxesVec_[i][0].xmax << ", "
                  << backBoxesVec_[i][0].ymax << "] ";
        
        this->is_cooling_ = false;
        this->clear_snapshot();
        this->backBoxesVec_.clear();
      }
    }
  }

  return retv;
}

ViolationTrafficSignFactory::ViolationTrafficSignFactory(const std::string& id,
                                                         const std::string& cfg)
    : ViolationCommonFactory(id, cfg),
      id_(id),
      cfg_(std::make_shared<ViolationTrafficSignConfig>(cfg)) {}

const std::string& ViolationTrafficSignFactory::id() const { return id_; }

spIViolation ViolationTrafficSignFactory::CreateIViolation(const BoxF& obj) {
  if (obj.label == -1) {
    return std::make_shared<ViolationTrafficSignClassify>(obj.uid, id_, cfg_);
  } else {
    return nullptr;
  }
}

REGISTER_VIOLATION(FLOW_TRAFFIC_SIGN_CODE, TrafficSign);

}  // namespace FLOW
