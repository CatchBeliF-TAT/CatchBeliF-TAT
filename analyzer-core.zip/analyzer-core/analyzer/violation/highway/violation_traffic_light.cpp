#include "violation_traffic_light.hpp"

#include <memory>

#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/helper.hpp"
#include "common/tad_internal.hpp"

#include "serving/violation_event.pb.h"
#include "serving/violation_config.pb.h"

#include "violation_highway_base.hpp"
#include "violation/violation_util.hpp"

#include "algorithm/traffic_light/traffic_light_recog.hpp"

namespace FLOW {

using namespace std;
static const std::string FLOW_TRAFFIC_LIGHT_CODE("2440");

ViolationTrafficLightConfig::ViolationTrafficLightConfig(const std::string& json)
    : detect_thresh_(1.0)
    , cooling_second_(600)
    , interval_second_(60)
    , interval2_second_(-1)
{
  std::string err;
  auto violation_cfg = std::make_shared<inference::ViolationConfig>();
  json2pb(json, violation_cfg.get(), &err);
  if (!err.empty()) {
    LOG(WARNING) << err << ", json= " << json;
    return;
  }
  auto& cfg = *violation_cfg;
  const int MIN_SIZE = 2 * 3;
  cooling_second_ =
      cfg.has_cooling_second() ? cfg.cooling_second() : cooling_second_;
  for (int i = 0; i < cfg.conditions_size(); i++) {
    const auto& cond = cfg.conditions(i);
    if (cond.name() == "violate_box") {
      if (cond.has_threshold()) {
          detect_thresh_ = cond.threshold();
      }
      if (cond.has_parking_second() && cond.parking_second()>0) {
          interval_second_ = cond.parking_second();
      }
      if (cond.has_period_second() && cond.period_second()>0) {
          interval_second_ = cond.period_second();
      }
      if (cond.has_period_second2() && cond.period_second2()>0) {
          interval2_second_ = cond.period_second2();
      }
      CHECK_GE(cond.data_size(), MIN_SIZE);
      VecFloat violate_data;
      std::copy_n(cond.data().begin(), cond.data_size() / 2 * 2,
                  std::back_inserter(violate_data));
      VecInt data_offset;
      std::copy_n(cond.data_offset().begin(), cond.data_offset_size(),
                  std::back_inserter(data_offset));
      if (data_offset.size() == 0) {
        data_offset.push_back(violate_data.size());
      }
      for (size_t i=0,start_pz=0; i < data_offset.size(); i++) {
        auto end_pz = std::min<int>(data_offset[i], violate_data.size());
        if (end_pz-start_pz >= 2*2) {
          violate_polygons_.resize(violate_polygons_.size()+1);
          violate_box_borders_.resize(violate_box_borders_.size()+1);
          BoxF& violate_box_border = violate_box_borders_.back();
          VecFloat& violate_polygon = violate_polygons_.back();
          // copy data
          violate_polygon.insert(violate_polygon.end(), &violate_data[start_pz], &violate_data[end_pz]);
          start_pz += violate_polygon.size();
          // cal border
          violate_box_border.xmin = violate_polygon[0];
          violate_box_border.xmax = violate_polygon[0];
          violate_box_border.ymin = violate_polygon[1];
          violate_box_border.ymax = violate_polygon[1];
          for (size_t j=2; j<violate_polygon.size(); j+=2){
            violate_box_border.xmin = std::min(violate_polygon[j], violate_box_border.xmin);
            violate_box_border.xmax = std::max(violate_polygon[j], violate_box_border.xmax);
            violate_box_border.ymin = std::min(violate_polygon[j+1], violate_box_border.ymin);
            violate_box_border.ymax = std::max(violate_polygon[j+1], violate_box_border.ymax);
          }
        }
      }
    }
  }
  enable_output_picture_ = cfg.enable_output_picture();
  data_ = violation_cfg;
}

class ViolationTrafficLightClassify : public ViolationHighwayBase {
 public:
  ViolationTrafficLightClassify(int object_id, const std::string& violation_id,
                               const spViolationTrafficLightConfig cfg)
      : ViolationHighwayBase(object_id, violation_id, cfg->data_)
      , cfg_(cfg)
      , is_cooling_(false)
      , trafficLightRecords_()
  {}

  virtual ~ViolationTrafficLightClassify() = default;

 public:
  virtual result_list_t check(BoxF& box, const ImageObjectsInfo& objs);
  virtual result_list_t get_results() const;
  void log_info(const ImageObjectsInfo& objs) const;
  result_list_t try_get_alarm(const ImageObjectsInfo& objs);

 protected:
  const spViolationTrafficLightConfig cfg_;
  bool is_cooling_;
  std::map<int64, VecBoxF> trafficLightRecords_;
};

class ICAlgEngine;

result_list_t ViolationTrafficLightClassify::get_results() const {
  result_list_t retv;
  const auto obj_id = object_id_;
  const auto stream_id = snapshots_[0].image->channel_id;
  const auto violation_code = cfg_->data_->code();
  const auto violation_name = cfg_->data_->name();
  const auto violation_id = violation_id_;
  const auto snapshots = snapshots_;
  const auto enable_output_picture = cfg_->enable_output_picture_;
  // const auto enable_save_picture = cfg_->data_->enable_save_debug_picture();
  auto action = [=](ICAlgEngine* engine) -> spEventProto {
    auto retv = std::make_shared<inference::Event>();
    inference::Event& event_with_type = *retv;
    event_with_type.set_event_type(get_event_type_form_code(violation_code));
    inference::ViolationEvent& highWayEvent = *(event_with_type.mutable_traffic_event());
    highWayEvent.set_stream_id(stream_id);
    // highWayEvent.set_obj_id(obj_id);
    highWayEvent.set_violation_id(violation_id);
    highWayEvent.set_violation_code(violation_code);
    highWayEvent.set_violation_name(violation_name);
    for (int i = 0; i < snapshots.size(); i++) {
      auto& image = snapshots[i].image;
      auto snap1 = highWayEvent.add_snapshots();
      snap1->set_now(snapshots[i].now.time_since_epoch().count());
      if (enable_output_picture) {
        snap1->set_image(Helper::get_pic(*(image->sframe->getMat())));
      }

      for (auto& box : image->objects) {
        auto obj = snap1->add_objects();
        auto strLabel = TrafficLight::helperGetStringTrafficLightColor(
              (TrafficLight::TrafficLightColor)(box.label));
        obj->set_type(strLabel);
        obj->set_score(box.score);
        obj->add_box(box.xmin);
        obj->add_box(box.ymin);
        obj->add_box(box.xmax);
        obj->add_box(box.ymax);
      }
    }

    return retv;
  };
  retv.push_back(action);
  return retv;
}

result_list_t ViolationTrafficLightClassify::check(
    BoxF& box, const ImageObjectsInfo& objs) {
  result_list_t retv;
  if (is_cooling_) {
      if (get_elapsed_time(objs).count() <= cfg_->cooling_second_ * 1000) {
        return retv;
      } else {
        this->is_cooling_ = false;
        this->clear_snapshot();
        this->trafficLightRecords_.clear();
      }
  }
  if (! objs.highways.traffic_light_event.processed){
    return retv;
  }
  if (cfg_->violate_box_borders_.empty()) {
      LOG(WARNING) << "==>skip check, no box in config"
                   << ", task_id=" << objs.channel_id
                   << ", violation_id=" << violation_id_;
    return retv;
  }

  if(snapshots_.empty()) {
    this->add_snapshot(box, objs);
    this->snapshots_.back().image = CloneWithoutImage(this->snapshots_.back().image);
  }

  static auto not_available = [](const BoxF& box){
        return (box.label == TrafficLight::TrafficLightColor::kColorBlack) ||
                (box.label == TrafficLight::TrafficLightColor::kColorEmpty);
  };

  auto traffic_lights = objs.highways.traffic_light_event.traffic_lights.count(violation_id_) ?
    objs.highways.traffic_light_event.traffic_lights.find(violation_id_)->second : VecBoxF();
  const auto time_n = get_elapsed_time(objs).count();
  //record save
  traffic_lights.resize(std::min(traffic_lights.size(), cfg_->violate_box_borders_.size()));
  trafficLightRecords_[time_n] = traffic_lights;

  // remove after error data
  auto bigger_itr = trafficLightRecords_.upper_bound(time_n);
  trafficLightRecords_.erase(bigger_itr, trafficLightRecords_.end());

  // check
  const int64_t max_period = std::max(cfg_->interval_second_, cfg_->interval2_second_);//秒
  const int64_t mini_req_time1 = cfg_->detect_thresh_*cfg_->interval_second_*1000;//毫秒
  const int64_t mini_req_time2 = cfg_->detect_thresh_*cfg_->interval2_second_*1000;//毫秒
  const int64_t total_time = trafficLightRecords_.rbegin()->first - trafficLightRecords_.begin()->first;//信号灯持续时间
  const int64_t frame_interval = total_time / (int)trafficLightRecords_.size();//多少毫秒一帧
  const int64_t start1 = trafficLightRecords_.rbegin()->first - cfg_->interval_second_*1000;//起始时刻
  const int64_t start2 = trafficLightRecords_.rbegin()->first - cfg_->interval2_second_*1000;
  static auto get_frame_interval_max_fn = [](const std::map<int64, VecBoxF>& in)->int64_t {
    int64 retv = 0;
    if (in.size()>=2){
      for(auto itr=in.begin(), itr2=++in.begin(); itr2!= in.end(); itr++,itr2++){
        retv = std::max(retv, itr2->first - itr->first);
      }
    }
    return retv;
  };

  std::vector<std::unordered_map<int,int> > counters(traffic_lights.size());
  for (const auto kv : trafficLightRecords_){
    //kv.first时间 second vecbox
      if (cfg_->interval_second_ >0 && kv.first >= start1) {
        for(int i=0; i<kv.second.size(); i++) {
          static const std::set<int> need_set = {
            TrafficLight::TrafficLightColor::kColorEmpty,
            TrafficLight::TrafficLightColor::kColorBlack,
          };
          if (need_set.count(kv.second[i].label)){
            counters[i][kv.second[i].label]++;
          }
        }
      }
      if (cfg_->interval2_second_ >0 && kv.first >= start2) {
        for(int i=0; i<kv.second.size(); i++) {
          static const std::set<int> need_set = {
            TrafficLight::TrafficLightColor::kColorGreen,
            TrafficLight::TrafficLightColor::kColorRed,
            TrafficLight::TrafficLightColor::kColorYellow,
            TrafficLight::TrafficLightColor::kColorDouble,
          };
          if (need_set.count(kv.second[i].label)) {
            counters[i][kv.second[i].label]++;
          }
        }
      }
  }

  // remove old data defer
  auto _remove_old_data = std::shared_ptr<void>(nullptr, [&](void*) {
  const auto older_time = time_n - max_period*1000;
  auto min_itr = trafficLightRecords_.lower_bound(older_time);
  trafficLightRecords_.erase(trafficLightRecords_.begin(), min_itr);
  });

  // output result
  std::vector<int> broken_light_index;
  for(int i=0; i<counters.size(); i++) {
    const auto broken_type = traffic_lights[i].label;
    const int broken_count = counters[i][broken_type];
    static const std::set<int> need_set = {
      TrafficLight::TrafficLightColor::kColorBlack,
    };
    static const std::set<int> need_set2 = {
      TrafficLight::TrafficLightColor::kColorGreen,
      TrafficLight::TrafficLightColor::kColorRed,
      TrafficLight::TrafficLightColor::kColorYellow,
      TrafficLight::TrafficLightColor::kColorDouble,
    };
    int match_index = -1;
    if (cfg_->interval_second_ > 0 &&
          need_set.count(broken_type) &&
          broken_count*frame_interval > mini_req_time1) {
      match_index = 0;
      broken_light_index.push_back(i);
    } else if (cfg_->interval2_second_ > 0 &&
          need_set2.count(broken_type) && 
          broken_count*frame_interval >= mini_req_time2) {
      match_index = 1;
      broken_light_index.push_back(i);
    } else {
      continue;
    }
    auto strLabel = TrafficLight::helperGetStringTrafficLightColor(
          (TrafficLight::TrafficLightColor)(broken_type));
    LOG(INFO) << "==>has broken light, " << objs.channel_id << "," << violation_id_ << "," << i
              << ",type=" << strLabel 
              << ",count=" << broken_count << "/" << trafficLightRecords_.size()
              << ",frame_interval=" << frame_interval << "/" << get_frame_interval_max_fn(trafficLightRecords_)
              << ",mini_req_time=(" << mini_req_time1 << "," << mini_req_time2 <<")["<<match_index<<"]";
  }
  if ( ! broken_light_index.empty()) {
    // found
    VecBoxF broken_lights;
    std::for_each(broken_light_index.begin(), broken_light_index.end(), [&](int index) {
      broken_lights.push_back(traffic_lights[index]);
    });

    this->is_cooling_ = true;
    this->clear_snapshot();
    this->add_snapshot(broken_lights.front(), objs);
    this->snapshots_.back().image->objects.clear();
    this->snapshots_.back().image->objects.swap( broken_lights );
    this->trafficLightRecords_.clear();
    retv = get_results();
  }

  return retv;
}

ViolationTrafficLightFactory::ViolationTrafficLightFactory(const std::string& id,
                                                         const std::string& cfg)
    : ViolationCommonFactory(id, cfg),
      id_(id),
      cfg_(std::make_shared<ViolationTrafficLightConfig>(cfg)) {}

const std::string& ViolationTrafficLightFactory::id() const { return id_; }

spIViolation ViolationTrafficLightFactory::CreateIViolation(const BoxF& obj) {
  if (obj.label == -1) {
    return std::make_shared<ViolationTrafficLightClassify>(obj.uid, id_, cfg_);
  } else {
    return nullptr;
  }
}

REGISTER_VIOLATION(FLOW_TRAFFIC_LIGHT_CODE, TrafficLight);

}  // namespace FLOW
