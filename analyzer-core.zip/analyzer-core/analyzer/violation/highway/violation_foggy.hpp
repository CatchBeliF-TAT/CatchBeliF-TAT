#ifndef VSS_VIOLATION_FLOW_FOGGY_HPP
#define VSS_VIOLATION_FLOW_FOGGY_HPP

#include "violation/traffic/violation_common.hpp"

namespace inference {
    class ViolationConfig;
}

namespace FLOW {

class ViolationFoggyConfig {
 public:
  ViolationFoggyConfig(const std::string& json);
  bool ParseJson(const std::string& json);

 public:
  std::shared_ptr<inference::ViolationConfig> data_;
  std::string                                 code_;
  bool                                        enable_output_picture_;
  int                                         cooling_second_;
  float                                       foggy_score_thresh_;
};

typedef std::shared_ptr<ViolationFoggyConfig> spViolationFoggyConfig;


 class ViolationFoggyFactory : public ViolationCommonFactory
 {
public:
   ViolationFoggyFactory(const std::string& id, const std::string& cfg);
    virtual ~ViolationFoggyFactory()=default;

public:
    virtual const std::string& id()const;
    virtual spIViolation CreateIViolation(const BoxF& obj);

protected:
    std::string                              id_;
    spViolationFoggyConfig                   cfg_;
 };

} // namespace FLOW
#endif // VSS_VIOLATION_DEBUG_HPP

