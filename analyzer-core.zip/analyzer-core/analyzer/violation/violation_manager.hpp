#ifndef VSS_VIOLATION_MANAGER_HPP
#define VSS_VIOLATION_MANAGER_HPP

#include <map>
#include <string>
#include <vector>
#include <memory>
#include <mutex>
#include <unordered_map>

#include "serving/config.pb.h"

namespace FLOW {

    typedef struct ImageObjectsInfo_ ImageObjectsInfo;
    typedef std::shared_ptr<ImageObjectsInfo> spImageObjectsInfo;
    typedef std::vector<spImageObjectsInfo> VecImage;

    class CStreamViolation;
    typedef std::shared_ptr<CStreamViolation> spCStreamViolation;

    class ViolationEventProcesser;
    typedef std::shared_ptr<ViolationEventProcesser> spViolationEventProcesser;
    typedef std::weak_ptr<ViolationEventProcesser> wpViolationEventProcesser;

    class CViolationManager {
    public:
        CViolationManager(wpViolationEventProcesser event, const std::string& config="");
        ~CViolationManager() = default;

    public:
        int AddViolation(const std::string& channel_id, const std::string& violation_id, const std::string& cfg);
        int AddStreamToTask(const std::string& task_id, const std::string& channel_id);
        int RemoveViolation(const std::string& channel_id, const std::string& violation_id);
        int RemoveViolationAll(const std::string& channel_id);
        void Process(const VecImage& images);

    private:
        static std::string                         try_patch(const std::map<std::string, std::string>& all_patch, const std::string& config);
        static std::map<std::string, std::string>  parse_patch(const std::string& config);
        static int                                 add_static_patch(std::map<std::string, std::string>& config_patch_map);
        std::string                                patch_global_config(const std::string& config) const;

    private:
        typedef std::unordered_map<std::string, spCStreamViolation> StreamOrTaskId2ViolationMap;
        typedef std::unordered_map<std::string, std::string> StreamId2TaskId2Map;
        StreamOrTaskId2ViolationMap channel_or_task_violation_map_;
        StreamId2TaskId2Map channel_task_map_;
        wpViolationEventProcesser violation_evenv_manager_;
        const std::map<std::string, std::string> config_patch_map_;
        const inference::AnalyzerConfig analyzer_cfg_;
        std::mutex lock_;
    };
}

#endif //VSS_VIOLATION_MANAGER_HPP
