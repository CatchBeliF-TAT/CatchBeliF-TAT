#ifndef TAD_VIOLATION_REGISTRY_HPP
#define TAD_VIOLATION_REGISTRY_HPP

#include <map>
#include <regex>
#include "common/log.hpp"
#include "violation_interface.hpp"

namespace FLOW {

    using Creator = std::function<spIViolationFactory(const std::string&, const std::string&)>;

    typedef std::map<std::string, Creator> CreatorRegistry;
    typedef std::map<std::string, std::pair<std::regex, Creator>> PatternCreatorRegistry;
    inline PatternCreatorRegistry::iterator match_code_pattern(const std::string& code, PatternCreatorRegistry& all) {
        for (auto itr=all.begin(); itr!=all.end(); itr++) {
            if (std::regex_match(code, itr->second.first)) {
                return itr;
            }
        }
      return all.end();
    }

    class CViolationRegistry {
    public:
        static CreatorRegistry& Registry() {
            static CreatorRegistry* g_registry_ = new CreatorRegistry();
            return *g_registry_;
        }
        static PatternCreatorRegistry& PatternRegistry() {
            static PatternCreatorRegistry* g_registry_ = new PatternCreatorRegistry();
            return *g_registry_;
        }

        static void AddCreator(const std::string& code, Creator creator) {
            CreatorRegistry& registry = Registry();
            CHECK_EQ(registry.count(code), 0)
                    << "Violation code " << code << " already registered.";
            LOG(DEBUG) << "Registering code: " << code;
            registry[code] = creator;
        }

        static void AddPatternCreator(const std::string& code, Creator creator, bool check=true) {
            PatternCreatorRegistry& registry = CViolationRegistry::PatternRegistry();
            if (check) {
                CHECK_EQ(registry.count(code), 0)
                    << "Violation pattern " << code << " already registered.";
            }
            LOG(DEBUG) << "Registering pattern: " << code;
            registry[code].first  = std::regex(code);
            registry[code].second = creator;
        }

        static void AddCreatorV2(const std::string& code, Creator creator) {
            static std::regex need_patern("^[0-9]{4}$");
            if (std::regex_match(code, need_patern)){
                const auto newCode = code + "[0-9]{2}$";
                AddCreator(code, creator);
                AddPatternCreator(newCode, creator, false);
            } else if (code.length() < 4) {
                AddCreator(code, creator);
            } else {
                AddPatternCreator(code, creator, false);
            }
        }

        static spIViolationFactory CreateViolationFactory(const std::string &code,
                const std::string &violation_id,
                const std::string &config) {

            CreatorRegistry& registry = Registry();
            if (registry.find(code) != registry.end()) {
                return registry[code](violation_id, config);
            }
            PatternCreatorRegistry& patternRegistry = PatternRegistry();
            auto pattern_itr = match_code_pattern(code, patternRegistry);
            if ( pattern_itr != patternRegistry.end() ) {
                return pattern_itr->second.second(violation_id, config);
            }
            CHECK_EQ(registry.count(code), 1) << "Unknown ViolationFactory code: " << code;
            return nullptr;
        }
    private:
        CViolationRegistry() {};
    };

    // helper class
    template<typename T>
    class ViolationCreatorRegistererHelperTemplate{
    public:
        typedef std::function<spIViolationFactory(const std::string&, const std::string&)> Creater;
    public:
        static spIViolationFactory CreaterFn(const std::string& code, const std::string& cfg) {
            spIViolationFactory retv = std::make_shared<T>(code, cfg);
            return retv;
        }
    public:
        ViolationCreatorRegistererHelperTemplate(const std::string& code){
            CViolationRegistry::AddCreatorV2(code, ViolationCreatorRegistererHelperTemplate::CreaterFn);
        }
    };

    #define TAD_CONCATENATE_IMPL(s1, s2) s1##s2
    #define TAD_CONCATENATE(s1, s2) TAD_CONCATENATE_IMPL(s1, s2)
    #ifdef __COUNT__
    #define TAD_ANONYMOUS_VARIABLE(s) TAD_CONCATENATE(s, __COUNT__)
    #else
    #define TAD_ANONYMOUS_VARIABLE(s) TAD_CONCATENATE(s, __LINE__)
    #endif

    #define REGISTER_VIOLATION_ANONYMOUS_IMPL(code, classname, anonymous_classname) \
        static ViolationCreatorRegistererHelperTemplate<Violation##classname##Factory> g_creator_##anonymous_classname(code);
    #define REGISTER_VIOLATION_ANONYMOUS(code, classname, anonymous_classname) \
        REGISTER_VIOLATION_ANONYMOUS_IMPL(code, classname, anonymous_classname)

    #define  REGISTER_VIOLATION(name, classname)\
        REGISTER_VIOLATION_ANONYMOUS(name, classname, TAD_ANONYMOUS_VARIABLE(classname))
    #define  REGISTER_VIOLATION_PATTERN(name, classname)\
        REGISTER_VIOLATION_ANONYMOUS(name, classname, TAD_ANONYMOUS_VARIABLE(classname))
}

#endif  // TAD_VIOLATION_REGISTRY_HPP
