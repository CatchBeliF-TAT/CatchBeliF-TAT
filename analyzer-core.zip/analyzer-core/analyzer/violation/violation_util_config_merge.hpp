#ifndef MERGE_HPP
#define MERGE_HPP

#include <map>
#include <google/protobuf/descriptor.h>
#include <google/protobuf/message.h>

namespace FLOW{
    void _search(const google::protobuf::Message& base_msg, const google::protobuf::Message& msg, const google::protobuf::FieldDescriptor* base_field,
                std::map<std::string,int>& m_from, std::map<std::string,int>& m_to, std::vector<std::string>& v_from);

    void merge_violation_cfg(const google::protobuf::Message& base_msg, google::protobuf::Message* msg, const bool& merge_force_flag) {
        const google::protobuf::Reflection *base_ref  = base_msg.GetReflection();
        const google::protobuf::Descriptor *base_des  = base_msg.GetDescriptor();
        const google::protobuf::Reflection *ref       = msg->GetReflection();
        size_t           base_count = base_des->field_count();

        for (size_t i = 0; i < base_count; i ++) {
            const google::protobuf::FieldDescriptor* base_field = base_des->field(i);
            if (base_field->is_optional() && !base_ref->HasField(base_msg, base_field)) {
                continue;
            }
            if (base_field->is_repeated() && !base_ref->FieldSize(base_msg, base_field)) {
                continue;
            }
            if (base_field->cpp_type() == google::protobuf::FieldDescriptor::CPPTYPE_MESSAGE) {

                if (base_field->is_repeated()) {
                    std::map<std::string, int> m_from, m_to;
                    std::vector<std::string> v_from;
                    _search(base_msg, *msg, base_field, m_from, m_to, v_from);
                    for(auto& itr : v_from) {
                        auto m_itr = m_to.find(itr);
                        if (m_itr != m_to.end()) {
                            merge_violation_cfg(base_ref->GetRepeatedMessage(base_msg, base_field, m_from[itr]),
                                    ref->MutableRepeatedMessage(msg, base_field, m_itr->second), merge_force_flag);
                        }
                        else {
                            ref->AddMessage(msg, base_field)->MergeFrom(
                              base_ref->GetRepeatedMessage(base_msg, base_field, m_from[itr]));
                        }
                    }
                    if (m_from.empty()) {
                        if (! merge_force_flag && ref->FieldSize(*msg, base_field) != 0) {
                            continue;
                        }
                        size_t array_size = base_ref->FieldSize(base_msg, base_field);
                        if (merge_force_flag && ref->FieldSize(*msg, base_field) != 0)
                            ref->ClearField(msg, base_field);
                        for (size_t j = 0; j < array_size; j ++) {
                            const google::protobuf::Message& sub_msg = base_ref->GetRepeatedMessage(base_msg, base_field, j);
                            ref->AddMessage(msg, base_field)->MergeFrom(sub_msg);
                        }
                    }
                }
                else {
                    merge_violation_cfg(base_ref->GetMessage(base_msg, base_field),
                            ref->MutableMessage(msg, base_field), merge_force_flag);
                }

                continue ;
            }// end if (base_field->cpp_type() == google::protobuf::FieldDescriptor::CPPTYPE_MESSAGE)

            if (base_field->is_repeated()) {
                if (! merge_force_flag && ref->FieldSize(*msg, base_field) != 0) {
                    continue;
                }
                size_t array_size = base_ref->FieldSize(base_msg, base_field);
                if (merge_force_flag && ref->FieldSize(*msg, base_field) != 0)
                    ref->ClearField(msg, base_field);
                for (size_t j = 0; j < array_size; j ++) {
                    switch (base_field->cpp_type()) {
    #define HANDLE_TYPE(CPPTYPE, METHOD)                                                 \
                        case google::protobuf::FieldDescriptor::CPPTYPE_##CPPTYPE:                         \
                              ref->Add##METHOD(msg, base_field,                          \
                                base_ref->GetRepeated##METHOD(base_msg, base_field, j)); \
                              break;

                        HANDLE_TYPE(INT32 , Int32 );
                        HANDLE_TYPE(INT64 , Int64 );
                        HANDLE_TYPE(UINT32, UInt32);
                        HANDLE_TYPE(UINT64, UInt64);
                        HANDLE_TYPE(FLOAT , Float );
                        HANDLE_TYPE(DOUBLE, Double);
                        HANDLE_TYPE(BOOL  , Bool  );
                        HANDLE_TYPE(STRING, String);
                        HANDLE_TYPE(ENUM  , Enum  );
    #undef HANDLE_TYPE
                        default:
                            break;
                    }
                }
            }
            else {
                if (! merge_force_flag && ref->HasField(*msg, base_field)) {
                    continue;
                }
                switch (base_field->cpp_type()) {
    #define HANDLE_TYPE(CPPTYPE, METHOD)                                 \
                    case google::protobuf::FieldDescriptor::CPPTYPE_##CPPTYPE:             \
                        ref->Set##METHOD(msg, base_field,                \
                        base_ref->Get##METHOD(base_msg, base_field));    \
                        break;

                    HANDLE_TYPE(INT32 , Int32 );
                    HANDLE_TYPE(INT64 , Int64 );
                    HANDLE_TYPE(UINT32, UInt32);
                    HANDLE_TYPE(UINT64, UInt64);
                    HANDLE_TYPE(FLOAT , Float );
                    HANDLE_TYPE(DOUBLE, Double);
                    HANDLE_TYPE(BOOL  , Bool  );
                    HANDLE_TYPE(STRING, String);
                    HANDLE_TYPE(ENUM  , Enum  );
    #undef HANDLE_TYPE
                    default:
                        break;
                }
            }
        }// end for (size_t i = 0; i < base_count; i ++)
    }// end merge

    void _search(const google::protobuf::Message& base_msg, const google::protobuf::Message& msg, const google::protobuf::FieldDescriptor* base_field,
                std::map<std::string,int>& m_from, std::map<std::string,int>& m_to, std::vector<std::string>& v_from) {
        const google::protobuf::Reflection *base_ref  = base_msg.GetReflection();
        const google::protobuf::Descriptor *base_des  = base_msg.GetDescriptor();
        int array_size = base_ref->FieldSize(base_msg, base_field);
        for (size_t i = 0; i < array_size; i ++) {
            const google::protobuf::Message&    sub_msg = base_ref->GetRepeatedMessage(base_msg, base_field, i);
            const google::protobuf::Reflection* sub_ref = sub_msg.GetReflection();
            const google::protobuf::Descriptor* sub_des = sub_msg.GetDescriptor();

            const google::protobuf::FieldDescriptor* sub_field = sub_des->FindFieldByName("name");
            if (! sub_field) continue;
            std::string tmp_name = sub_ref->GetString(sub_msg, sub_field);
            v_from.push_back(tmp_name);
            m_from[tmp_name] = i;
        }

        const google::protobuf::Reflection *ref  = msg.GetReflection();
        const google::protobuf::Descriptor *des  = msg.GetDescriptor();
        array_size = ref->FieldSize(msg, base_field);
        for (size_t i = 0; i < array_size; i ++) {
            const google::protobuf::Message&    sub_msg = ref->GetRepeatedMessage(msg, base_field, i);
            const google::protobuf::Reflection* sub_ref = sub_msg.GetReflection();
            const google::protobuf::Descriptor* sub_des = sub_msg.GetDescriptor();

            const google::protobuf::FieldDescriptor* sub_field = sub_des->FindFieldByName("name");
            if (! sub_field) continue;
            m_to[sub_ref->GetString(sub_msg, sub_field)] = i;
        }

    }
} // namespace FLOW
#endif
