#ifndef VSS_I_CONDITION_DATA_HPP
#define VSS_I_CONDITION_DATA_HPP

#include <memory>

#include "serving/violation_event.pb.h"
#include "violation/traffic/violation_base.hpp"

namespace FLOW {
class IConditionData {
public:
    IConditionData() = default;
    virtual ~IConditionData() = default;
    virtual void UpdateSnapshotReuslt(FLOW::ViolationSnapshot* pSn){}
};

typedef std::shared_ptr<IConditionData> spIConditionData;

}  // namespace FLOW
#endif  // VSS_I_CONDITION_DATA_HPP
