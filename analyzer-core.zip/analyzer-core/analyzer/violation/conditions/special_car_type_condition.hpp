#ifndef VSS_SPECIAL_CAR_TYPE_CONDITION_HPP
#define VSS_SPECIAL_CAR_TYPE_CONDITION_HPP

#include <functional>
#include <iterator>

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

namespace FLOW {
inline std::function<bool(const inference::ViolationEvent& e)> CreateSpecialCarTypeCondition(inference::ViolationConfig* cfg) {
    std::set<std::string> special_car_types;
    bool bPassConfig = true;
    for (const auto& condition : cfg->conditions()) {
        if (condition.name() == "special_car_type") {
                std::copy(condition.special_car_type().begin(),
                          condition.special_car_type().end(),
                          std::inserter(special_car_types, special_car_types.end()));
                if (condition.action() == "drop") {
                    bPassConfig = false;
                }
         }
     }

     std::function<bool(const inference::ViolationEvent& e)> condition = [special_car_types, bPassConfig](const inference::ViolationEvent& e)->bool {
         if (special_car_types.empty()) {
             return bPassConfig;
         }
         for (const auto& snapshot : e.snapshots()) {
             if( snapshot.objects_size() == 0) {
                 continue;
             }
             const auto& special_car_type = snapshot.objects(0).special_car_type();
             if (special_car_types.count(special_car_type) > 0) {
                 return bPassConfig;
             }
         }
         return !bPassConfig;
    };
    return condition;
}
} // namespace FLOW
#endif
