#ifndef VSS_POLYGON_CONDITION_HPP
#define VSS_POLYGON_CONDITION_HPP

#include <memory>
#include <functional>

#include "i_condition_data.hpp"
#include "serving/violation_config.pb.h"
#include "common/tad_internal.hpp"
#include "violation/violation_util.hpp"
#include "algorithm/traffic_light/traffic_light_recog.hpp"
#include "algorithm/vehicleattribute/vehicle_attr.hpp"

namespace FLOW {

typedef std::function<bool(const BoxF& last_box, const BoxF& current_box, const ImageObjectsInfo& objs)> fn_check_action;
typedef std::function<bool(const BoxF& last_box, const BoxF& current_box, const ImageObjectsInfo& objs, spIConditionData& data)> fn_check_action_withdata;

inline inference::Condition::ModeArgs PrasePolygonModeArgs(const inference::Condition& current_condition) {
    if (current_condition.has_mode_args()) {
        return current_condition.mode_args();
    }
    // old config
    inference::Condition::ModeArgs retv;
    retv.set_type("in"); //default
    if (current_condition.has_polygon_action()) {
        retv.set_type(current_condition.polygon_action());
        retv.mutable_center()->set_x(0.5);
        retv.mutable_center()->set_y(0.5);
    }
    return retv;
}

fn_check_action CreatePolygonCondition(const inference::Condition& current_condition, bool has_traffic_light_box, std::string violation_id="") {
    fn_check_action action = nullptr;
    if (current_condition.type() == "polygon" ||
        current_condition.type()== "mulit-polygon" || // spelling mistake
        current_condition.type()== "multi-polygon" ||
        current_condition.type()== "multi_polygon") {
        auto data_offset = current_condition.data_offset();
        if (data_offset.size() == 0) {
            data_offset.Add(current_condition.data_size() / 2 * 2);
        }
        const auto mode_args = PrasePolygonModeArgs(current_condition);
        action = [current_condition, mode_args, data_offset, has_traffic_light_box, violation_id] (
            const BoxF& last_box, const BoxF& box, const ImageObjectsInfo& objs)->bool
        {
            if (has_traffic_light_box){
                auto pcolor = objs.tlc.find(violation_id);
                if(pcolor==objs.tlc.end()){
                    return false;
                }
                if(pcolor->second.color!=TrafficLight::kColorRed){
                    return false;
                }
            }
            const auto polygon_action = mode_args.type();
            const auto data = current_condition.data();
            const float x_scale = mode_args.has_center() && mode_args.center().has_x()
                            ? mode_args.center().x() : 0.5;
            const float y_scale = mode_args.has_center() && mode_args.center().has_y()
                            ? mode_args.center().y() : 0.5;
            bool b_box_in = false;
            bool b_last_box_in = false;

            // current
            int start_offset = 0;
            for (auto offset : data_offset) {
                if (valid_boxes_scale_center_in_polygon(box, x_scale, y_scale, data.begin() + start_offset, offset - start_offset)) {
                    b_box_in = true;
                    break;
                }
                start_offset = offset;
            }
            if (polygon_action == "in") {
                return b_box_in;
            } else if (polygon_action == "enter" && !b_box_in) {
                return false;
            } else if (polygon_action == "leave" && b_box_in) {
                return false;
            } else if (polygon_action == "across") {
                // nop
            } else { // "in" as default
                return b_box_in;
            }

            // prev
            start_offset = 0;
            for (auto offset : data_offset) {
                if (valid_boxes_scale_center_in_polygon(last_box, x_scale, y_scale, data.begin() + start_offset, offset - start_offset)) {
                    b_last_box_in = true;
                    break;
                }
                start_offset = offset;
            }
            if (polygon_action == "enter") {
                return (!b_last_box_in) && b_box_in;
            } else if (polygon_action == "leave") {
                return (b_last_box_in) && (!b_box_in);
            } else if (polygon_action == "across") {
                return (b_last_box_in != b_box_in);
            } else { // "in" as default
                return b_box_in;
            }
        };
    }
    return action;
}

inline int64_t GetOffsetTimePoint(const inference::Condition& current_condition, const ImageObjectsInfo& frame) {
    return current_condition.has_enable_use_pts() 
            ? frame.pts
            : std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now()).time_since_epoch().count();
}

fn_check_action_withdata CreatePolygonConditionV2(const inference::Condition& current_condition, bool has_traffic_light_box, std::string violation_id="") {
    struct PolygonConditionData : public IConditionData{
        PolygonConditionData(const BoxF& b, int64_t now) : first_box(b), begin_stop_time(now) {}
        enum STATUS{
            NOT_ENTER,
            ALREADY_IN,
            LEAVE,
        };
        STATUS                  status=NOT_ENTER;
        bool                    reach_asked_time = false;
        int64_t                 begin_stop_time;
        BoxF                    first_box;
    };
    fn_check_action_withdata action = nullptr;
    auto check =CreatePolygonCondition(current_condition, has_traffic_light_box, violation_id);
    if (check != nullptr) {
        if (current_condition.has_parking_second() && current_condition.parking_second() > 0) {
            //in
            auto in_condition = current_condition;
            in_condition.set_polygon_action("in");
            auto check_in =CreatePolygonCondition(in_condition, has_traffic_light_box, violation_id);
            //enter
            auto enter_condition = current_condition;
            enter_condition.set_polygon_action("enter");
            auto check_enter =CreatePolygonCondition(enter_condition, has_traffic_light_box, violation_id);
            //leave
            auto leave_condition = current_condition;
            leave_condition.set_polygon_action("leave");
            auto check_leave =CreatePolygonCondition(leave_condition, has_traffic_light_box, violation_id);

            auto second = in_condition.parking_second()*1000;
            if (current_condition.polygon_action() == "enter-in") {
                action = [check_enter, check_in, enter_condition, second](const BoxF& last_box, const BoxF& box, const ImageObjectsInfo& frame, spIConditionData& pdata)->bool {
                    const auto now = GetOffsetTimePoint(enter_condition, frame);
                    if (pdata == nullptr) {
                        if (check_enter(last_box, box, frame)) {
                            LOG(DEBUG) << "==>enter polygon" << -1 << ", "
                                    << frame.channel_id << "," << "--" << "," << box.uid << ","
                                    << "pts=" << frame.pts;
                            pdata = std::make_shared<PolygonConditionData>(box, now);
                        }
                    } else if ((now - std::dynamic_pointer_cast<PolygonConditionData>(pdata)->begin_stop_time) >= second) {
                        pdata.reset();
                        if (check_in(last_box, box, frame)) {
                            LOG(DEBUG) << "==>enter polygon2" << -1 << ", "
                                    << frame.channel_id << "," << "--" << "," << box.uid << ","
                                    << "pts=" << frame.pts;
                            return true;
                        }
                    }
                    return false;
                };
                //float overlap_ratio = Boxes::IoU(revised_box, revised_last_box);
            } else if (current_condition.polygon_action() == "enter_duration_not_reached") {
                action = [current_condition, check_enter, check_in, check_leave](const BoxF& last_box, const BoxF& box, const ImageObjectsInfo& frame, spIConditionData& pdataOri)->bool {
                    const auto now = GetOffsetTimePoint(current_condition, frame);
                    if (pdataOri == nullptr){
                        pdataOri = std::make_shared<PolygonConditionData>(box, now);
                    }

                    auto pdata = std::dynamic_pointer_cast<PolygonConditionData>(pdataOri);
                    if(pdata->status == PolygonConditionData::NOT_ENTER){
                        if(check_in(last_box, box, frame)){
                            pdata->status = PolygonConditionData::ALREADY_IN;
                            pdata->begin_stop_time = now;
                            pdata->first_box = box;
                            LOG(DEBUG) << "==>enter polygon" << -1 << ", "
                                    << frame.channel_id << "," << "--" << "," << box.uid << ","
                                    << "pts=" << frame.pts;
                        }
                    } else if(pdata->status == PolygonConditionData::ALREADY_IN){
                        if(check_in(last_box, box, frame)){
                            auto iou = Boxes::IoU(pdata->first_box, box);
                            auto stop_time = now - pdata->begin_stop_time;
                            box.park_ms = stop_time;
                            if(iou>=0.9){
                                if( stop_time >= current_condition.parking_second()*1000 ){
                                    pdata->reach_asked_time = true;
                                    LOG(DEBUG) << "==>reach_asked_time" << -1 << ", "
                                            << frame.channel_id << "," << "--" << "," << box.uid << ","
                                            << "pts=" << frame.pts;
                                }
                            }else{
                                pdata->begin_stop_time = now;
                                pdata->first_box = box;
                                LOG(DEBUG) << "==>reset, iou:"<<iou << ", "
                                        << frame.channel_id << "," << "--" << "," << box.uid << ","
                                        << "pts=" << frame.pts;
                            }
                        }else{
                            pdata->status = PolygonConditionData::LEAVE;
                            if(!pdata->reach_asked_time){
                                return true;
                            }
                        }
                    } else if(pdata->status == PolygonConditionData::LEAVE){
                        if(!pdata->reach_asked_time){
                            return true;
                        }
                    }
                    return false;
                };
            }else {
            // only "in" support
            action = [check_in, current_condition, second](const BoxF& last_box, const BoxF& box, const ImageObjectsInfo& frame, spIConditionData& pdata)->bool {
                if (check_in(last_box, box, frame)) {
                    const auto now = GetOffsetTimePoint(current_condition, frame);
                    if (pdata == nullptr) {
                        LOG(DEBUG) << "==>enter polygon" << -1 << ", "
                                << frame.channel_id << "," << "--" << "," << box.uid << ","
                                << "pts=" << frame.pts;
                        pdata = std::make_shared<PolygonConditionData>(box, now);
                    }
                    auto data = std::dynamic_pointer_cast<PolygonConditionData>(pdata);
                    if ((now - data->begin_stop_time) >= second) {
                        LOG(DEBUG) << "==>enter polygon2" << -1 << ", "
                                << frame.channel_id << "," << "--" << "," << box.uid << ","
                                << "pts=" << frame.pts;
                        return true;
                    }
                }
                return false;
            };
            }
        } else {
            action = [check](const BoxF& last_box, const BoxF& box, const ImageObjectsInfo& frame, spIConditionData& pdata)->bool {
                return check(last_box, box, frame);
            };
        }
    }
    return action;
}

} // namespace FLOW
#endif
