#ifndef VSS_SUB_TYPE_CONDITION_HPP
#define VSS_SUB_TYPE_CONDITION_HPP

#include <functional>
#include <iterator>

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

namespace FLOW {
inline std::function<bool(const inference::ViolationEvent& e)> CreateSubTypeCondition(inference::ViolationConfig* cfg) {
    std::set<std::string> sub_types;
    bool bPassConfig = true;
    for (const auto& condition : cfg->conditions()) {
        if (condition.name() == "sub_type") {
                std::copy(condition.sub_type().begin(),
                          condition.sub_type().end(),
                          std::inserter(sub_types, sub_types.end()));
                if (condition.action() == "drop") {
                    bPassConfig = false;
                }
         }
     }

     std::function<bool(const inference::ViolationEvent& e)> condition = [sub_types, bPassConfig](const inference::ViolationEvent& e)->bool {
         if (sub_types.empty()) {
             return bPassConfig;
         }
         for (const auto& snapshot : e.snapshots()) {
             if( snapshot.objects_size() == 0) {
                 continue;
             }
             const auto& sub_type = snapshot.objects(0).sub_type();
             if (sub_types.count(sub_type) > 0) {
                 return bPassConfig;
             }
         }
         return !bPassConfig;
    };
    return condition;
}
} // namespace FLOW
#endif
