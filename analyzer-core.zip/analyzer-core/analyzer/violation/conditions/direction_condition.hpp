#ifndef VSS_DIRECTION_CONDITION_HPP
#define VSS_DIRECTION_CONDITION_HPP

#include <functional>
#include <iterator>

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

namespace FLOW {
std::function<bool(const inference::ViolationEvent& e)> CreateDirectionCondition(inference::ViolationConfig* cfg) {
    std::set<std::string> directions;
    bool bPassConfig = true;
    for (const auto& condition : cfg->conditions()) {
        if (condition.name() == "direction") {
                std::copy(condition.direction().begin(),
                          condition.direction().end(),
                          std::inserter(directions, directions.end()));
                if (condition.action() == "drop") {
                    bPassConfig = false;
                }
         }
     }

     std::function<bool(const inference::ViolationEvent& e)> condition = [directions, bPassConfig](const inference::ViolationEvent& e)->bool {
         if (directions.empty()) {
             return bPassConfig;
         }
         for (const auto& snapshot : e.snapshots()) {
             if( snapshot.objects_size() == 0) {
                 continue;
             }
             const auto& direction = snapshot.objects(0).direction();
             if (directions.count(direction) > 0) {
                 return bPassConfig;
             }
         }
         return !bPassConfig;
    };
    return condition;
}
} // namespace FLOW
#endif
