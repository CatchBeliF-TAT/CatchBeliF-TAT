
#include <algorithm>

#include "time_condition.hpp"

#include "common/log.hpp"
#include "serving/violation_config.pb.h"

using namespace std;

namespace FLOW {

std::pair<bool,std::string> TimeCondition::startsWith(const string& haystack, const string& needle) {
    std::pair<bool,std::string> retv;
    retv.first = needle.length() <= haystack.length() && equal(needle.begin(), needle.end(), haystack.begin());
    if (retv.first) {
        retv.second = haystack.substr(needle.length());
    }
    return retv;
}

TimeConditionMap CreateTimeConditionMap(const inference::ViolationConfig& cfg) {
    TimeConditionMap time_condition_map;
    int64_t start_date= 0;
    int64_t end_date  = 0;
    for (int i=0; i<cfg.conditions_size(); i++) {
        const auto& cond = cfg.conditions(i);
        if (cond.name() == "start_date"){
            start_date = cond.data_number();
        }
        if (cond.name() == "end_date"){
            end_date = cond.data_number();
        }
        std::pair<bool,std::string> value;
        if ( (value=TimeCondition::startsWith(cond.name(), "available_times")).first ){
            auto& available_times = time_condition_map[value.second].available_times_;
            available_times.clear();
            std::copy_n(cond.data().begin(), cond.data_size()/2*2, std::back_inserter(available_times));
        }
        if ( (value=TimeCondition::startsWith(cond.name(), "week_pattern")).first ){
            auto& week_pattern = time_condition_map[value.second].week_pattern_;
            week_pattern = std::regex(cond.data_string());
        }
    }
    for(auto& time_condition : time_condition_map){
        time_condition.second.start_date_ = start_date;
        time_condition.second.end_date_ = end_date;
    }
    return time_condition_map;
}
//keliu
TimeConditionMap CreateTimeConditionMap(const inference::MassiveflowViolationConfig& cfg) {
    inference::ViolationConfig jiaotong_config;
    *(jiaotong_config.mutable_conditions()) = cfg.conditions();
    return CreateTimeConditionMap(jiaotong_config);
}

} // namespace FLOW
