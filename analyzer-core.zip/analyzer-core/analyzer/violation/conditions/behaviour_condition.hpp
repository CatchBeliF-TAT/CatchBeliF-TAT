#ifndef VSS_BEHAVIOUR_CONDITION_HPP
#define VSS_BEHAVIOUR_CONDITION_HPP

#include <functional>
#include <iterator>

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

namespace FLOW {
std::function<bool(const inference::ViolationEvent& e)> CreateBehaviourCondition(inference::ViolationConfig* cfg) {
    std::set<std::string> nonmotor_behaviours;
    int min_req_count=1;
    bool bPassConfig = true;
    for (const auto& condition : cfg->conditions()) {
        if (condition.name() == "nonmotor_behaviour") {
                min_req_count = condition.has_data_number() ? condition.data_number() : min_req_count;
                std::copy(condition.nonmotor_behaviour().begin(),
                          condition.nonmotor_behaviour().end(),
                          std::inserter(nonmotor_behaviours, nonmotor_behaviours.end()));
                if (condition.action() == "drop") {
                    bPassConfig = false;
                }
         }
     }

     std::function<bool(const inference::ViolationEvent& e)> condition = [nonmotor_behaviours, min_req_count, bPassConfig](const inference::ViolationEvent& e)->bool {
         if (nonmotor_behaviours.empty()) {
             return bPassConfig;
         }

         int match_count=0;
         for (const auto& snapshot : e.snapshots()) {
             if( snapshot.objects_size() == 0) {
                 continue;
             }
             const auto& inBehaviours = snapshot.objects(0).nonmotor_behaviour();
             int has_behaviour_count=0;
             for (const auto& nonmotor_behaviour : inBehaviours) {
                 if (nonmotor_behaviours.count(nonmotor_behaviour) > 0) {
                     has_behaviour_count ++;
                 }
             }
             if (nonmotor_behaviours.size() == has_behaviour_count) {
                 match_count ++;
             }
         }
         if(match_count >= min_req_count) {
            return bPassConfig;
         }
         return !bPassConfig;
    };
    return condition;
}
} // namespace FLOW
#endif
