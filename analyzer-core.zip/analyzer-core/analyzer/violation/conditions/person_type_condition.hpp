#ifndef VSS_PERSON_TYPE_CONDITION_HPP
#define VSS_PERSON_TYPE_CONDITION_HPP

#include <functional>
#include <iterator>

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

namespace FLOW {
std::function<bool(const inference::ViolationEvent& e)> CreatePersonTypeCondition(inference::ViolationConfig* cfg) {
    std::set<std::string> person_types;
    bool bPassConfig = true;
    for (const auto& condition : cfg->conditions()) {
        if (condition.name() == "person_type") {
                std::copy(condition.person_type().begin(),
                          condition.person_type().end(),
                          std::inserter(person_types, person_types.end()));
                if (condition.action() == "drop") {
                    bPassConfig = false;
                }
         }
     }

     std::function<bool(const inference::ViolationEvent& e)> condition = [person_types, bPassConfig](const inference::ViolationEvent& e)->bool {
         if (person_types.empty()) {
             return bPassConfig;
         }
         for (const auto& snapshot : e.snapshots()) {
            if( snapshot.objects_size() == 0) {
                continue;
            }
            if( !snapshot.objects(0).has_person_type()) {
                continue;
            }
            const auto& person_type = snapshot.objects(0).person_type();
            if (person_types.count(person_type) > 0) {
                return bPassConfig;
            }
         }
         return !bPassConfig;
    };
    return condition;
}
} // namespace FLOW
#endif // VSS_PERSON_TYPE_CONDITION_HPP
