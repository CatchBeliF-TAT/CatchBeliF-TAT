#ifndef VSS_PLATE_TYPE_CONDITION_HPP
#define VSS_PLATE_TYPE_CONDITION_HPP

#include <functional>
#include <iterator>

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

namespace FLOW {
std::function<bool(const inference::ViolationEvent& e)> CreatePlateTypeCondition(inference::ViolationConfig* cfg) {
    std::set<std::string> plate_types;
    bool bPassConfig = true;
    for (const auto& condition : cfg->conditions()) {
        if (condition.name() == "plate_type") {
                std::copy(condition.plate_type().begin(),
                          condition.plate_type().end(),
                          std::inserter(plate_types, plate_types.end()));
                if (condition.action() == "drop") {
                    bPassConfig = false;
                }
         }
     }

     std::function<bool(const inference::ViolationEvent& e)> condition = [plate_types, bPassConfig](const inference::ViolationEvent& e)->bool {
         if (plate_types.empty()) {
             return bPassConfig;
         }
         for (const auto& snapshot : e.snapshots()) {
             if( snapshot.objects_size() == 0 &&
                ! snapshot.objects(0).has_plate()) {
                 continue;
             }
             const auto& plate_type = snapshot.objects(0).plate().plate_type();
             if (plate_types.count(plate_type) > 0) {
                 return bPassConfig;
             }
         }
         return !bPassConfig;
    };
    return condition;
}
} // namespace FLOW
#endif
