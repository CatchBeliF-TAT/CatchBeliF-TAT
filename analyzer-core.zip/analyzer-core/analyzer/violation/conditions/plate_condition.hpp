#ifndef VSS_PLATE_CONDITION_HPP
#define VSS_PLATE_CONDITION_HPP

#include "time_condition.hpp"

namespace FLOW {

TimeConditionMap CreatePlateConditionMap(inference::ViolationConfig* cfg);

} // namespace FLOW
#endif // VSS_PLATE_CONDITION_HPP
