#ifndef VSS_TIME_CONDITION_HPP
#define VSS_TIME_CONDITION_HPP
#include <vector>
#include <regex>
#include <chrono>
#include <string>
#include <map>

namespace inference {
    class ViolationConfig;
    class MassiveflowViolationConfig;
}

namespace FLOW {
using sys_milliseconds = std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds>;
//
// TimeCondition
//
class TimeCondition {
public:
    TimeCondition() 
        : start_date_(0)
        , end_date_(0)
        , available_times_()
        , week_pattern_(".*")
        , plate_pattern_(".*")
    {
    }
public:
    typedef std::vector<int64_t> Times;
    int64_t             start_date_;
    int64_t             end_date_;
    Times               available_times_;
    std::regex          week_pattern_;
    std::regex          plate_pattern_;
protected:
    bool enableData(int64_t value) const { return value; }
    bool inTimes(int64_t t) const{
        if (available_times_.empty()) {
            return true;
        }
        if (available_times_.size()==1 && t >= available_times_.front()) {
            return true;
        }
        for (size_t i = 1; i < available_times_.size(); i += 2) {
            if ( t >= available_times_[i-1] && t < available_times_[i]) {
                return true;
            }
        }
        return false;
    }

public:
    static std::pair<bool,std::string> startsWith(const  std::string& haystack, const  std::string& needle);

public:
    bool TimeMatch(sys_milliseconds t) const{
        const auto count_t = t.time_since_epoch().count();
        if (enableData(start_date_) && count_t < start_date_) {
            return false;
        }
        if (enableData(end_date_) && count_t > end_date_) {
            return false;
        }
        auto tt = std::chrono::system_clock::to_time_t(t);
        struct tm* ptm = localtime(&tt);
        const auto tm_wday = std::to_string(ptm->tm_wday);
        int64_t hhss=  ptm->tm_hour*100 + ptm->tm_min;
        return inTimes(hhss) && std::regex_match(tm_wday, week_pattern_);
    }
    bool PlateMatch(const std::string& plate) const{
        return std::regex_match(plate, plate_pattern_);
    }
};

typedef std::map<std::string, TimeCondition> TimeConditionMap;

TimeConditionMap CreateTimeConditionMap(const inference::ViolationConfig& cfg);
TimeConditionMap CreateTimeConditionMap(const inference::MassiveflowViolationConfig& cfg);
} // namespace FLOW
#endif // VSS_TIME_CONDITION_HPP
