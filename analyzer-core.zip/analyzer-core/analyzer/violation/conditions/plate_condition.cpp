
#include <algorithm>

#include "plate_condition.hpp"

#include "common/log.hpp"
#include "serving/violation_config.pb.h"

using namespace std;

namespace FLOW {

TimeConditionMap CreatePlateConditionMap(inference::ViolationConfig* cfg) {
    typedef std::map<std::string, bool> TimeConditionMapFlag;
    TimeConditionMap time_condition_map;
    TimeConditionMapFlag time_condition_map_flag;
    int64_t start_date = 0;
    int64_t end_date = 0;
    for (int i = 0; i < cfg->conditions_size(); i++) {
        const auto& cond = cfg->conditions(i);
        if (cond.name() == "start_date") {
            start_date = cond.data_number();
        }
        if (cond.name() == "end_date") {
            end_date = cond.data_number();
        }
        std::pair<bool, std::string> value;
        if ((value = TimeCondition::startsWith(cond.name(), "available_times")).first) {
            auto& available_times = time_condition_map[value.second].available_times_;
            available_times.clear();
            std::copy_n(cond.data().begin(), cond.data_size() / 2 * 2, std::back_inserter(available_times));
        }
        if ((value = TimeCondition::startsWith(cond.name(), "week_pattern")).first) {
            auto& week_pattern = time_condition_map[value.second].week_pattern_;
            week_pattern = std::regex(cond.data_string());
        }
        if ((value = TimeCondition::startsWith(cond.name(), "plate_pattern")).first) {
            time_condition_map_flag[value.second] = true;
            auto& plate_pattern = time_condition_map[value.second].plate_pattern_;
            plate_pattern = std::regex(cond.data_string());
        }
    }
    TimeConditionMap retv;
    for (const auto& flagkv : time_condition_map_flag) {
        retv[flagkv.first] = time_condition_map[flagkv.first];
    }

    for (auto& time_condition : retv) {
        time_condition.second.start_date_ = start_date;
        time_condition.second.end_date_ = end_date;
    }
    return retv;
}

}  // namespace FLOW
