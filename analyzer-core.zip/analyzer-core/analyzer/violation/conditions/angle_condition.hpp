#ifndef VSS_ANGLE_CONDITION_HPP
#define VSS_ANGLE_CONDITION_HPP

#include <functional>
#include <iterator>

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

namespace FLOW {
std::function<bool(const inference::ViolationEvent& e)> CreateAngleCondition(inference::ViolationConfig* cfg) {
    auto retv = [](const inference::ViolationEvent&)->bool { return true; };
    // disable this condition
    return retv;
    // disable this condition


    if (! cfg->has_cross_angle()) {
        return retv;
    }
    auto cross_angle = cfg->cross_angle();
    std::vector<::inference::Condition> lines;
    for (const auto& condition : cfg->conditions()) {
        if (condition.type() == "line" &&
            condition.data_size() >= 4) {
                lines.push_back(condition);
         }
     }
    if (lines.size() < 2) {
        return retv;
    }

     float min_angle=91.0f;
     int min_i=0,min_j=1;
     for(int i=0;i<lines.size(); i++) {
        for(int j=i+1;j<lines.size(); j++) {
            float tmp_angle = get_cross_line_angle(lines[i].data().begin(), lines[j].data().begin());
            if (tmp_angle < min_angle) {
                min_angle = tmp_angle;
                min_i = i;
                min_j = j;
            }
        }
     }
     {
        std::vector<::inference::Condition> tmp;
        tmp.push_back(lines[min_i]);
        tmp.push_back(lines[min_j]);
        tmp.swap(lines);
     }

     std::function<bool(const inference::ViolationEvent& e)> condition =
        [lines, min_i, min_j, cross_angle](const inference::ViolationEvent& e)->bool {
            if (e.snapshots_size() < min_i || e.snapshots_size() < min_j) {
                LOG(ERROR) << "==>cross_lines_angle" << -1 << ", "
                        << e.stream_id() << "," << "--" << "," << e.obj_id() << ","
                        << ",min_i=" << min_i
                        << ",min_j=" << min_j
                        << ",snapshots_size=" << e.snapshots_size();
                return true;
            }
            if (e.snapshots(min_i).objects_size() == 0 ||
                e.snapshots(min_i).objects(0).box_size() < 4 ||
                e.snapshots(min_j).objects_size() == 0 ||
                e.snapshots(min_j).objects(0).box_size() < 4) {
                return true;
            }
            float data[] = {
                (e.snapshots(min_i).objects(0).box(0)+e.snapshots(min_i).objects(0).box(2))/2,
                (e.snapshots(min_i).objects(0).box(1)+e.snapshots(min_i).objects(0).box(3))/2,
                (e.snapshots(min_j).objects(0).box(0)+e.snapshots(min_j).objects(0).box(2))/2,
                (e.snapshots(min_j).objects(0).box(1)+e.snapshots(min_j).objects(0).box(3))/2,
            };
            float current_angle = get_cross_line_angle(data, lines[0].data().begin());
            LOG(INFO) << "==>cross_lines_angle" << -1 << ", "
                    << e.stream_id() << "," << "--" << "," << e.obj_id() << ","
                    << ",angle=" << current_angle
                    << ",req_angle=" << cross_angle;
            if (current_angle > cross_angle) {
                return true;
            }
            return false;
    };
    return condition;
}
} // namespace FLOW
#endif
