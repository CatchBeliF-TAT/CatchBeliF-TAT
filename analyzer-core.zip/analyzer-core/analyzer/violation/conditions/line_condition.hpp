#ifndef VSS_LINE_CONDITION_HPP
#define VSS_LINE_CONDITION_HPP

#include <map>
#include <memory>
#include <functional>

#include "i_condition_data.hpp"
#include "serving/violation_config.pb.h"
#include "common/tad_internal.hpp"
#include "violation/violation_util.hpp"
#include "algorithm/traffic_light/traffic_light_recog.hpp"
#include "algorithm/vehicleattribute/vehicle_attr.hpp"


namespace FLOW {

typedef std::function<bool(const BoxF& last_box, const BoxF& current_box, const ImageObjectsInfo& objs)> fn_check_action;
typedef std::function<bool(const BoxF& last_box, const BoxF& current_box, const ImageObjectsInfo& objs, spIConditionData& data)> fn_check_action_withdata;

inline inference::Condition::ModeArgs PraseLineModeArgs(const inference::Condition& current_condition) {
    if (current_condition.has_mode_args()) {
        return current_condition.mode_args();
    }
    // old config
    inference::Condition::ModeArgs retv;
    if (current_condition.zuozhuan_across()) {
        retv.set_type("zuozhuan_across");
        retv.mutable_center()->set_x(0.5);
        retv.mutable_center()->set_y(0.5);
    } else if (current_condition.center_across()) {
        retv.set_type("center_across");
        retv.mutable_center()->set_x(0.5);
        retv.mutable_center()->set_y(0.5);
        if (current_condition.has_cross_angle()) {
            retv.set_cross_angle(current_condition.cross_angle());
        }
    } else if (current_condition.gaosu_across()) {
        retv.set_type("gaosu_across");
    } else { // default
        retv.set_type("box_touch");
    }
    return retv;
}

typedef std::function<bool(const BoxF& last_box, const BoxF& current_box, const inference::Condition::ModeArgs& args, const float* data)> fn_line_check_action;

inline bool fn_zuozhuan_across(const BoxF& revised_last_box, const BoxF& revised_box, const inference::Condition::ModeArgs& args, const float* data) {
    if ((revised_box.attr_direction.type == Attribute::Vehicle_Front && 
            valid_box_across_lines_v1(revised_box, data, 0.75f)) ||
        (revised_box.attr_direction.type == Attribute::Vehicle_Rear &&
            valid_box_across_lines_v2(revised_box, data, 0.75f)) ||
        (revised_box.attr_direction.type == Attribute::Vehicle_No_Direction &&
            (valid_box_across_lines_v1(revised_box, data, 0.5f) ||
                valid_box_across_lines_v2(revised_box, data, 0.5f)))) {
        return true;
    }
    return false;
}

inline bool fn_center_across(const BoxF& revised_last_box, const BoxF& revised_box, const inference::Condition::ModeArgs& args, const float* data) {
    const float x_scale = args.has_center() && args.center().has_x() 
                    ? args.center().x() : 0.5f;
    const float y_scale = args.has_center() && args.center().has_y() 
                    ? args.center().y() : 0.5f;
    if (!valid_boxes_scale_center_across_lines(revised_last_box, revised_box, x_scale, y_scale, data)) {
        return false;
    }
    const auto cross_anagle = args.has_cross_angle() ? args.cross_angle() : -1.0f;
    if ( args.has_cross_angle() ) {
        const auto current_anagle = get_cross_line_angle(revised_last_box, revised_box,data);
        if(current_anagle < args.cross_angle()) {
            LOG(INFO) << "==>cross_line_angle drop" << -1 << ", "
                    << "channel_id" << "," << "violation_id" << "," << revised_box.uid << ","
                    << "angle=" << current_anagle;
            return false;
        }
    }
    return true;
}

// box 下边与线相交
inline bool fn_gaosu_across(const BoxF& revised_last_box, const BoxF& revised_box, const inference::Condition::ModeArgs& args, const float* data) {
    if (valid_box_across_lines_gaosu(revised_box, data, 0.75f)) {
        return true;
    }
    return false;
}

// box任一边框与线相交
inline bool fn_box_touch(const BoxF& revised_last_box, const BoxF& revised_box, const inference::Condition::ModeArgs& args, const float* data) {
    if (valid_box_across_lines(revised_box, data, 0.75f)) {
        return true;
    }
    return false;
}

inline fn_check_action CreateLineCondition(const inference::Condition& current_condition, bool has_traffic_light_box, const google::protobuf::RepeatedField< float >& roi_data, std::string violation_id="") {
    fn_check_action action = nullptr;
    if (current_condition.type()== "line" ||
        current_condition.type()== "mulit-line"|| // spelling mistake
        current_condition.type()== "multi-line"||
        current_condition.type()== "multi_line"){

        const auto mode_args = PraseLineModeArgs(current_condition);
        fn_line_check_action fn_line=fn_box_touch;
        if (mode_args.type() == "zuozhuan_across") {
            fn_line = fn_zuozhuan_across;
        } else if (mode_args.type() == "center_across") {
            fn_line = fn_center_across;
        } else if (mode_args.type() == "gaosu_across") {
            fn_line = fn_gaosu_across;
        } else {
            // fn_box_touch
        }

        action = [current_condition, fn_line, mode_args, has_traffic_light_box, roi_data, violation_id](
            const BoxF& last_box, const BoxF& box, const ImageObjectsInfo& objs)->bool{
            const auto data = current_condition.data();
            const auto enable_roi_filter = current_condition.enable_roi();

            if (has_traffic_light_box){
                auto pcolor = objs.tlc.find(violation_id);
                if(pcolor==objs.tlc.end()){
                    return false;
                }
                if(pcolor->second.color!=TrafficLight::kColorRed){
                    return false;
                }
            }
            const int n = data.size() / 4 * 4;
            const BoxF& revised_last_box = (last_box.label == OBJECT_TYPE_VEHICLE && helperIsLargeVehicle((Attribute::VehicleType)last_box.attr_type.type)) ?
                                        BoxF(last_box.xmin, (last_box.ymin+last_box.ymax)/2, last_box.xmax, last_box.ymax) : last_box;
            const BoxF& revised_box = (box.label == OBJECT_TYPE_VEHICLE && helperIsLargeVehicle((Attribute::VehicleType)box.attr_type.type)) ?
                                        BoxF(box.xmin, (box.ymin+box.ymax)/2, box.xmax, box.ymax) : box;
            if (enable_roi_filter && !roi_data.empty()) {
                if (!valid_box_center_in_polygon(revised_box, roi_data.data(), roi_data.size())) {
                    return false;
                }
            }
            bool bPass = false;
            for (int j = 0; j < n; j += 4) {
                if (fn_line(revised_last_box, revised_box, mode_args, data.begin()+j)) {
                    bPass = true;
                    break;
                }
            }
            return bPass;
        };
    }
    return action;
}

inline fn_check_action_withdata CreateLineConditionV2(const inference::Condition& current_condition, bool has_traffic_light_box, const google::protobuf::RepeatedField< float >& roi_data, std::string violation_id="") {
    struct line_condition_data : public IConditionData{
    public:
        std::map<int64_t, BoxF> path;
        float                   direction_angle_min=90.1f;
        float                   direction_angle_max=0.0f;
        bool                    line_pass=false;
    public:
        void UpdateSnapshotReuslt(FLOW::ViolationSnapshot* pSn) {
            if (pSn && direction_angle_min<=90 && direction_angle_max>=0) {
                pSn->direction_angle_min_max.clear();
                pSn->direction_angle_min_max.push_back(direction_angle_min);
                pSn->direction_angle_min_max.push_back(direction_angle_max);
            }
        }
    };
    const auto get_offset_time_point = [](const inference::Condition& current_condition, const ImageObjectsInfo& frame) {
        return current_condition.has_enable_use_pts() 
                ? frame.pts
                : std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now()).time_since_epoch().count();
    };
    auto sp_ms = current_condition.has_direction_angle_span() ? current_condition.direction_angle_span()*1000 : 1*1000;

    fn_check_action_withdata action = nullptr;
    auto check =CreateLineCondition(current_condition, has_traffic_light_box, roi_data, violation_id);
    if (check != nullptr) {
        action = [current_condition, get_offset_time_point, sp_ms, check](const BoxF& last_box, const BoxF& box, const ImageObjectsInfo& frame, spIConditionData& pdata)->bool {
            if(pdata==nullptr) {
                pdata = std::make_shared<line_condition_data>();
            }
            line_condition_data& data = *std::dynamic_pointer_cast<line_condition_data>(pdata);
            if ( (current_condition.has_direction_angle_min() ||
                    current_condition.has_direction_angle_change_max()) &&
                 !data.line_pass) {
                const auto line_data = current_condition.data();
                const auto ts = get_offset_time_point(current_condition, frame);
                const auto old_size = data.path.size();
                data.path.erase(data.path.begin(), data.path.lower_bound(ts-sp_ms));
                const auto old_removed_size = data.path.size();
                data.path.erase(data.path.upper_bound(ts), data.path.end());
                data.path[ts] = box;
                if (old_size > old_removed_size) {
                    const auto direction_angle = get_cross_line_angle(data.path.begin()->second, box, line_data.begin());
                    data.direction_angle_min = std::min(data.direction_angle_min, direction_angle);
                    data.direction_angle_max = std::max(data.direction_angle_max, direction_angle);
                }
            }
            if (!data.line_pass) {
                auto retv = check(last_box, box, frame);
                if (retv) {
                    data.line_pass = true;
                    if(current_condition.has_direction_angle_min() || current_condition.has_direction_angle_change_max()) {
                        auto bDrop1 = current_condition.has_direction_angle_min() &&
                                        (data.direction_angle_min <= current_condition.direction_angle_min());
                        const auto direction_angle_change = (data.direction_angle_max-data.direction_angle_min);
                        auto bDrop2 = current_condition.direction_angle_change_max() &&
                                        (direction_angle_change >= current_condition.direction_angle_change_max());
                        if (bDrop1 || bDrop2) {
                            retv = false;
                        }
                        LOG(INFO) << "==>"<<(retv?"":" drop by")<<" direction_angle, " << -1
                                << ", "<< frame.channel_id << "," << "--" << "," << box.uid
                                << ", direction_angle_min=" << data.direction_angle_min
                                << ", direction_angle_max=" << data.direction_angle_max
                                << ", min_angle=" << current_condition.direction_angle_min()
                                << ", max_change_angle=" << current_condition.direction_angle_change_max();
                    }
                }
                return retv;
            }
            return false;
        };
    }
    return action;
}

} // namespace FLOW
#endif
