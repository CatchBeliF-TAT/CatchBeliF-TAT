#ifndef VSS_TYPE_CONDITION_HPP
#define VSS_TYPE_CONDITION_HPP

#include <functional>
#include <iterator>

#include "serving/violation_config.pb.h"
#include "serving/violation_event.pb.h"

namespace FLOW {
inline std::function<bool(const inference::ViolationEvent& e)> CreateNonmotorTypeCondition(inference::ViolationConfig* cfg) {
    std::set<std::string> nonmotor_types;
    bool bPassConfig = true;
    for (const auto& condition : cfg->conditions()) {
        if (condition.name() == "nonmotor_type") {
                std::copy(condition.nonmotor_type().begin(),
                          condition.nonmotor_type().end(),
                          std::inserter(nonmotor_types, nonmotor_types.end()));
                if (condition.action() == "drop") {
                    bPassConfig = false;
                }
         }
     }
     std::function<bool(const inference::ViolationEvent& e)> condition = [nonmotor_types, bPassConfig](const inference::ViolationEvent& e)->bool {
         if (nonmotor_types.empty()) {
             return bPassConfig;
         }
         for (const auto& snapshot : e.snapshots()) {
             if( snapshot.objects_size() == 0) {
                 continue;
             }
             const auto& inType = snapshot.objects(0).nonmotor_type();
             if (nonmotor_types.count(inType) > 0) {
                 return bPassConfig;
             }
         }
         return !bPassConfig;
     };
     return condition;
}
} // namespace FLOW
#endif
