#include "common/json.hpp"
#include "violation_registry.hpp"
#include "object_violation_factory.hpp"

namespace FLOW {

void ObjectViolationsFactory::AddViolation(const std::string& violation_id,const std::string& config)
{
    auto root = get_document(config);
    auto type = get_string(root, "code", "");
    factorys_[violation_id] = CViolationRegistry::CreateViolationFactory(type, violation_id, config);
}

void ObjectViolationsFactory::RemoveViolation(const std::string& violation_id)
{
    factorys_.erase(violation_id);
}

spObjectViolations ObjectViolationsFactory::CreateViolations(const BoxF& obj)
{
    auto retv = std::make_shared<ObjectViolations>();
    std::for_each(
        factorys_.begin(),
        factorys_.end(),
        [&obj, &retv](MapIViolationFactory::value_type& fac){
            retv->GetViolations().push_back(fac.second->CreateIViolation(obj));
        }
    );
    return retv;
}

spObjectViolations ObjectViolationsFactory::CreateViolations(const BoxF& obj, const std::string& violation_id)
{
    auto retv = std::make_shared<ObjectViolations>();
    const auto& factory = factorys_.find(violation_id);
    if (factory != factorys_.end()) {
        auto violation = factory->second->CreateIViolation(obj);
        if (violation) {
            retv->GetViolations().push_back(violation);
        }
    }
    return retv;
}

spObjectViolations ObjectViolationsFactory::CreateViolations(const std::string& violation_id)
{
    auto retv = std::make_shared<ObjectViolations>();
    const auto& factory = factorys_.find(violation_id);
    if (factory != factorys_.end()) {
        auto violation = factory->second->CreateIViolation(BoxF());
        if (violation) {
            retv->GetViolations().push_back(violation);
        }
    }
    return retv;
}

spObjectViolations ObjectViolationsFactory::CreateViolations(const BoxF& obj, time_point_milliseconds now)
{
    auto retv = std::make_shared<ObjectViolations>();
    std::for_each(
        factorys_.begin(),
        factorys_.end(),
        [&](MapIViolationFactory::value_type& fac){
            if (! fac.second->check_time(now)) {
                return;
            }
            auto tmp = fac.second->CreateIViolation(obj);
            if (tmp) {
                retv->GetViolations().push_back(tmp);
            }
            return;
        }
    );
    return retv;
}

bool ObjectViolationsFactory::CheckActiveTime(const std::string& violation_id, time_point_milliseconds now) {
    auto retv = false;
    const auto& factory = factorys_.find(violation_id);
    if (factory != factorys_.end()) {
        retv = factory->second->check_time(now);
    }
    return retv;
}

} // namespace FLOW
