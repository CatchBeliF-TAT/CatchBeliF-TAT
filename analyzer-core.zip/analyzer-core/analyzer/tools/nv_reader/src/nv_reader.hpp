#ifndef NVVideoReader_H
#define NVVideoReader_H

#include <iostream>
#include <memory>
#include <opencv2/opencv.hpp>

namespace ATVIDEO {

class NVVideoReader {
public:
    NVVideoReader(int device = 0);
    ~NVVideoReader() = default;

    bool open(const std::string &input);
    bool read(cv::Mat &mat, int64_t *pts = nullptr);
    float fps();
    int width();
    int height();
    void close();
    float stream_time_base();
    void set_extra_hw_frames(int n);

private:
    class impl;
    std::shared_ptr<impl> imp_ = nullptr;

    friend int check_interrupt(void *ctx);

};

}

#endif //NVVideoReader_H
