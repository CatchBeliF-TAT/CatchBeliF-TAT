#include <iostream>
#include <memory>
#include <opencv2/opencv.hpp>
#include "nv_reader.hpp"
#include <cuda.h>
#include "MathFunction.hpp"

extern "C"
{
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/opt.h>
#include <libavutil/pixdesc.h>
#include <libswscale/swscale.h>
#include <libavutil/time.h>
#include <libavutil/hwcontext.h>
#include <libavutil/imgutils.h>
#include <libavutil/avstring.h>
};
#include <libavutil/hwcontext_cuda.h>
//#include <libavutil/hwcontext_cuda_internal.h>

namespace ATVIDEO {

using namespace std;
using namespace cv;

using pkt_ptr = std::unique_ptr<AVPacket, decltype(&av_packet_unref)>;

static enum AVPixelFormat hw_pix_fmt;

class NVVideoReader::impl {
public:
    impl(int device);
    ~impl();
    bool open(const std::string &input);
    bool read(Mat &mat, int64_t *pts);
    int width();
    int height();
    float fps();
    float stream_time_base();
    void set_extra_hw_frames(int n);

private:
    int hw_decoder_init(AVCodecContext *ctx, const enum AVHWDeviceType type);
    int decode_write(AVCodecContext *avctx, AVPacket *packet, cv::Mat& mat, int& got_frame, int64_t *pts);

private:
    int device_ = 0;
    AVFormatContext *input_ctx_ = NULL;
    int video_stream_;
    AVStream *video_ = NULL;
    AVCodecContext *decoder_ctx_ = NULL;
    AVCodec *decoder_ = NULL;
    enum AVHWDeviceType type_;
    AVBufferRef *hw_device_ctx_ = NULL;
    bool get_first_key_frame = false;
    AVFrame *pRGBFrame = NULL;
    SwsContext *rgb_convert_ctx = NULL;
    int width_ = 0;
    int height_ = 0;
    float fps_ = 0.0;
    time_t check_time;
    //cv::cuda::GpuMat gpuMat;
    u_char * gpubuf_ = nullptr;
    size_t pitch_;
    bool is_open_ = false;
    float stream_time_base_den_ = 0;
    uint8_t *out_buffer = nullptr;
    int extra_hw_frames_ = 0;

    friend int check_interrupt(void *ctx);

};

NVVideoReader::NVVideoReader(int device) : imp_(new impl(device)) {

}

NVVideoReader::impl::impl(int device) : device_(device){
    av_register_all();
    avformat_network_init();
    av_log_set_level(AV_LOG_ERROR);

    //检查cuda硬件编码加速器是否存在
    type_ = av_hwdevice_find_type_by_name("cuda");
    if (type_ == AV_HWDEVICE_TYPE_NONE) {
        fprintf(stderr, "Device type %s is not supported.\n", "cuda");
        fprintf(stderr, "Available device types:");
        while((type_ = av_hwdevice_iterate_types(type_)) != AV_HWDEVICE_TYPE_NONE)
            fprintf(stderr, " %s", av_hwdevice_get_type_name(type_));
        fprintf(stderr, "\n");
    }
}

NVVideoReader::impl::~impl(){
    if (gpubuf_)
        cudaFree(gpubuf_);

    if (hw_device_ctx_)
        av_buffer_unref(&hw_device_ctx_);

    if (input_ctx_)
        avformat_close_input(&input_ctx_);

    if (decoder_ctx_)
        avcodec_free_context(&decoder_ctx_);

    if (pRGBFrame)
        av_frame_free(&pRGBFrame);

    if (rgb_convert_ctx)
        sws_freeContext(rgb_convert_ctx);

    if (out_buffer)
        delete [] out_buffer;
}

bool NVVideoReader::open(const std::string &input) {
    return imp_->open(input);
}

//得到硬件的hw format
static enum AVPixelFormat get_hw_format(AVCodecContext *ctx,
                                        const enum AVPixelFormat *pix_fmts)
{
    const enum AVPixelFormat *p;

    for (p = pix_fmts; *p != -1; p++) {
        if (*p == hw_pix_fmt)
            return *p;
    }

    fprintf(stderr, "Failed to get HW surface format.\n");
    return AV_PIX_FMT_NONE;
}

int NVVideoReader::impl::hw_decoder_init(AVCodecContext *ctx, const enum AVHWDeviceType type)
{
    int err = 0;

    //创建hwdevice context， 并设置使用的gpu id
    if ((err = av_hwdevice_ctx_create(&hw_device_ctx_, type,
                                      std::to_string(device_).c_str(), NULL, 0)) < 0) {
        fprintf(stderr, "Failed to create specified HW device.\n");
        return err;
    }
    ctx->hw_device_ctx = av_buffer_ref(hw_device_ctx_);

    return err;
}

int check_interrupt(void *ctx)
{
    auto p = (ATVIDEO::NVVideoReader::impl*)ctx;
    auto duration = time(NULL) - p->check_time;
    int timeout = duration >= 30 ? 1 : 0;
    if (timeout)
        av_log(NULL, AV_LOG_ERROR, "av_read_frame timeout\n");
    return timeout;
}

bool NVVideoReader::impl::open(const std::string &input) {
    int ret = 0, i;
    AVDictionary *opts = NULL;

    av_dict_set(&opts, "rtsp_transport", "tcp", 0);
    av_dict_set(&opts, "max_delay", "500000", 0);
    av_dict_set(&opts, "timeout", "3000000", 0);
    av_dict_set(&opts, "stimeout", "3000000", 0);

    if(av_stristart(input.c_str(),"rtmp",NULL) || av_stristart(input.c_str(),"rtsp",NULL)) {
        av_log(NULL, AV_LOG_WARNING,"remove 'timeout' option for rtmp.\n");
        av_dict_set(&opts, "timeout", NULL, 0);
    }

    input_ctx_ = avformat_alloc_context();
    check_time = time(NULL);
    input_ctx_->interrupt_callback.callback = check_interrupt;//打开超时回调
    input_ctx_->interrupt_callback.opaque = this;

    if (avformat_open_input(&input_ctx_, input.c_str(), NULL, &opts) != 0) {
        fprintf(stderr, "Cannot open input file '%s'\n", input.c_str());
        return false;
    }

    av_dict_free(&opts);

    input_ctx_->interrupt_callback.callback = NULL;//关闭超时回调
    input_ctx_->interrupt_callback.opaque = NULL;

    if (avformat_find_stream_info(input_ctx_, NULL) < 0) {
        fprintf(stderr, "Cannot find input stream information.\n");
        return false;
    }

    /* find the video stream information */
    ret = av_find_best_stream(input_ctx_, AVMEDIA_TYPE_VIDEO, -1, -1, &decoder_, 0);
    if (ret < 0) {
        fprintf(stderr, "Cannot find a video stream in the input file\n");
        return false;
    }
    video_stream_ = ret;

    for (i = 0;; i++) {
        const AVCodecHWConfig *config = avcodec_get_hw_config(decoder_, i);
        if (!config) {
            fprintf(stderr, "Decoder %s does not support device type %s.\n",
                    decoder_->name, av_hwdevice_get_type_name(type_));
            return false;
        }
        if (config->methods & AV_CODEC_HW_CONFIG_METHOD_HW_DEVICE_CTX &&
            config->device_type == type_) {
            hw_pix_fmt = config->pix_fmt;
            break;
        }
    }

    if (!(decoder_ctx_ = avcodec_alloc_context3(decoder_)))
        return false;

    video_ = input_ctx_->streams[video_stream_];
    width_ = static_cast<uint16_t>(video_->codecpar->width);
    height_ = static_cast<uint16_t>(video_->codecpar->height);

    stream_time_base_den_ = av_q2d(video_->time_base);

    if(video_->r_frame_rate.den > 0) {
        fps_ = (float)video_->r_frame_rate.num/video_->r_frame_rate.den;
    }
    else if(video_->codec->framerate.den > 0) {
        fps_ = (float)video_->codec->framerate.num / video_->codec->framerate.den;
    }
    else {
        fps_ = (float)video_->avg_frame_rate.num / video_->avg_frame_rate.den;
    }

    if(isnan(fps_))
        fps_ = 25;

    if (avcodec_parameters_to_context(decoder_ctx_, video_->codecpar) < 0)
        return false;

    decoder_ctx_->get_format  = get_hw_format;

    if (hw_decoder_init(decoder_ctx_, type_) < 0)
        return false;

    // make sure enough decoder surfaces
    decoder_ctx_->extra_hw_frames = extra_hw_frames_;

    if ((ret = avcodec_open2(decoder_ctx_, decoder_, NULL)) < 0) {
        fprintf(stderr, "Failed to open codec for stream #%u\n", video_stream_);
        return false;
    }

    pRGBFrame = av_frame_alloc();
    pRGBFrame->width = width_;
    pRGBFrame->height = height_;
    pRGBFrame->format = AV_PIX_FMT_BGR24;
    out_buffer=new uint8_t[avpicture_get_size(AV_PIX_FMT_BGR24, pRGBFrame->width, pRGBFrame->height)];
    avpicture_fill((AVPicture *)pRGBFrame, out_buffer, AV_PIX_FMT_BGR24, pRGBFrame->width, pRGBFrame->height);

    rgb_convert_ctx = sws_getContext(width_, height_, AV_PIX_FMT_NV12,
                                     pRGBFrame->width, pRGBFrame->height, AV_PIX_FMT_BGR24,
                                     SWS_FAST_BILINEAR, NULL, NULL, NULL);

    is_open_ = true;
    return true;
}

static void uchar2Mat(const unsigned char *inArrayCur, int img_w, int img_h, cv::Mat& mat)
{
    int i,j;

    for (i = 0; i < img_h; i++)
    {
        auto pData = mat.ptr<uchar>(i);
        for (j = 0; j < img_w*3; j++)
        {
            *pData++ = inArrayCur[(i)*img_w*3+j] ;
        }
    }
}

static int convert_rgb_transfer_data(cv::Mat &mat, AVFrame *src, u_char **gpubuf, size_t &pitch) {
    AVHWFramesContext *ctx = (AVHWFramesContext*)src->hw_frames_ctx->data;
    AVCUDADeviceContext *device_hwctx = (AVCUDADeviceContext *)ctx->device_ctx->hwctx;

    CUcontext dummy;
    CUresult err;
    int i;
    size_t width = src->width;
    size_t height = src->height;

    //解码的cuda context压栈
    err = cuCtxPushCurrent(device_hwctx->cuda_ctx);
    if (err != CUDA_SUCCESS)
        return AVERROR_UNKNOWN;
    if (!(*gpubuf)) {
        //如果工作gpu buffer没有分配则分配一块对齐的buffer
        cudaMallocPitch((void **)gpubuf, &pitch, sizeof(u_char)*width*3, height);
    }

    //使用解码的cuda stream执行rgb到yuv转换
    MathTools::process_avframe2bgr(*gpubuf,src->width,src->height,src->data[0],src->data[1],src->linesize,pitch, device_hwctx);

    //std::cout << "info: " << (void*)*gpubuf << " " << (void*)mat.data << " " << pitch << " " << width << " " << src->height << std::endl;;
    CUDA_MEMCPY2D cpy = {};
    cpy.srcMemoryType = CU_MEMORYTYPE_DEVICE;
    cpy.dstMemoryType = CU_MEMORYTYPE_HOST;
    cpy.srcDevice     = (CUdeviceptr)*gpubuf;
    cpy.dstHost       = mat.data;
    cpy.srcPitch      = pitch;
    cpy.dstPitch      = width*3;
    cpy.WidthInBytes  = FFMIN(pitch, width*3);
    cpy.Height        = src->height;

    //使用解码的cuda stream，异步memcpy到内存
    err = cuMemcpy2DAsync(&cpy, device_hwctx->stream);
    if (err != CUDA_SUCCESS) {
        std::cerr << "ERR code: " << err << std::endl;
        av_log(ctx, AV_LOG_ERROR, "Error transferring the data from the CUDA frame\n");
        return AVERROR_UNKNOWN;
    }

    //同步所有gpu操作
    err = cuStreamSynchronize(device_hwctx->stream);
    if (err != CUDA_SUCCESS) {
        av_log(ctx, AV_LOG_ERROR, "Error synchronizing CUDA stream\n");
        return AVERROR_UNKNOWN;
    }
    
    //cuda context出栈
    cuCtxPopCurrent(&dummy);
    
    return 0;
}

int NVVideoReader::impl::decode_write(AVCodecContext *avctx, AVPacket *packet, cv::Mat& mat, int& got_frame, int64_t *pts)
{
    AVFrame *frame = NULL, *sw_frame = NULL;
    AVFrame *tmp_frame = NULL;
    int size;
    int ret = 0;

    got_frame = 0;
    //发送待解码的数据包
    ret = avcodec_send_packet(avctx, packet);
    if (ret < 0) {
        fprintf(stderr, "Error during decoding\n");
        return ret;
    }

    while (true) {
        if (!(frame = av_frame_alloc()) || !(sw_frame = av_frame_alloc())) {
            fprintf(stderr, "Can not alloc frame\n");
            ret = AVERROR(ENOMEM);
            goto fail;
        }

        //获取解码完的frame
        ret = avcodec_receive_frame(avctx, frame);
        //得到帧的pts
        if(ret == 0 && pts)
            *pts = frame->pkt_pts;

        if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF) {
            av_frame_free(&frame);
            av_frame_free(&sw_frame);
            return 0;
        } else if (ret < 0) {
            fprintf(stderr, "Error while decoding\n");
            goto fail;
        }

        if (frame->format == hw_pix_fmt) {
            convert_rgb_transfer_data(mat, frame, &gpubuf_, pitch_);

            //cv::imwrite("save.bmp",mat);
        } else{
            tmp_frame = frame;

            size = av_image_get_buffer_size((AVPixelFormat)pRGBFrame->format, pRGBFrame->width,
                                            pRGBFrame->height, 1);

            sws_scale(rgb_convert_ctx, (const uint8_t* const*)tmp_frame->data, tmp_frame->linesize, 0,
                      height_, pRGBFrame->data, pRGBFrame->linesize);

            uchar2Mat(pRGBFrame->data[0], pRGBFrame->width, pRGBFrame->height, mat);
        }


        fail:
        av_frame_free(&frame);
        av_frame_free(&sw_frame);
        if (ret < 0)
            return ret;
        got_frame = 1;
    }
}

int NVVideoReader::impl::width() {
    return width_;
}

int NVVideoReader::width() {
    return imp_->width();
}

int NVVideoReader::impl::height() {
    return height_;
}

int NVVideoReader::height() {
    return imp_->height();
}

float NVVideoReader::impl::fps() {
    return fps_;
}

float NVVideoReader::fps() {
    return imp_->fps();
}

float NVVideoReader::stream_time_base() {
    return imp_->stream_time_base();
}

float NVVideoReader::impl::stream_time_base() {
    if (is_open_)
        return stream_time_base_den_;
    else
        return 0;
}

void NVVideoReader::set_extra_hw_frames(int n) {
    imp_->set_extra_hw_frames(n);
}

void NVVideoReader::impl::set_extra_hw_frames(int n) {
    extra_hw_frames_ = n;
}

bool NVVideoReader::read(cv::Mat &mat, int64_t *pts) {
    return imp_->read(mat, pts);
}

void NVVideoReader::close() {
    imp_.reset();
}

bool NVVideoReader::impl::read(cv::Mat &mat, int64_t *pts) {
    if (!is_open_)
        return false;

    int ret, got_frame;
    AVPacket packet{};

    if (mat.empty())
        mat.create(height_, width_, CV_8UC3);

    while (true) {
        auto packet_ptr = pkt_ptr(&packet, av_packet_unref);

        check_time = time(NULL);
        //读取待解码的数据包，如果流媒体或视频文件结束，则跳出循环
        if ((ret = av_read_frame(input_ctx_, &packet)) < 0)
            break;

        //跳过非视频数据包
        if (video_stream_ != packet.stream_index)
            continue;

        //保证从key frame开始解码
        if (packet.flags == 1) {
            get_first_key_frame = true;
        }

        if (!get_first_key_frame)
            continue;

        ret = decode_write(decoder_ctx_, &packet, mat, got_frame, pts);
        if (ret < 0) {
            break;
        }

        //如果解码出了一帧，返回true，相反则继续解码后面的数据包
        if (got_frame)
            return true;
    }

    //flush解码器里的缓存帧
    packet.data = NULL;
    packet.size = 0;
    ret = decode_write(decoder_ctx_, &packet, mat, got_frame, pts);

    if (got_frame)
        return true;
    else
        return false;
}

}



