#ifndef __MATHFUNCTION_HPP__
#define __MATHFUNCTION_HPP__

#include "cuda_runtime.h"
#include <opencv2/opencv.hpp>
#include <libavutil/hwcontext_cuda.h>

namespace MathTools
{
enum InterMethod{
  nearest,
  bilinear,
};
#define CUDA_KERNEL_LOOP(i, n) \
  for (int i = blockIdx.x * blockDim.x + threadIdx.x; \
       i < (n); \
       i += blockDim.x * gridDim.x)

// CUDA: use 16*16<512 threads per block
const int CUDA_NUM_THREADS = 512;

// CUDA: number of blocks for threads.
inline int GET_BLOCKS(const int N)
{
    return (N + CUDA_NUM_THREADS - 1) / CUDA_NUM_THREADS;
}

//void process(const cv::cuda::GpuMat &src, float *dst,
//             const int new_w, const int new_h,
//             float *param, InterMethod interMethod);

void process_avframe2bgr(u_char * dst,int width,int height,u_char *Ysrc,u_char *UVsrc,int * linestep, size_t pitch, AVCUDADeviceContext *device_hwctx);

} // namespace Shadow
#endif
