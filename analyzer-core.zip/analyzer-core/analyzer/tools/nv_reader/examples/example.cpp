#include <iostream>
#include <chrono>
#include <fstream>
#include "../src/nv_reader.hpp"
#include <opencv2/opencv.hpp>

using namespace ATVIDEO;
using namespace cv;
using namespace std;

int main(int argc, char* argv[]) {
    NVVideoReader reader(0);
    cv::VideoWriter writer;

    reader.open(argv[1]);
    int width = reader.width();
    int height = reader.height();
    float fps = reader.fps();

    writer.open("out.avi", CV_FOURCC('M', 'J', 'P', 'G'), fps, cv::Size(width, height));
    Mat img(height, width, CV_8UC3);

    std::chrono::steady_clock::time_point t1 = std::chrono::steady_clock::now();

    int frame_count = 0;
    while(reader.read(img)) {
        writer.write(img);
        cout << frame_count << endl;
        frame_count++;
    }

    writer.release();

    std::chrono::steady_clock::time_point t2 = std::chrono::steady_clock::now();
    std::chrono::duration<double> time_used = std::chrono::duration_cast<std::chrono::duration<double>>(t2 - t1);
    std::cout << "用时：" << time_used.count() << " 秒。" << std::endl;

    return 0;

}
