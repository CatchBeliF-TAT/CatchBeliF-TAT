#include <iostream>
#include <memory>
#include <opencv2/opencv.hpp>
#include "stream_writer.hpp"

extern "C"
{
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/opt.h>
#include <libavutil/pixdesc.h>
#include <libswscale/swscale.h>
#include <libavutil/time.h>
};

namespace ATVIDEO {

using namespace std;
using namespace cv;

using pkt_ptr = std::unique_ptr<AVPacket, decltype(&av_packet_unref)>;

class StreamWriter::impl {
public:
    impl(const string url);
    ~impl();
    void use_gpu(bool encode_gpu_on);
    void set_qp(int qp);
    void set_fps(double fps);
    bool write(Mat &mat, int64_t pts);
    void set_input_time_base(float time_base);
    bool close();

private:
    int open_output_file(AVFormatContext** ofmt_ctx, AVCodecContext **enc, const char *filename);
    int encode_frame(AVFrame *frame, AVCodecContext *enc_ctx, int64_t pts, int *got_frame);

private:
    string url_;
    bool encode_gpu_on_ = true;
    int encode_quality_qp_ = 28;
    bool open_ = false;
    int width_ = 0;
    int height_ = 0;
    double fps_ = 25.0;
    AVRational input_time_base_;
    AVRational output_time_base_;
    AVFormatContext *output_fmt_ctx = nullptr;
    AVCodecContext *output_enc_ctx = nullptr;
    AVFrame *pFrame = nullptr;
    AVFrame *pRGBFrame = nullptr;
    SwsContext *yuv_convert_ctx = nullptr;
    int64_t frame_count = 0;
    bool is_stream = true;
    uint8_t *rgb_buffer = nullptr;
    uint8_t *yuv_buffer = nullptr;
};

StreamWriter::StreamWriter(const string url) : imp_(new impl(url)) {

}

//初始化ffmpeg
StreamWriter::impl::impl(const string url) : url_(url){
    av_register_all();
    avformat_network_init();
    av_log_set_level(AV_LOG_ERROR);
}

StreamWriter::impl::~impl(){
    close();

    if (output_fmt_ctx)
        avformat_close_input(&output_fmt_ctx);

    if (output_enc_ctx)
        avcodec_free_context(&output_enc_ctx);

    if (pFrame)
        av_frame_free(&pFrame);

    if (pRGBFrame)
        av_frame_free(&pRGBFrame);

    if (yuv_convert_ctx)
        sws_freeContext(yuv_convert_ctx);

    if (rgb_buffer)
        delete [] rgb_buffer;

    if (yuv_buffer)
        delete [] yuv_buffer;
}

int StreamWriter::impl::open_output_file(AVFormatContext** ofmt_ctx, AVCodecContext **enc, const char *filename) {
    AVStream *out_stream;
    AVCodecContext *dec_ctx, *enc_ctx;
    AVCodec *encoder;
    int ret=0;
    unsigned int i=0;
    static int output_index = 0;

    string str_filename(filename);
    string format;
    if (str_filename.substr(0, 4) == "rtsp")
        format = "rtsp";
    else if (str_filename.substr(0, 4) == "rtmp")
        format = "flv";

    //判断是流媒体还是文件输入
    if (format.empty()) {
        avformat_alloc_output_context2(ofmt_ctx, NULL, NULL, filename);
        is_stream = false;
    }
    else {
        avformat_alloc_output_context2(ofmt_ctx, NULL, format.c_str(), filename);
        is_stream = true;
    }

    if (!*ofmt_ctx) {
        av_log(NULL, AV_LOG_ERROR, "Could not create output context\n");
        return AVERROR_UNKNOWN;
    }

    if (!((*ofmt_ctx)->oformat->flags & AVFMT_NOFILE)) {
        ret = avio_open(&(*ofmt_ctx)->pb, filename, AVIO_FLAG_WRITE);
        if (ret < 0) {
            av_log(NULL, AV_LOG_ERROR, "Could not open output file '%s'", filename);
            return ret;
        }
    }

    if (true) {
        /* in this example, we choose transcoding to same codec */
        //优先使用硬件编码，如果失败则采用libx264软编

        if (encode_gpu_on_){
            encoder = avcodec_find_encoder_by_name("h264_nvenc");
            if (!encoder)
                encoder = avcodec_find_encoder_by_name("libx264");
        }else{    
            encoder = avcodec_find_encoder_by_name("libx264");
	}

        if (!encoder) {
            av_log(NULL, AV_LOG_FATAL, "Necessary encoder not found\n");
            return AVERROR_INVALIDDATA;
        }

        out_stream = avformat_new_stream(*ofmt_ctx, encoder);
        if (!out_stream) {
            av_log(NULL, AV_LOG_ERROR, "Failed allocating output stream\n");
            return AVERROR_UNKNOWN;
        }

        enc_ctx = avcodec_alloc_context3(encoder);

        //设置多线程，slice并行编码
        enc_ctx->thread_count = 4;
        enc_ctx->active_thread_type = FF_THREAD_SLICE;

        if (!enc_ctx) {
            av_log(NULL, AV_LOG_FATAL, "Failed to allocate the encoder context\n");
            return AVERROR(ENOMEM);
        }

        /* In this example, we transcode to same properties (picture size,
         * sample rate etc.). These properties can be changed for output
         * streams easily using filters */
        enc_ctx->width = width_;
        enc_ctx->height = height_;

        /* take first format from list of supported formats */
        if (encoder->pix_fmts)
            enc_ctx->pix_fmt = AV_PIX_FMT_YUV420P;

        /* video time_base can be set to whatever is handy and supported by encoder */
        //对文件输出，根据fps设置time base
        int num = (int)(fps_ * 1000);
        int den = 1000;
        enc_ctx->time_base = av_inv_q(AVRational{num,den});
        enc_ctx->codec_tag = 0;
        enc_ctx->codec_id = AV_CODEC_ID_H264;
        enc_ctx->codec_type = AVMEDIA_TYPE_VIDEO;
        enc_ctx->gop_size = 12;   //gop长度
        enc_ctx->framerate = AVRational{num,den};

        if ((*ofmt_ctx)->oformat->flags & AVFMT_GLOBALHEADER)
            enc_ctx->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;

        //设置编码的profile
        enc_ctx->profile = FF_PROFILE_H264_BASELINE;

        if (0 == strcmp(encoder->name, "libx264")) {
            //选择快速编码模式
            av_opt_set(enc_ctx->priv_data, "preset", "ultrafast", 0);
            //选择零延时编码模式，编码器会立即输出当前帧的编码结果
            av_opt_set(enc_ctx->priv_data, "tune", "zerolatency", 0);
            std::string s = std::to_string(encode_quality_qp_);
            //std::string s = std::to_string(50);
            char const *pchar = s.c_str();
            av_opt_set(enc_ctx->priv_data, "qp", pchar, 0);
	}
        else if (0 == strcmp(encoder->name, "h264_nvenc")) {
            //设置qp控制编码质量和压缩率
            //av_opt_set(enc_ctx->priv_data, "qp", "28", 0);

            std::string s = std::to_string(encode_quality_qp_);
            //std::string s = std::to_string(50);
            char const *pchar = s.c_str();
            av_opt_set(enc_ctx->priv_data, "qp", pchar, 0);
            /*
            av_opt_set(enc_ctx->priv_data, "i_rc_method", "X264_RC_ABR", 0);
            int Mbitrate = (int) (4000000/1000);
            int MaxMbitrate = (int)((4000000*1.2)/1000);
            av_opt_set(enc_ctx->priv_data, "i_vbv_max_bitrate", "4800", 0);
            av_opt_set(enc_ctx->priv_data, "i_bitrate", "4000", 0);
            */
	}

        ret = avcodec_parameters_from_context(out_stream->codecpar, enc_ctx);
        if (ret < 0) {
            av_log(NULL, AV_LOG_ERROR, "Failed to copy encoder parameters to output stream #%u\n", i);
            return ret;
        }

        /* Third parameter can be used to pass settings to encoder */
        ret = avcodec_open2(enc_ctx, encoder, NULL);
        if (ret < 0) {
            av_log(NULL, AV_LOG_ERROR, "Cannot open video encoder for stream #%u\n", i);
            return ret;
        }

        out_stream->time_base = enc_ctx->time_base;
        out_stream->r_frame_rate = AVRational{num,den};

        //copy enc_ctx中的SPS，PPS信息到AVCodecParameters
        out_stream->codecpar->extradata = (uint8_t*)av_mallocz(enc_ctx->extradata_size);
        out_stream->codecpar->extradata_size = enc_ctx->extradata_size;
        memcpy(out_stream->codecpar->extradata, enc_ctx->extradata, out_stream->codecpar->extradata_size);

        *enc = enc_ctx;
    } else if (dec_ctx->codec_type == AVMEDIA_TYPE_UNKNOWN) {
        av_log(NULL, AV_LOG_FATAL, "Elementary stream #%d is of unknown type, cannot proceed\n", i);
        return AVERROR_INVALIDDATA;
    }

    //设置rtsp使用tcp连接
    AVDictionary *opts = NULL;
    av_dict_set(&opts,"rtsp_transport", "tcp", 0);
    av_dict_set(&opts, "stimeout", "3000000", 0);
    /* init muxer, write output file header */
    ret = avformat_write_header(*ofmt_ctx, &opts);
    //推流的time base
    output_time_base_ = (*ofmt_ctx)->streams[0]->time_base;
    if (ret < 0) {
        av_log(NULL, AV_LOG_ERROR, "Error occurred when opening output file\n");
        return ret;
    }
    av_dict_free(&opts);

    output_index++;
    return 0;
}

void StreamWriter::set_fps(double fps) {
    imp_->set_fps(fps);
}
//对来源是流媒体的帧，设置输入源的time base
void StreamWriter::set_input_time_base(float time_base) {
    imp_->set_input_time_base(time_base);
}

void StreamWriter::use_gpu(bool encode_gpu_on) {
    imp_->use_gpu(encode_gpu_on);
}

void StreamWriter::set_qp(int qp) {
    imp_->set_qp(qp);
}


//对来源是视频文件的帧，设置fps
void StreamWriter::impl::set_fps(double fps) {
    fps_ = fps;
}

void StreamWriter::impl::set_input_time_base(float time_base) {
    input_time_base_ = av_d2q(time_base, std::numeric_limits<int>::max());
}

bool StreamWriter::write(cv::Mat &mat, int64_t pts) {
    return imp_->write(mat, pts);
}

void Mat2uchar(cv::Mat& mat, int img_w, int img_h, unsigned char *array)
{
    int i,j;

    for (i = 0; i < img_h; i++)
    {
        auto pData = mat.ptr<uchar>(i);
        for (j = 0; j < img_w*3; j++)
        {
            array[(i)*img_w*3+j] = *pData++;
        }
    }
}

void StreamWriter::impl::use_gpu(bool encode_gpu_on) {
    encode_gpu_on_ = encode_gpu_on;
}

void StreamWriter::impl::set_qp(int qp) {
    encode_quality_qp_ = qp;
}

int StreamWriter::impl::encode_frame(AVFrame *frame, AVCodecContext *enc_ctx, int64_t pts, int *got_frame) {
    int ret;
    int got_frame_local;
    AVPacket enc_pkt = {};
    auto auto_packet = pkt_ptr(&enc_pkt, av_packet_unref);
    int (*enc_func)(AVCodecContext *, AVPacket *, const AVFrame *, int *) = avcodec_encode_video2;

    if (!got_frame)
        got_frame = &got_frame_local;

    /* encode filtered frame */
    enc_pkt.data = NULL;
    enc_pkt.size = 0;
    av_init_packet(&enc_pkt);

    ret = enc_func(enc_ctx, &enc_pkt, frame, got_frame);

    if (pts && is_stream) {
        //流媒体输出，转换源time base到编码time base，并计算pts
        enc_pkt.pts=av_rescale_q(pts, input_time_base_, output_time_base_);
        enc_pkt.dts=enc_pkt.pts;
    }
    else {
        //文件输出，则采用frame_count和fps，直接计算pts
        AVRational time_base=output_fmt_ctx->streams[0]->time_base;
        int64_t calc_duration=(int64_t)(AV_TIME_BASE/av_q2d(output_fmt_ctx->streams[0]->r_frame_rate));
        enc_pkt.pts=(int64_t)((frame_count*calc_duration)/(double)(av_q2d(time_base)*AV_TIME_BASE));
        enc_pkt.dts=enc_pkt.pts;
        enc_pkt.duration=(int64_t)(calc_duration/(double)(av_q2d(time_base)*AV_TIME_BASE));
    }

    //设置输出流中index 0为视频流
    enc_pkt.stream_index = 0;
    enc_pkt.pos = -1;

    frame_count++;

    if (ret < 0)
        return ret;
    if (!(*got_frame))
        return 0;

    //得到一帧编码数据，写入流或者文件
    ret = av_interleaved_write_frame(output_fmt_ctx, &enc_pkt);

    return ret;
}

bool StreamWriter::impl::write(Mat &mat, int64_t pts) {
    int ret;
    if (width_ == 0 || height_ == 0){
        width_ = mat.cols;
        height_ = mat.rows;

        pRGBFrame = av_frame_alloc();
        pRGBFrame->width = width_;
        pRGBFrame->height = height_;
        pRGBFrame->format = AV_PIX_FMT_BGR24;
        rgb_buffer=new uint8_t[avpicture_get_size(AV_PIX_FMT_BGR24, pRGBFrame->width, pRGBFrame->height)];
        avpicture_fill((AVPicture *)pRGBFrame, rgb_buffer, AV_PIX_FMT_BGR24, pRGBFrame->width, pRGBFrame->height);

        pFrame = av_frame_alloc();
        pFrame->width = width_;
        pFrame->height = height_;
        pFrame->format = AV_PIX_FMT_YUV420P;
        yuv_buffer=new uint8_t[avpicture_get_size(AV_PIX_FMT_YUV420P, pFrame->width, pFrame->height)];
        avpicture_fill((AVPicture *)pFrame, yuv_buffer, AV_PIX_FMT_YUV420P, pFrame->width, pFrame->height);

        yuv_convert_ctx = sws_getContext(width_, height_, AV_PIX_FMT_BGR24,
                                         width_, height_, AV_PIX_FMT_YUV420P,
                                         SWS_BILINEAR, NULL, NULL, NULL);

        ret = open_output_file(&output_fmt_ctx, &output_enc_ctx, url_.c_str());
        if (ret < 0)
            return false;

        open_ = true;
    }

    if (open_) {
        Mat2uchar(mat, pRGBFrame->width, pRGBFrame->height, pRGBFrame->data[0]);
        sws_scale(yuv_convert_ctx, (const uint8_t* const*)pRGBFrame->data, pRGBFrame->linesize, 0,
                  height_, pFrame->data, pFrame->linesize);

        ret = encode_frame(pFrame, output_enc_ctx, pts, nullptr);
        if (ret < 0) {
            open_ = false;
            return false;
        }

        return true;
    }

    return false;
}

bool StreamWriter::close() {
    return imp_->close();
}

bool StreamWriter::impl::close() {
    if (open_)
        av_write_trailer(output_fmt_ctx);

    open_ = false;

    return true;
}


}

StreamWriterHandle create_stream_writer(const char* url) {
    auto wr = new ATVIDEO::StreamWriter(url);
    return reinterpret_cast<StreamWriterHandle>(wr);
}

void destroy_stream_writer(StreamWriterHandle writer) {
    auto wr = reinterpret_cast<ATVIDEO::StreamWriter*>(writer);
    delete wr;
}

void stream_writer_setFPS(StreamWriterHandle writer, double fps) {
    auto wr = reinterpret_cast<ATVIDEO::StreamWriter*>(writer);
    wr->set_fps(fps);
}

void stream_writer_set_input_time_base(StreamWriterHandle writer, float time_base) {
    auto wr = reinterpret_cast<ATVIDEO::StreamWriter*>(writer);
    wr->set_input_time_base(time_base);
}

bool stream_writer_write(StreamWriterHandle writer, cv::Mat* mat, int64_t pts) {
    auto wr = reinterpret_cast<ATVIDEO::StreamWriter*>(writer);
    cv::Mat temp(*mat);
    return wr->write(temp, pts);
}

bool stream_writer_close(StreamWriterHandle writer) {
    auto wr = reinterpret_cast<ATVIDEO::StreamWriter*>(writer);
    return wr->close();
}

