#ifndef STREAM_WRITER_STREAM_WRITER_H
#define STREAM_WRITER_STREAM_WRITER_H

#include <iostream>
#include <memory>
#include <opencv2/opencv.hpp>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

typedef void* StreamWriterHandle;

StreamWriterHandle create_stream_writer(const char* url);
void destroy_stream_writer(StreamWriterHandle writer);
void stream_writer_setFPS(StreamWriterHandle writer, double fps);
void stream_writer_set_input_time_base(StreamWriterHandle writer, float time_base);
bool stream_writer_write(StreamWriterHandle writer, CvMat* mat, int64_t *pts = nullptr);
bool stream_writer_close(StreamWriterHandle writer);

#ifdef __cplusplus
} // close extern "C" {

namespace ATVIDEO {

class StreamWriter {

public:
    StreamWriter(const std::string url);
    ~StreamWriter(){};
  
    void use_gpu(bool encode_gpu_on);
    void set_qp(int qp);
    void set_fps(double fps);
    void set_input_time_base(float time_base);
    bool write(cv::Mat &mat, int64_t pts);
    bool close();

private:
    class impl;
    std::shared_ptr<impl> imp_ = nullptr;
};

}

#endif

#endif //STREAM_WRITER_STREAM_WRITER_H
