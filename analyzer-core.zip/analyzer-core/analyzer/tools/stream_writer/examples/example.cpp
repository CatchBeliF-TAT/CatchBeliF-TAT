#include <iostream>
#include <chrono>
#include <iomanip>
#include <unistd.h>
#include "../src/stream_writer.hpp"

using namespace ATVIDEO;
using namespace cv;
using namespace std;

int main(int argc, char* argv[]) {

//    StreamWriter write("rtmp://127.0.0.1:1936/live/test");
    StreamWriter write("rtsp://100.100.56.222:5544/test");
    int count = 1;
    Mat im_mat;
    while (true) {
        stringstream ss;
        ss << setw(5) << setfill('0') << count << ".jpg";
        string s = ss.str();
        cout << s << endl;

        im_mat= imread(ss.str());
        if (im_mat.empty())
            break;
        write.write(im_mat);
        count++;
//        usleep(300000);
//        if(count == 50)
//            break;
    }

}
