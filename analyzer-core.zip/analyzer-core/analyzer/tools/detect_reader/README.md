# Detect Reader

## 主要实现功能

1. 视频帧逐帧读取
2. 检测当前帧是不是场景切换，包含突变场景和渐变场景
3. 自适应检测当前帧是否包含明显运动物体


## 接口定义

### C++接口

``` c++
//创建detect reader对象，shot_on是否打开镜头检测功能，motion_on是否打开运动物体检测功能
DR(bool shot_on, bool motion_on);
//打开一个视频文件或流媒体
bool open(const std::string &input);
//读取一帧图像，数据存储在opencv Mat中, BGR格式
bool read(cv::Mat &mat);
//获取视频fps
float fps();
//获取视频宽度
int width();
//获取视频高度
int height();
//关闭并销毁detect reader对象
void close();
//获取当前帧是否是场景切换
bool shot();
//获取当前帧是否包含明显运动物体
bool motion();
//运动检测中的ROI区域设置
void set_mv_roi(MV_ROI roi);
enum MV_ROI {
    MV_ROI_WHOLE,       //全部画面
    MV_ROI_CENTRAL,     //中心区域
    MV_ROI_HORIZONTAL,  //去除画面上部和下部，保留中部
    MV_ROI_VERTICAL,    //去除画面左部和右部，保留中部
};

```

### Python接口

安装python包
``` shell
cd python
python setup install

```

python example
``` python
import dr
# 构造detect_reader
reader = dr.detect_reader(shot=True, motion=False)
reader.open(input_file)  # 若传入字符串，需要使用reader.open(str.encode("xxx"))
fps = reader.fps()
width = reader.width()
height = reader.height()
reader.set_mv_roi(dr.MV_ROI_WHOLE)
# 读取BGR格式的帧数据，帧数据为numpy数组，视频结尾返回None
mat_array = reader.read()
# 当前帧是否为镜头切换
shot = reader.shot()

```

## 依赖

1. gcc 5.4 以上

    Mac上编译python版本需要打开setup.py
    ``` python
    os.environ["CC"] = "g++-8"       #修改为对应的g++版本
    os.environ["CXX"] = "g++-8"      #修改为对应的g++版本
    ```
    修改setup.py相应的ffmpeg lib dir

2. libx264

``` shell
    wget http://oxmz2ax9v.bkt.clouddn.com/x264-snapshot-20180528-2245-stable.tar.bz2
    tar xf x264-snapshot-20180528-2245-stable.tar.bz2
    rm x264-snapshot-20180528-2245-stable.tar.bz2
    cd x264-snapshot-20180528-2245-stable
    ./configure --enable-shared --disable-asm && make && sudo make install
```

3. ffmpeg3.4.2以上

``` shell
    wget  http://ffmpeg.org/releases/ffmpeg-3.4.2.tar.bz2
    tar xf ffmpeg-3.4.2.tar.bz2
    rm ffmpeg-3.4.2.tar.bz2
    cd ffmpeg-3.4.2
    ./configure --enable-shared --enable-libx264 --enable-gpl
    make -j8 && sudo make install
```

4. OpenCV, python接口需要OpenCV3

## 镜头分割可执行文件的运行方法

在安装好部分软件后，可以直接运行预编译好的可执行文件，进行视频的镜头分割

1. 安装软件

``` shell
    apt-get install -y software-properties-common
    add-apt-repository -y ppa:jonathonf/ffmpeg-3
    apt-get update && apt install -y libavformat-dev x264 libopencv-dev
```

2. 下载可执行文件

    执行文件: http://peb4s2hzu.bkt.clouddn.com/shot_cut
    
    测试文件: http://p78cdhlse.bkt.clouddn.com/prc.mp4

3. 运行可执行文件

```shell
    ./shot_cut <input file> <output file>
```
