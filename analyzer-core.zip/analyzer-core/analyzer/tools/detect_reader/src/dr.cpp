#include "dr.hpp"
#include "detect_reader.hpp"

namespace ATVIDEO {

DR::DR() {
    engine_ = std::shared_ptr<DetectReader>(new DetectReader(false, false));
}

DR::DR(bool shot_on, bool motion_on) {
    engine_ = std::shared_ptr<DetectReader>(new DetectReader(shot_on, motion_on));
}

bool DR::open(const std::string &input) {
    return engine_->open(input);
}

bool DR::open_output(const std::string &output) {
    return engine_->open_output(output);
}

bool DR::read(cv::Mat &mat, int64_t *pts){
    return engine_->read(mat, pts);
}

float DR::fps(){
    return engine_->fps();
}

int DR::width(){
    return engine_->width();
}

int DR::height(){
    return engine_->height();
}

bool DR::shot() {
    return engine_->shot();
}

bool DR::motion() {
    return engine_->motion();
}

void DR::set_mv_roi(MV_ROI roi) {
    engine_->set_mv_roi(roi);
}

float DR::stream_time_base() {
    return engine_->stream_time_base();
}

void DR::close(){
    engine_.reset();
}

}

DRHandle create_detect_reader(bool shot_on, bool motion_on) {
    auto rd = new ATVIDEO::DR(shot_on, motion_on);
    return reinterpret_cast<DRHandle>(rd);
}

void destroy_detect_reader(DRHandle reader) {
    auto rd = reinterpret_cast<ATVIDEO::DR*>(reader);
    delete rd;
}

bool detect_reader_open(DRHandle reader, const char* input) {
    auto rd = reinterpret_cast<ATVIDEO::DR*>(reader);
    return rd->open(input);
}

bool detect_reader_open_output(DRHandle reader, const char* output) {
    auto rd = reinterpret_cast<ATVIDEO::DR*>(reader);
    return rd->open_output(output);
}

bool detect_reader_read(DRHandle reader, cv::Mat* mat, int64_t *pts) {
    auto rd = reinterpret_cast<ATVIDEO::DR*>(reader);
    cv::Mat temp(*mat);
    return rd->read(temp, pts);
}

float detect_reader_fps(DRHandle reader) {
    auto rd = reinterpret_cast<ATVIDEO::DR*>(reader);
    return rd->fps();
}

int detect_reader_width(DRHandle reader) {
    auto rd = reinterpret_cast<ATVIDEO::DR*>(reader);
    return rd->width();
}

int detect_reader_height(DRHandle reader) {
    auto rd = reinterpret_cast<ATVIDEO::DR*>(reader);
    return rd->height();
}

void detect_reader_close(DRHandle reader) {
    auto rd = reinterpret_cast<ATVIDEO::DR*>(reader);
    rd->close();
}

bool detect_reader_shot(DRHandle reader) {
    auto rd = reinterpret_cast<ATVIDEO::DR*>(reader);
    return rd->shot();
}

bool detect_reader_motion(DRHandle reader) {
    auto rd = reinterpret_cast<ATVIDEO::DR*>(reader);
    return rd->motion();
}

void detect_reader_set_mv_roi(DRHandle reader, MV_ROI roi) {
    auto rd = reinterpret_cast<ATVIDEO::DR*>(reader);
    rd->set_mv_roi(roi);
}

float detect_reader_stream_time_base(DRHandle reader) {
    auto rd = reinterpret_cast<ATVIDEO::DR*>(reader);
    return rd->stream_time_base();
}



