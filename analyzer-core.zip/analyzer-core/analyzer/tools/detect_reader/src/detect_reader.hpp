#ifndef DETECT_READER_H
#define DETECT_READER_H

extern "C"
{
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/opt.h>
#include <libavutil/pixdesc.h>
#include <libswscale/swscale.h>
#include <libavutil/motion_vector.h>
#include <libavutil/avstring.h>
};
#include <string>
#include <algorithm>
#include <opencv2/opencv.hpp>
#include <deque>
#include "dr.hpp"

namespace ATVIDEO {

typedef struct StreamContext {
    AVCodecContext *dec_ctx;
    AVCodecContext *enc_ctx;
    AVCodecContext *enc_ctx1;
} StreamContext;


class DR::DetectReader{
public:
    DetectReader();
    DetectReader(bool shot_detect_on, bool motion_detect_on);
    virtual ~DetectReader();
    bool open(const std::string& input);
    bool open_output(const std::string& output);
    bool read(cv::Mat& mat, int64_t *pts);
    float fps();
    int width();
    int height();
    bool shot();
    bool motion();
    void set_mv_roi(MV_ROI roi);
    float stream_time_base();

private:
    int open_input_file(const char* input);
    int open_encoder(AVFormatContext** ofmt_ctx, AVCodecContext **enc, int sc, int me_ramge);
    int encode_frame(AVFrame *frame, AVCodecContext *enc_ctx, int *got_frame, int &scene_frame_count, bool &scene);
    int open_output_file(AVFormatContext** ofmt_ctx, AVCodecContext **enc, const char *filename);
    int output_encode_frame(AVFrame *frame, AVCodecContext *enc_ctx, int *got_frame);
    void process_mv(AVFrame *frame, double &avg_mv);
    bool std_dev_condition(cv::Mat &mv_mat);
    void get_roi_rect(cv::Mat &mv_mat, cv::Rect &rect);

private:
    bool shot_dectect_on_;
    bool motion_detect_on_;
    AVFormatContext *ifmt_ctx_ = nullptr;
    AVFormatContext *ofmt_ctx = nullptr;
    AVFormatContext *ofmt_ctx1 = nullptr;
    AVFormatContext *output_fmt_ctx = nullptr;
    AVCodecContext *output_enc_ctx = nullptr;
    StreamContext *stream_ctx_ = nullptr;
    SwsContext *rgb_convert_ctx = nullptr;
    SwsContext *yuv_convert_ctx = nullptr;
    AVFrame *pRGBFrame = nullptr;
    AVFrame *pScaleFrame = nullptr;
    AVFrame *pScaleFrame_smooth = nullptr;
    AVFrame *raw_frame = nullptr;
    float fps_ = 0.f;
    int width_ = 0;
    int height_ = 0;
    float stream_time_base_den_ = 0;
    bool is_open_ = false;
    int scale_width = 0;
    int scale_height = 0;
    int encode_width = 0;
    int encode_height = 0;
    int sc_threshold = 120;
    int video_stream_idx = 0;
    int scene_frame_count = 0;
    int scene_frame_count1 = 0;
    int frame_num = 0;
    bool is_scene_frame_ = false;
    bool is_motion_frame_ = false;
    bool get_first_key_frame = false;
    std::deque<double> stddev_queue;
    std::deque<double> stddev_stat;
    std::deque<double> avgmv_queue;
    MV_ROI mv_roi_ = MV_ROI_WHOLE;
    time_t check_time;
    std::string output_name;
    int output_count = 0;

    uint8_t *rgb_out_buffer = nullptr;
    uint8_t *scale_out_buffer = nullptr;
    uint8_t *scale_smooth_out_buffer = nullptr;

    friend int check_interrupt(void *ctx);
};

}

#endif //SCOPE_SCENE_DETECT_H
