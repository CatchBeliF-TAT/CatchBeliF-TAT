#ifndef DR_H
#define DR_H

#include <iostream>
#include <memory>
#include <opencv2/opencv.hpp>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

enum MV_ROI {
    MV_ROI_WHOLE,
    MV_ROI_CENTRAL,
    MV_ROI_HORIZONTAL,
    MV_ROI_VERTICAL,
};

typedef void* DRHandle;

DRHandle create_detect_reader(bool shot_on, bool motion_on);
void destroy_detect_reader(DRHandle reader);
bool detect_reader_open(DRHandle reader, const char* input);
bool detect_reader_open_output(DRHandle reader, const char* output);
bool detect_reader_read(DRHandle reader, CvMat* mat, int64_t *pts = nullptr);
float detect_reader_fps(DRHandle reader);
int detect_reader_width(DRHandle reader);
int detect_reader_height(DRHandle reader);
void detect_reader_close(DRHandle reader);
bool detect_reader_shot(DRHandle reader);
bool detect_reader_motion(DRHandle reader);
void detect_reader_set_mv_roi(DRHandle reader, MV_ROI roi);
float detect_reader_stream_time_base(DRHandle reader);

#ifdef __cplusplus
} // close extern "C" {

namespace ATVIDEO {

class DR {
public:
    DR();
    DR(bool shot_on, bool motion_on);
    ~DR() = default;

    bool open(const std::string &input);
    bool open_output(const std::string& output);
    bool read(cv::Mat &mat, int64_t *pts = nullptr);
    float fps();
    int width();
    int height();
    void close();
    bool shot();
    bool motion();
    void set_mv_roi(MV_ROI roi);
    float stream_time_base();
private:
    class DetectReader;
    std::shared_ptr<DetectReader> engine_ = nullptr;

    friend int check_interrupt(void *ctx);

};

}

#endif

#endif //SCOPE_SD_H
