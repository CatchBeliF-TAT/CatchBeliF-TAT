#include <iostream>
#include <numeric>
#include <iomanip>
#include <functional>
#include "detect_reader.hpp"

namespace ATVIDEO {

using namespace cv;
using namespace std;

#define SPS_HEADER 0x42
#define I_FRAME_HEADER 0x88

#undef av_err2str
std::string av_err2str(int errnum) {
    char errbuf[AV_ERROR_MAX_STRING_SIZE];
    av_strerror(errnum, errbuf, AV_ERROR_MAX_STRING_SIZE);
    return std::string{errbuf};
}

template<typename T>
class AVDeleter {
public:
    AVDeleter() : deleter_(nullptr) {}
    AVDeleter(std::function<void(T**)> deleter) : deleter_{deleter} {}

    void operator()(T *p) {
        deleter_(&p);
    }
private:
    std::function<void(T**)> deleter_;
};

template<typename T>
using av_unique_ptr = std::unique_ptr<T, AVDeleter<T>>;

template <typename T>
av_unique_ptr<T> av_make_unique(T* raw_ptr, void (*deleter)(T**)) {
    return av_unique_ptr<T>(raw_ptr, AVDeleter<T>(deleter));
}

using pkt_ptr = std::unique_ptr<AVPacket, decltype(&av_packet_unref)>;

DR::DetectReader::DetectReader() : shot_dectect_on_(false),
                               motion_detect_on_(false){

}

DR::DetectReader::DetectReader(bool shot_detect_on, bool motion_detect_on) : shot_dectect_on_(shot_detect_on),
                                                           motion_detect_on_(motion_detect_on){

}

DR::DetectReader::~DetectReader() {
    if (ifmt_ctx_)
        avformat_close_input(&ifmt_ctx_);

    if (ofmt_ctx)
        avformat_close_input(&ofmt_ctx);

    if (ofmt_ctx1)
        avformat_close_input(&ofmt_ctx1);

    if (stream_ctx_ && stream_ctx_->dec_ctx)
        avcodec_free_context(&stream_ctx_->dec_ctx);

    if (stream_ctx_ && stream_ctx_->enc_ctx)
        avcodec_free_context(&stream_ctx_->enc_ctx);

    if (stream_ctx_ && stream_ctx_->enc_ctx1)
        avcodec_free_context(&stream_ctx_->enc_ctx1);

    if (stream_ctx_)
        av_free(stream_ctx_);

    if (pRGBFrame)
        av_frame_free(&pRGBFrame);

    if (pScaleFrame)
        av_frame_free(&pScaleFrame);

    if (pScaleFrame_smooth)
        av_frame_free(&pScaleFrame_smooth);

    if (raw_frame)
        av_frame_free(&raw_frame);

    if (rgb_convert_ctx)
        sws_freeContext(rgb_convert_ctx);

    if (yuv_convert_ctx)
        sws_freeContext(yuv_convert_ctx);

    if (rgb_out_buffer)
        delete [] rgb_out_buffer;

    if (scale_out_buffer)
        delete [] scale_out_buffer;

    if (scale_smooth_out_buffer)
        delete [] scale_smooth_out_buffer;

    if (!output_name.empty()) {
        av_write_trailer(output_fmt_ctx);

        avcodec_free_context(&output_enc_ctx);

        if (output_fmt_ctx && !(output_fmt_ctx->oformat->flags & AVFMT_NOFILE))
            avio_closep(&output_fmt_ctx->pb);
        avformat_free_context(output_fmt_ctx);
    }
}

bool DR::DetectReader::open(const std::string& input) {
    const char* filename = input.c_str();
    av_register_all();
    avformat_network_init();
    if (open_input_file(filename) < 0)
        return false;

    AVCodecContext *video_dec_ctx = ifmt_ctx_->streams[video_stream_idx]->codec;
    encode_width = (video_dec_ctx->width+32) >> 6 << 4;
    encode_height = (video_dec_ctx->height+32) >> 6 << 4;
    encode_width = std::max(encode_width, 64);
    encode_height = std::max(encode_height, 64);

    if (shot_dectect_on_) {
        if (open_encoder(&ofmt_ctx, &(stream_ctx_->enc_ctx), 150, 16) < 0)
            return false;

        if (open_encoder(&ofmt_ctx1, &(stream_ctx_->enc_ctx1), 100, 64) < 0)
            return false;
    }

    is_open_ = true;

    //YUV转RGB
    pRGBFrame = av_frame_alloc();
    pRGBFrame->width = stream_ctx_->dec_ctx->width;
    pRGBFrame->height = stream_ctx_->dec_ctx->height;
    pRGBFrame->format = AV_PIX_FMT_BGR24;
    rgb_out_buffer=new uint8_t[avpicture_get_size(AV_PIX_FMT_BGR24, pRGBFrame->width, pRGBFrame->height)];
    avpicture_fill((AVPicture *)pRGBFrame, rgb_out_buffer, AV_PIX_FMT_BGR24, pRGBFrame->width, pRGBFrame->height);


    rgb_convert_ctx = sws_getContext(video_dec_ctx->width, video_dec_ctx->height, video_dec_ctx->pix_fmt,
                                     pRGBFrame->width, pRGBFrame->height, AV_PIX_FMT_BGR24,
                                     SWS_BICUBIC, NULL, NULL, NULL);

    pScaleFrame = av_frame_alloc();
    pScaleFrame->width = encode_width;
    pScaleFrame->height = encode_height;
    pScaleFrame->format = AV_PIX_FMT_YUV420P;
    scale_out_buffer=new uint8_t[avpicture_get_size(AV_PIX_FMT_YUV420P, pScaleFrame->width, pScaleFrame->height)];
    avpicture_fill((AVPicture *)pScaleFrame, scale_out_buffer, AV_PIX_FMT_YUV420P, pScaleFrame->width, pScaleFrame->height);

    yuv_convert_ctx = sws_getContext(video_dec_ctx->width, video_dec_ctx->height, video_dec_ctx->pix_fmt,
                                     pScaleFrame->width, pScaleFrame->height, AV_PIX_FMT_YUV420P,
                                     SWS_BICUBIC, NULL, NULL, NULL);

    pScaleFrame_smooth = av_frame_alloc();
    pScaleFrame_smooth->width = encode_width;
    pScaleFrame_smooth->height = encode_height;
    pScaleFrame_smooth->format = AV_PIX_FMT_YUV420P;
    scale_smooth_out_buffer=new uint8_t[avpicture_get_size(AV_PIX_FMT_YUV420P, pScaleFrame_smooth->width, pScaleFrame_smooth->height)];
    avpicture_fill((AVPicture *)pScaleFrame_smooth, scale_smooth_out_buffer, AV_PIX_FMT_YUV420P, pScaleFrame_smooth->width, pScaleFrame_smooth->height);

    raw_frame = av_frame_alloc();
    if (!raw_frame) {
        return false;
    }

    return true;
}

bool DR::DetectReader::open_output(const std::string& output){
    output_name = output;
    if (open_output_file(&output_fmt_ctx, &output_enc_ctx, output_name.c_str()) < 0)
        return false;

    return true;
}

//超时中断检查callback函数
int check_interrupt(void *ctx)
{
    auto p = (ATVIDEO::DR::DetectReader*)ctx;
    auto duration = time(NULL) - p->check_time;
    //30秒超时
    int timeout = duration >= 30 ? 1 : 0;
    if (timeout)
        av_log(NULL, AV_LOG_ERROR, "av_read_frame timeout\n");
    return timeout;
}

int DR::DetectReader::open_input_file(const char* input) {
    int ret=0;
    unsigned int i=0;
    AVDictionary *opts = NULL;

    //对rtsp流使用tcp连接，并设置最大延时和超时
    av_dict_set(&opts, "rtsp_transport", "tcp", 0);
    av_dict_set(&opts, "max_delay", "500000", 0);
    av_dict_set(&opts, "timeout", "3000000", 0);
    av_dict_set(&opts, "stimeout", "3000000", 0);

    if(av_stristart(input,"rtmp",NULL) ||av_stristart(input,"rtsp",NULL)) {
        av_log(NULL, AV_LOG_WARNING,"remove 'timeout' option for rtmp.\n");
        av_dict_set(&opts, "timeout", NULL, 0);
    }

    ifmt_ctx_ = avformat_alloc_context();
    //设置超时callback
    check_time = time(NULL);
    ifmt_ctx_->interrupt_callback.callback = check_interrupt;//打开超时回调
    ifmt_ctx_->interrupt_callback.opaque = this;

    if ((ret = avformat_open_input(&ifmt_ctx_, input, NULL, &opts)) < 0) {
        av_log(NULL, AV_LOG_ERROR, "Cannot open input file\n");
        return ret;
    }
    av_dict_free(&opts);

    ifmt_ctx_->interrupt_callback.callback = NULL;//关闭超时回调
    ifmt_ctx_->interrupt_callback.opaque = NULL;

    if ((ret = avformat_find_stream_info(ifmt_ctx_, NULL)) < 0) {
        av_log(NULL, AV_LOG_ERROR, "Cannot find stream information\n");
        return ret;
    }

    ret = av_find_best_stream(ifmt_ctx_, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
    if (ret < 0) {
        fprintf(stderr, "Could not find %s stream in input file '%s'\n",
                av_get_media_type_string(AVMEDIA_TYPE_VIDEO), input);
        return ret;
    } else {
        video_stream_idx = ret;
    }

    stream_ctx_ = (StreamContext *)av_mallocz_array(1, sizeof(*stream_ctx_));
    if (!stream_ctx_)
        return AVERROR(ENOMEM);

    AVStream *stream = ifmt_ctx_->streams[video_stream_idx];
    //计算time base，推流的时候需要做time base的转换
    stream_time_base_den_ = (float)stream->time_base.den / stream->time_base.num;

    //计算fps
    if(stream->r_frame_rate.den > 0) {
        fps_ = (float)stream->r_frame_rate.num/stream->r_frame_rate.den;
    }
    else if(stream->codec->framerate.den > 0) {
        fps_ = (float)stream->codec->framerate.num / stream->codec->framerate.den;
    }
    else {
        fps_ = (float)stream->avg_frame_rate.num / stream->avg_frame_rate.den;
    }

    if(isnan(fps_))
        fps_ = 25;

    width_ = static_cast<uint16_t>(stream->codecpar->width);
    height_ = static_cast<uint16_t>(stream->codecpar->height);

    AVCodec *dec = avcodec_find_decoder(stream->codecpar->codec_id);
    AVCodecContext *codec_ctx;
    if (!dec) {
        av_log(NULL, AV_LOG_ERROR, "Failed to find decoder for stream #%u\n", video_stream_idx);
        //return AVERROR_DECODER_NOT_FOUND;
        return -1;
    }
    codec_ctx = avcodec_alloc_context3(dec);
    //设置解码thread数量，并设置frame和slice并行解码
    codec_ctx->thread_count = 2;
    codec_ctx->active_thread_type = FF_THREAD_FRAME | FF_THREAD_SLICE;

    if (!codec_ctx) {
        av_log(NULL, AV_LOG_ERROR, "Failed to allocate the decoder context for stream #%u\n", video_stream_idx);
        return AVERROR(ENOMEM);
    }
    ret = avcodec_parameters_to_context(codec_ctx, stream->codecpar);
    if (ret < 0) {
        av_log(NULL, AV_LOG_ERROR, "Failed to copy decoder parameters to input decoder context "
                "for stream #%u\n", video_stream_idx);
        return ret;
    }
    /* Reencode video & audio and remux subtitles etc. */
    if (codec_ctx->codec_type == AVMEDIA_TYPE_VIDEO)
        codec_ctx->framerate = av_guess_frame_rate(ifmt_ctx_, stream, NULL);

    //设置输出额外的运动矢量信息
    opts = NULL;
    av_dict_set(&opts, "flags2", "+export_mvs", 0);
    /* Open decoder */
    ret = avcodec_open2(codec_ctx, dec, &opts);
    av_dict_free(&opts);

    if (ret < 0) {
        av_log(NULL, AV_LOG_ERROR, "Failed to open decoder for stream #%u\n", i);
        return ret;
    }
    stream_ctx_->dec_ctx = codec_ctx;

    av_dump_format(ifmt_ctx_, 0, input, 0);
    return 0;
}

int DR::DetectReader::open_output_file(AVFormatContext** ofmt_ctx, AVCodecContext **enc, const char *filename) {
    AVStream *out_stream;
    AVCodecContext *dec_ctx, *enc_ctx;
    AVCodec *encoder;
    int ret=0;
    unsigned int i=0;
    static int output_index = 0;

    stringstream ss;
    ss << filename << "_" << setw(5) << setfill('0') << output_index << ".avi";
    cout << "Writing video " << ss.str() << endl;
    string temp_name = ss.str();
    avformat_alloc_output_context2(ofmt_ctx, NULL, NULL, temp_name.c_str());
    if (!*ofmt_ctx) {
        av_log(NULL, AV_LOG_ERROR, "Could not create output context\n");
        return AVERROR_UNKNOWN;
    }

    out_stream = avformat_new_stream(*ofmt_ctx, NULL);
    if (!out_stream) {
        av_log(NULL, AV_LOG_ERROR, "Failed allocating output stream\n");
        return AVERROR_UNKNOWN;
    }

    dec_ctx = stream_ctx_->dec_ctx;

    if (dec_ctx->codec_type == AVMEDIA_TYPE_VIDEO) {
        /* in this example, we choose transcoding to same codec */
        encoder = avcodec_find_encoder_by_name("libx264");
        if (!encoder) {
            av_log(NULL, AV_LOG_FATAL, "Necessary encoder not found\n");
            return AVERROR_INVALIDDATA;
        }
        enc_ctx = avcodec_alloc_context3(encoder);

        enc_ctx->thread_count = 2;
        enc_ctx->active_thread_type = FF_THREAD_SLICE;

        if (!enc_ctx) {
            av_log(NULL, AV_LOG_FATAL, "Failed to allocate the encoder context\n");
            return AVERROR(ENOMEM);
        }

        /* In this example, we transcode to same properties (picture size,
         * sample rate etc.). These properties can be changed for output
         * streams easily using filters */
        if (dec_ctx->codec_type == AVMEDIA_TYPE_VIDEO) {
            enc_ctx->width = dec_ctx->width;
            enc_ctx->height = dec_ctx->height;
            enc_ctx->sample_aspect_ratio = dec_ctx->sample_aspect_ratio;
            /* take first format from list of supported formats */
            if (encoder->pix_fmts)
                enc_ctx->pix_fmt = encoder->pix_fmts[0];
            else
                enc_ctx->pix_fmt = dec_ctx->pix_fmt;
            /* video time_base can be set to whatever is handy and supported by encoder */
            enc_ctx->time_base = av_inv_q(AVRational{25,1});
        } else {
            enc_ctx->sample_rate = dec_ctx->sample_rate;
            enc_ctx->channel_layout = dec_ctx->channel_layout;
            enc_ctx->channels = av_get_channel_layout_nb_channels(enc_ctx->channel_layout);
            /* take first format from list of supported formats */
            enc_ctx->sample_fmt = encoder->sample_fmts[0];
            enc_ctx->time_base = (AVRational){1, enc_ctx->sample_rate};
        }

        //quality control, may effect the scene detect
        enc_ctx->profile = FF_PROFILE_H264_BASELINE;
        av_opt_set(enc_ctx->priv_data, "tune", "zerolatency", 0);

        /* Third parameter can be used to pass settings to encoder */
        ret = avcodec_open2(enc_ctx, encoder, NULL);

        if (ret < 0) {
            av_log(NULL, AV_LOG_ERROR, "Cannot open video encoder for stream #%u\n", i);
            return ret;
        }
        ret = avcodec_parameters_from_context(out_stream->codecpar, enc_ctx);
        if (ret < 0) {
            av_log(NULL, AV_LOG_ERROR, "Failed to copy encoder parameters to output stream #%u\n", i);
            return ret;
        }
        if ((*ofmt_ctx)->oformat->flags & AVFMT_GLOBALHEADER)
            enc_ctx->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;

        out_stream->time_base = enc_ctx->time_base;
        *enc = enc_ctx;
    } else if (dec_ctx->codec_type == AVMEDIA_TYPE_UNKNOWN) {
        av_log(NULL, AV_LOG_FATAL, "Elementary stream #%d is of unknown type, cannot proceed\n", i);
        return AVERROR_INVALIDDATA;
    }

    if (!((*ofmt_ctx)->oformat->flags & AVFMT_NOFILE)) {
        ret = avio_open(&(*ofmt_ctx)->pb, temp_name.c_str(), AVIO_FLAG_WRITE);
        if (ret < 0) {
            av_log(NULL, AV_LOG_ERROR, "Could not open output file '%s'", temp_name.c_str());
            return ret;
        }
    }

    /* init muxer, write output file header */
    ret = avformat_write_header(*ofmt_ctx, NULL);
    if (ret < 0) {
        av_log(NULL, AV_LOG_ERROR, "Error occurred when opening output file\n");
        return ret;
    }

    output_index++;
    return 0;
}

int DR::DetectReader::open_encoder(AVFormatContext** ofmt_ctx, AVCodecContext **enc, int sc, int me_range) {
    AVStream *out_stream;
    AVCodecContext *dec_ctx, *enc_ctx;
    AVCodec *encoder;
    int ret=0;
    unsigned int i=0;

    const char* output = "temp.avi";
    avformat_alloc_output_context2(ofmt_ctx, NULL, NULL, output);
    if (!*ofmt_ctx) {
        av_log(NULL, AV_LOG_ERROR, "Could not create output context\n");
        return AVERROR_UNKNOWN;
    }

    out_stream = avformat_new_stream(*ofmt_ctx, NULL);
    if (!out_stream) {
        av_log(NULL, AV_LOG_ERROR, "Failed allocating output stream\n");
        return AVERROR_UNKNOWN;
    }

    dec_ctx = stream_ctx_->dec_ctx;

    if (scale_width == 0 || scale_height == 0) {
        scale_width = dec_ctx->width;
        scale_height = dec_ctx->height;
    }

    if (dec_ctx->codec_type == AVMEDIA_TYPE_VIDEO) {
        /* in this example, we choose transcoding to same codec */
        encoder = avcodec_find_encoder_by_name("libx264");
        if (!encoder) {
            av_log(NULL, AV_LOG_FATAL, "Necessary encoder not found\n");
            return AVERROR_INVALIDDATA;
        }
        enc_ctx = avcodec_alloc_context3(encoder);

        enc_ctx->thread_count = 2;
        enc_ctx->active_thread_type = FF_THREAD_SLICE;

        if (!enc_ctx) {
            av_log(NULL, AV_LOG_FATAL, "Failed to allocate the encoder context\n");
            return AVERROR(ENOMEM);
        }

        /* In this example, we transcode to same properties (picture size,
         * sample rate etc.). These properties can be changed for output
         * streams easily using filters */
        if (dec_ctx->codec_type == AVMEDIA_TYPE_VIDEO) {
            enc_ctx->width = encode_width;
            enc_ctx->height = encode_height;
            enc_ctx->sample_aspect_ratio = dec_ctx->sample_aspect_ratio;
            /* take first format from list of supported formats */
            if (encoder->pix_fmts)
                enc_ctx->pix_fmt = encoder->pix_fmts[0];
            else
                enc_ctx->pix_fmt = dec_ctx->pix_fmt;
            /* video time_base can be set to whatever is handy and supported by encoder */
            enc_ctx->time_base = av_inv_q(dec_ctx->framerate);
        } else {
            enc_ctx->sample_rate = dec_ctx->sample_rate;
            enc_ctx->channel_layout = dec_ctx->channel_layout;
            enc_ctx->channels = av_get_channel_layout_nb_channels(enc_ctx->channel_layout);
            /* take first format from list of supported formats */
            enc_ctx->sample_fmt = encoder->sample_fmts[0];
            enc_ctx->time_base = (AVRational){1, enc_ctx->sample_rate};
        }

        //quality control, may effect the scene detect

        enc_ctx->me_range = me_range;
        enc_ctx->max_qdiff = 10;
        enc_ctx->qmin = 4;
        enc_ctx->qmax = 4;
        //enc_ctx->qcompress = 1.0;

        //scene detect parameter
        enc_ctx->gop_size = 6000;
        enc_ctx->profile = FF_PROFILE_H264_BASELINE;
        enc_ctx->scenechange_threshold = sc;
        enc_ctx->keyint_min = 1;
        av_opt_set(enc_ctx->priv_data, "tune", "zerolatency", 0);
        av_opt_set_int(enc_ctx->priv_data, "me_method", 4, 0);

        /* Third parameter can be used to pass settings to encoder */
        ret = avcodec_open2(enc_ctx, encoder, NULL);

        if (ret < 0) {
            av_log(NULL, AV_LOG_ERROR, "Cannot open video encoder for stream #%u\n", i);
            return ret;
        }
        ret = avcodec_parameters_from_context(out_stream->codecpar, enc_ctx);
        if (ret < 0) {
            av_log(NULL, AV_LOG_ERROR, "Failed to copy encoder parameters to output stream #%u\n", i);
            return ret;
        }
        if ((*ofmt_ctx)->oformat->flags & AVFMT_GLOBALHEADER)
            enc_ctx->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;

        out_stream->time_base = enc_ctx->time_base;
        *enc = enc_ctx;
    } else if (dec_ctx->codec_type == AVMEDIA_TYPE_UNKNOWN) {
        av_log(NULL, AV_LOG_FATAL, "Elementary stream #%d is of unknown type, cannot proceed\n", i);
        return AVERROR_INVALIDDATA;
    }

    return 0;
}

float DR::DetectReader::fps() {
    if (is_open_)
        return fps_;
    else
        return 0;
}

int DR::DetectReader::width() {
  if (is_open_)
    return width_;
  else
    return 0;
}

int DR::DetectReader::height() {
  if (is_open_)
    return height_;
  else
    return 0;
}

bool DR::DetectReader::shot() {
  if (is_open_)
    return is_scene_frame_;
  else
    return false;
}

bool DR::DetectReader::motion() {
    if (is_open_)
        return is_motion_frame_;
    else
        return false;
}

float DR::DetectReader::stream_time_base() {
    if (is_open_)
        return stream_time_base_den_;
    else
        return 0;
}

void DR::DetectReader::set_mv_roi(MV_ROI roi) {
    mv_roi_ = roi;
}

void uchar2Mat(const unsigned char *inArrayCur, int img_w, int img_h, cv::Mat& mat)
{
    int i,j;

    for (i = 0; i < img_h; i++)
    {
        auto pData = mat.ptr<uchar>(i);
        for (j = 0; j < img_w*3; j++)
        {
            *pData++ = inArrayCur[(i)*img_w*3+j] ;
        }
    }
}

int DR::DetectReader::encode_frame(AVFrame *frame, AVCodecContext *enc_ctx, int *got_frame, int &scene_frame_count, bool &scene) {
    int ret;
    int got_frame_local;
    AVPacket enc_pkt = {};
    auto auto_packet = pkt_ptr(&enc_pkt, av_packet_unref);
    int (*enc_func)(AVCodecContext *, AVPacket *, const AVFrame *, int *) =
    (ifmt_ctx_->streams[video_stream_idx]->codecpar->codec_type ==
     AVMEDIA_TYPE_VIDEO) ? avcodec_encode_video2 : avcodec_encode_audio2;

    scene = false;

    if (!got_frame)
        got_frame = &got_frame_local;

    /* encode filtered frame */
    enc_pkt.data = NULL;
    enc_pkt.size = 0;
    av_init_packet(&enc_pkt);
    ret = enc_func(enc_ctx, &enc_pkt,
                   frame, got_frame);

    if (ret < 0)
        return ret;
    if (!(*got_frame))
        return 0;

    auto type = (int)enc_pkt.data[5];
    //new sequence or I frame
    if (scene_frame_count > 10 && ( type == SPS_HEADER || type == I_FRAME_HEADER)) {
        scene_frame_count = 0;
        scene = true;
    } else
        scene = false;

    scene_frame_count++;

    return ret;
}

int DR::DetectReader::output_encode_frame(AVFrame *frame, AVCodecContext *enc_ctx, int *got_frame) {
    int ret;
    int got_frame_local;
    AVPacket enc_pkt = {};
    auto auto_packet = pkt_ptr(&enc_pkt, av_packet_unref);
    int (*enc_func)(AVCodecContext *, AVPacket *, const AVFrame *, int *) =
    (ifmt_ctx_->streams[video_stream_idx]->codecpar->codec_type ==
     AVMEDIA_TYPE_VIDEO) ? avcodec_encode_video2 : avcodec_encode_audio2;

    if (!got_frame)
        got_frame = &got_frame_local;

    /* encode filtered frame */
    enc_pkt.data = NULL;
    enc_pkt.size = 0;
    av_init_packet(&enc_pkt);

    frame->pts = output_count;
    ret = enc_func(enc_ctx, &enc_pkt, frame, got_frame);

    if (ret < 0)
        return ret;
    if (!(*got_frame))
        return 0;

    enc_pkt.duration = 1;
    enc_pkt.pts = enc_pkt.dts;
    enc_pkt.stream_index = 0;
    av_packet_rescale_ts(&enc_pkt,
                         output_enc_ctx->time_base,
                         output_fmt_ctx->streams[0]->time_base);

    av_log(NULL, AV_LOG_DEBUG, "Muxing frame\n");
    /* mux encoded frame */
    ret = av_interleaved_write_frame(output_fmt_ctx, &enc_pkt);

    output_count++;
    return ret;
}

void DR::DetectReader::get_roi_rect(cv::Mat &mv_mat, cv::Rect &rect) {
    switch (mv_roi_) {
        case MV_ROI_WHOLE:
            rect = cv::Rect(0 ,0, mv_mat.cols, mv_mat.rows);
            break;
        case MV_ROI_CENTRAL:
            rect = cv::Rect(mv_mat.cols/4, mv_mat.rows/4, mv_mat.cols/2, mv_mat.rows/2);
            break;
        case MV_ROI_HORIZONTAL:
            rect = cv::Rect(0, mv_mat.rows/4, mv_mat.cols, mv_mat.rows/2);
            break;
        case MV_ROI_VERTICAL:
            rect = cv::Rect(mv_mat.cols/3, 0, mv_mat.cols/3, mv_mat.rows);
            break;
        default:
            rect = cv::Rect(0 ,0, mv_mat.cols, mv_mat.rows);
    }
}

bool DR::DetectReader::std_dev_condition(cv::Mat &mv_mat) {
#define STD_DEV_BUFFER_LEN (30 * 120)
#define STD_DEV_QUEUE_LEN (90)
#define LATEST_FRAME_LEN (10)

    static bool last_status = false;
    bool ret = true;
    Rect roi;
    get_roi_rect(mv_mat, roi);

    Mat temp = mv_mat(roi);
    Mat mean_mat, stddev_mat;
    meanStdDev(temp, mean_mat, stddev_mat);

    double current_stddev = stddev_mat.at<double>(0, 0);
    stddev_stat.push_back(current_stddev);
    if (stddev_stat.size() > STD_DEV_BUFFER_LEN){
        stddev_stat.pop_front();
    }

    double sum = accumulate(stddev_stat.begin(), stddev_stat.end(), 0.0);
    double mean =  sum / stddev_stat.size();
    //cout << "mean:" << mean << " stddev" << stddev_mat;

    double accum  = 0.0;
    std::for_each (stddev_stat.begin(), stddev_stat.end(), [&](const double d) {
        accum  += (d - mean) * (d - mean);
    });

    double stddev = sqrt(accum/stddev_stat.size());
    stddev_queue.push_back(current_stddev);
    if (stddev_queue.size() > STD_DEV_QUEUE_LEN)
        stddev_queue.pop_front();

    int index = 0;
    double long_stddev_sum = 0;
    double short_stddev_sum = 0;
    if (stddev_queue.size() == STD_DEV_QUEUE_LEN) {
        for(auto &it : stddev_queue) {
            long_stddev_sum += it;
            if (index >= STD_DEV_QUEUE_LEN - LATEST_FRAME_LEN) {
                short_stddev_sum += it;
            }
            index++;
        }

        long_stddev_sum /= stddev_queue.size();
        short_stddev_sum /= LATEST_FRAME_LEN;
    } else {
        long_stddev_sum = short_stddev_sum = current_stddev;
    }

    double status_weight = last_status ? 0.8 : 1.0;
    stddev = stddev < 1.0 ? 2.0 : stddev;
    if (short_stddev_sum > 0.8 * mean)
        ret = true;
    else if (long_stddev_sum < (status_weight / stddev + 0.2) * mean)
        ret = false;

    //cout << short_stddev_sum << " " << long_stddev_sum << " " << stddev << endl;
    last_status = ret;
    return ret;
}

template<class T>
inline const T& clip( const T& v, const T& min, const T& max) {
    return std::min(std::max(v, min), max);
}

void DR::DetectReader::process_mv(AVFrame *frame, double &avg_mv){
    int i;
    AVFrameSideData *sd;
    sd = av_frame_get_side_data(frame, AV_FRAME_DATA_MOTION_VECTORS);
    double weight_table[10] = {1, 1, 3, 3, 3, 3, 3, 3, 1, 1};

    if (sd) {
        auto *mvs = (const AVMotionVector *)sd->data;
        cv::Mat mv_mat = cv::Mat::zeros(height_, width_, CV_16UC1);

        for (i = 0; i < sd->size / sizeof(*mvs); i++) {
            const AVMotionVector *mv = &mvs[i];

            int dx = (mv->dst_x-mv->src_x) * 1;
            int dy = (mv->dst_y-mv->src_y) * 1;
            double rad = sqrt(dx*dx + dy*dy);

            if (rad > 0) {
                int x_start = clip(mv->src_x - mv->w/2, 0, width_);
                int y_start = clip(mv->src_y - mv->h/2, 0, height_);
                int x_end = clip(mv->src_x + mv->w/2, 0, width_);
                int y_end = clip(mv->src_y + mv->h/2, 0, height_);

                for (int j = y_start; j < y_end; j++) {
                    auto weight_index = int(floor(10 * (double)j/height_));
                    double weight = weight_table[weight_index];
                    auto *data = mv_mat.ptr<ushort>(j);
                    for (int i = x_start; i < x_end; i++) {
                        data[i] = (ushort) (rad * weight);
                    }
                }
            }
        }

        if (motion_detect_on_)
            is_motion_frame_ = std_dev_condition(mv_mat);

        Mat mean_mat, stddev_mat;
        meanStdDev(mv_mat, mean_mat, stddev_mat);
        avg_mv = mean_mat.at<double>(0, 0);
    }
}

//解码得到图像的同时，可以得到帧对用的pts(play timestamp)，推流的时候按解码的pts推流，以保证推流的流畅
bool DR::DetectReader::read(cv::Mat& mat, int64_t *pts) {
    if (!is_open_)
        return false;

    int (*dec_func)(AVCodecContext *, AVFrame *, int *, const AVPacket *);
    enum AVMediaType type;
    using deleter = std::function<void (AVFrame**)>;

    static int cooldown = 0;
    int got_frame;
    int ret;
    AVPacket raw_pkt{};

    AVCodecContext *video_dec_ctx = ifmt_ctx_->streams[video_stream_idx]->codec;
    type = ifmt_ctx_->streams[video_stream_idx]->codecpar->codec_type;
    dec_func = (type == AVMEDIA_TYPE_VIDEO) ? avcodec_decode_video2 :
               avcodec_decode_audio4;

    //如果mat是空的，则分配空间
    if (mat.empty())
        mat.create(video_dec_ctx->height,video_dec_ctx->width,CV_8UC3);

    while (true) {
        //判断av_read_frame是否超时
        check_time = time(NULL);
        //packet采用unique_ptr自动调用av_packet_unref释放空间
        auto packet = pkt_ptr(&raw_pkt, av_packet_unref);
        if ((ret = av_read_frame(ifmt_ctx_, &raw_pkt)) < 0) {
            //视频流断了，或者读取到文件结尾
            av_log(NULL, AV_LOG_INFO, "av_read_frame error, %s\n", av_err2str(ret).c_str());
            break;
        }

        //如果packet不是video数据，则跳过
        if (video_stream_idx != raw_pkt.stream_index)
            continue;

        //解码必须从一个key frame开始，避免解码得到错误的帧
        if (raw_pkt.flags == 1) {
            get_first_key_frame = true;
        }

        if (!get_first_key_frame)
            continue;

//        av_packet_rescale_ts(packet.get(),
//                             ifmt_ctx_->streams[video_stream_idx]->time_base,
//                             stream_ctx_->dec_ctx->time_base);

        ret = dec_func(stream_ctx_->dec_ctx, raw_frame, &got_frame, packet.get());

        if (ret < 0) {
            av_log(NULL, AV_LOG_ERROR, "Decoding failed\n");
            return false;
        }

        //如果解码得到一帧
        if (got_frame) {
            double avg_mv;
            if (shot_dectect_on_ || motion_detect_on_)
                process_mv(raw_frame, avg_mv);

            raw_frame->key_frame = 0;
            raw_frame->pict_type = AV_PICTURE_TYPE_NONE;
            if(pts)
                *pts = raw_frame->pkt_pts;

            //yuv转rgb
            sws_scale(rgb_convert_ctx, (const uint8_t* const*)raw_frame->data, raw_frame->linesize, 0,
                      video_dec_ctx->height, pRGBFrame->data, pRGBFrame->linesize);
            uchar2Mat(pRGBFrame->data[0], pRGBFrame->width, pRGBFrame->height, mat);

            is_scene_frame_ = false;
            if (shot_dectect_on_) {
                bool scene = false;
                bool smooth_scene = false;

                sws_scale(yuv_convert_ctx, (const uint8_t* const*)raw_frame->data, raw_frame->linesize, 0,
                          video_dec_ctx->height, pScaleFrame->data, pScaleFrame->linesize);
                ret = encode_frame(pScaleFrame, stream_ctx_->enc_ctx, nullptr, scene_frame_count, scene);

                avgmv_queue.push_back(avg_mv);
                if (avgmv_queue.size() > 5)
                    avgmv_queue.pop_front();

                double sum = accumulate(avgmv_queue.begin(), avgmv_queue.end(), 0.0);
                double mean =  sum / avgmv_queue.size();

                if (frame_num % 10 == 0)
                    av_frame_copy(pScaleFrame_smooth, pScaleFrame);

                ret = encode_frame(pScaleFrame_smooth, stream_ctx_->enc_ctx1, nullptr, scene_frame_count1, smooth_scene);

                if (scene && avg_mv < 5.)
                    is_scene_frame_ = true;

                if (cooldown <= 0 && smooth_scene && (mean < 3. || avg_mv < 5.))
                    is_scene_frame_ = true;

                if (is_scene_frame_)
                    cooldown = 30;

                cooldown--;

                if (!output_name.empty()) {
                    if (is_scene_frame_) {
                        av_write_trailer(output_fmt_ctx);

                        avcodec_free_context(&output_enc_ctx);

                        if (output_fmt_ctx && !(output_fmt_ctx->oformat->flags & AVFMT_NOFILE))
                            avio_closep(&output_fmt_ctx->pb);
                        avformat_free_context(output_fmt_ctx);

                        open_output_file(&output_fmt_ctx, &output_enc_ctx, output_name.c_str());

                        output_count = 0;
                    }

                    output_encode_frame(raw_frame, output_enc_ctx, nullptr);
                }

                /*
                std::stringstream ss;
                ss << frame_num << " " << scene << " " << smooth_scene << " " << cooldown << " " << (is_scene_frame_? 1 : 0) << " " << (float)mean;
                cv::putText(mat, ss.str(), cv::Point(10, 30), cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0, 0, 255), 2);
                */
            }

            frame_num++;
            return true;
        }

    }

    //利用空的packet，让解码器flush缓冲的帧
    AVPacket empty_pkt{};
    dec_func(stream_ctx_->dec_ctx, raw_frame, &got_frame, &empty_pkt);
    if (got_frame) {
        if(pts)
            *pts = raw_frame->pkt_pts;

        sws_scale(rgb_convert_ctx, (const uint8_t *const *) raw_frame->data, raw_frame->linesize, 0,
                  video_dec_ctx->height, pRGBFrame->data, pRGBFrame->linesize);

        uchar2Mat(pRGBFrame->data[0], pRGBFrame->width, pRGBFrame->height, mat);

        return true;
    }
    else
        return false;

}

}
