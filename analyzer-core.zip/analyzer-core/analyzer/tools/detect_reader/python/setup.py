from setuptools import setup, Extension
from Cython.Distutils import build_ext
import numpy
import os

libdr = ['/usr/local/lib', '/usr/local/ffmpeg/lib']
incdr = [numpy.get_include(), '/usr/local/include/', 'dr/']

# choose g++ version support c++11
# os.environ["CC"] = "g++-8"
# os.environ["CXX"] = "g++-8"

ext = [
    Extension('dr.cvt', ['dr/cvt.pyx'],
        language = 'c++',
        extra_compile_args = ['-std=c++11'],
        include_dirs = incdr,
        library_dirs = libdr,
        libraries = ['opencv_core']),
    Extension('dr.libdr', ['dr/dr.pyx', '../src/dr.cpp', '../src/detect_reader.cpp'],
        language = 'c++',
        extra_compile_args = ['-std=c++11'],
        include_dirs = incdr,
        library_dirs = libdr,
        libraries = ['opencv_core', 'opencv_imgproc', 'avformat', 'avcodec', 'avutil', 'swscale'])
]

setup(
    name = 'dr',
    version="1.0",
    description="Read frame from a video file with shot and motion detection",
    author="Zhu Liang",
    author_email="zhuliang@qiniu.com",
    packages=['dr'],
    cmdclass = {'build_ext':build_ext},
    ext_modules = ext
)
