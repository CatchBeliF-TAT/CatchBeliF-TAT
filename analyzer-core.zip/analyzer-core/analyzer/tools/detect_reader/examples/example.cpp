#include <iostream>
#include <chrono>
#include "../src/dr.hpp"

using namespace ATVIDEO;
using namespace cv;

int main(int argc, char* argv[]) {
    if (argc != 2 && argc != 3) {
        std::cout << "Usage: example <input file> [<output file>]" << std::endl;
        return 0;
    }

    DR reader(true, false);

    if (!reader.open(argv[1]))
        return 0;

    if (argc == 3 && !reader.open_output(argv[2]))
        return 0;

    cv::Mat mat;
    cv::namedWindow("1");
    reader.set_mv_roi(MV_ROI_WHOLE);

    std::chrono::steady_clock::time_point t1 = std::chrono::steady_clock::now();

    int frame = 0;
    while(true) {
        if (!reader.read(mat))
            break;
        bool shot = reader.shot();
        std::cout << "Processing Frame# " << frame++ << std::endl;
        imshow("1", mat);
        waitKey(1);
    }

    std::chrono::steady_clock::time_point t2 = std::chrono::steady_clock::now();
    std::chrono::duration<double> time_used = std::chrono::duration_cast<std::chrono::duration<double>>(t2 - t1);
    std::cout << "用时：" << time_used.count() << " 秒。" << std::endl;
}
