#include "analyzer_server.hpp"
#include "analyzer.h"

#include <google/protobuf/util/json_util.h>

namespace analyzer_grpc {

Analyzer::Analyzer() {
}

Analyzer::~Analyzer() {
    if (engine_) {
        flow_release(&engine_);
    }
}

grpc::Status Analyzer::Operation(grpc::ServerContext *context,
                const inference::Config *request,
                inference::Response *response) {
    int code=-1;
    std::string request_str;
    google::protobuf::util::JsonPrintOptions options;
    options.preserve_proto_field_names = true;
    google::protobuf::util::MessageToJsonString(*request, &request_str, options);
    auto task = request->task();
    try
    {
    if (task == "InitEngine") {
        if (engine_ != nullptr) {
            response->set_message("InitEngine Failed!");
        } else {
            flow_create(&engine_, request_str.data(), request_str.size(), &code);
        }
    } else if (task == "AddStream") {
        flow_add_stream(engine_, request_str.data(), request_str.size(), &code);
    } else if (task == "StopStream") {
        flow_stop_stream(engine_, request_str.data(), request_str.size(), &code);
    } else if (task == "AddPushStream") {
        flow_add_push_stream(engine_, request_str.data(), request_str.size(), &code);
    } else if (task == "StopPushStream") {
        flow_stop_push_stream(engine_, request_str.data(), request_str.size(), &code);
    } else if (task == "AddViolation") {
        flow_add_violation(engine_, request_str.data(), request_str.size(), &code);
    } else if (task == "AddStreamToTask") {
        flow_add_stream_2_task(engine_, request_str.data(), request_str.size(), &code);
    } else if (task == "RemoveViolation") {
        flow_remove_violation(engine_, request_str.data(), request_str.size(), &code);
    }else if (task == "Metrics"){
        flow_msg* buffer=nullptr;
        flow_msg_create(&buffer);
        std::shared_ptr<flow_msg> _buffer_deleter(buffer, flow_msg_release);
        flow_get_metrics(engine_, buffer, &code);
        if (code == flow_status_ok) {
            int data_length=0;
            const void * data=nullptr;
            flow_msg_size(buffer, &data_length);
            flow_msg_data(buffer, &data);
            std::string output(static_cast<const char*>(data), data_length);
            response->set_result(output);
        }else{
            response->set_message("Metrics Failed!");
        }
    } else if (task == "GetStreamStatus") {
        flow_msg* buffer=nullptr;
        flow_msg_create(&buffer);
        std::shared_ptr<flow_msg> _buffer_deleter(buffer, flow_msg_release);
        flow_get_stream_status(engine_, buffer, &code);
        if (code == flow_status_ok) {
            int data_length=0;
            const void * data=nullptr;
            flow_msg_size(buffer, &data_length);
            flow_msg_data(buffer, &data);
            std::string status(static_cast<const char*>(data), data_length);
            response->set_result(status);
        }
        else {
            response->set_message("GetStreamStatus Failed!");
        }
    } else {
        response->set_message("Unknown task: " + task);
    }

    response->set_code(code);
    if (code == flow_status_ok) {
        response->set_message("Success");
    }
    }
    catch(const std::exception& e)
    {
        std::cerr << "Exception: " << e.what() << '\n';
        exit(1);
    }
    return grpc::Status::OK;
}

grpc::Status Analyzer::Inference(::grpc::ServerContext* context, 
                        const ::inference::InferenceArgs* request, 
                        ::inference::Response* response) {
    int code=-1;
    try
    {
        flow_msg* buffer=nullptr;
        flow_msg_create(&buffer);
        std::shared_ptr<flow_msg> _buffer_deleter(buffer, flow_msg_release);
        flow_image_process(engine_,
            request->image_data().data(), request->image_data().size(),
            request->args().data(), request->args().size(),
            buffer, &code);
        if (code == flow_status_ok) {
            int data_length=0;
            const void * data=nullptr;
            flow_msg_size(buffer, &data_length);
            flow_msg_data(buffer, &data);
            std::string result(static_cast<const char*>(data), data_length);
            response->set_result(result);
            response->set_code(0);
            response->set_message("ok");
        }
    }
    catch(const std::exception& e)
    {
        std::cerr << "Exception: " << e.what() << '\n';
        exit(1);
    }
    return grpc::Status::OK;
}

grpc::Status Analyzer::OnMessage(::grpc::ServerContext* context,
                        const ::inference::MessageReq* request,
                        ::grpc::ServerWriter< ::inference::Message>* writer) {
    int code=-1;
    struct _UserData{
        ::grpc::ServerContext* context;
        ::grpc::ServerWriter< ::inference::Message>* writer;
    };
    auto userData = _UserData{context, writer};
    auto call_back_fn = [](void* user_data, const void* data, const int size)->int {
        auto socket = static_cast<_UserData*>(user_data);
        if (socket && socket->context && socket->writer) {
            ::inference::Message event;
            event.set_content(data, size);
            event.set_content_length(std::to_string(size));
            event.set_content_type("protobuf");
            if (socket->writer->Write(event)) {
                return flow_status_ok;
            }
            socket->context->TryCancel();
        }
        return flow_status_failed_unknown;
    };
    flow_add_event_callback(engine_, call_back_fn, &userData, &code);
    while(!context->IsCancelled()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    return grpc::Status::OK;

}

} // namespace analyzer_grpc
