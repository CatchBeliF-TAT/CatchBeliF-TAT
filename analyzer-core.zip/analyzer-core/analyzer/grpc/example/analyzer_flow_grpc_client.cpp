#include <grpc++/grpc++.h>
#include <google/protobuf/util/json_util.h>

#include "service.grpc.pb.h"

#include "common/json.hpp"
#include "common/util.hpp"

#include <memory>

using namespace FLOW;

class Client {
 public:
  explicit Client(const std::shared_ptr<grpc::Channel> &channel)
      : stub_(inference::Inference::NewStub(channel)) {}

  void Request(const inference::Config &config) {
    inference::Response response;

    grpc::ClientContext context;
    const auto &status = stub_->Operation(&context, config, &response);
    CHECK(status.ok());

    LOG(INFO) << "Response code: " << response.code()
              << ", message: " << response.message()
              << ", result: " << response.result();
  }
  void OnMessage() {
    inference::Response response;

    grpc::ClientContext context;
    ::inference::MessageReq request;
    const auto reader = stub_->OnMessage(&context, request);

    int count =0;
    ::inference::Message msg;
    while (reader->Read(&msg)) {
      std::string msg_str;
      google::protobuf::util::JsonPrintOptions options;
      options.preserve_proto_field_names = true;
      google::protobuf::util::MessageToJsonString(msg, &msg_str, options);
      LOG(INFO) << count++ << " : "<< msg_str;
      msg.Clear();
    }
  }

 private:
  std::unique_ptr<inference::Inference::Stub> stub_;
};

std::vector<std::string> parse_violations(const std::string &config) {
  std::vector<std::string> retv;
  auto doc = get_document(config);
  const auto &value = get_value(doc, "violations");
  if (value.IsArray()) {
    const auto &violations = value.GetArray();
    for (int i = 0; i < violations.Size(); i++) {
      rapidjson::StringBuffer s;
      rapidjson::Writer<rapidjson::StringBuffer> writer(s);
      violations[i].Accept(writer);
      retv.push_back(s.GetString());
    }
  }
  return retv;
}

int main(int argc, char const *argv[]) {
  // engine_config: "config/config_v1.2.json"
  // stream_id: "eee"
  // stream_url:
  // "/home/atlab/Workspace/zzj/Alg-VideoAlgorithm/project/tad/xuhuivideo/test/test/01A2P000.mp4"
  // violation_type: "100"
  // violation_config: "config/test_shixianbiandao.json"
  // zmq_endpoint: "tcp://localhost:5555"

  if (argc < 3) {
    LOG(INFO) << "Usage: test_analyzer_client server_address task_name ... ";
    return 0;
  }

  std::string server_address(argv[1]), task(argv[2]);

  auto channel =
      grpc::CreateChannel(server_address, grpc::InsecureChannelCredentials());

  Client client(channel);

  inference::Config config;
  inference::Response response;

  if (task == "InitEngine") {
    std::string engine_config(argv[3]);
    if (argc == 5) {
      if ( Path(engine_config).is_file()) {
        engine_config = Util::read_text_from_file(engine_config);
      }
      config.Clear();
      config.set_task(task);
      config.set_engine_config(engine_config);
      config.set_zmq_endpoint(argv[4]);
      client.Request(config);
    } else {
      LOG(INFO) << "Usage: test_analyzer_client server_address InitEngine "
                   "engine_config zmq_endpoint";
    }
  } else if (task == "AddStream" || task == "AddPushStream") {
    if (argc == 5) {
      config.Clear();
      config.set_task(task);
      config.set_stream_id(argv[3]);
      config.set_stream_url(argv[4]);
      client.Request(config);
    } else {
      LOG(INFO) << "Usage: test_analyzer_client server_address " << task
                << " stream_id stream_url";
    }
  } else if (task == "StopStream" || task == "StopPushStream") {
    if (argc == 4) {
      config.Clear();
      config.set_task(task);
      config.set_stream_id(argv[3]);
      client.Request(config);
    } else {
      LOG(INFO) << "Usage: test_analyzer_client server_address " << task
                << " stream_id";
    }
  } else if (task == "AddViolation") {
    if (argc == 6) {
      config.Clear();
      config.set_task(task);
      config.set_stream_id(argv[3]);
      config.set_violation_type(argv[4]);
      const auto &violations = Util::read_text_from_file(argv[5]);
      for (const auto &violation : parse_violations(violations)) {
        config.set_violation_config(violation);
        client.Request(config);
      }
    } else {
      LOG(INFO) << "Usage: test_analyzer_client server_address AddViolation "
                   "stream_id violation_type violation_config";
    }
  } else if (task == "RemoveViolation") {
    if (argc == 5) {
      config.Clear();
      config.set_task(task);
      config.set_stream_id(argv[3]);
      config.set_violation_type(argv[4]);
      client.Request(config);
    } else {
      LOG(INFO) << "Usage: test_analyzer_client server_address RemoveViolation "
                   "stream_id violation_type";
    }
  } else if (task == "AddViolationNoParse") {
    if (argc == 6) {
      config.Clear();
      config.set_task("AddViolation");
      config.set_stream_id(argv[3]);
      config.set_violation_type(argv[4]);
      config.set_violation_config(Util::read_text_from_file(argv[5]));
      client.Request(config);
    } else {
      LOG(INFO) << "Usage: test_analyzer_client server_address AddViolationNoParse "
                   "stream_id violation_type violation_config";
    }
  } else if (task == "AddStreamToTask") {
    if (argc == 5) {
      config.Clear();
      config.set_task(task);
      config.set_task_id(argv[3]);
      config.set_stream_id(argv[4]);
      client.Request(config);
    } else {
      LOG(INFO) << "Usage: test_analyzer_client server_address AddStreamToTask "
                   "taks_id stream_id";
    }
  } else if (task == "GetStreamStatus") {
    if (argc == 3) {
      config.Clear();
      config.set_task(task);
      client.Request(config);
    } else {
      LOG(INFO) << "Usage: test_analyzer_client server_address GetStreamStatus";
    }
  } else if (task == "OnMessage") {
    if (argc == 3) {
      client.OnMessage();
    } else {
      LOG(INFO) << "Usage: test_analyzer_client server_address OnMessage";
    }
  } else {
    LOG(INFO) << "Unknown task " << task;
  }

  return 0;
}
