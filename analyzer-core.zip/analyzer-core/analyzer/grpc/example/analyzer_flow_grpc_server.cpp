#include "analyzer_server.hpp"
#include "common/log.hpp"

using namespace analyzer_grpc;
using namespace FLOW;

int main(int argc, char const* argv[]) {
  if (argc < 2) {
    LOG(INFO) << "Usage: test_analyzer_server server_address";
    return 0;
  }

  std::string server_address(argv[1]);

  Analyzer service;

  grpc::ServerBuilder builder;
  builder.SetMaxReceiveMessageSize(10 * 1024 * 1024);
  builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
  builder.RegisterService(&service);
  std::shared_ptr<grpc::Server> server(builder.BuildAndStart());

  LOG(INFO) << "Server listening on " << server_address;

  server->Wait();

  return 0;
}
