#ifndef ANALYZER_ANALYZER_HPP
#define ANALYZER_ANALYZER_HPP

#include <future>
#include <memory>
#include <thread>
#include <grpc++/grpc++.h>

#include "service.grpc.pb.h"

namespace analyzer_grpc{

class Analyzer final : public inference::Inference::Service {
public:
    Analyzer();
    ~Analyzer();

    grpc::Status Operation(grpc::ServerContext *context,
                            const inference::Config *request,
                            inference::Response *response) override;

    grpc::Status Inference(::grpc::ServerContext* context, 
                            const ::inference::InferenceArgs* request, 
                            ::inference::Response* response) override;
    grpc::Status OnMessage(::grpc::ServerContext* context,
                            const ::inference::MessageReq* request,
                            ::grpc::ServerWriter< ::inference::Message>* writer) override;

protected:
    void* engine_ = nullptr;
};
} // namspace analyzer_grpc

#endif  // ANALYZER_ANALYZER_HPP
