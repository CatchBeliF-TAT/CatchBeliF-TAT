#include "metric.hpp"
#include "prometheus/text_serializer.h"
#include "prometheus/metric_family.h"

#include <vector>
#include <string>


namespace FLOW {

  using namespace prometheus;

  Metric& Metric::Instance() {
    static Metric instance_;
    return instance_;
  }

  Metric::Metric() {
    registry = std::make_shared<Registry>();
  
    std::vector<detail::CKMSQuantiles::Quantile> quantiles;
    quantiles.push_back(detail::CKMSQuantiles::Quantile{0.9,0.05});
    quantiles.push_back(detail::CKMSQuantiles::Quantile{0.5,0.05});
    // decoder & encoder
    decode_stream_count                 = &BuildGauge().Name("decode_stream_count").Help("decode stream count").Labels({{"scope", "decoder"}}).Register(*registry).Add({});
    encode_stream_count                 = &BuildGauge().Name("encode_stream_count").Help("encode stream count").Labels({{"scope", "encoder"}}).Register(*registry).Add({});
    decode_frame_count                  = &BuildCounter().Name("decode_frame_count").Help("decode frame count").Labels({{"scope", "decoder"}}).Register(*registry);
    encode_frame_count                  = &BuildCounter().Name("encode_frame_count").Help("encode frame count").Labels({{"scope", "encoder"}}).Register(*registry);
    decode_delay_frame_count            = &BuildCounter().Name("decode_delay_frame_count").Help("decode delay frame count").Labels({{"scope", "decoder"}}).Register(*registry);
    //dsp
    dsp_video_memory_total_used_        = &BuildGauge().Name("vedio_memory_total_used").Help("").Labels({{"type", "dsp_video_mem"}}).Register(*registry).Add({{"unit", "MB"}});
    dsp_delay_time_for_each_channel_    = &BuildGauge().Name("delay_time_for_each_channel").Help("").Labels({{"type", "dsp_delay_time"}}).Register(*registry);
    dsp_batch_size_for_singleton_model_ = &BuildGauge().Name("batch_size_for_singleton_model").Help("").Labels({{"type", "dsp_batch_size_singleton"}}).Register(*registry);
    dsp_batch_size_for_each_channel_    = &BuildGauge().Name("batch_size_for_each_channel").Help("").Labels({{"type", "dsp_batch_size"}}).Register(*registry);
    dsp_total_input_for_each_channel_   = &BuildCounter().Name("input_for_each_channel").Help("").Labels({{"type", "dsp_input"}}).Register(*registry);
    dsp_total_output_for_each_channel_  = &BuildCounter().Name("output_for_each_channel").Help("").Labels({{"type", "dsp_output"}}).Register(*registry);
    //profile
    profile_seconds_total               = &BuildCounter().Name("profile_seconds_total").Help("").Labels({{"scope", "profile"}}).Register(*registry);
    profile_count_total                 = &BuildCounter().Name("profile_count_total"  ).Help("").Labels({{"scope", "profile"}}).Register(*registry);
    profile_summary                     = &BuildSummary().Name("profile_summary"      ).Help("").Labels({{"scope", "profile"}}).Register(*registry);
    object_counter                      = &BuildCounter().Name("object_count_total"   ).Help("").Labels({{"scope", "profile"}}).Register(*registry);
    // event processer
    event_counter                      = &BuildCounter().Name("event_count"          ).Help("").Labels({{"scope", "event_processer"}}).Register(*registry);
    // engine counter
    algorithm_req_count                 = &BuildCounter().Name("algorithm_req_count" ).Help("").Labels({{"scope", "algorithm"}}).Register(*registry);
    algorithm_resp_count                = &BuildCounter().Name("algorithm_resp_count").Help("").Labels({{"scope", "algorithm"}}).Register(*registry);
  }  


  std::string Metric::Output() {
    TextSerializer ser;
    std::vector<MetricFamily> v = registry->Collect();
    std::string str = ser.Serialize(v);
    return str;
    // LOG(INFO) << str;
    //return const_cast<char *>(str.c_str());
  }

}