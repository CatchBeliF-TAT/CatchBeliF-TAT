#include "analyzer.h"

#include <string>

#include "common/pbjson.hpp"
#include "serving/input_arguments.pb.h"
#include "serving/violation_event.pb.h"
#include "flow_engine.hpp"
#include "analyzer/config.h"

using namespace FLOW;
using namespace std;

struct flow_msg{
    std::string data;
 };

void flow_version(int *major, int *minor, int *patch) {
    *major = PROJECT_VER_MAJOR;
    *minor = PROJECT_VER_MINOR;
    *patch = PTOJECT_VER_PATCH;
}

void flow_create(void **ctx, const void *params, const int params_size, int *code) {
    LOG(INFO) << PTOJECT_GIT_INFO;
    const string request(static_cast<const char*>(params), params_size);
    inference::InptArguments request_pb;
    string err;
    *code = json2pb(request, &request_pb, &err);
    if (*code != flow_status_ok) {
        *code = flow_status_argument_parse_error;
        return;
    }

    CFlowEngine* engine = new CFlowEngine(request_pb.engine_config());
    *code = engine->Init();
    if (*code == flow_status_ok) {
        *ctx = engine;
    } else {
        *ctx = nullptr;
    }
}

void flow_add_stream(void *ctx, const void *params, const int params_size, int *code) {
    CFlowEngine *engine = reinterpret_cast<CFlowEngine *>(ctx);

    const string request(static_cast<const char*>(params), params_size);
    inference::InptArguments request_pb;
    string err;
    *code = json2pb(request, &request_pb, &err);
    if (*code != flow_status_ok) {
        *code = flow_status_argument_parse_error;
        return;
    }

    *code = engine->AddStream(request_pb.stream_url(), request_pb.stream_id(), request_pb.engine_config());
    return;
}

void flow_add_push_stream(void *ctx, const void *params, const int params_size, int *code) {
    CFlowEngine *engine = reinterpret_cast<CFlowEngine *>(ctx);
    const string request(static_cast<const char*>(params), params_size);
    inference::InptArguments request_pb;
    string err;
    *code = json2pb(request, &request_pb, &err);
    if (*code != flow_status_ok) {
        *code = flow_status_argument_parse_error;
        return;
    }
    
    *code = engine->AddPushStream(request_pb.stream_url(), request_pb.stream_id());
    return;
}

void flow_stop_stream(void *ctx, const void *params, const int params_size, int *code) {
    CFlowEngine *engine = reinterpret_cast<CFlowEngine *>(ctx);
    const string request(static_cast<const char*>(params), params_size);
    inference::InptArguments request_pb;
    string err;
    *code = json2pb(request, &request_pb, &err);
    if (*code != flow_status_ok) {
        *code = flow_status_argument_parse_error;
        return;
    }
    
    *code = engine->StopStream(request_pb.stream_id());
    return;
}

void flow_stop_push_stream(void *ctx, const void *params, const int params_size, int *code) {
    CFlowEngine *engine = reinterpret_cast<CFlowEngine *>(ctx);
    const string request(static_cast<const char*>(params), params_size);
    inference::InptArguments request_pb;
    string err;
    *code = json2pb(request, &request_pb, &err);
    if (*code != flow_status_ok) {
        *code = flow_status_argument_parse_error;
        return;
    }
    
    *code = engine->StopPushStream(request_pb.stream_id());
    return;
}

void flow_get_stream_status(void *ctx, struct flow_msg *buffer, int *code) {
    CFlowEngine *engine = reinterpret_cast<CFlowEngine *>(ctx);
    std::string status;
    if (nullptr == buffer) {
        *code = flow_status_out_of_buffer;
    } else {
        engine->GetStatus(status);
        buffer->data = status;
        *code = flow_status_ok;
    }
    return;
}

void flow_add_violation(void *ctx, const void *params, const int params_size, int *code) {
    CFlowEngine *engine = reinterpret_cast<CFlowEngine *>(ctx);
    const string request(static_cast<const char*>(params), params_size);
    inference::InptArguments request_pb;
    string err;
    *code = json2pb(request, &request_pb, &err);
    if (*code != flow_status_ok) {
        *code = flow_status_argument_parse_error;
        return;
    }
    std::string status;
    *code = engine->AddViolation(request_pb.stream_id(),
                                request_pb.violation_type(),
                                request_pb.violation_config());
    return;
}

void flow_remove_violation(void *ctx, const void *params, const int params_size, int *code) {
    CFlowEngine *engine = reinterpret_cast<CFlowEngine *>(ctx);
    const string request(static_cast<const char*>(params), params_size);
    inference::InptArguments request_pb;
    string err;
    *code = json2pb(request, &request_pb, &err);
    if (*code != flow_status_ok) {
        *code = flow_status_argument_parse_error;
        return;
    }
    std::string status;
    *code = engine->RemoveViolation(request_pb.stream_id(), request_pb.violation_type());
    return;

}

void flow_add_stream_2_task(void *ctx, const void *params, const int params_size, int *code) {
    CFlowEngine *engine = reinterpret_cast<CFlowEngine *>(ctx);
    const string request(static_cast<const char*>(params), params_size);
    inference::InptArguments request_pb;
    string err;
    *code = json2pb(request, &request_pb, &err);
    if (*code != flow_status_ok) {
        *code = flow_status_argument_parse_error;
        return;
    }
    *code = engine->AddStreamToTask(request_pb.task_id(), request_pb.stream_id());
    return;
}

void flow_add_event_callback(void *ctx, flow_event_callback fn, void *user_data, int *code) {
    CFlowEngine *engine = reinterpret_cast<CFlowEngine *>(ctx);
    auto call_with_proto = [fn, user_data](const spEventProto event)->int{
            const auto data = event->SerializeAsString();
            return fn(user_data, data.data(), data.size());
        };

    *code = engine->AddViolationEventCallBack(call_with_proto);
    return;

}

void flow_image_process(void *ctx, const void *image, const int image_size,
                                    const void *params, const int params_size,
                                    struct flow_msg *buffer, int *code) {
    CFlowEngine *engine = reinterpret_cast<CFlowEngine *>(ctx);
    const string image_data(static_cast<const char*>(image), image_size);
    const string request(static_cast<const char*>(params), params_size);
    inference::PictureReqList request_pb;
    inference::PictureRespList response_pb;
    string err;
    *code = json2pb(request, &request_pb, &err);
    if (*code != flow_status_ok){
        *code = flow_status_argument_parse_error;
        return;
    }
    *code = engine->ProcessPicture(image_data, request_pb, &response_pb);
    if (*code != flow_status_ok){
        return;
    }
    if (nullptr == buffer) {
        *code = flow_status_out_of_buffer;
        return;
    } 
    std::string output;
    pb2json(&response_pb, &output);
    buffer->data = output;
    return;
}

void flow_release(void **ctx) {
    CFlowEngine *engine = reinterpret_cast<CFlowEngine *>(*ctx);
    delete engine;
    *ctx = nullptr;
}

void flow_get_metrics(void *ctx, struct flow_msg *buffer, int *code){
    CFlowEngine *engine = reinterpret_cast<CFlowEngine *>(ctx);
    std::string output;
    if (nullptr == buffer) {
        *code = flow_status_out_of_buffer;
    } else {
        engine->GetMetricsOutput(output);
        buffer->data = output;
        *code = flow_status_ok;
    }
    return;
}


void flow_msg_create(flow_msg **msg) {
    if (*msg != nullptr) {
        delete *msg;
    }
    *msg = new flow_msg();
}

void flow_msg_release(flow_msg *msg) {
    if (msg != nullptr) {
        delete msg;
    }
}

void flow_msg_size(const flow_msg *msg, int *size) {
    *size = msg->data.size();
}

void flow_msg_data (const flow_msg *msg, const void **data) {
    *data = msg->data.data();
}
