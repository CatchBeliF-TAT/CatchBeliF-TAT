#include "flow_engine.hpp"

#include <regex>

#include "json_helper.hpp"
#include "metric.hpp"
#include "common/log.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "stream/stream_manager.hpp"
#include "violation/violation_manager.hpp"
#include "violation/violation_event.hpp"
#include "alg_engine/alg_engine_factory.hpp"
#include "algorithm/plate/vehicle_plate.hpp"
#include "algorithm/algorithm_factory.hpp"
#include "serving/violation_event.pb.h"

using namespace std;

namespace FLOW {

    CFlowEngine::CFlowEngine(const string &config)
        : config_str_(config)
        , config_([config](){ inference::AnalyzerConfig cfg; std::string err; auto code = json2pb(config, &cfg, &err); LOG_IF(FATAL, code!=0); return cfg; }())
        , algorithm_map_(CreateAlgorithm(config_.engine_config().algorithms()))
        , stream_manager_(make_shared<CStreamManager>(config_.stream_config()))
        , alg_engine_vector_(CreateEngines(config_.general_config().tad_type()))
        , alg_engine_map_(CreateEngineMap(config_.general_config().tad_type(), alg_engine_vector_))
        , violation_evenv_manager_(make_shared<ViolationEventProcesser>(
                alg_engine_vector_.empty() ? nullptr : alg_engine_vector_.front(),
                config_.stream_config().has_video_record_dir() ? stream_manager_ : nullptr,
                config_.general_config().event_processor_thread())) // TODO, need fix
        , violation_manager_(make_shared<CViolationManager>(wpViolationEventProcesser(violation_evenv_manager_), config))
        , exit_(false)
        , call_back_thread_exit_(false)
        , dsp(config_.general_config().dsp_print_log_interval())
    {
        if (config_.general_config().has_dsp_max_block_interval()) {
            dsp.set_max_block_time(config_.general_config().dsp_max_block_interval());
        }
        if (config_.general_config().has_dsp_print_error_log_path()) {
            dsp.set_block_crash_logfile_path(config_.general_config().dsp_print_error_log_path());
        }
    }

    CFlowEngine::~CFlowEngine() {
        exit_.store(true);
        call_back_thread_exit_.store(true);
        if (process_thread_.joinable()) {
            process_thread_.join();
        }
        if (call_back_thread_.joinable()) {
            call_back_thread_.join();
        }
    }

    int CFlowEngine::Init() {
        for(auto alg_engine : alg_engine_vector_) {
            int code=0;
            alg_engine->Init(config_.engine_config(), code);
            if (code != module_status_success) {
                return code;
            }
        }

        stream_manager_->setEncodeGpuOn(config_.stream_config().encode_gpu_on());
        stream_manager_->setEncodeQP(config_.stream_config().encode_quality_qp());

        process_thread_ = std::thread([this](){
            SET_THREAD_NAME(std::string("PROCESS_MAIN"));
            while (1) {
                if (exit_.load()) {
                    break;
                }
                this->Process();
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }
        });
        
        return 0;
    }

    int CFlowEngine::AddStream(const string &url, const string &channel_id, const string &config) {
        LOG(INFO) << "AddStream " << url << " channel id: " << channel_id;
        auto stream_config = config_.stream_config();
        {
            std::string parse_error;
            inference::StreamConfig cfg;
            json2pb(config, &cfg, &parse_error);
            if (!parse_error.empty()) {
                LOG(WARNING) << "AddStream parse config error, err:" << parse_error << " json: " << config;
            }
            // merge config
            stream_config.MergeFrom(cfg);
        }

        if (stream_config.device_input() && !alg_engine_vector_.empty()) {
            const std::vector<int> inputShapes = alg_engine_vector_.front()->GetDetectInputShapes();
            stream_config.clear_detect_input_shapes();
            std::copy(inputShapes.begin(), inputShapes.end(), 
                        google::protobuf::RepeatedFieldBackInserter(stream_config.mutable_detect_input_shapes()));
        }
        int ret = stream_manager_->AddStream(url, channel_id, stream_config);
        if (ret == 0){
            std::unique_lock<std::mutex> lock{lock_};
            if (!dsp.get_node(channel_id, "in")) {
                auto chin = dsp.add_node(channel_id, "in", config_.general_config().in_node_queue_size());
                auto chout = dsp.add_node(channel_id, "out", config_.general_config().out_node_queue_size());
                chin->task(false);
                auto channel = stream_manager_->GetChannel(channel_id);
                chout->process([this, channel, channel_id](VecImage& in) {
                    if (in.size() == 0) return;
                    violation_manager_->Process(in);
                    stream_manager_->PushFramesWithRenders(in, channel);
                    in.clear();
                });
                dsp.root()->next(chin);
                chin->next(chout);
            }
            for(auto alg_engine: alg_engine_vector_) {
                alg_engine->AddStream(channel_id, config);
            }
        }

        return ret;
    }

    int CFlowEngine::AddPushStream(const string &url, const string &channel_id) {
        int ret;
        ret = stream_manager_->AddPushStream(url, channel_id, 0,
                                config_.stream_config().output_stream_size(),
                                config_.stream_config().fps());
        return ret;
    }

    int CFlowEngine::StopStream(const string &channel_id) {
        LOG(INFO) << "StopStream channel id: " << channel_id;
        {
            std::unique_lock<std::mutex> lock{lock_};
            channel_task_map_.erase(channel_id);
        }
        int ret = stream_manager_->StopStream(channel_id);
        for(auto alg_engine : alg_engine_vector_) {
            alg_engine->RemoveStream(channel_id);
        }

        { 
            std::unique_lock<std::mutex> lock{lock_};
            dsp.remove_channel(channel_id);
        }
        violation_manager_->RemoveViolationAll(channel_id);

        channel_violation_map_.erase(channel_id);
        return ret;
    }

    int CFlowEngine::StopPushStream(const string &channel_id) {
        LOG(INFO) << "StopPushStream channel id: " << channel_id;

        int ret = stream_manager_->StopPushStream(channel_id);
        return ret;
    }

    void CFlowEngine::GetStatus(string &status_json) {
        std::map<string, int> status;
        stream_manager_->GetStatus(status);

        status_json = stream_status_json(status);
    }

    void CFlowEngine::GetMetricsOutput(string &output) {
        output =  Metric::Instance().Output();
    }

    void CFlowEngine::Process() {
        std::unique_lock<std::mutex> lock{lock_};
        bool push_data = false;
        auto root = dsp.root();
        int remainCapOfNode;
        int numOfFailedPush = 0; //root节点在本轮push失败的次数，只要能push下去一个就算成功
        for (auto &nx: root->next()) {
            remainCapOfNode = nx->remainCap(root.get());
            if (remainCapOfNode == 0) {
                numOfFailedPush++;
                continue;
            }
            auto pQueue = stream_manager_->GetFrameQueue(nx->channel());
            if (!pQueue) {
                LOG(INFO) << "FLOW: not queue for stream " << nx->channel();
                continue;
            }
            root->in().clear();
            while (!pQueue->empty() && root->in().size() < remainCapOfNode) {
                auto frame = pQueue->pop();
                if (frame.channel_id.empty()) continue;
                if (frame.sframe == nullptr) continue;

                auto newImage = std::make_shared<ImageObjectsInfo>();
                newImage->channel_id  = frame.channel_id;
                newImage->sframe      = frame.sframe;
                newImage->ptz_pos     = frame.location;
                newImage->pts         = frame.pts;
                newImage->count       = frame.count;
                newImage->ntp_time_stamp    = frame.ntp_time_stamp;
                newImage->time_interval     = frame.time_interval;
                newImage->pts_interval      = frame.pts_interval;
                newImage->jitter_status     = frame.jitter_status;
                root->in().push_back(newImage);
            }
            if(root->in().size()<remainCapOfNode){
                nx->block_by_root(true);
            }else{
                nx->block_by_root(false);
            }
            if (root->in().empty()) continue;
            //LOG(INFO)<< "push image: "<< root->in().back()->count;
            root->ts(root->in().back()->count);
            nx->update_input_count(root->count());
            root->push(nx);
            push_data = true;
        }
        if(root->test_root_fail(numOfFailedPush)){
            if(root->inc_wait()){
                if(!root->finish_print_topo()){
                    std::stringstream dsp_log;
                    dsp_log<<"DSP: root block"<<'\n';
                    dsp.print_topo_root(true, dsp_log);
                    LOG(WARNING)<<dsp_log.str();
                    root->finish_print_topo(true);
                }
            }
        }
        for(int i=0; i<alg_engine_vector_.size(); i++) {
            alg_engine_vector_[i]->Process(dsp);
        }
        dsp.dispatch();

        if (!push_data) usleep(5);
    }

    int CFlowEngine::AddViolation(const string &channel_id, const std::string& violation_id, const std::string& cfg){
        std::unique_lock<std::mutex> lock{lock_};

        auto config = get_document(cfg);
        auto fps = get_float(config, "fps", config_.stream_config().fps());
        auto violation_code = get_string(config, "code", "0");
        auto enable_renader = get_bool(config, "render", true);
        channel_fps_map_[channel_id][violation_id] = fps;
        auto max_fps = 0.0f;
        for (auto& kv : channel_fps_map_[channel_id]){
            if (kv.second > max_fps) max_fps = kv.second;
        }

        size_t index=0;
        VecAlgRender renders;
        stream_manager_->GetVecAlgRender(channel_id, &renders);
        renders.resize(alg_engine_vector_.size());
        channel_violation_map_[channel_id].resize(alg_engine_vector_.size());
        for(auto alg_engine : alg_engine_vector_) {
            stream_manager_->SetStreamFps(channel_id, max_fps);
            alg_engine->AddViolation(channel_id, violation_id, cfg);
            alg_engine->AddViolation2(channel_id, violation_id, cfg, dsp);
            auto render = alg_engine->GetRender(violation_code);
            if (enable_renader && render != nullptr) {
                renders[index] = render;
                channel_violation_map_[channel_id][index][violation_id] = true;
            }
            index++;
        }
        stream_manager_->SetVecAlgRender(channel_id, renders);

        for (auto& iter : channel_task_map_) {
            if (iter.second == channel_id) {
                for(auto alg_engine : alg_engine_vector_) {
                    stream_manager_->SetStreamFps(iter.first, max_fps);
                    alg_engine->AddViolation(iter.first, violation_id, cfg);
                    alg_engine->AddViolation2(iter.first, violation_id, cfg, dsp);
                }
            }
        }
        return violation_manager_->AddViolation(channel_id, violation_id, cfg);
    }

    int CFlowEngine::AddStreamToTask(const std::string &task_id, const std::string& channel_id) {
        std::unique_lock<std::mutex> lock{lock_};
        channel_task_map_[channel_id] = task_id;
        return violation_manager_->AddStreamToTask(task_id, channel_id);
    }

    int CFlowEngine::RemoveViolation(const std::string &channel_id, const std::string& violation_id){
        std::unique_lock<std::mutex> lock{lock_};

        channel_fps_map_[channel_id].erase(violation_id);
        auto max_fps = 0.0f;
        for (auto& kv : channel_fps_map_[channel_id]){
            if (kv.second > max_fps) max_fps = kv.second;
        }
        if (channel_fps_map_[channel_id].empty()) {
            channel_fps_map_.erase(channel_id);
        }

        VecAlgRender renders;
        stream_manager_->GetVecAlgRender(channel_id, &renders);
        renders.resize(alg_engine_vector_.size());
        if (channel_violation_map_.count(channel_id) > 0){
            for (size_t i = 0; i < channel_violation_map_[channel_id].size(); i++) {
                channel_violation_map_[channel_id][i].erase(violation_id);
                if (channel_violation_map_[channel_id][i].empty()) {
                    renders[i] = nullptr;
                }
            }
        }
        stream_manager_->SetVecAlgRender(channel_id, renders);
        
        for(auto alg_engine : alg_engine_vector_) {
            stream_manager_->SetStreamFps(channel_id, max_fps);
            alg_engine->RemoveViolation(channel_id, violation_id);
            alg_engine->RemoveViolation2(channel_id, violation_id, dsp);
        }
        for (auto& iter : channel_task_map_) {
            if (iter.second == channel_id) {
                for(auto alg_engine : alg_engine_vector_) {
                    stream_manager_->SetStreamFps(iter.first, max_fps);
                    alg_engine->RemoveViolation(iter.first, violation_id);
                    alg_engine->RemoveViolation2(iter.first, violation_id, dsp);
                }
            }
        }
        return violation_manager_->RemoveViolation(channel_id, violation_id);
    }

    int CFlowEngine::GetViolationEvnet(spEventProto *event){
        return violation_evenv_manager_->Pop(-1, *event);
    }
    
    int CFlowEngine::AddViolationEventCallBack(std::function<int(const spEventProto)> callback) {
        std::unique_lock<std::mutex> lock{lock_};
        if (call_back_thread_.joinable()) {
            call_back_thread_exit_.store(true);
            call_back_thread_.join();
            call_back_thread_exit_.store(false);
            call_back_thread_ = std::thread();
        }
        if (!call_back_thread_.joinable()) {
            call_back_thread_ = std::thread([this, callback](){
                SET_THREAD_NAME(std::string("CALLBACK_MAIN"));
                while(1) {
                    if (exit_.load()) {
                        break;
                    }
                    if (call_back_thread_exit_.load()) {
                        break;
                    }
                    spEventProto event;
                    auto ok  = this->violation_evenv_manager_->Pop(-1, event);
                    if (!ok) {
                        std::this_thread::sleep_for(std::chrono::milliseconds(10));
                    } else {
                        const int MAX_DEBUG_MESSAGE_LEN = 5120;
                        std::string evnetLog;
                        pb2json_option option;
                        option.ignore_bytes = true;
                        option.large_obj_array_limit = 5;
                        pb2json_with_option(option, event.get(), &evnetLog);
                        if (evnetLog.length() > MAX_DEBUG_MESSAGE_LEN) {
                            evnetLog = "Event: " +
                                        evnetLog.substr(0,MAX_DEBUG_MESSAGE_LEN) +
                                        "<..." + std::to_string(evnetLog.length()-MAX_DEBUG_MESSAGE_LEN) + "...>";
                        }
                        LOG(INFO) << "==>" << evnetLog;

                        auto retv = callback(event);
                        if (0 != retv) {
                            return;
                        }
                    }
                }
            });
            return 0;
        } else {
            return 1;
        }
    }

    int CFlowEngine::ProcessPicture(const std::string &image_data,
                        const inference::PictureReqList& args,
                        inference::PictureRespList* resps) {
        std::vector<unsigned char> vectordata(image_data.begin(),image_data.end());
        const auto image_mat = std::make_shared<cv::Mat>(cv::imdecode(vectordata, 1));
        std::vector<std::promise<void>> vec_barrier;
        resps->mutable_resps()->Clear();
        for(const auto& req : args.reqs()) {
            inference::PictureResp* resp = resps->mutable_resps()->Add();
            const std::regex split("/");
            std::vector<std::string> paths(std::sregex_token_iterator(req.operation().begin(), req.operation().end(), split, -1),
                                                std::sregex_token_iterator());
            if (paths.size() >= 2 && alg_engine_map_.count(paths[0])) {
                VecBoxF boxes;
                if (req.has_rect()) {
                    boxes.push_back(BoxF(req.rect().x(), req.rect().y(), req.rect().x()+req.rect().w(), req.rect().y()+req.rect().h()));
                } else {
                    boxes.push_back(BoxF(0, 0, image_mat->cols, image_mat->rows));
                }
                boxes.front().label=OBJECT_TYPE_VEHICLE;
                alg_engine_map_[paths[0]]->ProcessByName(paths[1], std::make_shared<ShellFrame>(image_mat), boxes);
                // process boxes
                if (!boxes.empty() && !boxes.front().plates.empty()) {
                    const auto& plate = boxes.front().plates.front();
                    auto x_pair = std::minmax_element(plate.points.begin(),plate.points.end(),
                        [](const PlateInfo<float>::PointT& p1, const PlateInfo<float>::PointT& p2){
                            return p1.x < p2.x;
                        });
                    auto y_pair = std::minmax_element(plate.points.begin(),plate.points.end(),
                        [](const PlateInfo<float>::PointT& p1, const PlateInfo<float>::PointT& p2){
                            return p1.y < p2.y;
                        });
                    resp->mutable_label()->Add(Plate::helperGetStringPlateType(plate.label));
                    resp->mutable_content()->Add()->assign(plate.content);
                    resp->mutable_score()->Add(plate.score);
                    auto rect = resp->mutable_object()->Add();
                    rect->set_x(x_pair.first->x);
                    rect->set_y(y_pair.first->y);
                    rect->set_w(x_pair.second->x - x_pair.first->x);
                    rect->set_h(y_pair.second->y - y_pair.first->y);
                }
                resp->set_code(200);
            } else if (paths.size() == 1) {
                vec_barrier.push_back(std::move(std::promise<void>()));
                auto& barrier = vec_barrier.back();
                auto done = [&barrier](){ barrier.set_value(); };
                if (0 == algorithm_map_.count(req.operation())) {
                    resp->set_code(404);
                    resp->set_msg("service not found");
                    done();
                    continue;
                }
                auto handler = std::dynamic_pointer_cast<flow_process_inference>(algorithm_map_[req.operation()]);
                if (handler == nullptr) {
                    resp->set_code(403);
                    resp->set_msg("bad service");
                    done();
                    continue;
                }
                handler->inference(*image_mat, req, resp, done);
            } else {
                resp->set_code(404);
                resp->set_msg("service not found");
            }
            LOG(INFO) << "ProcessPicture code:" << resp->code();
        }

        for (auto itr=vec_barrier.rbegin(); itr!=vec_barrier.rend(); itr++) {
            itr->get_future().wait();
        }
        
        return 0;
    }

}
