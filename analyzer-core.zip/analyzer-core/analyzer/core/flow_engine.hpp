#ifndef VSS_VSS_ENGINE_HPP
#define VSS_VSS_ENGINE_HPP

#include <string>
#include <thread>
#include <memory>
#include <unordered_map>
#include <mutex>
#include <list>
#include <vector>
#include <map>

#include "common/util.hpp"
#include "flow_dispatch.hpp"

#include "serving/config.pb.h"
#include "serving/input_arguments.pb.h"

namespace inference{
    class Event;
}

namespace FLOW {
    class flow_process_base;
    typedef std::shared_ptr<flow_process_base> sp_flow_process_base;
    typedef std::map<std::string, sp_flow_process_base> map_process_base;
    
    class ICAlgEngine;
    typedef std::shared_ptr<ICAlgEngine> spICAlgEngine;
    typedef std::vector<spICAlgEngine> VecICAlgEngine;
    typedef std::map<std::string, spICAlgEngine> MapICAlgEngine;

    typedef struct ImageObjectsInfo_ ImageObjectsInfo;
    typedef std::shared_ptr<ImageObjectsInfo> spImageObjectsInfo;
    typedef std::list<spImageObjectsInfo> ImageQueue;
    typedef std::shared_ptr<ImageQueue> spImageQueue;
    typedef std::vector<spImageQueue> VecImageQueue;

    class CStreamManager;
    typedef std::shared_ptr<CStreamManager> spCStreamManager;
    class ViolationEventProcesser;
    typedef std::shared_ptr<ViolationEventProcesser> spViolationEventProcesser;
    class CViolationManager;
    typedef std::shared_ptr<CViolationManager> spCViolationManager;
    typedef std::shared_ptr<inference::Event> spEventProto;

    class CFlowEngine {
    public:
        explicit CFlowEngine(const std::string &config);

        ~CFlowEngine();

    public:
        int Init();

        int AddStream(const std::string &url, const std::string &channel_id, const std::string &config);

        int AddPushStream(const std::string &url, const std::string &channel_id);

        int AddViolation(const std::string &channel_id, const std::string& violation_id, const std::string& cfg);

        int AddStreamToTask(const std::string &task_id, const std::string& channel_id);

        int RemoveViolation(const std::string &channel_id, const std::string& violation_id);

        int StopStream(const std::string &channel_id);

        int StopPushStream(const std::string &channel_id);

        void GetStatus(std::string &status);

        void GetMetricsOutput(std::string &output);

        void Process();

        int GetViolationEvnet(spEventProto *event);
        
        int AddViolationEventCallBack(std::function<int(const spEventProto)> callback);

        int ProcessPicture(const std::string &image_data,
                            const inference::PictureReqList& args,
                            inference::PictureRespList* resps);
    public:
        inference::AnalyzerConfig config_;
        std::string config_str_;
        std::unordered_map<std::string, std::vector<std::unordered_map<std::string, bool>>> channel_violation_map_;

    private:
        map_process_base algorithm_map_;
        spCStreamManager stream_manager_;
        VecICAlgEngine   alg_engine_vector_;
        MapICAlgEngine   alg_engine_map_;
        spViolationEventProcesser violation_evenv_manager_;
        spCViolationManager violation_manager_;
        std::atomic<bool> exit_;
        std::thread process_thread_;
        std::atomic<bool> call_back_thread_exit_;
        std::thread call_back_thread_;
        std::unordered_map<std::string, std::string> channel_task_map_;
        std::unordered_map<std::string, std::unordered_map<std::string, float>> channel_fps_map_;
        std::mutex lock_;

        CFlowDispatch dsp;
    };
}

#endif //VSS_VSS_ENGINE_HPP
