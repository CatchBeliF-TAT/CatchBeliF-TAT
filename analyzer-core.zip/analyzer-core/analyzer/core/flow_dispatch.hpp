#ifndef TAD_ALG_FLOW_DISPATCH_HPP
#define TAD_ALG_FLOW_DISPATCH_HPP

#include <atomic>
#include <vector>
#include <set>
#include <functional>
#include <chrono>
#include <iostream>
#include <string>
#include <algorithm>
#include <list>
#include <future>
#include <unordered_map>
#include <fstream>

#include "common/log.hpp"
#include "common/tad_internal.hpp"
#include "common/ThreadPool.h"

#include "metric.hpp"

namespace FLOW {
    class CFlowDispatch {
    public:
        typedef std::function<void(VecImage&)> ExecFunc;
        typedef std::function<VecImage(VecImage&)> SkipFunc;

    private:
        class model {
        public:
            mutable  std::mutex lock_;
            VecImage images_;    // protected by lock_
            ExecFunc f_;
            SkipFunc sf_;
            bool     running_;   // still consuming images in queue
            bool     singleton_; // inherit node
            uint64_t hi_;        // higest position
            std::atomic<uint64_t> low_;       // up to this position
            std::atomic<int> times_;
            uint64_t         last_at_ = 0;
            int              last_times_ = 0;
            // don't lock in non-singleton mode
            #define LOCK() \
                std::unique_lock<std::mutex> lock{}; \
                if (singleton_) lock = std::unique_lock<std::mutex>(lock_); 

            void pop(VecImage& out) {
                LOCK();
                if (!images_.empty()) {
                    out.insert(out.end(), images_.begin(), images_.end());
                    images_.clear();
                }
            }

            float get_avg_batch_size(){
                uint64_t tmp_at_    = low_.load();
                int      tmp_times_ = times_.load();
                if(tmp_times_==last_times_){
                    return 0.0;
                }
                float result = (float)(tmp_at_-last_at_)/(float)(tmp_times_-last_times_);
                last_at_ = tmp_at_;
                last_times_ = tmp_times_;
                return result;
            }

        public:
            model(ExecFunc f, bool s) :f_(f), running_(false), singleton_(s), hi_(0), low_(0), times_(0){}

            void f(ExecFunc fun) { this->f_ = fun; }
            void sf(SkipFunc fun) { this->sf_ = fun; }

            ExecFunc f() { return this->f_; }
            SkipFunc sf() {return this->sf_;}
            uint64_t at() { return low_.load(); }

            bool run_self() {
                LOCK();
                if (running_) return false;
                running_ = true;
                return true;
            }
            uint64_t size() {
                LOCK();
                return images_.size();
            }

            uint64_t push(VecImage& in) {
                LOCK();
                if (in.size()) images_.insert(images_.end(), in.begin(), in.end());
                hi_ += in.size();
                return hi_;
            }

            void run() {
                VecImage input;
                while (true) {
                    this->pop(input);
                    int oldsize = input.size();
                    if (oldsize) (f_)(input);    // no output for singleton now

                    {
                        LOCK();
                        times_.fetch_add(1);
                        low_.fetch_add(oldsize - input.size());
                        if (!input.empty() || !images_.empty()) continue;
                        running_ = false;
                        break;
                    }
                }
            }
        };
        typedef std::shared_ptr<model> spModel;

    public:
        class node;
        typedef std::shared_ptr<node> spNode;

        class node {
            friend CFlowDispatch;
        public:
            enum {
                ST_BEGIN          = 0, // wait for run, no image in wait queue
                ST_PROCESSING     = 1, // image in wait queue is running
                ST_PROCESSED      = 2, // image in wait queue is waiting to pass to the next nodes
                ST_ROOT_BLOCK     = 3, // 突然涌入大量image在root节点处堆积
           };
        private:
            struct TsQueue {
                uint64_t ts;
                VecImage q;
                TsQueue(): ts(0) {}
            };
            typedef std::unordered_map<node*, TsQueue> MTsQueue;

            std::string      channel_; // channel id
            std::string      name_;    // name, map key
            bool             task_;    // thread pool or local thread processing
            uint64_t         at_;      // position at model run queue
            int              stat_;    // process step control
            MTsQueue         parent_;  // parents input
            TsQueue          in_;      // input for execution
            std::set<spNode> next_;    // next steps
            spModel          model_;   // execution entity
            bool             print_topo_; //print topo only once if wait for more than 8s.
                                          // if printed in this round, print_topo_ is true.
            uint64_t         model_at_ = 0;
            int              times_ = 0;    
            std::chrono::time_point<std::chrono::system_clock> begin_time_ = std::chrono::system_clock::now();         

            static std::unordered_map<std::string,spModel>& n2m() {     // for batching, for example, model inference
                static std::unordered_map<std::string,spModel> name2models_;
                return name2models_;
            }

            node(const std::string &channel, const std::string &name, int size, bool singleton = false) : 
                channel_(channel), name_(name), size_(size), task_(true), at_(0), model_(nullptr), print_topo_(false){
                    stat_ = ST_BEGIN;
                    if (!singleton) {
                        model_ = std::make_shared<model>([](VecImage& in){ in.clear(); }, singleton);
                    } else if (n2m().find(name_) == n2m().end()) {
                        model_ = std::make_shared<model>([](VecImage& in){ in.clear(); }, singleton);
                        n2m()[name_] = model_;
                    } else {
                        model_ = n2m()[name_];
                    }
                }
        protected:
            int               size_;    // queue size
        public:
            std::string&      channel()           { return channel_;                     }
            std::string&      name()              { return name_;                        }
            node*             task(bool b)        { task_ = b; return this;              }
            bool              task()              { return task_;                        }
            uint64_t          ts()                { return in_.ts;                          }
            node*             ts(uint64_t b)      { in_.ts = b; return this;                }
            std::set<spNode>& next()              { return next_;                        }
            bool              full(node* p)       { return (in_.q.size() + parent_[p].q.size()) >= 2*size_; }
            VecImage&         in()                { return in_.q;                          }
            node*             stat(int st)        { stat_ = st; return this;             }
            int               stat()              { return stat_;                        }
            node*             process(ExecFunc e) { model_->f(e); return this;           }
            node*             setSkipFunc(SkipFunc e) {model_->sf(e); return this;}
            int               remainCap(node* p)  { return 2*size_ - (int)(in_.q.size()) - (int)(parent_[p].q.size());}
            bool&             finish_print_topo() { return print_topo_;}
            node*             finish_print_topo(bool p) {print_topo_ = p; return this;}
            spModel&          getModel()               {return model_;}
            bool              empty()             { return in_.q.empty();             }
            uint64_t          count()             {return (uint64_t)(in_.q.back()->count);}
            virtual node*     clear()             { in_.q.clear();   return this;     }
            virtual node*     update_input_count(uint64_t i)  { return this;}
            virtual void      block_by_root(bool b)  {}
            virtual void      update_metric_info(bool print, std::ostream& dsp_log)    {}

            static std::string get_useless_label_for_prometheus_debug() {
                static std::atomic<int> value(0);
                std::stringstream ss;
                ss<<value.fetch_add(1);
                return ss.str();
            }
            void update_time(){
                begin_time_ = std::chrono::system_clock::now();
            }

            std::chrono::time_point<std::chrono::system_clock> get_begin_time(){
                return begin_time_;
            }

            bool push(const spNode &nx) {
                auto &meinnx = nx->parent_[this];
                int remainCapacity = nx->remainCap(this);
                if (meinnx.ts > this->ts()) return true;   // i am late
                for (auto &o: this->in_.q) {
                    if (o->count > meinnx.ts) {
                        if (remainCapacity<=0) return false;   // wait for next round
                        meinnx.q.push_back(o);
                        meinnx.ts = o->count;
                        remainCapacity--; 
                    }
                }
                meinnx.ts = this->ts();
                return true;
            }

            bool build_in() { // populate in_ and update each ts
                uint64_t last_ts = this->ts();

                uint64_t min_max_ts = std::numeric_limits<uint64_t>::max();
                for (auto &p: parent_) { 
                    auto &ts = p.second.ts;
                    if (ts <= this->ts()) return false;     // wait for new data
                    if (ts < min_max_ts) min_max_ts = ts;   // get minimal of max
                }
                if (min_max_ts == std::numeric_limits<uint64_t>::max()) return false; // no parent

                if((min_max_ts - this->ts()) > size_){
                    min_max_ts = this->ts() + size_;
                }
                std::set<spImageObjectsInfo> s;     // use set to remove duplicate
                for (auto &p: parent_) {
                    for (auto it = p.second.q.begin(); it != p.second.q.end();) {
                        if ((*it)->count > min_max_ts) break;
                        if ((*it)->count > this->ts()) s.insert(*it);
                        it = p.second.q.erase(it);
                    }
                }
                if(s.size()>size_){
                    LOG(INFO) << "wait queue overflow, s.size(): "<< s.size();
                }
                in_.q.insert(in_.q.end(), s.begin(), s.end());
                std::sort(in_.q.begin(), in_.q.end(), [] (const spImageObjectsInfo &l, const spImageObjectsInfo &r) {
                        return l->count < r->count ;
                    });
                
                this->ts(min_max_ts);
                return this->ts() != last_ts;    // really, always true
            }

            node* next(spNode nx) {
                std::queue<spNode> searchQueue;
                if(this==nx.get()){
                    LOG(FATAL) << "DSP: Do not connect the same node, node name:"<< this->name_<<", channel: "<<this->channel_;
                }
                searchQueue.push(nx);
                while(!searchQueue.empty()){
                    spNode node = searchQueue.front();
                    searchQueue.pop();
                    if(node.get()==this){
                        LOG(FATAL) << "DSP: Can not add this node in current topo, a cycle farmated, node name:"<< this->name_<<", channel: "<<this->channel_;
                    }
                    for (auto &son: node->next()){
                        searchQueue.push(son);
                    }
                }
                auto &tmp = nx->parent_[this];
                next_.insert(nx); 
                return this;  
            }

            node* nonext(const spNode &nx) {
                nx->parent_.erase(this);
                this->next_.erase(nx);
                return this;
            }

            node* nonext(const std::string &ch, const std::string &name) {
                for (auto &nx: this->next_) {
                    if (nx->channel() == ch && nx->name() == name) {
                        nx->parent_.erase(this);
                        this->next_.erase(nx);
                        break;
                    }
                }
                return this;
            }

            std::string str(std::chrono::time_point<std::chrono::system_clock> now, double& time) { 
                std::chrono::duration<double> diff = now - begin_time_;
                if(diff.count()>time){
                    time = diff.count();
                }
                std::string par = " [", ret = channel_ + ":" + name_ + " timestamp:" + std::to_string(ts()) + " state:" + std::to_string(stat())+ " last time:" + std::to_string(diff.count())
                    + " wait_queue:" + std::to_string(in_.q.size()) + " run_queue:" + std::to_string(model_->size());
                for (auto &p: parent_) par = par + " " + p.first->channel() + ":" + p.first->name()  + "->" + std::to_string(p.second.q.size())
                    + ", timestamp:" + std::to_string(p.second.ts);
                return "FLOW:" + ret + par + "]";
            }

            bool inc_wait(float max_block_time=5) {
                std::chrono::time_point<std::chrono::system_clock> now = std::chrono::system_clock::now();
                if (max_block_time >0 && std::chrono::duration_cast<std::chrono::seconds>(now - begin_time_).count() >= max_block_time) {
                    return true;
                }
                return false;
            }

            // push images and check if need to call engine (singleton mode, another is running on behalf)
            bool need_run() {
                if(model_->sf()){
                    VecImage queue = (model_->sf())(in_.q);
                    if(queue.empty()){
                        return false;
                    }else{
                        this->at_ = model_->push(queue);
                    }
                }else{
                    this->at_ = model_->push(in_.q);
                }
                return true;
            }

            bool if_not_run(){
                return model_->run_self() ? true : false;
            }

            void run() { // can be in thread
                model_->run();
            }

            bool test_done() {
                return model_->at() >= this->at_;
            }

            bool test_root_fail(int numOfFailedPush){ //测试root本轮是否成功,超过1/4的next节点push失败视作本轮操作失败
                if(2*numOfFailedPush > this->next().size()){
                    if(this->stat_ != ST_ROOT_BLOCK){
                        this->stat_ = ST_ROOT_BLOCK;
                        this->begin_time_ = std::chrono::system_clock::now();
                    }
                    return true;
                }else{
                    this->stat_ = ST_BEGIN;
                    this->print_topo_ = false;
                    return false;
                }
            }
        };  // node
        
        //add in_node, out_node support
        class in_node :public node{
            friend CFlowDispatch;
        private:
            in_node(const std::string &channel, const std::string &name, int size, bool singleton = false)
                :node(channel, name, size, singleton), in_(0){
                input_total_counter_ = &Metric::Instance().dsp_total_input_for_each_channel_->Add({{"channel", this->channel()},{"useless_label", get_useless_label_for_prometheus_debug()}});
            }

            uint64_t in_ = 0;
            uint64_t last_ = 0;
            bool block_by_root_ = false;
            prometheus::Counter *input_total_counter_;
            //std::chrono::time_point<std::chrono::system_clock> begin_ = std::chrono::system_clock::now();
            
        public:
            ~in_node(){
                Metric::Instance().dsp_total_input_for_each_channel_->Remove(input_total_counter_);
            }
            node* update_input_count(uint64_t i){
                in_ = i;
                return this;
            }

            void block_by_root(bool b)  {
                block_by_root_ = b;
            }

            void update_metric_info(bool print, std::ostream& dsp_log){
                if(print){
                    dsp_log<<"    in_node: total processed size is: "<<in_ - last_<<", block by root: "<<block_by_root_<<'\n';
                }
                input_total_counter_->Increment(double(in_ - last_));
                last_ = in_;
            }

            /*
            double get_fall_behind_size(){
                std::chrono::time_point<std::chrono::system_clock> now = std::chrono::system_clock::now();
                std::chrono::duration<double> diff = now - begin_;
                double calculate_in = (double)12.8*diff.count();
                return calculate_in - (double)in_;
            }*/
        };

        class out_node :public node{
            friend CFlowDispatch;
        private:
            out_node(const std::string &channel, const std::string &name, int size, bool singleton = false)
                :node(channel, name, size, singleton), out_(0){
                output_total_counter_ = &Metric::Instance().dsp_total_output_for_each_channel_->Add({{"channel", this->channel()},{"useless_label", get_useless_label_for_prometheus_debug()}});
            }
            uint64_t out_ = 0;
            uint64_t last_ = 0;
            prometheus::Counter *output_total_counter_;

        public:
            ~out_node(){
                Metric::Instance().dsp_total_output_for_each_channel_->Remove(output_total_counter_);
            }
            node* clear(){
                out_ = node::count();
                node::clear();
                return this;
            }
            void update_metric_info(bool print, std::ostream& dsp_log){
                if(print){
                    dsp_log <<"    out_node: total processed size is: "<<out_ - last_ <<'\n';
                }
                output_total_counter_->Increment(double(out_ - last_));
                last_ = out_;
            }
        };

    private:
        std::unordered_map<std::string, std::unordered_map<std::string, spNode> > ch2node_;
        ThreadPool task_pool_;
        spNode root_;
        //time for print batch size
        std::chrono::time_point<std::chrono::system_clock> time_ = std::chrono::system_clock::now();
        //time for calculete the time program run
        std::chrono::time_point<std::chrono::system_clock> program_begin_ = std::chrono::system_clock::now();
        int channel_size_ = 0;
        bool print_ = false;
        int time_interval_ = 4;
        float max_block_time_ = 20;
        std::string block_logfile_path_;


    public:
        void set_max_block_time(float value) {
            max_block_time_ = value;
        }
        void set_block_crash_logfile_path(std::string path) {
            block_logfile_path_ = path;
        }
        void set_debug_log_interval(int time){
            print_ = true;
            time_interval_ = time;
        }

        spNode root() { return this->root_; }

        spNode add_node(const std::string &ch, const std::string &name, int size, bool singleton = false) {
            spNode md;
            if(name=="in"){
                md = std::shared_ptr<node>(new in_node(ch, name, size, singleton));
            }else if(name=="out"){
                md = std::shared_ptr<node>(new out_node(ch, name, size, singleton));
            }else{
                md = std::shared_ptr<node>(new node(ch, name, size, singleton)); 
            }
            ch2node_[ch][md->name()] = md;
            return md;
        }

        spNode get_node(const std::string &ch, const std::string &name) { // can be null
            auto chit = ch2node_.find(ch);
            if (chit == ch2node_.end()) return spNode();
            auto chmd = chit->second.find(name);
            if (chmd == chit->second.end()) return spNode();
            return chmd->second;
        }

        void remove_node(spNode &md, bool print = true) {
            for (auto &nx: md->next()) nx->parent_.erase(md.get());
            for (auto &p: md->parent_) p.first->next().erase(md);

            auto chit = ch2node_.find(md->channel());
            if (chit == ch2node_.end()) return;
            auto chmd = chit->second.find(md->name());
            if (chmd == chit->second.end()) return;
            chit->second.erase(chmd);
            //to do
            //if(!md->getModel()->singleton_){
            //    Metric::Instance().dsp_batch_size_for_each_channel_->Remove(&Metric::Instance().dsp_batch_size_for_each_channel_->Add({{"channel_model",md->channel_+"_"+md->name_}}));
            //}
        }

        void remove_node(const std::string &ch, const std::string &name) {
            if (auto md = get_node(ch, name)) remove_node(md);
        }

        void remove_channel(const std::string &ch) {
            auto it = ch2node_.find(ch);
            if (it == ch2node_.end()) return;
            std::stringstream rm_ch_log;
            rm_ch_log<<"Remove channel: "<<ch<<", begin."<<'\n';
            print_topo_root(true, rm_ch_log);
            while (it->second.size()) {
                remove_node(it->second.begin()->second, false);
            }
            ch2node_.erase(ch);
            Metric::Instance().dsp_delay_time_for_each_channel_->Remove(&Metric::Instance().dsp_delay_time_for_each_channel_->Add({{"channel", ch}}));
            LOG(WARNING)<<rm_ch_log.str();
            
        }
        
        void print_topo(const spNode &md, int level, std::chrono::time_point<std::chrono::system_clock> now, double& time, std::ostream& dsp_log) {
            dsp_log << std::string(level * 4, ' ') << md->str(now, time) << '\n';
            for (auto &nx: md->next()) {
                print_topo(nx, level + 1, now, time, dsp_log);
            }
        }
        
        void find_largest_time(const spNode &md, std::chrono::time_point<std::chrono::system_clock> now, double& time) {
            std::chrono::time_point<std::chrono::system_clock> begin_time = md->get_begin_time();
            std::chrono::duration<double> diff = now - begin_time;
            if(diff.count()>time){
                time = diff.count();
            }
            for (auto &nx: md->next()) {
                find_largest_time(nx, now, time);
            }
        }

        void print_each_channel_input_output(bool print, std::ostream& dsp_log){

            for(auto &ch: ch2node_){
                if(print){
                    dsp_log << "channel: " << ch.first << '\n';
                }
                for (auto &m: ch.second){
                    m.second->update_metric_info(print,dsp_log);
                }
            }
        }

        void print_video_mem_size(bool print, std::ostream& dsp_log){
            double mem_size = (double)(ShellFrame::getValue().load()>>20);
            Metric::Instance().dsp_video_memory_total_used_->Set(mem_size);
            if(print){
                dsp_log <<"DSP: print video mem size:" << mem_size << " MB"<<'\n';
            }
        }

        void print_topo_root(bool print, std::ostream& dsp_log) {
            std::chrono::time_point<std::chrono::system_clock> now = std::chrono::system_clock::now();
            std::chrono::duration<double> diff = now - program_begin_;
            if(print){
                dsp_log << "DSP: Print topo begin!, program run time:" << std::to_string(diff.count())<<'\n';
                for (auto &nx: root_->next()) {
                    double time=0.0;
                    //print topo include find latgest time
                    print_topo(nx, 1, now, time, dsp_log);
                    Metric::Instance().dsp_delay_time_for_each_channel_->Add({{"channel", nx->channel()}}).Set(time);
                }
                dsp_log << "DSP: Print topo end!" << '\n';
            }else{
                for (auto &nx: root_->next()) {
                    double time=0.0;
                    find_largest_time(nx, now, time);
                    Metric::Instance().dsp_delay_time_for_each_channel_->Add({{"channel", nx->channel()}}).Set(time);
                }
            }
        }

        bool checknode(const spNode &md){
            if(md->stat() != node::ST_BEGIN){return false;}
            bool next_status  = true;
            for (auto next : md->next()){
                next_status = next_status && checknode(next);
                if (next_status == false) return next_status;
            }
            return next_status;
        }

        bool is_clear(){
            return checknode(root_);
        }

        //print batch size for all node
        void print_batch_size(bool print, std::ostream& dsp_log){
            if(print){
                dsp_log <<"DSP: print batch size for singleton model: "<<'\n';
                for(auto &e: node::n2m()){
                    float res = e.second->get_avg_batch_size();
                    dsp_log <<"model: "<<e.first<<", batch size: "<<res<<'\n';
                    Metric::Instance().dsp_batch_size_for_singleton_model_->Add({{"model", e.first}}).Set(res);
                }
                dsp_log <<"DSP: print batch size for non-singleton model: "<<'\n';
                for (auto &ch: ch2node_){
                    dsp_log << "channel: " << ch.first << '\n';
                    //m is pair<model_name, spNode>
                    for (auto &m: ch.second) {
                        if(!m.second->getModel()->singleton_){
                            float res = m.second->getModel()->get_avg_batch_size();
                            dsp_log <<"     model: "<< m.first <<", batch size: "<<res<<'\n';
                            Metric::Instance().dsp_batch_size_for_each_channel_->Add({{"channel_model",m.second->channel_+"_"+m.second->name_}}).Set(res);
                        }
                    }                    
                }
            }else{
                for(auto &e: node::n2m()){
                    Metric::Instance().dsp_batch_size_for_singleton_model_->Add({{"model", e.first}}).Set(e.second->get_avg_batch_size());
                }
                for (auto &ch: ch2node_){
                    //m is pair<model_name, spNode>
                    for (auto &m: ch.second) {
                        if(!m.second->getModel()->singleton_){
                            Metric::Instance().dsp_batch_size_for_each_channel_->Add({{"channel_model",m.second->channel_+"_"+m.second->name_}}).Set(m.second->getModel()->get_avg_batch_size());
                        }
                    }                    
                }
            }
        }

        void print_channel_size(bool print, std::ostream& dsp_log){
            if(!print){
                return;
            }
            dsp_log <<"DSP: print channel size: before: "<< channel_size_-1 <<", now: "<<ch2node_.size()-1 <<'\n';
            channel_size_ = ch2node_.size();
        }
    protected:
        CFlowDispatch(const CFlowDispatch&) = delete;
        CFlowDispatch& operator=(const CFlowDispatch&) = delete;

    public:
        explicit CFlowDispatch(const int print_time_interval=-1)
            : task_pool_(std::thread::hardware_concurrency(), "DSP_WORKER")
        {
            root_ = add_node("flow", "root", 16);
            if (print_time_interval > 0) {
                this->set_debug_log_interval(print_time_interval);
            }
        }

        ~CFlowDispatch() {}

        void dispatch() {
            std::chrono::time_point<std::chrono::system_clock> now = std::chrono::system_clock::now();
            std::chrono::duration<double> diff = now - time_;
            std::stringstream dsp_log;
            if (diff.count() >= (double)time_interval_) {
                if(print_){
                    dsp_log<<"DSP: print info begin, time interval: "<<diff.count()<<'\n';
                }
                print_channel_size(print_, dsp_log);
                print_video_mem_size(print_, dsp_log);
                print_batch_size(print_, dsp_log);
                print_each_channel_input_output(print_, dsp_log);
                print_topo_root(print_, dsp_log);
                time_ = now;
                if(print_){
                    dsp_log<<"DSP: print info end"<<'\n';
                    LOG(INFO)<<dsp_log.str();
                }
            }

            std::vector<spNode> nodes;
            for (auto &nx: root_->next()) nodes.push_back(nx);
            while (!nodes.empty()) {
                auto md = nodes.front();
                nodes.erase(nodes.begin());
                for (auto &nx: md->next()) nodes.push_back(nx);
                int st = md->stat();
                if (node::ST_PROCESSING == st) {
                    if ( md->test_done()) {
                            md->stat(node::ST_PROCESSED);
                            md->update_time();
                    } else if (md->if_not_run()) {
                            if (md->task()) {
                                this->task_pool_.enqueue([md] { md->run(); });
                            } else {
                                md->run();
                            }
                        }
                     else {
                        // nop
                    }
                }
                if (node::ST_PROCESSED == st) {
                    bool done = true;
                    for (auto &nx: md->next()) {
                        if (!md->push(nx)) done = false;
                    }

                    if (done) {
                        md->clear();
                        md->stat(node::ST_BEGIN);
                        md->update_time();
                        md->print_topo_ = false;
                    } else {
                        if (md->inc_wait()) {
                            if(!md->print_topo_){
                                std::stringstream dsp_topo_log;
                                dsp_topo_log<<md->channel()<<", "<<md->name()<<", block"<<'\n';
                                print_topo_root(true, dsp_topo_log);
                                LOG(WARNING)<<dsp_topo_log.str();
                                md->print_topo_ = true;
                            }
                        }
                    }
                } else if (node::ST_BEGIN == st) {
                    if (!md->build_in()) continue;  // make sure input ready
                    if ( md->empty()) continue; // no image in wait queue
                    if(!md->need_run()){
                        md->stat(node::ST_PROCESSED);
                        md->update_time();
                        continue;
                    }

                    md->stat(node::ST_PROCESSING);
                    md->update_time();
                    if (md->if_not_run()) {
                        if (md->task()) {
                            this->task_pool_.enqueue([md] { md->run(); });
                        } else {
                            md->run();
                        }
                    }
                }

                if(node::ST_PROCESSING == st){
                    if (max_block_time_>0) {
                        if (md->inc_wait(max_block_time_)) {
                            LOG(WARNING)<<"ERROR!!! OVER 20S!!!!!";
                            //print log
                            if (block_logfile_path_.size()) {
                                std::string time = std::to_string(now.time_since_epoch().count());
                                auto of = std::ofstream(block_logfile_path_+"/"+time+"_error.log");
                                print_topo_root(true, of);
                            } else {
                                print_topo_root(true, std::cout);
                            }
                            LOG(FATAL)<<("*****>> FATAL ERROR: RUNNING OVER 20S IN SOME ALGORITHM <<*****");
                        }
                    }
                }
            } 
        } // dispatch
    };//class CFlowDispatch
};

#endif
