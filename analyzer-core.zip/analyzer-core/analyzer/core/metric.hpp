#ifndef TAD_METRIC_HPP
#define TAD_METRIC_HPP

#include <chrono>
#include <sstream>

#include "prometheus/counter.h"
#include "prometheus/gauge.h"
#include "prometheus/summary.h"
#include "prometheus/histogram.h"
#include "prometheus/family.h"
#include "prometheus/registry.h"

namespace FLOW{
  class Metric {

  private :
    Metric();
    Metric(const Metric&)=delete;
    ~Metric() = default;

  public :
      static Metric& Instance();
      std::string Output();

  private :
    static Metric                           instance_;
    std::shared_ptr<prometheus::Registry>   registry;

  public :
    typedef prometheus::Gauge   Gauge;
    typedef prometheus::Counter Counter;
    typedef prometheus::Summary Summary;
    // decoder & encoder
    Gauge                                   *decode_stream_count;
    Gauge                                   *encode_stream_count;
    prometheus::Family<Counter>             *decode_frame_count;
    prometheus::Family<Counter>             *encode_frame_count;
    prometheus::Family<Counter>             *decode_delay_frame_count;
    //dsp
    prometheus::Gauge                       *dsp_video_memory_total_used_;
    prometheus::Family<Gauge>               *dsp_delay_time_for_each_channel_;
    prometheus::Family<Gauge>               *dsp_batch_size_for_singleton_model_;
    prometheus::Family<Gauge>               *dsp_batch_size_for_each_channel_;
    prometheus::Family<Counter>             *dsp_total_input_for_each_channel_;
    prometheus::Family<Counter>             *dsp_total_output_for_each_channel_;    
    // profile
    prometheus::Family<Counter>             *profile_seconds_total;  //运行总时间
    prometheus::Family<Counter>             *profile_count_total;    //运行次数
    prometheus::Family<Summary>             *profile_summary;        //运行时长统计
    prometheus::Family<Counter>             *object_counter;         //目标数统计
    // event processer
    prometheus::Family<Counter>             *event_counter;         //事件统计
      // engine counter
    prometheus::Family<Counter>             *algorithm_req_count;
    prometheus::Family<Counter>             *algorithm_resp_count;

  };

  class ProfileMetric{
  public:
    class Helper{
    public:
      Helper(ProfileMetric& metric)
        : metric_(metric)
        , start_(std::chrono::system_clock::now())
      {
      }
      ~Helper() {
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> diff = end - start_;
        metric_.count_total_->Increment();
        metric_.seconds_total_->Increment(diff.count());
        metric_.summary_->Observe(diff.count());
      }
    protected:
      ProfileMetric& metric_;
      std::chrono::time_point<std::chrono::system_clock> start_;
    };

  public:
    typedef std::map<std::string, std::string>  LablesType;
    typedef prometheus::Summary::Quantiles      Quantiles;
    #define  DEFAULT_QUANTILES Quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}}

  public:
    ProfileMetric(const std::map<std::string,std::string>& labels, const Quantiles& quantiles=DEFAULT_QUANTILES) {
      std::stringstream address; address<<this;
      std::map<std::string,std::string> copy_labels = {
          {"engine", ""},
          {"model", ""},
          {"stream_id", ""},
          {"uid", address.str()},
      };
      for (const auto& kv : copy_labels){
        if (labels.count(kv.first)){
          copy_labels[kv.first] = labels.find(kv.first)->second;
        }
      }
      seconds_total_ = &Metric::Instance().profile_seconds_total->Add(copy_labels);
      count_total_   = &Metric::Instance().profile_count_total->Add(copy_labels);
      summary_       = &Metric::Instance().profile_summary->Add(copy_labels, quantiles);
    }
    ~ProfileMetric() {
      Metric::Instance().profile_seconds_total->Remove(seconds_total_);
      Metric::Instance().profile_count_total->Remove(count_total_);
      Metric::Instance().profile_summary->Remove(summary_);
    }
    friend class Helper;
  protected:
    prometheus::Counter * seconds_total_;
    prometheus::Counter * count_total_;
    prometheus::Summary * summary_;
  };
}

#endif