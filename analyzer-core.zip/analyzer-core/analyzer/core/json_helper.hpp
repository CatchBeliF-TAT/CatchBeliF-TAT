#ifndef SCOPE_CORE_HELPER_HPP
#define SCOPE_CORE_HELPER_HPP

#include <map>
#include <vector>

#include "common/json.hpp"

namespace FLOW {

inline std::string stream_status_json(std::map<std::string, int> &status) {
  rapidjson::Document document;
  auto &a = document.GetAllocator();
  rapidjson::Value j_result(rapidjson::kObjectType);

  for (auto &statu : status) {
    j_result.AddMember(rapidjson::StringRef(statu.first.c_str()),
                       rapidjson::Value(statu.second), a);
  }

  rapidjson::StringBuffer buffer;
  rapidjson::Writer<rapidjson::StringBuffer> writer(buffer);
  j_result.Accept(writer);
  std::string json_str = std::string(buffer.GetString());

  return json_str;
}

}  // namespace FLOW

#endif  // SCOPE_CORE_HELPER_HPP
