#ifndef VSS_STREAM_MANAGER_HPP
#define VSS_STREAM_MANAGER_HPP

#include <string>
#include <vector>
#include <unordered_map>
#include <memory>
#include <mutex>
#include <opencv2/opencv.hpp>

#include "video_reader.hpp"
#include "video_writer.hpp"
#include "common/tad_internal.hpp"
#include "serving/config.pb.h"


namespace FLOW {

    class CVideoReader;
    class CVideoWriter;
    typedef std::vector<AlgRender> VecAlgRender;
    typedef std::unordered_map<std::string, AlgRender> MapAlgRender;
    struct CVideoChannel {
        std::string                      id;
        std::string                      url;
        int                              device =-1;
        bool                             enable_tracking_debug = false;
        bool                             enable_encode_force_pts = false;
        std::shared_ptr<CVideoReader>    reader;
        std::shared_ptr<CVideoWriter>    writer;
        VecAlgRender                     writer_renders;
        std::mutex                       writer_lock_;
    };
    typedef std::shared_ptr<CVideoChannel> spCVideoChannel;
    typedef std::unordered_map<std::string, spCVideoChannel> ChannelMap;

    const int MAX_FRAME_QUEUE_SIZE = 255;  
    class CStreamManager {
    public:
        CStreamManager(const inference::StreamConfig& cfg=inference::StreamConfig{});
        ~CStreamManager() = default;

    public:
        int AddStream(const std::string& url, const std::string& channel_id, const inference::StreamConfig& cfg);
        int AddPushStream(const std::string& url, const std::string& channel_id, const int device, const float size=1.0f, float fps=25.0, int enable_tracking_debug=-1);
        int StopStream(const std::string& channel_id);
        int StopPushStream(const std::string& channel_id);
        int GetStatus(std::map<std::string, int>& vec_status);
        spFrameQueue GetFrameQueue(const std::string channel_id) { 
            std::unique_lock<std::mutex> lock{lock_};
            if (frame_queue_.find(channel_id) == frame_queue_.end()) return spFrameQueue();
            return frame_queue_[channel_id];
        }
        void RemoveFrameQueue(const std::string channel_id) { 
            std::unique_lock<std::mutex> lock{lock_};
            frame_queue_.erase(channel_id);
        }
        spCVideoChannel GetChannel(const std::string channel_id) { 
            std::unique_lock<std::mutex> lock{lock_};
            if (channels_.find(channel_id) == channels_.end()) return spCVideoChannel();
            return channels_[channel_id];
        }
        int PushFrames(const VecImage& image_objects_map);
        int PushFrames(const VecImage& image_objects_map, int tad_type);
        int PushFrames2(const VecImage& images, spCVideoChannel channel, int tad_type);
        int PushFramesWithRenders(const VecImage& images, spCVideoChannel channel);
        void setEncodeGpuOn(bool gpu_on){encode_gpu_on = gpu_on;}
        void setEncodeQP(int qp){encode_quality_qp = qp;}
        void SetStreamFps(const std::string& channel_id, float fps);
        std::string WriteRecordStream(const std::string& channel_id, int64_t start, int64_t end, const std::string &event_id);

        void SetVecAlgRender(const std::string& channel_id, const VecAlgRender& renders);
        void GetVecAlgRender(const std::string& channel_id, VecAlgRender* renders);
        

    private:
        const inference::StreamConfig cfg_;
        ChannelMap   channels_;
        std::mutex   lock_;
        //spFrameQueue frame_queue_;
        std::unordered_map<std::string, spFrameQueue> frame_queue_;
        int queue_size_;
        bool encode_gpu_on = true;
        int  encode_quality_qp = 28;
    };
}

#endif //VSS_STREAM_MANAGER_HPP
