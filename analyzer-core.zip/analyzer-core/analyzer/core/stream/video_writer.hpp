#ifndef VSS_VIDEO_WRITER_HPP
#define VSS_VIDEO_WRITER_HPP


#include <memory>
#include <thread>
#include <functional>

#include <opencv2/opencv.hpp>
#include "common/Queue.h"
#include "video_reader.hpp"
#include "serving/config.pb.h"

namespace prometheus{
    class Counter;
}

namespace FLOW {

    typedef std::function<MatPts(float scale)> MatPtsBuilder;
    class CVideoWriter {
    public:
        CVideoWriter(const std::string& url, const std::string& channel_id, const inference::StreamConfig& cfg);
        ~CVideoWriter();

    public:
        void PushFrame(const MatPts& matPts);
        void PushFrame(MatPtsBuilder matPts);
        void Stop();
        inline bool IsStop() { return stop == true; };
        inline bool IsInit() { return time_base_den_ > 0; }
        void set_time_base_den(float time_base);
        
    private:
        void Run();

    private:
        const inference::StreamConfig cfg_;
        Queue<MatPtsBuilder> frame_queue;
        std::shared_ptr<void> writer_;
        std::thread write_thread;
        std::atomic<bool> stop;
        std::string channel_id_ = "";
        std::string url_ = "";
        bool push_error = false;
        float time_base_den_ = 0.f;
        prometheus::Counter* encode_frame_counter_ = nullptr;
    };

    inline float fixScale(float input, int width, int height) {
        if (input<=1.0f) {
            return input;
        }
        else
        {
            float scale = std::min((input*16/9.0f)/width, input/height);
            return scale;
        }
    }
}

#endif //VSS_VIDEO_WRITER_HPP
