#ifndef VSS_VIDEO_READER_HPP
#define VSS_VIDEO_READER_HPP

#include <memory>
#include <thread>
#include <unordered_map>
#include <opencv2/opencv.hpp>

#include "common/tad_internal.hpp"
#include "common/Queue.h"
#include "serving/config.pb.h"

namespace prometheus{
    class Counter;
}
namespace FLOW {

struct MatPts
{
    std::string channel_id;
    ShellFrame_Ptr sframe;
    PosInfo location;
    int64_t pts;
    int64_t count;
    int64_t ntp_time_stamp=-1;
    float   time_interval=0;
    float   pts_interval=0;
    int     jitter_status=-1;
};

typedef Queue<MatPts> FrameQueue;
typedef std::shared_ptr<FrameQueue> spFrameQueue;

class CVideoReader
{
public:
    CVideoReader(const std::string &url, const std::string &channel_id, const inference::StreamConfig& cfg);
    ~CVideoReader();

public:
    enum STATUS{
        eStatusUndefine,
        eStatusStarting,
        eStatusStarted,
        eStatusStopping,
        eStatusStoped,
    };

public:
    void GetFrame(MatPts *frame);
    spFrameQueue GetFrameQueue() { return frame_queue_; }
    int GetFrameQueueSize();
    bool Status();
    int64_t Count();
    void Start();
    void Stop();
    void WriteRec(int64_t start, int64_t end, const std::string &event_id);
    float get_time_base_den();
    void SetFps(float fps);

private:
    void Run();

private:
    std::shared_ptr<void> reader_;
    spFrameQueue frame_queue_;
    std::atomic_bool bBreak_;
    spFrameQueue self_queue_;
    std::thread read_thread_;
    const std::string channel_id_;
    const std::string url_;
    const inference::StreamConfig cfg_;
    PosInfo ptz_info_;
    int64_t ntp_time_stamp_=-1;
    float new_fps_,current_fps_;
    STATUS status_ = eStatusUndefine;
    bool   stop_ = false;
    float fps_=0.0;
    int64_t count_ = 0;
    float time_base_den_ = 0.f;
    prometheus::Counter* decode_frame_counter_ = nullptr;
    prometheus::Counter* decode_delay_receive_frame_counter_ = nullptr;
    prometheus::Counter* decode_delay_send_frame_counter_ = nullptr;
    bool resolution_first_judged = true;
};
} // namespace FLOW
#endif //VSS_VIDEO_READER_HPP
