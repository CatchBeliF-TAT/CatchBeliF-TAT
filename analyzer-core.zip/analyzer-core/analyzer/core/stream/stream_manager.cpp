
#include <string>
#include <opencv2/opencv.hpp>

#include "common/log.hpp"
#include "common/util.hpp"
#include "stream_manager.hpp"

using namespace std;
using namespace cv;

namespace FLOW {
    static bool g_enable_stream_debug = false;
    CStreamManager::CStreamManager(const inference::StreamConfig& cfg)
        : cfg_(cfg)
        , channels_()
        , queue_size_(std::max<int>(cfg_.decode_queue_size(),1))
        //, frame_queue_(std::make_shared<FrameQueue>(std::max(queue_size,1)))
    {
    }

    int CStreamManager::AddStream(const string& url, const string& channel_id, const inference::StreamConfig& cfg) {
        spCVideoChannel channel;
        g_enable_stream_debug = std::ifstream("enable_stream_debug").is_open();
        {
            std::unique_lock<std::mutex> lock{lock_};
            if (channels_.find(channel_id) != channels_.end()) {
                return -1;
            }
            channel = std::make_shared<CVideoChannel>();
            channels_[channel_id] = channel;
            channel->device = cfg.gpu_id();
            channel->id = channel_id;
            channel->url = url;
            inference::StreamConfig cfg_copy = cfg;
            if (!cfg_copy.has_decode_queue_size()){
                cfg_copy.set_decode_queue_size(queue_size_);
            }
            channel->reader = make_shared<CVideoReader>(url, channel_id, cfg_copy);
            channel->enable_tracking_debug |= cfg.enable_tracking_debug();
            channel->enable_encode_force_pts = cfg.enable_encode_force_pts();
            frame_queue_[channel_id] = channel->reader->GetFrameQueue();
        }
        channel->reader->Start();
        return 0;
    }

    void CStreamManager::SetStreamFps(const std::string& channel_id, float fps) {
        std::unique_lock<std::mutex> lock{lock_};
        auto channel = channels_.find(channel_id);
        if (channel != channels_.end()) {
            channel->second->reader->SetFps(fps);
        }
    }

    int CStreamManager::AddPushStream(const string& url, const string& channel_id, const int device, const float size, float fps, int enable_tracking_debug) {
        g_enable_stream_debug = std::ifstream("enable_stream_debug").is_open();
        {
            std::unique_lock<std::mutex> lock{lock_};
            if (channels_.find(channel_id) != channels_.end()) {
                auto& channel = channels_[channel_id];
                inference::StreamConfig cfg;
                cfg.set_output_stream_size(size);
                cfg.set_fps(fps);
                cfg.set_enable_tracking_debug(enable_tracking_debug);
                cfg.set_encode_gpu_on(encode_gpu_on);
                cfg.set_encode_quality_qp(encode_quality_qp);
                cfg.set_enable_encode_force_pts(channel->enable_encode_force_pts);
                enable_tracking_debug = (enable_tracking_debug<0) ? \
                            channel->enable_tracking_debug : enable_tracking_debug;
                cfg.set_enable_tracking_debug(enable_tracking_debug);

                // create writer
                auto writer = make_shared<CVideoWriter>(url, channel_id, cfg);
                channel->writer = writer;
            } else {
                return -1;
            }
        }
        return 0;
    }

    int CStreamManager::StopStream(const string& channel_id) {
        spCVideoChannel channel;
        {
            std::unique_lock<std::mutex> lock{lock_};
            if (channels_.find(channel_id) != channels_.end()) {
                channel = channels_[channel_id];
                channels_.erase(channel_id);
            }
            frame_queue_.erase(channel_id);
        }
        return 0;
    }

    int CStreamManager::StopPushStream(const string& channel_id) {
        std::shared_ptr<CVideoWriter> writer;
        {
            std::unique_lock<std::mutex> lock{lock_};
            if (channels_.find(channel_id) != channels_.end()) {
                std::unique_lock<std::mutex> lock{channels_[channel_id]->writer_lock_};
                writer = channels_[channel_id]->writer;
                channels_[channel_id]->writer.reset();
            }
        }
        return 0;
    }

    std::string CStreamManager::WriteRecordStream(const string& channel_id, int64_t start, int64_t end, const std::string &event_id) {
        std::string path;
        if (!cfg_.has_video_record_dir()) {
            return path;
        }
        spCVideoChannel channel;
        {
            std::unique_lock<std::mutex> lock{lock_};
            if (channels_.find(channel_id) != channels_.end()) {
                channel = channels_[channel_id];
            }
        }
        // check_dir
        static bool check_dir=false;
        if (!check_dir) {
            check_dir = true;
            mkpath(cfg_.video_record_dir().c_str(), S_IRWXU);
        }
        // start == end
        // only use on supre_edge and XuChen said 30s is ok
        if(start==end){
            float time_base = channel->reader->get_time_base_den();
            int64_t pts_for_15s = 15.0/time_base;
            start -= pts_for_15s;
            end += pts_for_15s;
        }
        // save rec
        if (channel && channel->reader) {
            path = cfg_.video_record_dir() + "/" + event_id + ".mp4";
            channel->reader->WriteRec(start,end, path);
        }
        return path;
    }

    int CStreamManager::GetStatus(map<string, int>& status) {
        {
            Profiler profiler;
            profiler.tic("GetStatus");

            std::unique_lock<std::mutex> lock{lock_};
            for (auto &kv : channels_) {
                status[kv.first] = kv.second->reader->Status() ? STREAM_STATUS_SUCCESS : STREAM_STATUS_FAIL;
            }
            profiler.toc("GetStatus");
            //LOG(INFO) << profiler.get_stats_str();
         }
        return 0;
    }

    int CStreamManager::PushFrames(const VecImage& images) {
        {
            std::unique_lock<std::mutex> lock{lock_};
            for (const auto &image : images) {
                auto itr = channels_.find(image->channel_id);
                if (itr == channels_.end()) {
                    continue;
                }
                auto& channel = itr->second;
                auto& writer = channel->writer;
                auto& enable_debug = channel->enable_tracking_debug;
                if (writer && image->sframe != nullptr) {
                    if(!writer->IsInit()) {
                        auto time_base_den = channel->reader->get_time_base_den();
                        writer->set_time_base_den(time_base_den);
                    }
                    auto frame_builder = [image, enable_debug](float){
                        MatPts matPts;
                        matPts.sframe = image->sframe;
                        matPts.pts = image->pts;
                        return matPts;
                    };
                    writer->PushFrame(frame_builder);
                }
            }
        }
        return 0;
    }

    int CStreamManager::PushFramesWithRenders(const VecImage& images, spCVideoChannel channel) {
        std::shared_ptr<CVideoWriter> writer;
        VecAlgRender writer_renders;
        {
            std::unique_lock<std::mutex> lock{channel->writer_lock_};
            writer = channel->writer;
            writer_renders = channel->writer_renders;
        }
        if(writer){
            for (const auto &image : images) {
                auto enable_debug = g_enable_stream_debug | channel->enable_tracking_debug;
                if (image->sframe) {
                    if(!writer->IsInit()) {
                        auto time_base_den = channel->reader->get_time_base_den();
                        writer->set_time_base_den(time_base_den);
                    }
                    auto frame_builder = [image, enable_debug, writer_renders](float scale){
                        MatPts matPts;
                        Mat_Ptr mat = std::make_shared<Mat>();
                        scale = fixScale(scale, image->sframe->width(), image->sframe->height());
                        cv::resize(*image->sframe->getMat(), *mat, cv::Size(), scale, scale);
                        for(auto &render : writer_renders){
                            if (render) {
                                render(*image, mat, enable_debug);
                            }
                        }
                        matPts.sframe = std::make_shared<ShellFrame>(mat);
                        matPts.pts = image->pts;
                        return matPts;
                    };
                    writer->PushFrame(frame_builder);
                }
            }
        }
        return 0;
    }

    void CStreamManager::SetVecAlgRender(const std::string& channel_id, const VecAlgRender& renders) {
        spCVideoChannel channel;
        {     
            std::unique_lock<std::mutex> lock{lock_};
            if (channels_.count(channel_id) > 0) {
                channel = channels_[channel_id];
            }
        }
        if (channel) {
            std::unique_lock<std::mutex> lock{channel->writer_lock_};
            channel->writer_renders = renders;
        }
    }

    void CStreamManager::GetVecAlgRender(const std::string& channel_id, VecAlgRender* renders) {
        renders->clear();
        spCVideoChannel channel;
        {     
            std::unique_lock<std::mutex> lock{lock_};
            if (channels_.count(channel_id) > 0) {
                channel = channels_[channel_id];
            }
        }
        if (channel) {
            std::unique_lock<std::mutex> lock{channel->writer_lock_};
            *renders = channel->writer_renders;
        }
    }
}

