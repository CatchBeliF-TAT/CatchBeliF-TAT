#ifndef __PIC_JITTER_DETECTOR__
#define __PIC_JITTER_DETECTOR__
#include <list>
#include <vector>

using std::list;
using std::vector;
#ifdef __cplusplus
extern "C"{
#endif

/*图像结构体*/
typedef struct __FRAME_DATA__{
    int             width;
    int             height;
    int             channel;
    unsigned char   *data;
}FRAME_DATA;

struct motion_out {
    vector<int> vect;
    vector<int> abs; 
    float  judge;
};

class PicJitterDetector{
    public:
    /*推荐阈值
    抽帧模式: thre_jit = 10, thre_rot_hi=20, thre_rot_lo=15
    不抽帧模式:thre_jit = 10, thre_rot_hi=15, thre_rot_lo=11
    */
    explicit PicJitterDetector(float thre_jit = 10, float thre_rot_hi = 20.0, float thre_rot_lo = 15.0);
    ~PicJitterDetector();

    /*抖动判断
    input:           frame 帧结构体
    output:          0 未动, 1 抖动, 2 转动
    note:            接口缓存上一帧数据指针,当前帧判断时,上一帧数据不能释放
    */
    int JitterJudge(FRAME_DATA &frame);

    /*重新设置阈值*/
    int SetThreshold(float thre_jit = 10, float thre_rot_hi = 15.0, float thre_rot_lo = 11.0);
    
    /*重置状态参数*/
    int ResetState();

    /*预转动状态标志*/
    int pre_rotate_flag = 0;

    private:
    list<FRAME_DATA>  pic_buffer;
    list<float>       mv_buffer;
    float             jitter_thre;
    float             rotate_thre_hi;
    float             rotate_thre_lo;
    int               count_jit   = 0;
    unsigned int      count_mark  = 0;
    int               rotate_flag = 0;
    
};

#ifdef __cplusplus
}
#endif
#endif