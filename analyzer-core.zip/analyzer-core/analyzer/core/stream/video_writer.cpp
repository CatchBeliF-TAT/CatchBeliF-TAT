#include "video_writer.hpp"

#include <sstream>

#include "core/metric.hpp"
#include "common/log.hpp"
#include "common/util.hpp"

using namespace std;

#ifdef USE_MEDIA_UTILS
    #include "stream_writer.h"
    inline std::shared_ptr<void> create_writer(const string &url) {
        return std::shared_ptr<media_utils::stream_writer>(
            media_utils::new_stream_writer(url), [](void* p) { media_utils::destory_stream_writer((media_utils::stream_writer*)(p)); }
        );
    }
    inline std::shared_ptr<media_utils::stream_writer> cast_writer(std::shared_ptr<void> sp) {
        return std::static_pointer_cast<media_utils::stream_writer>(sp);
    }
#elif defined(USE_NV_WRITER)
    #include "stream_writer.hpp"
    inline std::shared_ptr<void> create_writer(const string &url) {
        return std::shared_ptr<ATVIDEO::StreamWriter>(
            new ATVIDEO::StreamWriter(url), [](void* p) { delete (ATVIDEO::StreamWriter*)(p); }
        );
    }
    inline std::shared_ptr<ATVIDEO::StreamWriter> cast_writer(std::shared_ptr<void> sp) {
        return std::static_pointer_cast<ATVIDEO::StreamWriter>(sp);
    }
#else
    #include "dr.hpp"
    inline std::shared_ptr<void> create_writer(const string &url) {
        return std::shared_ptr<ATVIDEO::DR>(
            new ATVIDEO::DR(url), [](void* p) { delete (ATVIDEO::DR*)(p); }
        );
    }
    inline std::shared_ptr<ATVIDEO::DR> cast_writer(std::shared_ptr<void> sp) {
        return std::static_pointer_cast<ATVIDEO::DR>(sp);
    }
#endif // USE_MEDIA_UTILS

namespace FLOW {

    const int DEFAULT_WRITE_QUEUE_SIZE = 16;
    CVideoWriter::CVideoWriter(const string &url, const string &channel_id, const inference::StreamConfig& cfg)
        : cfg_(cfg)
        , writer_(create_writer(url))
        , channel_id_(channel_id)
        , url_(url)
        , frame_queue(DEFAULT_WRITE_QUEUE_SIZE)
        , stop(false)
    {
        Metric::Instance().encode_stream_count->Increment();
        std::stringstream address; address<<this;
        encode_frame_counter_ = &Metric::Instance().encode_frame_count->Add({
                        {"stream_id", channel_id_},
                        {"uuid", address.str()},
                    });
        write_thread = std::thread(&CVideoWriter::Run, this);
    }


    CVideoWriter::~CVideoWriter() {
        Stop();
        if (encode_frame_counter_) {
            Metric::Instance().encode_frame_count->Remove(encode_frame_counter_);
        }
        Metric::Instance().encode_stream_count->Decrement();
    }

    void CVideoWriter::Run() {
        SET_THREAD_NAME(std::string("W_")+channel_id_);
        LOG(INFO) << "Start CVideoWriter channel id " << channel_id_;
        bool ret;
        Profiler profiler;
        int count=0;
        int retry_silent_count=0;
        auto writer = cast_writer(writer_);
        writer->use_gpu(cfg_.encode_gpu_on());
        writer->set_qp(cfg_.encode_quality_qp());
        while (!stop) {
            auto frame_builder = frame_queue.pop();
            if (!frame_builder) {
                continue;
            }
            if (push_error) {
                retry_silent_count++;
                // reset write after 250 frame(10s)
                if (retry_silent_count > 25*10) {
                    retry_silent_count=0;
                    push_error = false;
                    if(writer) { writer->close(); }
                    // reset writer
                    writer_ = create_writer(url_);
                    writer = cast_writer(writer_);
                    writer->use_gpu(cfg_.encode_gpu_on());
                    writer->set_qp(cfg_.encode_quality_qp());
                    frame_queue.clear();
                    LOG(INFO) << "Restart CVideoWriter channel id " << channel_id_;
                }
                continue;
            }
            profiler.tic("CVideoWriter");
            MatPts matPts = frame_builder(cfg_.output_stream_size());
            if (matPts.sframe != nullptr) {
                LOG(DEBUG) << "push frame PTS: " << matPts.pts << ", time_base_den: " << time_base_den_;
                if (cfg_.has_enable_encode_force_pts() && cfg_.enable_encode_force_pts()){
                    matPts.pts = 0;
                }
                writer->set_input_time_base(time_base_den_);
                ret = writer->write(*matPts.sframe->getMat(), matPts.pts);
                if (!ret) {
                    push_error = true;
                    continue;
                }
                encode_frame_counter_->Increment();
            }
            profiler.toc("CVideoWriter");
            LOG_IF(DEBUG,(count++%5==0)) << channel_id_ <<": " << profiler.get_stats_str();
        }

        stop = true;
        if(writer) { writer->close(); }
        frame_queue.cancel_pops();
        LOG(INFO) << "CVideoWriter channel id " << channel_id_ << " stop!";
    }

    void CVideoWriter::PushFrame(const MatPts& matPts) {
        frame_queue.push([matPts](float)->MatPts{return matPts;});
    }

    void CVideoWriter::PushFrame(MatPtsBuilder builder) {
        frame_queue.push(builder);
    }

    void CVideoWriter::Stop() {
        stop = true;
        frame_queue.clear();
        frame_queue.cancel_pops();
        if (write_thread.joinable()) {
            write_thread.join();
        }
    }

    void CVideoWriter::set_time_base_den(float time_base) {
        time_base_den_ = time_base;
        cast_writer(writer_)->set_input_time_base(time_base_den_);
    }

    // void CVideoWriter::set_scale(float scale) {
    //     scale_ = scale;
    // }

    // void CVideoWriter::set_fps(float fps) {
    //     fps_ = fps;
    //     cast_writer(writer_)->set_fps(fps);
    // }

    // float CVideoWriter::scale() {
    //     return scale_;
    // }
}

