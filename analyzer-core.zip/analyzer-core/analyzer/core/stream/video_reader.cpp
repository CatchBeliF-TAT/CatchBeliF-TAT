#include "video_reader.hpp"

#include <sstream>
#include <malloc.h>

#include "core/metric.hpp"
#include "common/log.hpp"
#include "common/util.hpp"

#ifdef __x86_64__
#   include "pic_jitter_detector.hpp"
#endif

#ifndef USE_MEDIA_UTILS
#define USE_NV_READER
#else
#undef USE_NV_READER
#endif

#ifdef USE_MEDIA_UTILS
#   include "common/helper.hpp"
#   include "common/json.hpp"
#   include "frame_reader.h"
    inline std::shared_ptr<void> create_reader(const inference::StreamConfig& cfg) {
        return std::shared_ptr<media_utils::frame_reader>(
            media_utils::new_stream_transfer(),
            [](void* p) {
                delete static_cast<media_utils::frame_reader*>(p);
            }
        );
    }
    inline std::shared_ptr<media_utils::frame_reader> cast_reader(std::shared_ptr<void> sp) {
        return std::static_pointer_cast<media_utils::frame_reader>(sp);
    }
#elif defined(USE_NV_READER)
#   include "nv_reader.hpp"
    inline std::shared_ptr<void> create_reader(const inference::StreamConfig& cfg) {
        return std::shared_ptr<ATVIDEO::NVVideoReader>(
            new ATVIDEO::NVVideoReader(cfg.gpu_id()),
            [](void* p) { 
                delete static_cast<ATVIDEO::NVVideoReader*>(p);
            }
        );
    }
    inline std::shared_ptr<ATVIDEO::NVVideoReader> cast_reader(std::shared_ptr<void> sp) {
        return std::static_pointer_cast<ATVIDEO::NVVideoReader>(sp);
    }
#else
#   include "dr.hpp"
#   include "detect_reader.hpp"
    inline std::shared_ptr<void> create_reader(const inference::StreamConfig& cfg) {
        return std::shared_ptr<ATVIDEO::DR>(
            new ATVIDEO::DR(0, 0),
            [](void* p) { 
                delete static_cast<ATVIDEO::DR*>(p);
            }
        );
    }
    inline std::shared_ptr<ATVIDEO::DR> cast_reader(std::shared_ptr<void> sp) {
        return std::static_pointer_cast<ATVIDEO::DR>(sp);
    }
#endif // USE_MEDIA_UTILS


namespace FLOW {
using namespace std;
using namespace cv;
const int DEFAULT_READ_QUEUE_SIZE = 32;

#ifdef USE_MEDIA_UTILS
inline bool parse_ptz_info(const std::string& ptz_info, PosInfo &location){
    const auto &document = get_document(ptz_info);
    if (!document.HasMember("data")) {
        return false;
    }
    auto & data_value = get_value(document, "data");
    if (!data_value.HasMember("ptz_current_pos")) {
        return false;
    }
    auto pos = get_array<float>(data_value, "ptz_current_pos");
    if (pos.size() >=3) {
        location.angle_x = pos[0];
        location.angle_y = pos[1];
        location.scale = pos[2];
        return true;
    }
    return false;
}

inline bool parse_ntp_time_stamp(const std::string& ptz_info, int64_t &ntp_time_ms){
    const auto &document = get_document(ptz_info);
    if (!document.HasMember("data")) {
        return false;
    }
    auto & data_value = get_value(document, "data");
    if (!data_value.HasMember("ntp_time_stamp")) {
        return false;
    }
    const int64_t INVALID_TIMSE_MS= -1;
    auto ms = get_int64(data_value, "ntp_time_stamp", INVALID_TIMSE_MS);
    if (ms != INVALID_TIMSE_MS) {
        ntp_time_ms = ms;
        return true;
    }
    return false;
}

inline bool parse_roi(const inference::StreamConfig& conf, vector<float>& out){
    if (conf.person_detect_roi_size() < 4) {
        return false;
    }
    out.resize(4);
    out[0]=conf.person_detect_roi(0);
    out[1]=conf.person_detect_roi(1);
    out[2]=conf.person_detect_roi(0);
    out[3]=conf.person_detect_roi(1);
    for(int i=2; i <(conf.person_detect_roi_size()); i+=2){
        if (conf.person_detect_roi(i) < out[0]) out[0] = conf.person_detect_roi(i);
        if (conf.person_detect_roi(i) > out[2]) out[2] = conf.person_detect_roi(i);
        if (conf.person_detect_roi(i+1) < out[1]) out[1] = conf.person_detect_roi(i+1);
        if (conf.person_detect_roi(i+1) > out[3]) out[3] = conf.person_detect_roi(i+1);
    }
    return (out.size() >=4 && out[0] != out[2] && out[1] != out[3]);
}

inline bool parse_rois(const vector<vector<float> >& datas, vector<float>& out){
    out.clear();
    for (auto& data : datas) {
        if (data.size() < 2) continue;
        if (out.empty()) {
            out.resize(4);
            out[0]=data[0];
            out[1]=data[1];
            out[2]=data[0];
            out[3]=data[1];
        }
        for(int i=0; i <data.size(); i+=2){
            if (data[i] < out[0]) out[0] = data[i];
            if (data[i] > out[2]) out[2] = data[i];
            if (data[i+1] < out[1]) out[1] = data[i+1];
            if (data[i+1] > out[3]) out[3] = data[i+1];
        }
    }
    return (out.size() >=4 && out[0] != out[2] && out[1] != out[3]);
}
inline std::string url_to_json_config(const std::string &url, const vector<vector<float> >& rois, const inference::StreamConfig& conf) {
//inline std::string url_to_json_config(const std::string &url, const std::string &decode_device, bool device_input, 
//                                     float fps, int dec_threads, bool drop_packet, bool player_mode, std::vector<int> input_shapes) {
  using namespace rapidjson;
  Document document;
  auto &alloc = document.GetAllocator();
  Value j_config(kObjectType);
  j_config.AddMember("in", Value(StringRef(url.c_str())), alloc);
  j_config.AddMember("device", Value(StringRef(conf.decode_device().c_str())), alloc);
  j_config.AddMember("drop-packet", Value(conf.drop_packet()), alloc);
  j_config.AddMember("player-mode", Value(conf.player_mode()), alloc);
  if (conf.fps() > 0) {
    j_config.AddMember("fps", Value(conf.fps()), alloc);
  }
  if (conf.dec_threads() > 0) {
    j_config.AddMember("dec-threads", Value(conf.dec_threads()), alloc);
  }

    Value scales_config(kArrayType);
    if (conf.device_input()) {
        CHECK(conf.detect_input_shapes_size() > 3);
        for(auto& roi : rois) {
        Value scale_config(kObjectType);
        if (!roi.empty()) {
            scale_config.AddMember("roi-left", Value(roi[0]), alloc);
            scale_config.AddMember("roi-top", Value(roi[1]), alloc);
            scale_config.AddMember("roi-right", Value(roi[2]), alloc);
            scale_config.AddMember("roi-bottom", Value(roi[3]), alloc);
        }
        scale_config.AddMember("width", Value(conf.detect_input_shapes(3)), alloc);
        scale_config.AddMember("height", Value(conf.detect_input_shapes(2)), alloc);
        scale_config.AddMember("with-ratio", Value(true), alloc);
        scale_config.AddMember("padding-b", Value(103.53), alloc);
        scale_config.AddMember("padding-g", Value(116.28), alloc);
        scale_config.AddMember("padding-r", Value(123.675), alloc);
        scales_config.PushBack(scale_config, alloc);
        }
        j_config.AddMember("scales", scales_config, alloc);
        j_config.AddMember("cuda-oom-wait", Value(conf.cuda_oom_wait()), alloc);
    }
    if (conf.has_video_record_dir()) {
        Value extend_conf(kObjectType);
        extend_conf.AddMember("extend",Value(50), alloc);
        j_config.AddMember("record", extend_conf, alloc);
    }
    j_config.AddMember("ptz", Value().SetBool(conf.parse_ptz() || conf.parse_ntp_time_stamp()), alloc);

  StringBuffer buffer;
  Writer<StringBuffer> writer(buffer);
  j_config.Accept(writer);
  LOG(INFO)<<std::string(buffer.GetString());
  return std::string(buffer.GetString());
}

#endif


    CVideoReader::CVideoReader(const string &url,
                               const string &channel_id,
                               const inference::StreamConfig& cfg)
                : url_(url)
                , channel_id_(channel_id)
                , frame_queue_(new FrameQueue(DEFAULT_READ_QUEUE_SIZE))
                , bBreak_(false)
                , self_queue_(frame_queue_)
                , status_(eStatusUndefine)
                , stop_(false)
                , count_(0)
                , cfg_(cfg)
                , reader_(create_reader(cfg))
                , new_fps_(cfg.fps())
                , current_fps_(cfg.fps())
    {
        Metric::Instance().decode_stream_count->Increment();
        std::stringstream address; address<<this;
        decode_frame_counter_ = &Metric::Instance().decode_frame_count->Add({
                        {"stream_id", channel_id_},
                        {"uuid", address.str()},
                    });
        decode_delay_receive_frame_counter_ = &Metric::Instance().decode_delay_frame_count->Add({
                        {"stream_id", channel_id_},
                        {"uuid", address.str()},
                        {"type", "receive"},
                    });
        decode_delay_send_frame_counter_ = &Metric::Instance().decode_delay_frame_count->Add({
                        {"stream_id", channel_id_},
                        {"uuid", address.str()},
                        {"type", "send"},
                    });
#if defined(USE_NV_READER)
        cast_reader(reader_)->set_extra_hw_frames(4);
#endif
    }
    CVideoReader::~CVideoReader() {
        Stop();
        if (decode_frame_counter_) {
            Metric::Instance().decode_frame_count->Remove(decode_frame_counter_);
        }
        if (decode_delay_receive_frame_counter_) {
            Metric::Instance().decode_delay_frame_count->Remove(decode_delay_receive_frame_counter_);
        }
        if (decode_delay_send_frame_counter_) {
            Metric::Instance().decode_delay_frame_count->Remove(decode_delay_send_frame_counter_);
        }
        Metric::Instance().decode_stream_count->Decrement();
    }

    void CVideoReader::Start() {
        if (status_ == eStatusUndefine) {
            read_thread_ = std::thread(&CVideoReader::Run, this);
        }
    }

    bool CVideoReader::Status() {
        return status_ <= eStatusStarted;
    }

    int64_t CVideoReader::Count() {
        return count_;
    }

    float CVideoReader::get_time_base_den() {
        if (cfg_.enable_use_pts()) {
            return 0.001f;
        }
        return time_base_den_;
    }

    void CVideoReader::Run() {
        SET_THREAD_NAME(std::string("R_")+channel_id_);
        bool ret;
        status_ = eStatusStarting;
#ifdef USE_MEDIA_UTILS
        vector<vector<float> > rois(1);
        vector<float> out_roi;
        if (parse_roi(cfg_, out_roi)) {
            rois.push_back(out_roi);
        }
        ret = cast_reader(reader_)->open(url_to_json_config(url_, rois, cfg_));
#else
        ret = cast_reader(reader_)->open(url_);
#endif
        if (!ret) {
            LOG(INFO) << "Open CVideoReader channel id " << channel_id_ << "failed";
            status_ = eStatusStoped;
        } else {
            fps_ = cast_reader(reader_)->fps();
            time_base_den_ = cast_reader(reader_)->stream_time_base();
            LOG(INFO) << "Start CVideoReader channel id " << channel_id_;
            status_ = eStatusStarted;
            count_ = 0;
            int64_t pre_pts = -1;
            int64_t pre_time = -1;
            int64_t delta_pts = 0;
#ifdef __x86_64__
            PicJitterDetector pic_jitter_detector;

            if  ( cfg_.has_enable_video_revolve_detect() && cfg_.enable_video_revolve_detect() &&
                    cfg_.has_jitter_para()) {
                int thre_jit = 10, thre_rot_hi = 15, thre_rot_lo = 11; //默认为抽帧模式,不设置jitter_parameter
                auto jitter_parameter = cfg_.jitter_para();
                if ( jitter_parameter.has_thre_jit() ) {
                    thre_jit = jitter_parameter.thre_jit();
                }
                if ( jitter_parameter.has_thre_rot_hi()) {
                    thre_rot_hi = jitter_parameter.thre_rot_hi();
                }
                if ( jitter_parameter.has_thre_rot_lo()) {
                    thre_rot_lo = jitter_parameter.thre_rot_lo();
                }
                pic_jitter_detector.SetThreshold(thre_jit, thre_rot_hi, thre_rot_lo);
            }
            shared_ptr<Mat>  image_pre;
#endif
            typedef std::map<std::string, std::string> LablesType;
            const prometheus::Summary::Quantiles quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
            auto profile_metric_        = std::make_shared<ProfileMetric>(LablesType{{"decoder", "decoder"}, {"model", "moving"       }}, quantiles);
            while (!stop_) {
#ifdef USE_MEDIA_UTILS
                auto fps_tmp = new_fps_;
                if (fps_tmp > 0 && current_fps_ != fps_tmp) {
                    cast_reader(reader_)->set_fps(fps_tmp);
                    current_fps_ = fps_tmp;
                }
#endif
                shared_ptr<Mat> image(new cv::Mat);
                MatPts mat_pts;
                VecVframe oriframes;
                mat_pts.channel_id = channel_id_;
#ifdef USE_MEDIA_UTILS
                std::string ptz_info;
                //mat_pts.frames.resize(rois.size());
                oriframes.resize(rois.size());
                bool got_frame = cast_reader(reader_)->read(*image, oriframes, mat_pts.pts, ptz_info);

                if(got_frame){
                    mat_pts.sframe = std::make_shared<ShellFrame>(image);
                    for(auto e: oriframes){
                        //e is a Vframe_Ptr, need to transfer to std::shared_ptr<Vframe_Ptr_Shell>
                        if(e){
                          mat_pts.sframe->addVframe(e);
                        }else{
                            LOG(ERROR)<<"error! do not get frame!!!";
                        }
                    }
                    if(cfg_.has_width()&&cfg_.has_height()){
                        if(cfg_.width()!=mat_pts.sframe->width()||cfg_.height()!=mat_pts.sframe->height()){
                            LOG(ERROR)<<"resolution not equal, stream resolution: "<<mat_pts.sframe->width()<<"*"<<mat_pts.sframe->height()<<"snapshot resolution: "<<cfg_.width()<<"*"<<cfg_.height();
                            break;
                        }else{
                            if(resolution_first_judged){
                                resolution_first_judged = false;
                                LOG(WARNING)<<"vedio resolution equal to the pic resolution";
                            }
                        }
                    }

#ifdef __x86_64__
                    if ( cfg_.has_enable_video_revolve_detect() && cfg_.enable_video_revolve_detect() ){
                        int img_h = image->rows;
                        int img_w = image->cols;
                        int channel = image->channels();
                        FRAME_DATA frame_data{img_w, img_h, channel,image->ptr<uchar>()};
                        {
                            ProfileMetric::Helper _metric_helper(*profile_metric_);
                            mat_pts.jitter_status = pic_jitter_detector.JitterJudge(frame_data);
                        }
                        image_pre = image;
                    }
#endif
                }
                // process ptz
                if (got_frame && cfg_.parse_ptz()) {
                    mat_pts.location = ptz_info_;
                    PosInfo current_ptz;
                    if (ptz_info != "" && parse_ptz_info(ptz_info, current_ptz)) {
                        bool changed = !Helper::is_same_postion(ptz_info_, current_ptz);
                        if (changed) {
                            ptz_info_ = current_ptz;
                            LOG(INFO) << "==> "<< channel_id_ 
                                        <<", ptz_pos(" 
                                        << ptz_info_.angle_x << ", "
                                        << ptz_info_.angle_y << ", "
                                        << ptz_info_.scale   << ")";
                        }
                        mat_pts.location = ptz_info_;
                        mat_pts.location.changed = changed;
                    }
                }
                // process ntp_time_stamp
                if (got_frame && cfg_.parse_ntp_time_stamp()) {
                    int64_t ntp_time_stamp=ntp_time_stamp_;
                    if (ptz_info != "" && parse_ntp_time_stamp(ptz_info, ntp_time_stamp)) {
                        if (ntp_time_stamp_ > ntp_time_stamp) {
                            LOG(WARNING) << "ntp_time_stamp error"
                                         << ", new="<< ntp_time_stamp
                                         << ", old="<< ntp_time_stamp_;
                            ntp_time_stamp = ntp_time_stamp_+1;
                        }
                        ntp_time_stamp_ = ntp_time_stamp;
                    } else {
                        ntp_time_stamp_ += std::max<int64_t>(1, delta_pts*CVideoReader::get_time_base_den());
                    }
                    mat_pts.ntp_time_stamp = ntp_time_stamp_;
                }
#else
                mat_pts.mat->create(cast_reader(reader_)->height(), cast_reader(reader_)->width(), CV_8UC3);
                bool got_frame = cast_reader(reader_)->read(*mat_pts.mat, &mat_pts.pts);
#endif
                if (got_frame && mat_pts.pts != -1) {
                    decode_frame_counter_->Increment();
                    mat_pts.count = ++count_;
                    // convert pts as millisecond
                    if (cfg_.enable_use_pts()) {
                        mat_pts.pts = mat_pts.pts/(cast_reader(reader_)->stream_time_base()/1000);
                    }

                    // process pts_interval & time_interval
                    auto now = std::chrono::time_point_cast<std::chrono::milliseconds>(
                        std::chrono::steady_clock::now());
                    mat_pts.pts_interval = (pre_pts > 0 && mat_pts.pts>pre_pts)
                        ? CVideoReader::get_time_base_den()*(mat_pts.pts-pre_pts)
                        : 0;
                    mat_pts.time_interval = (pre_time > 0 && now.time_since_epoch().count()>pre_time)
                        ? (now.time_since_epoch().count() - pre_time) / 1000.0f
                        : 0;
                    delta_pts = (pre_pts > 0 && mat_pts.pts>pre_pts) ? mat_pts.pts-pre_pts : 0;
                    pre_pts = mat_pts.pts;
                    pre_time = now.time_since_epoch().count();
                    if (cfg_.max_time_interval()>0 &&
                        (mat_pts.time_interval > cfg_.max_time_interval() ||
                         mat_pts.pts_interval  > cfg_.max_time_interval())) {
                        mat_pts.location.changed = true;
                    }

                    if ( mat_pts.pts_interval > 0.5 ) {
                        decode_delay_receive_frame_counter_->Increment();
                    }

                    auto pre_send_time = now.time_since_epoch().count();
                    // push frame
                    frame_queue_->push(mat_pts, bBreak_);

                    auto after_send = std::chrono::time_point_cast<std::chrono::milliseconds>(
                        std::chrono::steady_clock::now());
                    auto send_duration = (after_send.time_since_epoch().count() - pre_send_time) / 1000.0f;
                    if ( send_duration > 0.5 ) {
                        decode_delay_send_frame_counter_->Increment();
                    }
                    if (count_ % 100 == 0) {
                        LOG(DEBUG) << "Get frame from channel " << channel_id_ << ":" << count_;
                    }
                } else {
#ifdef USE_MEDIA_UTILS
                    if (mat_pts.pts == -1){
                        break;
                    }
                    std::this_thread::sleep_for(std::chrono::milliseconds(10));
#else
                    break;
#endif  
                }
            }
            status_ = eStatusStopping;
            cast_reader(reader_)->close();
        }
        self_queue_->cancel_pops();
        status_ = eStatusStoped;
        LOG(INFO) << "CVideoReader channel id " << channel_id_ << " stop!";
    }

    void CVideoReader::GetFrame(MatPts *frame) {
        int timeout = (int)(1000.0/fps_);
        try {
            *frame = frame_queue_->pop();
        }
        catch (std::runtime_error& e) {
            LOG(WARNING) << "VideoReader GetFrame timeout!";
            return;
        }
    }

    int CVideoReader::GetFrameQueueSize() {
        return frame_queue_->size();
    }

    void CVideoReader::Stop() {
        stop_ = true;
        self_queue_->cancel_pops();
        frame_queue_->break_push(bBreak_);
        if (read_thread_.joinable()) {
            read_thread_.join();
        }
        malloc_trim(0);
    }

    void CVideoReader::WriteRec(int64_t start, int64_t end, const std::string &path) {
#ifdef USE_MEDIA_UTILS
        bool succeed = cast_reader(reader_)->rec_write(start, end, path, 10*1000);
        if ( !succeed ) {
            LOG(WARNING) << "VideoReader::rec_write failed, " << path;
           remove(path.c_str());
        }
#else
        LOG(WARNING) << "VideoReader::WriteRec not implemented!";
#endif
    }

    void CVideoReader::SetFps(float fps) {
#ifdef USE_MEDIA_UTILS
        new_fps_ = fps;
#else
        LOG(WARNING) << "VideoReader::SetFps not implemented!";
#endif

    }
}  // namespace FLOW
