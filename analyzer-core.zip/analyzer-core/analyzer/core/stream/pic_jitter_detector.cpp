#include <vector>
#include <bitset>
#include <iostream>
#include <algorithm>
#include <fstream>
#include <cmath>
#include "pic_jitter_detector.hpp"

#ifdef __x86_64__
#   include <immintrin.h>
#   include <avx512fintrin.h>
#endif

using namespace std;


#define KERNEL_SIZE 8
#define AREA_SIZE 32
#define STEP 16
#define NUM_PATCH (AREA_SIZE*2/STEP + 1)

float detectMotionVector(const FRAME_DATA &frame1, const FRAME_DATA &frame2, float &mv_x, int thre=5, int k=4 , int area_size=6);

PicJitterDetector::PicJitterDetector(float thre_jit, float thre_rot_hi, float thre_rot_lo){
    jitter_thre = thre_jit;
    rotate_thre_hi = thre_rot_hi;
    rotate_thre_lo = thre_rot_lo;
}

PicJitterDetector::~PicJitterDetector(){

}

int PicJitterDetector::SetThreshold(float thre_jit, float thre_rot_hi, float thre_rot_lo){
    if(thre_jit<0 || thre_jit>40) return -1;
    if(thre_rot_hi<0 || thre_rot_hi>40) return -1;
    if(thre_rot_lo<0 || thre_rot_lo>40) return -1;

    jitter_thre = thre_jit;
    rotate_thre_hi = thre_rot_hi;
    rotate_thre_lo = thre_rot_lo;
    return 0;
}

int PicJitterDetector::ResetState(){
    count_jit       = 0;
    count_mark      = 0;
    rotate_flag     = 0;
    pre_rotate_flag = 0;
    return 0;
}

#ifdef __x86_64__
int PicJitterDetector::JitterJudge(FRAME_DATA &frame){
    //
    float mv_x = 0.;
    float mv_mean = 0.;
    // -------*****-------
    int cnt_th = 5;                    //连续cnt_th帧都过阈值，进入转动状态；抖动严重时，应调大
    count_mark &= 0x000000ff;          //转动状态判断区间
    // --------------
    
    if(pic_buffer.empty()){
        pic_buffer.push_back(frame);
        return 0;
    }
    else{
        FRAME_DATA pre_frame = pic_buffer.front();
        FRAME_DATA cur_frame = frame;
        pic_buffer.push_back(frame);
        pic_buffer.pop_front();
        mv_mean =  detectMotionVector(pre_frame, cur_frame, mv_x);
        mv_buffer.push_back(mv_mean);
    }
    // 抖动判断
    if(mv_mean>jitter_thre){
        count_jit = 3;
    }
    if(mv_mean>rotate_thre_hi){//转动状态切换，使用高阈值
        count_mark<<=1;
        count_mark++;
        pre_rotate_flag = 1;
        int tmp_mark = count_mark&0x0000001f; //cnt_th
        if(__builtin_popcount(tmp_mark)>=cnt_th){
            rotate_flag = 1;
        }
    }
    else{
        count_mark<<=1;
        pre_rotate_flag = 0;
        if(rotate_flag){//转动状态内，使用低阈值
            if(mv_mean>rotate_thre_lo){
                if(__builtin_popcount(count_mark)<5){
                    rotate_flag = 0;
                    count_mark&=0;
                }
                // count_mark++;
            }
            else{
                rotate_flag = 0;
                count_mark&=0;
            }
        }
        else{
            count_mark&=0;
        }
        // if(__builtin_popcount(count_mark)<=6){//count_mark标志的帧中<lo到2帧，退出转动状态
        //     rotate_flag = 0;
        // }
    }
    //---------------------------------------------------------
    // mean_mvdis = mv_mean;
    if(!rotate_flag){
        if(count_jit>0){
            count_jit--;
            return 1;
        }
    }
    else{
        return 2;
    }

    return 0;
}

float detectMotionVector(const FRAME_DATA &frame1, const FRAME_DATA &frame2, float &mv_x, int thre, int k , int area_size) {
    int cnt_vec = 0;
    float sum_vec = 0;
    float sum_vec_x = 0;
    int width = frame1.width;
    int height = frame1.height;
    int channel = frame1.channel;
    int scale = (width / 960);
    float mv_judge = 0;

    int step_exter = STEP * scale;
    int step_inter = 2 * scale;
    k              = KERNEL_SIZE * scale;
    area_size           = AREA_SIZE * scale;

    int edge_off   = area_size + k;

    unsigned char *pre = (unsigned char *)frame1.data;
    unsigned char *cur = (unsigned char *)frame2.data;

    unsigned char a = 127;
    unsigned char b = 1;
    unsigned char plan_mask = 15;
    
    __m256i mask_127  = _mm256_set1_epi8(a);
    __m256i mask_b    = _mm256_set1_epi8(b);
    __m256i mask_plan = _mm256_set1_epi8(plan_mask);
    int mse0, mse1;
    for (int y = edge_off; y < height - edge_off  -1; y += 2 * k) {
        for (int x = edge_off; x < width - edge_off -1; x += 2 * k) {
            int y_match = -1;
            int x_match = -1;
            int context_pix = 0; 

            // float minVal = 255 * 255 * k * k;
            float minVal = 64 * 64 * k * k;
            // float minVal = 32 * 32 * k * k;
            float orinVal = 0;
            alignas(64) unsigned char cur_patch[KERNEL_SIZE][KERNEL_SIZE];

            for (int i = -k; i < k; i += step_inter){
                for (int j = -k; j < k; j += step_inter){
                    int x_i = (j + k) / step_inter;
                    int y_i = (i + k) / step_inter;
                    cur_patch[y_i][x_i] = cur[((y + i) * width + (x + j)) * channel];
                }
            }
          
            __m256i cur_vec1  = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(cur_patch));
            __m256i cur_vec2  = _mm256_loadu_si256(reinterpret_cast<const __m256i*>((unsigned char*)cur_patch + 32));

            //过滤平坦区域
            // algorithm 1
            __m256i temp_vec1   = _mm256_subs_epu8(cur_vec1, cur_vec2);
            __m256i temp_vec2   = _mm256_subs_epu8(cur_vec2, cur_vec1);
            temp_vec1           = _mm256_adds_epu8(temp_vec1, temp_vec2);
            temp_vec1           = _mm256_min_epu8(temp_vec1, mask_127);
            temp_vec1           = _mm256_cmpgt_epi8(temp_vec1, mask_plan);
            context_pix += __builtin_popcountll(_mm256_extract_epi64(temp_vec1, 0));
            context_pix += __builtin_popcountll(_mm256_extract_epi64(temp_vec1, 1));
            context_pix += __builtin_popcountll(_mm256_extract_epi64(temp_vec1, 2));
            context_pix += __builtin_popcountll(_mm256_extract_epi64(temp_vec1, 3));
            if(context_pix < 8*5){
                 continue;
            }
            // algorithm 2
            //

            alignas(64) uint8_t patch_SA[NUM_PATCH][KERNEL_SIZE * KERNEL_SIZE];
            int count2 = 0;
            for (int y_ = y - area_size; y_ <= y + area_size; y_ += step_exter,count2++){
                int off_SA = ((y_ - k)*width + x - edge_off)*channel;
                for (int m = 0; m < KERNEL_SIZE; m++){// 预加KERNEL_SIZE载行,并重排, m'st row
                    for (int n = 0; n < NUM_PATCH; n++){
                        for(int q = 0; q < KERNEL_SIZE; q++){
                            patch_SA[n][m*KERNEL_SIZE + q] = pre[off_SA + (n*step_exter + q*step_inter)*channel];
                        }
                    }
                    off_SA += (width)*step_inter*channel;//
                }
                
                int idx_x = 0;
                if(KERNEL_SIZE * KERNEL_SIZE < 32){
                    __m256i cur_vec = (__m256i)_mm256_broadcast_pd((const __m128d*)(cur_patch));
                    for (int x_ = x - area_size; x_ < x + area_size; x_ += 2*step_exter, idx_x+=2){
                        __m256i pre_vec   = _mm256_loadu_si256 (reinterpret_cast<const __m256i*>(patch_SA[idx_x]));
                        __m256i temp_vec  = _mm256_subs_epu8(cur_vec, pre_vec);
                        pre_vec           = _mm256_subs_epu8(pre_vec, cur_vec);
                        pre_vec           = _mm256_adds_epu8(pre_vec, temp_vec);
                        //
                        __m128i tmp1 = _mm256_extracti128_si256(pre_vec,0);
                        temp_vec          = _mm256_cvtepu8_epi16(tmp1);
                        temp_vec          = _mm256_madd_epi16(temp_vec,temp_vec);
                        temp_vec          = _mm256_hadd_epi32(temp_vec, temp_vec);
                        tmp1 = _mm256_extracti128_si256(pre_vec,1);
                        pre_vec           = _mm256_cvtepu8_epi16(tmp1);  
                        pre_vec           = _mm256_madd_epi16(pre_vec,pre_vec);
                        pre_vec           = _mm256_hadd_epi32(pre_vec, pre_vec);
                        mse0 = 0;
                        mse1 = 0;

                        mse0 += _mm256_extract_epi32(temp_vec, 0);
                        mse0 += _mm256_extract_epi32(temp_vec, 1);
                        mse0 += _mm256_extract_epi32(temp_vec, 4);
                        mse0 += _mm256_extract_epi32(temp_vec, 5);
                        mse1 += _mm256_extract_epi32(pre_vec, 0);
                        mse1 += _mm256_extract_epi32(pre_vec, 1);
                        mse1 += _mm256_extract_epi32(pre_vec, 4);
                        mse1 += _mm256_extract_epi32(pre_vec, 5);
                        // ---------------------------------------------------------------------
                        if ( mse0 <= minVal) {
                            minVal = mse0;x_match = x_;y_match = y_;
                        }
                        if ( mse1 <= minVal) {
                            minVal = mse1;x_match = x_ + step_exter;y_match = y_;
                        }
                        if (x == x_ and y == y_) {
                            orinVal = mse0;
                        }
                        if (x == (x_ + step_exter) and y == y_) {
                            orinVal = mse1;
                        }
                    }
                }
                else if(KERNEL_SIZE * KERNEL_SIZE <= 64){
                    // ACC (r1-r2)*(r1-r2)
                    for (int x_ = x - area_size; x_ <= x + area_size; x_ += step_exter, idx_x++){
                        mse0        = 0;
                        context_pix = 0;
        
                        __m256i pre_vec1   = _mm256_loadu_si256 (reinterpret_cast<const __m256i*>(patch_SA[idx_x]));
                        __m256i pre_vec2   = _mm256_loadu_si256 (reinterpret_cast<const __m256i*>((unsigned char*)(patch_SA[idx_x]) + 32));

                        __m256i temp_vec   = _mm256_subs_epu8(cur_vec1, pre_vec1);
                        pre_vec1           = _mm256_subs_epu8(pre_vec1, cur_vec1);
                        pre_vec1           = _mm256_adds_epu8(pre_vec1, temp_vec);

                        //准确实现
                        temp_vec          = _mm256_cvtepu8_epi16(_mm256_extracti128_si256(pre_vec1,0));
                        temp_vec          = _mm256_madd_epi16(temp_vec,temp_vec);
                        pre_vec1           = _mm256_cvtepu8_epi16(_mm256_extracti128_si256(pre_vec1,1));  
                        pre_vec1           = _mm256_madd_epi16(pre_vec1, pre_vec1);
                        pre_vec1           = _mm256_add_epi32(pre_vec1, temp_vec);
                        pre_vec1           = _mm256_hadd_epi32(pre_vec1, pre_vec1);

                        //------------------------------近似实现----------------------------
                        // pre_vec1           = _mm256_maddubs_epi16(pre_vec1, _mm256_min_epu8(pre_vec1, mask_127));
                        // pre_vec1           = _mm256_madd_epi16(pre_vec1, mask_b);
                        // pre_vec1           = _mm256_hadd_epi32(pre_vec1, pre_vec1);

                        mse0 += _mm256_extract_epi32(pre_vec1, 0);
                        mse0 += _mm256_extract_epi32(pre_vec1, 1);
                        mse0 += _mm256_extract_epi32(pre_vec1, 4);
                        mse0 += _mm256_extract_epi32(pre_vec1, 5);
                        //------------------------------
                        
                        temp_vec           = _mm256_subs_epu8(cur_vec2, pre_vec2);
                        pre_vec2           = _mm256_subs_epu8(pre_vec2, cur_vec2);
                        pre_vec2           = _mm256_adds_epu8(pre_vec2, temp_vec);
                        //1
                        temp_vec          = _mm256_cvtepu8_epi16(_mm256_extracti128_si256(pre_vec2,0));
                        temp_vec          = _mm256_madd_epi16(temp_vec,temp_vec);
                        pre_vec2           = _mm256_cvtepu8_epi16(_mm256_extracti128_si256(pre_vec2,1));  
                        pre_vec2           = _mm256_madd_epi16(pre_vec2, pre_vec2);
                        pre_vec2           = _mm256_add_epi32(pre_vec2, temp_vec);
                        pre_vec2           = _mm256_hadd_epi32(pre_vec2, pre_vec2);
                        //2
                        // pre_vec2           = _mm256_maddubs_epi16(pre_vec2, _mm256_min_epu8(pre_vec2, mask_127));
                        // pre_vec2           = _mm256_madd_epi16(pre_vec2, mask_b);
                        if(KERNEL_SIZE==6){
                            mse0 += _mm256_extract_epi32(pre_vec2, 0);
                        }
                        else if(KERNEL_SIZE==8){
                            // pre_vec2           = _mm256_hadd_epi32(pre_vec2, pre_vec2);

                            mse0 += _mm256_extract_epi32(pre_vec2, 0);
                            mse0 += _mm256_extract_epi32(pre_vec2, 1);
                            mse0 += _mm256_extract_epi32(pre_vec2, 4);
                            mse0 += _mm256_extract_epi32(pre_vec2, 5);
                        }
                        // ---------------------------------------------------------------------
                        if ( mse0 < minVal) {
                            minVal = mse0;x_match = x_;y_match = y_;
                        }
                        if (x == x_ and y == y_) {
                            orinVal = mse0;
                        }
                     }
                }
                else{
                    return -1;
                }
            }
            // --------------------------------------------------------------------------------
            if (minVal == orinVal){
                x_match = x;
                y_match = y;
            }
            //Caculate abs of motion vector 
            float vec_abs =  abs(x - x_match) + abs(y - y_match );
            if(x_match==-1||y_match==-1){
                vec_abs = 0;
            }
            //Caculate sum_vec/cnt_vec to judge shake
            cnt_vec++;
            sum_vec += vec_abs;
            sum_vec_x += (x - x_match);
        }
    }
    mv_judge = sum_vec/cnt_vec;
    mv_x = sum_vec_x/cnt_vec;

    return mv_judge/scale;
}
#endif