#ifndef TAD_ALG_CONSTRUCTION_ENGINE_HPP
#define TAD_ALG_CONSTRUCTION_ENGINE_HPP

#include <memory>
#include <mutex>
#include <atomic>
#include <set>

#include "alg_engine_interface.hpp"

#include "core/flow_dispatch.hpp"
#include "serving/config.pb.h"
#include "common/Queue.h"

namespace prometheus{
    class Counter;
    typedef std::shared_ptr<Counter> spCounter;
}

namespace FLOW {

    namespace Detect {
        class DetectModule;
    }

    class ProfileMetric;
    typedef std::shared_ptr<ProfileMetric> spProfileMetric;

    // CAlgConstructionEngine
    class CAlgConstructionEngine : public ICAlgEngine{
    public:
        CAlgConstructionEngine() = default;
        virtual ~CAlgConstructionEngine() = default;

    public:
        virtual void Init(const inference::EngineConfig &config, int &code);
        virtual std::vector<int> GetDetectInputShapes() const;
        virtual void GetBatchFrames(VecImage &queue, VecImage &image_map) const;
        virtual void Process(CFlowDispatch &dsp);
        void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) override;

        virtual void AddStream(const std::string &channel_id, const std::string &config);
        virtual void RemoveStream(const std::string &channel_id);
        virtual void AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config);
        virtual void RemoveViolation(const std::string &channel_id, const std::string &violation_id);
        
    protected:
        struct ChannelUpdateData {
            std::string     channel_id_;
            bool            add;
        };
        typedef std::shared_ptr<ChannelUpdateData> spChannelUpdateData;

        struct ChannelData { // need all ptr
            std::string             channel_id_;
            prometheus::spCounter   detect_object_counter_;
            bool UpdateCfg(ChannelUpdateData update) {
                if (update.channel_id_ != channel_id_) {
                    return false;
                }
                return true;
            }
        };
        typedef std::shared_ptr<ChannelData> spChannelData;

        class safeChannelDataMap {
            public:
            spChannelData find(const std::string& key) const {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                return (it != map_.end()) ? it->second : nullptr;
            }
            spChannelData insert(const std::string& key, spChannelData value) {
                std::unique_lock<std::mutex> lock{lock_};
                auto old_value = map_[key];
                map_[key] = value;
                return old_value;
            }
            spChannelData erase(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                spChannelData old_value;
                if (it != map_.end()) {
                    old_value = it->second;
                    map_.erase(it);
                }
                return old_value;
            }
            typedef std::function<bool(const std::string&, spChannelData)> visiter;
            void visit(visiter v) const{
                std::unique_lock<std::mutex> lock{lock_};
                for(auto &kv : map_) {
                    if(!v(kv.first, kv.second)) {
                        break;
                    }
                }
            }
        protected:
            mutable std::mutex lock_;
            std::unordered_map<std::string, spChannelData> map_;
        };

    protected:
        void GetBatchFramesDetect(VecImage &queue, VecImage &image_map) const;
        void detectProcess(const VecImage &images);
        bool Skip(int64_t count) const;
        void PrintDetectInfo(const VecImage& images)const;

    protected:
        std::string config_str_;
        inference::Construction config_;
        std::vector<int> detect_input_shapes_;

    protected:
        std::mutex detect_lock_;
        std::shared_ptr<Detect::DetectModule> detector_ = nullptr;

    protected:
        spProfileMetric profile_metric_detector_;

    protected:
        safeChannelDataMap              channel_data_map_;
        Queue<spChannelUpdateData>      channel_data_update_queue_;
    };

}

#endif //TAD_ALG_CONSTRUCTION_ENGINE_HPP
