#ifndef TAD_ALG_GANGWEI_ENGINE_HPP
#define TAD_ALG_GANGWEI_ENGINE_HPP

#include <memory>
#include <mutex>
#include <atomic>
#include <set>

#include "alg_engine_interface.hpp"

#include "common/Queue.h"
#include "serving/config.pb.h"
#include "core/flow_dispatch.hpp"

namespace prometheus{
    class Counter;
    typedef std::shared_ptr<Counter> spCounter;
}

namespace FLOW {

    namespace Detect {
        class DetectModule;
    }
    namespace duchaMar{
        class DuchaMarModule;
    }

    class ProfileMetric;
    typedef std::shared_ptr<ProfileMetric> spProfileMetric;

    // CAlgGangweiEngine
    class CAlgGangweiEngine : public ICAlgEngine{
    public:
        CAlgGangweiEngine() = default;
        virtual ~CAlgGangweiEngine() = default;

    public:
        virtual void Init(const inference::EngineConfig &config, int &code);
        virtual void GetBatchFrames(VecImage &queue, VecImage &image_map) const;
        void GetBatchFramesDetect(VecImage &queue, VecImage &image_map) const;
        virtual void Process(CFlowDispatch &dsp);
        void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) override;

        virtual void AddStream(const std::string &channel_id, const std::string &config);
        virtual void RemoveStream(const std::string &channel_id);
        virtual void AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config);
        virtual void RemoveViolation(const std::string &channel_id, const std::string &violation_id);
        
    protected:
        class process_step_data {
        public:
            explicit process_step_data(VecImage data) 
                : data_(data)
                , status_(eWaitProcess)
            {}
            VecImage& Data() { return data_; }
            bool IsProcessing() { auto status = status_.load(); return status == eProcessing; }
            bool IsProcessed() { auto status = status_.load(); return status == eProcessed; }
            void SetProcessing() { status_ = eProcessing; }
            void SetProcessed() { status_ = eProcessed; }

        protected:
            enum _status{
                eWaitProcess, eProcessing, eProcessed,
            };
            VecImage data_;
            std::atomic<_status> status_;
        };
        typedef std::shared_ptr<process_step_data> process_step;

        struct ChannelUpdateData {
            std::string     channel_id_;
            bool            add;
            std::string     violation_id;
            float           fps;
        };
        typedef std::shared_ptr<ChannelUpdateData> spChannelUpdateData;

        struct ChannelData { // need all ptr
            typedef std::set<std::string> string_set;
            std::string         channel_id_;
            bool                has_detect_;
            int                 detect_interval_;
            string_set          violations;

            bool UpdateCfg(ChannelUpdateData update, const inference::Gangwei &config) {
                if (update.channel_id_ != channel_id_) {
                    return false;
                }
                if (update.add) {
                    this->violations.insert(update.violation_id);
                    this->has_detect_ = true;
                } else {
                    this->violations.erase(update.violation_id);
                    if (this->violations.empty()) {
                        this->has_detect_ = false;
                    }
                }

                // auto fps = update.fps;
                // if (fps <= 0.0f) {
                //     fps = 25;
                // }
                if (this->has_detect_) {
                    // auto detect_interval = (int)round(fps / config.attribute_fps());
                    // if (detect_interval <= 0) {
                    //     detect_interval = 1;
                    // }
                    this->detect_interval_ = 1;
                }

                return true;
            }
        };
        typedef std::shared_ptr<ChannelData> spChannelData;

        class safeChannelDataMap {
            public:
            spChannelData find(const std::string& key) const {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                return (it != map_.end()) ? it->second : nullptr;
            }
            spChannelData insert(const std::string& key, spChannelData value) {
                std::unique_lock<std::mutex> lock{lock_};
                auto old_value = map_[key];
                map_[key] = value;
                return old_value;
            }
            spChannelData erase(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                spChannelData old_value;
                if (it != map_.end()) {
                    old_value = it->second;
                    map_.erase(it);
                }
                return old_value;
            }
            typedef std::function<bool(const std::string&, spChannelData)> visiter;
            void visit(visiter v) const{
                std::unique_lock<std::mutex> lock{lock_};
                for(auto &kv : map_) {
                    if(!v(kv.first, kv.second)) {
                        break;
                    }
                }
            }
        protected:
            mutable std::mutex lock_;
            std::unordered_map<std::string, spChannelData> map_;
        };

    protected:
        void gangweiProcess(const VecImage &images);
        bool Skip(int64_t count, int interval) const;
        void PrintDetectInfo(const VecImage& images)const;

    protected:
       inference::Gangwei config_;

    protected:
        std::mutex gangwei_lock_;
        std::shared_ptr<Detect::DetectModule> detector_ = nullptr;
        std::shared_ptr<duchaMar::DuchaMarModule> gangweiMar_ = nullptr;

    protected:
        safeChannelDataMap              channel_data_map_;
        Queue<spChannelUpdateData>      channel_data_update_queue_;
#ifdef USE_MEDIA_UTILS
        std::unordered_map<std::string, float> violation_fps_map_;
#endif

    protected:
        std::list<process_step> detect_queue_;

        spProfileMetric profile_metric_detector_;
        spProfileMetric profile_metric_gangwei_mar_;
    };

}

#endif //TAD_ALG_GANGWEI_ENGINE_HPP
