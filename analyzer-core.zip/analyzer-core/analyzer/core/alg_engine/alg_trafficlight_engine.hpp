#ifndef TAD_ALG_TRAFFICLIGHT_ENGINE_HPP
#define TAD_ALG_TRAFFICLIGHT_ENGINE_HPP

#include <memory>
#include <mutex>
#include <atomic>
#include <functional>

#include "common/Queue.h"
#include "alg_engine_interface.hpp"
#include "serving/config.pb.h"

namespace prometheus{
    class Counter;
    typedef std::shared_ptr<Counter> spCounter;
}

namespace FLOW {

    namespace TrafficLight {
        class TrafficLightRecog;
    }

    class ProfileMetric;
    typedef std::shared_ptr<ProfileMetric> spProfileMetric;

    // CAlgTrafficlightEngine
    class CAlgTrafficlightEngine : public ICAlgEngine{
    public:
        CAlgTrafficlightEngine() = default;
        virtual ~CAlgTrafficlightEngine() = default;

    public:
        virtual void Init(const inference::EngineConfig &config, int &code);
        virtual void GetBatchFrames(VecImage &queue, VecImage &image_map) const;
        virtual void Process(CFlowDispatch &dsp);

        void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) override;
        virtual void AddStream(const std::string &channel_id, const std::string &config);
        virtual void RemoveStream(const std::string &channel_id);
        virtual void AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config);
        virtual void RemoveViolation(const std::string &channel_id, const std::string &violation_id);
        virtual AlgRender GetRender(const std::string &violation_code) const override;
        
    protected:
        struct ChannelData { // need all ptr
            std::string                         channel_id_;
            std::shared_ptr<RectF>              detect_roi_;
            std::shared_ptr<ImageObjectsInfo>   last_image_;
            int action_;
            std::map<std::string,int>           task_codes;
            std::string                         add_violation_;
            std::string                         add_violation_code_;
            std::string                         remove_violation_;
            typedef std::shared_ptr<VecBoxF> spVecBoxF;
            std::map<std::string,spVecBoxF>     trafficlight_boxes_;
            bool UpdateCfg(ChannelData other) {
                if ( other.channel_id_ != channel_id_ ) {
                    return false;
                }
                if ( other.detect_roi_ ) {
                    this->detect_roi_.swap(other.detect_roi_);
                }
                if ( other.last_image_ ) {
                    this->last_image_.swap(other.last_image_);
                }
                if ( ! other.trafficlight_boxes_.empty() ){
                    this->trafficlight_boxes_.insert(other.trafficlight_boxes_.begin(),other.trafficlight_boxes_.end());
                }

                if ( ! other.add_violation_.empty() ) {
                  auto it = this->task_codes.find(other.add_violation_);
                  if (it == this->task_codes.end()){
                   this->task_codes[other.add_violation_] = 1;
                  }else{
                    this->task_codes[other.add_violation_]++;
                  }
                }
                LOG(INFO)<<other.add_violation_<<"  "<<this->task_codes[other.add_violation_];
                if ( ! other.remove_violation_.empty() ) {
                  auto it = this->task_codes.find(other.remove_violation_);
                  if (it != this->task_codes.end()){
                    if (this->task_codes[other.remove_violation_] ==1){
                      this->task_codes.erase(it);
                    }else{
                      this->task_codes[other.remove_violation_]--;
                    }

                  }
                }
                return true;
            }
        };
        typedef std::shared_ptr<ChannelData> spChannelData;

        class safeChannelDataMap {
            public:
            spChannelData find(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                return (it != map_.end()) ? it->second : nullptr;
            }
            spChannelData insert(const std::string& key, spChannelData value) {
                std::unique_lock<std::mutex> lock{lock_};
                auto old_value = map_[key];
                map_[key] = value;
                return old_value;
            }
            spChannelData erase(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                spChannelData old_value;
                if (it != map_.end()) {
                    old_value = it->second;
                    map_.erase(it);
                }
                return old_value;
            }
        protected:
            mutable std::mutex lock_;
            std::unordered_map<std::string, spChannelData> map_;
        };

    protected:
        static void Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug=false);
        void TrafficLightProcess(const VecImage &images);
        void GetBatchFrames(VecImage &queue, VecImage &image_map, std::function<bool(int)> need_skip, int max_batch) const;
        bool ParseConfig(const std::string& json, std::string* code, VecBoxF *boxes, std::string* bg_img_path);
        static bool match_code(const std::string& code);

    protected:
        inference::TrafficLight config_;

    protected:
        Profiler trafficlight_profiler_;

        std::mutex trafficlight_lock_;
        std::shared_ptr<TrafficLight::TrafficLightRecog> trafficlight_engine_ = nullptr;

    protected:
        spProfileMetric profile_metric_trafficlight_;

    protected:
        safeChannelDataMap      channel_data_map_;
        Queue<spChannelData>    channel_data_update_queue_;

    };

}

#endif //TAD_ALG_TRAFFICLIGHT_ENGINE_HPP
