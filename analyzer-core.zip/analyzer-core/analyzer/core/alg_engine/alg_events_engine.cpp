#include <future>
#include <algorithm>
#include <vector>
#include "common/io.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"

#include "helper.hpp"
#include "alg_events_engine.hpp"
#include "core/flow_dispatch.hpp"

#include "serving/violation_config.pb.h"
#include "algorithm/weather/weather.hpp"
#include "algorithm/persondet/persondet.hpp"
#include "algorithm/leftobject/leftobject.hpp"
#include "algorithm/traffic_sign/traffic_sign.hpp"
#include "algorithm/fire/fire.hpp"
#include "algorithm/throwobject/throwobject.hpp"

namespace FLOW {

using namespace std;

static const std::string EVENTS_WEATHER_ENGINE    ("events-weather");
static const std::string EVENTS_BREAKIN_ENGINE    ("events-breakin");
static const std::string EVENTS_LEFTOBJECT_ENGINE ("events-leftobject");
static const std::string EVENTS_THROWOBJECT_ENGINE("events-throwobject");
static const std::string EVENTS_TRAFFICSIGN_ENGINE("events-trafficsign");
static const std::string EVENTS_FIRE_ENGINE       ("events-fire");

bool CAlgEventsEngine::match_code(const std::string& violation_code, std::string* engine_name) const {
  static const std::string WEATHER_CODE("2435");
  static const std::string BREAKIN_PERSIONCODE("2434");
  static const std::string BREAKIN_NONMOTOR_CODE2("2436");
  static const std::string LEFTOBJECT_CODE("2433");
  static const std::string THROWOBJECT_CODE("2438");
  static const std::string TRAFFIC_SIGN_CODE("2441");
  static const std::string FIRE_CODE("2437");

  static const std::unordered_map<std::string, std::string> VIOLATION_MAP = {
      //violation_code  <===> engine_name
      {WEATHER_CODE,            EVENTS_WEATHER_ENGINE},
      {BREAKIN_PERSIONCODE,     EVENTS_BREAKIN_ENGINE},
      {BREAKIN_NONMOTOR_CODE2,  EVENTS_BREAKIN_ENGINE},
      {LEFTOBJECT_CODE,         EVENTS_LEFTOBJECT_ENGINE},
      {THROWOBJECT_CODE,        EVENTS_THROWOBJECT_ENGINE},
      {TRAFFIC_SIGN_CODE,       EVENTS_TRAFFICSIGN_ENGINE},
      {FIRE_CODE,               EVENTS_FIRE_ENGINE},
  };
  auto itr = VIOLATION_MAP.find(violation_code.substr(0,4));
  auto found = (itr != VIOLATION_MAP.end());
  if (engine_name) {
    *engine_name = found ? itr->second : "";
  }
  return found;
}

void CAlgEventsEngine::Init(const inference::EngineConfig &config, int &code) {
    config_ = config.events();

  std::map<std::string, std::pair<inference::Algorithm, std::vector<char>>> params = {
      {"weather_model",             {config_.weather(),                   {}}},
      {"fire_model",                {config_.fire(),                      {}}},
      {"person_det_model",          {config_.break_in(),                  {}}},
      {"traffic_det_model",         {config_.left_object_traffic_det(),   {}}},
      {"leftobject_classify_model", {config_.left_object_classify(),      {}}},
      {"traffic_sign_model",        {config_.traffic_sign(),              {}}},
      {"throwobject_detect_model",  {config_.throwobject_detect(),        {}}},
  };
  for (auto &kv : params) {
    if (kv.second.first.model_path() == "") {
      LOG(WARNING) << "Skip load model " << kv.first << ", path: (" << kv.second.first.model_path() <<")";
      continue;
    }
    if (!IO::ReadBinaryFile(kv.second.first.model_path(), &kv.second.second)) {
      LOG(FATAL) << "Load model " << kv.first << " error, path: " << kv.second.first.model_path();
      return;
    }
  }

  if (config_.weather().model_path().length()) {
    weather_engine_ = make_shared<Weather::Weather>();
    weather_engine_->Setup(params["weather_model"].second, config_.weather());
  }

  if (config_.fire().model_path().length()) {
    fire_engine_ = make_shared<Fire::Fire>();
    fire_engine_->Setup(params["fire_model"].second, config_.fire());
  }

  if (config_.break_in().model_path().length()) {
    breakin_engine_ = make_shared<BreakIn::BreakInDetector>();
    breakin_engine_->Setup(params["person_det_model"].second, config_.break_in(), code);
  }

  if (config_.left_object_traffic_det().model_path().length() &&
      config_.left_object_classify().model_path().length()) {
    leftobject_detect_engine_ = make_shared<Leftobject::LeftobjectDetect>();
    leftobject_detect_engine_->Setup(params["traffic_det_model"].second, config_.left_object_traffic_det(), code);
    leftobject_classify_engine_ = make_shared<Leftobject::LeftobjectClassify>();
    leftobject_classify_engine_->Setup(params["leftobject_classify_model"].second, config_.left_object_classify(), code);
  }

  if (config_.left_object_traffic_det().model_path().length() &&
      config_.throwobject_detect().model_path().length()) {
    throwobject_detect_engine_ = make_shared<Throwobject::Throwobject>();
    throwobject_detect_engine_->Setup(params["throwobject_detect_model"].second, config_.throwobject_detect(), code);
    throwobject_vehicle_engine_ = make_shared<Throwobject::Throwobject>();
    throwobject_vehicle_engine_->SetupVehicle(params["traffic_det_model"].second, config_.left_object_traffic_det(), code);
  }

  if (config_.traffic_sign().model_path().length()) {
    traffic_sign_engine_ = make_shared<TrafficSign::TrafficSign >();
    traffic_sign_engine_->Setup(params["traffic_sign_model"].second, config_.traffic_sign());
  }

  // metric init
  typedef std::map<std::string, std::string> LablesType;
  const prometheus::Summary::Quantiles quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
  profile_metric_weather_         = std::make_shared<ProfileMetric>(LablesType{{"engine", "highway"}, {"model", "weather"     }}, quantiles);
  profile_metric_fire_            = std::make_shared<ProfileMetric>(LablesType{{"engine", "highway"}, {"model", "fire"        }}, quantiles);
  profile_metric_breakin_         = std::make_shared<ProfileMetric>(LablesType{{"engine", "highway"}, {"model", "breakin"     }}, quantiles);
  profile_metric_left_object_     = std::make_shared<ProfileMetric>(LablesType{{"engine", "highway"}, {"model", "left_object" }}, quantiles);
  profile_metric_traffic_sign_    = std::make_shared<ProfileMetric>(LablesType{{"engine", "highway"}, {"model", "traffic_sign"}}, quantiles);
  profile_metric_throw_object_    = std::make_shared<ProfileMetric>(LablesType{{"engine", "highway"}, {"model", "throw_object"}}, quantiles);
}

bool CAlgEventsEngine::SkipBreakIn(int64_t count){
  const auto remain = count % config_.break_in_interval_global();
  const auto max_remain = config_.break_in_interval_local() * config_.break_in_interval_last();
   if (remain < max_remain){
     return  remain % config_.break_in_interval_local();
   }
   return true;
}
 
void CAlgEventsEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
      LOG(FATAL) << "no implement";
}

void CAlgEventsEngine::GetBatchFrames(VecImage &queue, VecImage &images, std::function<bool(int)> need_skip, int max_batch) const {
  int count = 0;
  images.clear();
  for (auto it = queue.begin(); it != queue.end() && count < max_batch; ) {
    auto &frame = *it;
    if (!need_skip(frame->count)){
      count++;
      frame->highways.left_object_event.need_detect_flag = true;
      frame->highways.throw_object_event.need_detect_flag = true;
      images.push_back(frame);
    }
    else{
      frame->highways.left_object_event.need_detect_flag = false;
      frame->highways.throw_object_event.need_detect_flag = false;
    }
    it = queue.erase(it);
  }
}

void CAlgEventsEngine::Process(CFlowDispatch &dsp) {
  while (!channel_data_update_queue_.empty()) {
    auto new_data = channel_data_update_queue_.pop();
    auto& channel_id = new_data->channel_id_;
    if (auto old_data = channel_data_map_.find(new_data->channel_id_)) {
      auto copy_data = std::make_shared<ChannelData>(*old_data);
      if (copy_data->UpdateCfg(*new_data)) {
        channel_data_map_.insert(channel_id, copy_data);
      }
    }
    if (auto channel_data = channel_data_map_.find(channel_id)) {
      CFlowDispatch::spNode weather;
      CFlowDispatch::spNode breakin, leftobject, chin, chout;
      CFlowDispatch::spNode traffic_sign;
      CFlowDispatch::spNode fire;
      CFlowDispatch::spNode leftobject_detect, leftobject_vibe, leftobject_classify;
      CFlowDispatch::spNode throwobject, throwobject_vehicle;
      chin = dsp.get_node(channel_id, "in");
      chout = dsp.get_node(channel_id, "out");
      if (!chin || !chout) return;     
      if (new_data->action_ == ChannelData::ACTION_ADD_VIOLATION) {   // add violation
        std::string engine_name = new_data->engine_name_;
        if (EVENTS_WEATHER_ENGINE == engine_name &&
            1 == channel_data->highway_engines_.count(engine_name)){
          auto interval = config_.weather_interval();
          auto need_skip_fn = [interval](int count)->bool { return count % interval; };
          weather = dsp.add_node(channel_id, "events-weather", config_.detect_queue_size(), true);
          weather->process([this, need_skip_fn](VecImage &in) {
            VecImage frames;
            this->GetBatchFrames(in, frames, need_skip_fn, config_.weather().batch_size());
            if (!frames.empty()) {
              this->weatherProcess(frames);
            }
          });
          chin->next(weather);
          weather->next(chout);
        }
        else if (EVENTS_FIRE_ENGINE == engine_name &&
            1 == channel_data->highway_engines_.count(engine_name)){
          auto interval = config_.fire_interval();
          auto need_skip_fn = [interval](int count)->bool { return count % interval; };
          fire = dsp.add_node(channel_id, "events-fire", config_.detect_queue_size(), true);
          fire->process([this, need_skip_fn](VecImage &in) {
            VecImage frames;
            this->GetBatchFrames(in, frames, need_skip_fn, config_.fire().batch_size());
            if (!frames.empty()) {
              this->FireProcess(frames);
            }
          });
          chin->next(fire);
          fire->next(chout);
        }
        else if (EVENTS_BREAKIN_ENGINE == engine_name &&
            1 == (channel_data->highway_engines_.count(engine_name))){
          auto need_skip_fn = [this](int count)->bool { return this->SkipBreakIn(count); };
          breakin = dsp.add_node(channel_id, "events-breakin", config_.detect_queue_size(), true);
          breakin->process([this, need_skip_fn](VecImage &in) {
            VecImage frames;
            this->GetBatchFrames(in, frames, need_skip_fn, config_.break_in().batch_size());
            if (!frames.empty()) {
              this->BreakInProcess(frames);
            }
          });
          breakin->setSkipFunc([this](VecImage &in){
            VecImage frames_need;
            std::copy_if(in.begin(), in.end(), std::back_inserter(frames_need),
                         [this](const spImageObjectsInfo& image){ return !this->SkipBreakIn(image->count); });
            return frames_need;
          });
          chin->next(breakin);
          breakin->next(chout);
        }
        else if (EVENTS_LEFTOBJECT_ENGINE == engine_name &&
            1 == channel_data->highway_engines_.count(engine_name)) {
          auto interval = config_.left_object_interval_bg();
          auto need_skip_fn = [interval](int count)->bool {
              return  count % interval;
          };
          leftobject_detect = dsp.add_node(channel_id, "events-leftobject-detect", config_.detect_queue_size(), true);
          leftobject_detect->process([this, need_skip_fn](VecImage &in) {
            VecImage frames;
            this->GetBatchFrames(in, frames, need_skip_fn, config_.left_object_traffic_det().batch_size());
            if (!frames.empty()) {
              this->LeftobjectDetectProcess(frames);
            }
          });
          chin->next(leftobject_detect);

          leftobject_vibe = dsp.add_node(channel_id, "events-leftobject-vibe", config_.detect_queue_size());
          leftobject_vibe->process([this, channel_id](VecImage &in) {
              auto channel_data = this->channel_data_map_.find(channel_id);
              if (!in.empty()) {
                  this->LeftobjectVibeProcess(channel_data, in);
                  in.clear();
              }
          });
          leftobject_detect->next(leftobject_vibe);

          leftobject_classify = dsp.add_node(channel_id, "events-leftobject-classify", config_.detect_queue_size(), true);
          leftobject_classify->process([this, need_skip_fn](VecImage &in) {
              VecImage frames;
              this->GetBatchFrames(in, frames, need_skip_fn, config_.left_object_traffic_det().batch_size());
              if (!frames.empty()) {
                  this->LeftobjectClassifyProcess(frames);
              }
          });
          leftobject_vibe->next(leftobject_classify);
          leftobject_classify->next(chout);
        }
        else if (EVENTS_THROWOBJECT_ENGINE == engine_name &&
                 1 == channel_data->highway_engines_.count(engine_name)){
            auto interval = config_.throwobject_interval();
            auto throwobject_detect_threshold = config_.throwobject_detect().detect_threshold();
            auto need_skip_fn = [interval](int count)->bool { return count % interval; };
            throwobject = dsp.add_node(channel_id, "events-throwobject", config_.detect_queue_size());
            throwobject->process([this, need_skip_fn, channel_id](VecImage &in) {
                auto channel_data = this->channel_data_map_.find(channel_id);
                VecImage frames;
                this->GetBatchFrames(in, frames, need_skip_fn, config_.throwobject_detect().batch_size());
                if (!frames.empty()) {
                    this->ThrowobjectDetectProcess(channel_data, frames);
                }
            });
            chin->next(throwobject);

            throwobject_vehicle = dsp.add_node(channel_id, "throwobject-vehicle", config_.detect_queue_size());
            throwobject_vehicle->process([this, need_skip_fn](VecImage &in) {
              VecImage frames;
              this->GetBatchFrames(in, frames, need_skip_fn, config_.throwobject_detect().batch_size());
              if (!frames.empty()) {
                this->ThrowobjectVehicleProcess(frames);
              }
            });
            throwobject->next(throwobject_vehicle);
            throwobject_vehicle->next(chout);
        }
        else if (EVENTS_TRAFFICSIGN_ENGINE == engine_name &&
            1 == channel_data->highway_engines_.count(engine_name)){
          auto interval = config_.traffic_sign_interval();
          auto need_skip_fn = [interval](int count)->bool { return count % interval; };
          traffic_sign = dsp.add_node(channel_id, "events-trafficsign", config_.detect_queue_size(), true);
          traffic_sign->process([this, need_skip_fn](VecImage &in) {
            VecImage frames;
            this->GetBatchFrames(in, frames, need_skip_fn, config_.traffic_sign().batch_size());
            if (!frames.empty()) {
              this->TrafficSignProcess(frames);
            }
          });
          chin->next(traffic_sign);
          traffic_sign->next(chout);
        }
        else {
          // nop
        }
      } else if (new_data->action_ == ChannelData::ACTION_REMOVE_VIOLATION) { // remove violation
        std::string engine_name = new_data->engine_name_;
        if (EVENTS_WEATHER_ENGINE == engine_name &&
            0 == channel_data->highway_engines_.count(engine_name)){
          dsp.remove_node(channel_id, "events-weather");
        }
        if (EVENTS_FIRE_ENGINE == engine_name &&
            0 == channel_data->highway_engines_.count(engine_name)){
          dsp.remove_node(channel_id, "events-fire");
        }
        if (EVENTS_BREAKIN_ENGINE == engine_name &&
            0 == (channel_data->highway_engines_.count(engine_name))){
          dsp.remove_node(channel_id, "events-breakin");
        }
        if (EVENTS_LEFTOBJECT_ENGINE == engine_name &&
            0 == channel_data->highway_engines_.count(engine_name)){
          dsp.remove_node(channel_id, "events-leftobject-detect");
          dsp.remove_node(channel_id, "events-leftobject-vibe");
          dsp.remove_node(channel_id, "events-leftobject-classify");
        }
        if (EVENTS_THROWOBJECT_ENGINE == engine_name &&
            0 == channel_data->highway_engines_.count(engine_name)){
            dsp.remove_node(channel_id, "events-throwobject-detect");
        }
        if (EVENTS_TRAFFICSIGN_ENGINE == engine_name &&
            0 == channel_data->highway_engines_.count(engine_name)){
          dsp.remove_node(channel_id, "events-trafficsign");
        }
      }
    } else if (new_data->action_ == ChannelData::ACTION_REMOVE_STREAM) {
          dsp.remove_node(channel_id, "events-weather");
          dsp.remove_node(channel_id, "events-fire");
          dsp.remove_node(channel_id, "events-breakin");
          dsp.remove_node(channel_id, "events-leftobject");
          dsp.remove_node(channel_id, "events-throwobject");
          dsp.remove_node(channel_id, "events-trafficsign");
    }
  }
}

void CAlgEventsEngine::ProcessByName(const std::string &name,
                                     const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) {
}

void CAlgEventsEngine::weatherProcess(const VecImage &images) {
  if (nullptr == weather_engine_) { return; }
  std::unique_lock<std::mutex> lock{detect_weather_lock_};
  ProfilerHelper _profiler(
      &weather_profiler_, "weatherProcess",
      [](Profiler *p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });

  typedef std::function<bool(int)> TypeFilter;
  // detect
  VecImage image_detect;
  VecMat mat_detect;
  std::vector<cv::Rect> rois;
  std::vector<TypeFilter> det_types;
  // traffic light recog
  VecImage image_tlc;
  VecMat mat_tlc;
  VecBoxF boxes;

  for (auto &image : images) {
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }

    const auto &pic_mat = image->sframe->getMat();
    cv::Rect roi;
    if (channel_data->detect_roi_) {
      const auto &detect_roi = *(channel_data->detect_roi_);
      roi = cv::Rect(detect_roi.x, detect_roi.y, detect_roi.w, detect_roi.h);
    } else {
      roi = cv::Rect(0, 0, image->sframe->width(), image->sframe->height());
    }

    image_detect.push_back(image);
    mat_detect.push_back(pic_mat);
    rois.push_back(roi);
    det_types.push_back([](int type) -> bool { return true; });
  }

  int code = -1;
  weather_profiler_.tic("weather BatchPredict");
  std::vector<Weather_Event> events;
  {
    ProfileMetric::Helper _metric_helper(*profile_metric_weather_);
    weather_engine_->Process(mat_detect, events);
  }
  weather_profiler_.toc("weather BatchPredict");

  for (size_t i = 0; i < image_detect.size(); i++) {
    image_detect[i]->highways.weather_event = events[i];
  }
}

void CAlgEventsEngine::BreakInProcess(const VecImage &images) {
  if (nullptr == breakin_engine_) { return; }
  std::unique_lock<std::mutex> lock{detect_breakin_lock_};
  ProfilerHelper _profiler(&breakin_profiler_, "BreakInProcess", [](Profiler *p) {
    LOG(DEBUG) << "profiler " << p->get_stats_str();
  });

  typedef std::function<bool(int)> TypeFilter;
  // detect
  VecImage image_detect;
  VecMat mat_detect;
  std::vector<cv::Rect> rois;
  std::vector<TypeFilter> det_types;
  // traffic light recog
  VecImage image_tlc;
  VecMat mat_tlc;
  VecBoxF boxes;

  for (auto &image : images) {
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }

    const auto &pic_mat = image->sframe->getMat();
    cv::Rect roi;
    if (channel_data->detect_roi_) {
      const auto &detect_roi = *(channel_data->detect_roi_);
      roi = cv::Rect(detect_roi.x, detect_roi.y, detect_roi.w, detect_roi.h);
    } else {
      roi = cv::Rect(0, 0, image->sframe->width(), image->sframe->height());
    }

    image_detect.push_back(image);
    mat_detect.push_back(pic_mat);
    rois.push_back(roi);
    det_types.push_back([](int type) -> bool { return true; });
  }

  int code = -1;
  breakin_profiler_.tic("persondet BatchPredict");
  std::vector<BreakIn_Event> events;
  {
    ProfileMetric::Helper _metric_helper(*profile_metric_breakin_);
    breakin_engine_->Process(mat_detect, events);   
  }
  breakin_profiler_.toc("persondet BatchPredict");

  for (size_t i = 0; i < image_detect.size(); i++) {
    image_detect[i]->highways.break_in_event = events[i];
  }

}


void CAlgEventsEngine::LeftobjectVibeProcess(spChannelData channel, const VecImage &images) {
    std::unique_lock<std::mutex> lock{detect_leftobject_lock_};
    ProfilerHelper _profiler(&leftobject_profiler_, "leftobjectProcess",
                             [](Profiler* p){LOG(DEBUG) <<"profiler "<< p->get_stats_str();}
    );
    if (channel == nullptr) {
        return;
    }
    typedef std::function<bool(int)> TypeFilter;
    // detect
    VecImage image_detect;
    VecShellFrame mat_detect;
    std::vector<TypeFilter> det_types;

    std::vector<VecBoxF> detected_boxes;
    std::vector<bool>    need_detect_flags;

    for (auto &image : images) {
        if (image->ptz_pos.changed){
            channel->leftobject_engine_->Reset();
            continue;
        }
        auto channel_data = channel_data_map_.find(image->channel_id);
        if (nullptr == channel_data.get()) {
            continue;
        }
        image_detect.push_back(image);
        mat_detect.push_back(image->sframe);
        detected_boxes.push_back(image->highways.left_object_event.left_objects);
        need_detect_flags.push_back(image->highways.left_object_event.need_detect_flag);
    }

    leftobject_profiler_.tic("Leftobject BatchPredict");
    std::vector<LeftObject_Event> events;
    {
      ProfileMetric::Helper _metric_helper(*profile_metric_left_object_);
      channel->leftobject_engine_->Process(mat_detect, need_detect_flags, detected_boxes, events);
    }
    leftobject_profiler_.toc("Leftobject BatchPredict");

    for (size_t i = 0; i < image_detect.size(); i++) {
        image_detect[i]->highways.left_object_event.left_objects      = events[i].left_objects;
//        image_detect[i]->highways.left_object_event.need_detect_flag = need_detect_flags[i];
    }
}


void CAlgEventsEngine::LeftobjectDetectProcess(const VecImage &images) {
    if (nullptr == leftobject_detect_engine_) { return; }
    std::unique_lock<std::mutex> lock{detect_leftobject_detect_lock_};
    ProfilerHelper _profiler(&leftobject_profiler_, "leftobjectProcess",
                             [](Profiler* p){LOG(DEBUG) <<"profiler "<< p->get_stats_str();}
    );

    typedef std::function<bool(int)> TypeFilter;
    // detect
    VecImage image_detect;
    VecShellFrame mat_detect;
    std::vector<cv::Rect> rois;
    std::vector<TypeFilter> det_types;
    // traffic light recog
    VecImage image_tlc;
    VecMat mat_tlc;
    VecBoxF boxes;
    std::vector<LeftObject_Event> events;
    for (auto &image : images) {
        if (image->ptz_pos.changed){
            continue;
        }
        auto channel_data = channel_data_map_.find(image->channel_id);
        if (nullptr == channel_data.get()) {
            continue;
        }

        image_detect.push_back(image);
        mat_detect.push_back(image->sframe);
        det_types.push_back([](int type) -> bool { return true; });
        events.push_back(image->highways.left_object_event);
    }

    leftobject_profiler_.tic("Leftobject BatchPredict");
    {
      ProfileMetric::Helper _metric_helper(*profile_metric_left_object_);
      leftobject_detect_engine_->Process(mat_detect, events);
    }
    leftobject_profiler_.toc("Leftobject BatchPredict");

    for (size_t i = 0; i < image_detect.size(); i++) {
        image_detect[i]->highways.left_object_event.left_objects = events[i].left_objects;
    }
}


void CAlgEventsEngine::LeftobjectClassifyProcess(const VecImage &images) {
    if (nullptr == leftobject_classify_engine_) { return; }
    std::unique_lock<std::mutex> lock{detect_leftobject_classify_lock_};
    ProfilerHelper _profiler(&leftobject_profiler_, "leftobjectProcess",
                             [](Profiler* p){LOG(DEBUG) <<"profiler "<< p->get_stats_str();}
    );
    typedef std::function<bool(int)> TypeFilter;
    // detect
    VecImage image_detect;
    VecShellFrame mat_detect;
    std::vector<cv::Rect> rois;
    std::vector<TypeFilter> det_types;
    // traffic light recog
    VecImage image_tlc;
    VecMat mat_tlc;
    VecBoxF boxes;
    std::vector<LeftObject_Event> events;
    std::vector<VecBoxF> vibe_boxes;
    for (auto &image : images) {
        if (image->ptz_pos.changed){
            continue;
        }
        auto channel_data = channel_data_map_.find(image->channel_id);
        if (nullptr == channel_data.get()) {
            continue;
        }

        image_detect.push_back(image);
        mat_detect.push_back(image->sframe);
        det_types.push_back([](int type) -> bool { return true; });
        vibe_boxes.push_back(image->highways.left_object_event.left_objects);
    }

    leftobject_profiler_.tic("Leftobject BatchPredict");
    {
      ProfileMetric::Helper _metric_helper(*profile_metric_left_object_);
      leftobject_classify_engine_->Process(mat_detect, vibe_boxes, events);
    }
    leftobject_profiler_.toc("Leftobject BatchPredict");

    for (size_t i = 0; i < image_detect.size(); i++) {
        image_detect[i]->highways.left_object_event.left_objects = events[i].left_objects;
    }
}

void CAlgEventsEngine::ThrowobjectDetectProcess(spChannelData channel, const VecImage &images) {
    if (nullptr==throwobject_detect_engine_ || nullptr==throwobject_vehicle_engine_ ) { return; }
    if (nullptr==channel) { return; }
    std::unique_lock<std::mutex> lock{detect_throwobject_lock_};
    ProfilerHelper _profiler(&throwobject_profiler_, "throwobjectProcess",
                             [](Profiler* p){LOG(DEBUG) <<"profiler "<< p->get_stats_str();}
    );

    typedef std::function<bool(int)> TypeFilter;
    // detect
    VecImage image_detect;
    VecMat mat_detect;
    std::vector<cv::Rect> rois;
    std::vector<TypeFilter> det_types;
    VecBoxF boxes;
    std::vector<ThrowObject_Event> events;
    for (auto &image : images) {
        if (image->ptz_pos.changed){
            continue;
        }
        auto channel_data = channel_data_map_.find(image->channel_id);
        if (nullptr == channel_data.get()) {
            continue;
        }

        const auto &pic_mat = image->sframe->getMat();
        image_detect.push_back(image);
        mat_detect.push_back(pic_mat);
        det_types.push_back([](int type) -> bool { return true; });
        events.push_back(image->highways.throw_object_event);
    }
    throwobject_profiler_.tic("Throwobject BatchPredict");
    {
        ProfileMetric::Helper _metric_helper(*profile_metric_throw_object_);
        throwobject_detect_engine_->Process(mat_detect, events);
    }
    throwobject_profiler_.toc("Throwobject BatchPredict");

    for (size_t i = 0; i < image_detect.size(); i++) {
        image_detect[i]->highways.throw_object_event.throw_objects = events[i].throw_objects;
    }
}

void CAlgEventsEngine::ThrowobjectVehicleProcess(const VecImage &images) {
  std::unique_lock<std::mutex> lock{throwobject_vehicle_lock_};
  ProfilerHelper _profiler(
      &throwobject_profiler_, "throwobject_profiler_",
      [](Profiler *p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });

  typedef std::function<bool(int)> TypeFilter;
  //Vehicle Filter
  VecImage image_detect;
  VecMat mat_detect;
  std::vector<TypeFilter> det_types;

  std::vector<VecBoxF> Cboxes;

  for (auto &image : images) {
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }

    const auto &pic_mat = image->sframe->getMat();
    image_detect.push_back(image);
    mat_detect.push_back(pic_mat);
    Cboxes.push_back(image->highways.throw_object_event.throw_objects);
    det_types.push_back([](int type) -> bool { return true; });
  }

  throwobject_profiler_.tic("ThrowobjectVehicle BatchPredict");
  std::vector<ThrowObject_Event> events;
  {
    ProfileMetric::Helper _metric_helper(*profile_metric_throw_object_);
    throwobject_vehicle_engine_->VehicleProcess(mat_detect, Cboxes, events);
  }
  throwobject_profiler_.toc("ThrowobjectVehicle BatchPredict");

  for (size_t i = 0; i < image_detect.size(); i++) {
    image_detect[i]->highways.throw_object_event.vehicle_objects = events[i].vehicle_objects;
  }
}

void CAlgEventsEngine::TrafficSignProcess(const VecImage &images) {
  if (nullptr == traffic_sign_engine_) { return; }
  std::unique_lock<std::mutex> lock{traffic_sign_lock_};
  ProfilerHelper _profiler(&traffic_sign_profiler_, "Traffic_sign", [](Profiler *p) {
    LOG(DEBUG) << "profiler " << p->get_stats_str();
  });
  for (auto image :images)
    LOG(INFO)<<"processing image pts = "<< image->pts;

  typedef std::function<bool(int)> TypeFilter;
  // detect
  VecImage image_detect;
  VecMat mat_detect;
  std::vector<cv::Rect> rois;
  std::vector<TypeFilter> det_types;
  // traffic light recog
  VecImage image_tlc;
  VecMat mat_tlc;
  VecBoxF boxes;

  for (auto &image : images) {
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }

    const auto &pic_mat = image->sframe->getMat();
    cv::Rect roi;
    if (channel_data->detect_roi_) {
      const auto &detect_roi = *(channel_data->detect_roi_);
      roi = cv::Rect(detect_roi.x, detect_roi.y, detect_roi.w, detect_roi.h);
    } else {
      roi = cv::Rect(0, 0, image->sframe->width(), image->sframe->height());
    }

    image_detect.push_back(image);
    mat_detect.push_back(pic_mat);
    rois.push_back(roi);
    det_types.push_back([](int type) -> bool { return true; });
  }

  int code = -1;
  traffic_sign_profiler_.tic("Traffic_sign BatchPredict");
  std::vector<TrafficSign_Event> events;
  {
    ProfileMetric::Helper _metric_helper(*profile_metric_traffic_sign_);
    traffic_sign_engine_->Process(mat_detect, events);
  }
  traffic_sign_profiler_.toc("Traffic_sign BatchPredict");

  for (size_t i = 0; i < image_detect.size(); i++) {
    image_detect[i]->highways.traffic_sign_event = events[i];
    if (events[i].traffic_signs.size()> 0) {
      LOG(INFO) << "find traffic sign obj in pts = "<<images[i]->pts 
                <<", count="<<events[i].traffic_signs.size();
    }
  }

}

void CAlgEventsEngine::FireProcess(const VecImage &images) {
  if (nullptr == fire_engine_) { return; }
  std::unique_lock<std::mutex> lock{detect_fire_lock_};
  ProfilerHelper _profiler(
      &fire_profiler_, "FireProcess",
      [](Profiler *p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });

  typedef std::function<bool(int)> TypeFilter;
  // detect
  VecImage image_detect; 
  VecMat mat_detect;
  std::vector<cv::Rect> rois;
  std::vector<TypeFilter> det_types;

  for (auto &image : images) {
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }

    const auto &pic_mat = image->sframe->getMat();
    cv::Rect roi;
    if (channel_data->detect_roi_) {
      const auto &detect_roi = *(channel_data->detect_roi_);
      roi = cv::Rect(detect_roi.x, detect_roi.y, detect_roi.w, detect_roi.h);
    } else {
      roi = cv::Rect(0, 0, image->sframe->width(), image->sframe->height());
    }

    image_detect.push_back(image);
    mat_detect.push_back(pic_mat);
    rois.push_back(roi);
    det_types.push_back([](int type) -> bool { return true; });
  }

  int code = -1;
  fire_profiler_.tic("fire BatchPredict");
  std::vector<Fire_Event> events;
  {
    ProfileMetric::Helper _metric_helper(*profile_metric_fire_);
    fire_engine_->Process(mat_detect, events);
  }
  fire_profiler_.toc("fire BatchPredict");

  for (size_t i = 0; i < image_detect.size(); i++) {
    events[i].processed = true;
    image_detect[i]->highways.fire_event = events[i];
  }
}
void CAlgEventsEngine::AddStream(const std::string &channel_id,
                                 const std::string &config) {
  int code = 0;
  auto channel_data = channel_data_map_.find(channel_id);
  if (nullptr == channel_data.get()) {
    channel_data = std::make_shared<ChannelData>();
    channel_data->channel_id_ = channel_id;
    channel_data->last_image_ = std::make_shared<ImageObjectsInfo>();
    channel_data->leftobject_engine_ = std::make_shared<Leftobject::Leftobject>();
    channel_data_map_.insert(channel_id, channel_data);
  }
}
void CAlgEventsEngine::RemoveStream(const std::string &channel_id) {
  channel_data_map_.erase(channel_id);

  auto vdata = std::make_shared<ChannelData>();
  vdata->channel_id_ = channel_id;
  vdata->action_ = ChannelData::ACTION_REMOVE_STREAM;
  channel_data_update_queue_.push(vdata);
}

void CAlgEventsEngine::AddViolation(const std::string &channel_id,
                                    const std::string &violation_id,
                                    const std::string &config) {
  auto channel_data_old = channel_data_map_.find(channel_id);
  if (channel_data_old) {
    string roi_cfg;
    {
      auto data = std::make_shared<inference::ViolationConfig>();
      string err;
      json2pb(config, data.get(), &err);
      inference::Roi roi;
      *roi.mutable_data() = data->roi();
      pb2json(&roi, &roi_cfg);
    }
    std::string violation_code, engine_name;
    auto channel_data = std::make_shared<ChannelData>();
    channel_data->channel_id_ = channel_id;
    channel_data->action_ = ChannelData::ACTION_ADD_VIOLATION;
    if (parse_violation_code(config, violation_code) &&
        match_code(violation_code, &engine_name)) {
      channel_data->violation_code_ = violation_code;
      channel_data->engine_name_    = engine_name;
      channel_data->violation_id_   = violation_id;
      channel_data_update_queue_.push(channel_data);
    }
  }
}

void CAlgEventsEngine::RemoveViolation(const std::string &channel_id,
                                       const std::string &violation_id) {
  auto channel_data = channel_data_map_.find(channel_id);
  if (channel_data) {
    //channel_data->tracker_->RemoveStreamRoiConfig(violation_id);
    auto vdata = std::make_shared<ChannelData>();
    vdata->channel_id_ = channel_id;
    vdata->action_ = ChannelData::ACTION_REMOVE_VIOLATION;
    vdata->violation_id_ = violation_id;
    channel_data_update_queue_.push(vdata);
  }
}

}  // namespace FLOW

