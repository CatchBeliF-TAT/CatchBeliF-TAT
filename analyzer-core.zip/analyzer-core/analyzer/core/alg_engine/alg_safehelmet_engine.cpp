#include <future>
#include <algorithm>
#include <vector>
#include "common/io.hpp"
#include "common/pbjson.hpp"
#include "common/util_scale.hpp"
#include "common/tad_internal.hpp"

#include "helper.hpp"
#include "alg_safehelmet_engine.hpp"
#include "core/flow_dispatch.hpp"
#include "helper.hpp"

#include "serving/violation_config.pb.h"
#include "algorithm/safehelmet/safehelmet.hpp"


namespace FLOW {

using namespace std;

void CAlgSafehelmetEngine::Init(const inference::EngineConfig &config, int &code) {
    config_ = config.safehelmet();

  std::map<std::string, std::pair<inference::Algorithm, std::vector<char>>> params = {
      {"head_person_model", {config_.head_person(),   {}}},
      {"classfy_model",     {config_.classfy(),       {}}},
      {"vehicle_model",     {config_.vehicle(),       {}}},
  };
  for (auto &kv : params) {
    if (!IO::ReadBinaryFile(kv.second.first.model_path(), &kv.second.second)) {
      LOG(FATAL) << "Load model " << kv.first << " error, path: " << kv.second.first.model_path();
      return;
    }
  }

  safehelmet_engine_ = make_shared<Safehelmet::Safehelmet>();
  safehelmet_engine_->Setup_head_person(params["head_person_model"].second, config_.head_person(), code);
  safehelmet_engine_->Setup_classfy(params["classfy_model"].second, config_.classfy(), code);
  safehelmet_engine_->Setup_vehicle(params["vehicle_model"].second, config_.vehicle(), code);
        
  // metric init
  typedef std::map<std::string, std::string> LablesType;
  const prometheus::Summary::Quantiles quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
  profile_metric_safehelmet_ = std::make_shared<ProfileMetric>(LablesType{{"engine", "safehelmet"}, {"model", "safehelmet"}}, quantiles);
}

void CAlgSafehelmetEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
    LOG(FATAL) << "no implement";
}

void CAlgSafehelmetEngine::GetBatchFrames(VecImage &queue, VecImage &images, std::function<bool(int)> need_skip, int max_batch) const {
    int count = 0;
    images.clear();
    for (auto it = queue.begin(); it != queue.end() && count < max_batch; ) {
        auto &frame = *it;
        if (!need_skip(frame->count)){
            count++;
            images.push_back(frame);
        }
        it = queue.erase(it);
    }
}

void CAlgSafehelmetEngine::Process(CFlowDispatch &dsp) {
  while (!channel_data_update_queue_.empty()) {
    auto new_data = channel_data_update_queue_.pop();
    auto& channel_id = new_data->channel_id_;
    if (auto old_data = channel_data_map_.find(new_data->channel_id_)) {
      auto copy_data = std::make_shared<ChannelData>(*old_data);
      if (copy_data->UpdateCfg(*new_data)) {
        channel_data_map_.insert(channel_id, copy_data);
      }
    }
    if (auto channel_data = channel_data_map_.find(channel_id)) {
        const std::string SAFEHELMET_CODE("26");
        const std::string NOSAFEHELMET_CODE("27");
//        CFlowDispatch::spNode safehelmet, chin, chout;
        CFlowDispatch::spNode safehelmet_head_person_detect, safehelmet_resize_crop, safehelmet_classfy, safehelmet_vehicle, chin, chout;
        chin = dsp.get_node(channel_id, "in");
        chout = dsp.get_node(channel_id, "out");
        if (!chin || !chout) return;
        if (new_data->action_ == 1) {   // add violation
            if ((SAFEHELMET_CODE == new_data->add_violation_ &&
                1 == channel_data->safehelmet_task_codes.count(SAFEHELMET_CODE)) ||
                (NOSAFEHELMET_CODE == new_data->add_violation_ &&
                1 == channel_data->safehelmet_task_codes.count(NOSAFEHELMET_CODE))) {
                auto safehelmet_detect_interval = config_.safehelmet_detect_interval();
                auto head_person_detect_threshold = config_.head_person().detect_threshold();
                auto classfy_thresholds = config_.classfy().detect_thresholds();
                auto vehicle_detect_threshold = config_.vehicle().detect_threshold();

                auto need_skip_fn = [safehelmet_detect_interval](int count) -> bool {
                    return count % safehelmet_detect_interval;
                };
                safehelmet_head_person_detect = dsp.add_node(channel_id, "safehelmet-head-person-detect",
                                                             config_.detect_queue_size(), true);
                safehelmet_head_person_detect->process([this, need_skip_fn](VecImage &in) {
                    VecImage frames;
                    this->GetBatchFrames(in, frames, need_skip_fn, config_.head_person().batch_size());
                    if (!frames.empty()) {
                        this->SafehelmetHeadPersonDetectProcess(frames);
                    }
                });
                chin->next(safehelmet_head_person_detect);

                safehelmet_resize_crop = dsp.add_node(channel_id, "safehelmet-classify",
                                                             config_.detect_queue_size(), true);
                safehelmet_resize_crop->process([this, need_skip_fn](VecImage &in) {
                    VecImage frames;
                    this->GetBatchFrames(in, frames, need_skip_fn, 100);//resize不需要组batch
                    if (!frames.empty()) {
                        this->SafehelmetResizeCropProcess(frames);
                    }
                });
                safehelmet_head_person_detect->next(safehelmet_resize_crop);

                safehelmet_classfy = dsp.add_node(channel_id, "safehelmet-classfy", config_.detect_queue_size(), true);
                safehelmet_classfy->process([this, need_skip_fn](VecImage &in) {
                    VecImage frames;
                    this->GetBatchFrames(in, frames, need_skip_fn, config_.classfy().batch_size());
                    if (!frames.empty()) {
                        this->SafehelmetClassfyProcess(frames);
                    }
                });
                safehelmet_resize_crop->next(safehelmet_classfy);

                safehelmet_vehicle = dsp.add_node(channel_id, "safehelmet-vehicle", config_.detect_queue_size(), true);
                safehelmet_vehicle->process([this, need_skip_fn](VecImage &in) {
                    VecImage frames;
                    this->GetBatchFrames(in, frames, need_skip_fn, config_.classfy().batch_size());
                    if (!frames.empty()) {
                        this->SafehelmetVehicleProcess(frames);
                    }
                });
                safehelmet_classfy->next(safehelmet_vehicle);
                safehelmet_vehicle->next(chout);
            } else {
                // nop
            }
        } else if (new_data->action_ == 2) { // remove violation
            if ((SAFEHELMET_CODE == new_data->remove_violation_ &&
                0 == channel_data->safehelmet_task_codes.count(SAFEHELMET_CODE)) ||
                (NOSAFEHELMET_CODE == new_data->remove_violation_ &&
                0 == channel_data->safehelmet_task_codes.count(NOSAFEHELMET_CODE))) {
//          dsp.remove_node(channel_id, "cloud-safehelmet");
                dsp.remove_node(channel_id, "safehelmet-head-person-detect");
                dsp.remove_node(channel_id, "safehelmet-classfy");
                dsp.remove_node(channel_id, "safehelmet-vehicle");
            }
        }
    }
//    } else if (new_data->action_ == 2) {
//          dsp.remove_node(channel_id, "cloud-safehelmet");
//    }
  }
}

void CAlgSafehelmetEngine::ProcessByName(const std::string &name,
                                         const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) {
}

void CAlgSafehelmetEngine::SafehelmetHeadPersonDetectProcess(const VecImage &images) {
    std::unique_lock<std::mutex> lock{safehelmet_head_person_detect_lock_};
    ProfilerHelper _profiler(
            &safehelmet_head_person_detect_profiler_, "SafehelmetHeadPersonDetectProcess",
            [](Profiler *p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });

    typedef std::function<bool(int)> TypeFilter;
    // detect
    VecImage image_detect;
    VecMat mat_detect;
    std::vector<TypeFilter> det_types;

    for (auto &image : images) {
        auto channel_data = channel_data_map_.find(image->channel_id);
        if (nullptr == channel_data.get()) {
            continue;
        }

        const auto &pic_mat = image->sframe->getMat();
        image_detect.push_back(image);
        mat_detect.push_back(pic_mat);
        det_types.push_back([](int type) -> bool { return true; });
    }

    safehelmet_head_person_detect_profiler_.tic("SafehelmetHeadPersonDetect BatchPredict");
    std::vector<SafeHelmet_Event> events;
    {
        ProfileMetric::Helper _metric_helper(*profile_metric_safehelmet_);
        safehelmet_engine_->HeadPersonProcess(mat_detect, events);
    }
    safehelmet_head_person_detect_profiler_.toc("SafehelmetHeadPersonDetect BatchPredict");

    for (size_t i = 0; i < image_detect.size(); i++) {
        image_detect[i]->clouds.safe_helmet_event.safe_helmets = events[i].safe_helmets;
    }
}

void CAlgSafehelmetEngine::SafehelmetResizeCropProcess(const VecImage &images) {
    std::unique_lock<std::mutex> lock{safehelmet_resize_crop_lock_};


    VecImage image_detect;
    VecMat mat_detect;
    std::vector<SafeHelmet_Event> events;

    for (auto &image : images) {
        auto channel_data = channel_data_map_.find(image->channel_id);
        if (nullptr == channel_data.get()) {
            continue;
        }

        const auto &pic_mat = image->sframe->getMat();
        image_detect.push_back(image);
        mat_detect.push_back(pic_mat);
        events.push_back(image->clouds.safe_helmet_event);
    }

    {
        safehelmet_engine_->ResizeAndCrop(mat_detect, events);
    }

    for (size_t i = 0; i < image_detect.size(); i++) {
        image_detect[i]->clouds.safe_helmet_event.safehelmets_mat = events[i].safehelmets_mat;
    }
}

void CAlgSafehelmetEngine::SafehelmetClassfyProcess(const VecImage &images) {
    std::unique_lock<std::mutex> lock{safehelmet_classfy_lock_};
    ProfilerHelper _profiler(
            &safehelmet_classfy_profiler_, "SafehelmetClassfyProcess",
            [](Profiler *p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });

    //classfy
    std::vector<SafeHelmet_Event> events;
    VecImage image_detect;
    for (auto &image : images) {
        auto channel_data = channel_data_map_.find(image->channel_id);
        if (nullptr == channel_data.get()) {
            continue;
        }
        image_detect.push_back(image);
        events.push_back(image->clouds.safe_helmet_event);
    }

    safehelmet_classfy_profiler_.tic("SafehelmetClassfy BatchPredict");
    {
        ProfileMetric::Helper _metric_helper(*profile_metric_safehelmet_);
        safehelmet_engine_->ClassfyProcess(events);
    }
    safehelmet_classfy_profiler_.toc("SafehelmetClassfy BatchPredict");

    for (size_t i = 0; i < image_detect.size(); i++) {
        image_detect[i]->clouds.safe_helmet_event.safe_helmets = events[i].safe_helmets;
    }
}

void CAlgSafehelmetEngine::SafehelmetVehicleProcess(const VecImage &images) {
    std::unique_lock<std::mutex> lock{safehelmet_vehicle_lock_};
    ProfilerHelper _profiler(
            &safehelmet_vehicle_profiler_, "SafehelmetVehicleProcess",
            [](Profiler *p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });

    typedef std::function<bool(int)> TypeFilter;
    //Vehicle Filter
    VecImage image_detect;
    VecMat mat_detect;
    std::vector<TypeFilter> det_types;

    std::vector<VecBoxF> Cboxes;

    for (auto &image : images) {
        auto channel_data = channel_data_map_.find(image->channel_id);
        if (nullptr == channel_data.get()) {
            continue;
        }

        const auto &pic_mat = image->sframe->getMat();
        image_detect.push_back(image);
        mat_detect.push_back(pic_mat);
        Cboxes.push_back(image->clouds.safe_helmet_event.safe_helmets);
        det_types.push_back([](int type) -> bool { return true; });
    }

    safehelmet_vehicle_profiler_.tic("SafehelmetVehicle BatchPredict");
    std::vector<SafeHelmet_Event> events;
    {
        ProfileMetric::Helper _metric_helper(*profile_metric_safehelmet_);
        safehelmet_engine_->VehicleProcess(mat_detect, Cboxes, events);
    }
    safehelmet_vehicle_profiler_.toc("SafehelmetVehicle BatchPredict");

    for (size_t i = 0; i < image_detect.size(); i++) {
        image_detect[i]->clouds.safe_helmet_event.safe_helmets = events[i].safe_helmets;
    }
}

void CAlgSafehelmetEngine::AddStream(const std::string &channel_id,
                                 const std::string &config) {
  int code = 0;
  auto channel_data = channel_data_map_.find(channel_id);
  if (nullptr == channel_data.get()) {
    channel_data = std::make_shared<ChannelData>();
    channel_data->channel_id_ = channel_id;
    channel_data->last_image_ = std::make_shared<ImageObjectsInfo>();
    channel_data_map_.insert(channel_id, channel_data);
  }
}
void CAlgSafehelmetEngine::RemoveStream(const std::string &channel_id) {
  channel_data_map_.erase(channel_id);

  auto vdata = std::make_shared<ChannelData>();
  vdata->channel_id_ = channel_id;
  vdata->action_ = 2;
  channel_data_update_queue_.push(vdata);
}

void CAlgSafehelmetEngine::AddViolation(const std::string &channel_id,
                                    const std::string &violation_id,
                                    const std::string &config) {
  auto channel_data_old = channel_data_map_.find(channel_id);
  if (channel_data_old) {
    string roi_cfg;
    {
      auto data = std::make_shared<inference::ViolationConfig>();
      string err;
      json2pb(config, data.get(), &err);
      inference::Roi roi;
      *roi.mutable_data() = data->roi();
      pb2json(&roi, &roi_cfg);
    }
    std::string violation_code;
    auto channel_data = std::make_shared<ChannelData>();
    channel_data->channel_id_ = channel_id;
    channel_data->action_ =1;
    if (parse_violation_code(config, violation_code)) {
      channel_data->add_violation_ = violation_code;
    }
    channel_data_update_queue_.push(channel_data);
  }
}

void CAlgSafehelmetEngine::RemoveViolation(const std::string &channel_id,
                                       const std::string &violation_id) {
  auto channel_data = channel_data_map_.find(channel_id);
  if (channel_data) {
    //channel_data->tracker_->RemoveStreamRoiConfig(violation_id);
    auto vdata = std::make_shared<ChannelData>();
    vdata->channel_id_ = channel_id;
    vdata->action_ = 2;
    vdata->remove_violation_ = violation_id;
    channel_data_update_queue_.push(vdata);
  }
}

AlgRender CAlgSafehelmetEngine::GetRender(const std::string &violation_code) const {
  if(violation_code == "26" || violation_code == "27" ) {
      return CAlgSafehelmetEngine::Render;
  }
  return nullptr;
}

void CAlgSafehelmetEngine::Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug){
    if (!enable_tracking_debug) return;
    const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
    for (auto &object : image_objects.clouds.safe_helmet_event.safe_helmets) {
        cv::Scalar scalar;
        auto text = std::to_string(object.label)+"_"+std::to_string(object.score);
        if(0 == object.label){//戴了
            scalar = cv::Scalar(0, 255, 0);
        }
        else if(1 == object.label){//没戴
            scalar = cv::Scalar(255, 0, 0);
        }
        cv::putText(*mat, text,
                    cv::Point(object.xmin, object.ymin - 10)*scale,
                    cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);
        cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                      cv::Point(object.xmax, object.ymax)*scale, scalar, 2);

    }
}


}  // namespace FLOW

