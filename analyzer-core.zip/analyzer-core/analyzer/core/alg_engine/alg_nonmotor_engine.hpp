#ifndef TAD_ALG_NONMOTOR_ENGINE_HPP
#define TAD_ALG_NONMOTOR_ENGINE_HPP

#include <memory>
#include <mutex>
#include <atomic>

#include "core/flow_dispatch.hpp"
#include "serving/config.pb.h"

#include "alg_vehicle_engine.hpp"

namespace prometheus{
    class Counter;
    typedef std::shared_ptr<Counter> spCounter;
}

namespace FLOW {
    // CAlgVehicleEngine
    class CAlgNonmotorEngine : public CAlgVehicleEngine {
    public:
        CAlgNonmotorEngine() = default;
        virtual ~CAlgNonmotorEngine() = default;
        virtual std::vector<int> GetDetectInputShapes()const;

    public:
        virtual void Init(const inference::EngineConfig &config, int &code);
        void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) override;
        inference::Nonmotor config_;
        std::vector<int>  detect_input_shapes;
    
    protected:
        virtual bool needAtrrBox(const BoxF& box);
        spProfileMetric profile_metric_waimai_plate_;
        spProfileMetric profile_metric_behaviour_attr_;
    };

} // namespace FLOW

#endif //TAD_ALG_NONMOTOR_ENGINE_HPP
