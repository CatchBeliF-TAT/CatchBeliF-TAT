#ifndef TAD_ALG_FALL_ENGINE_HPP
#define TAD_ALG_FALL_ENGINE_HPP

#include <atomic>
#include <functional>
#include <memory>
#include <mutex>

#include "alg_engine_interface.hpp"
#include "common/Queue.h"
#include "serving/config.pb.h"

namespace prometheus {
class Counter;
typedef std::shared_ptr<Counter> spCounter;
}  // namespace prometheus

namespace FLOW {

namespace Fall {
class Fall;
}

class ProfileMetric;
typedef std::shared_ptr<ProfileMetric> spProfileMetric;

// CAlgFallEngine
class CAlgFallEngine : public ICAlgEngine {
 public:
  CAlgFallEngine() = default;
  virtual ~CAlgFallEngine() = default;

 public:
  virtual void Init(const inference::EngineConfig& config, int& code);
  virtual void GetBatchFrames(VecImage& queue, VecImage& image_map) const;
  virtual void Process(CFlowDispatch& dsp);

  void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame,
                     VecBoxF& boxes) override;
  virtual void AddStream(const std::string& channel_id,
                         const std::string& config);
  virtual void RemoveStream(const std::string& channel_id);
  virtual void AddViolation(const std::string& channel_id,
                            const std::string& violation_id,
                            const std::string& config);
  virtual void RemoveViolation(const std::string& channel_id,
                               const std::string& violation_id);
  virtual AlgRender GetRender(const std::string &violation_code) const override;

  static void Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat,
                     bool enable_tracking_debug = false);

 protected:
  struct ChannelData {  // need all ptr
    std::string channel_id_;
    std::shared_ptr<RectF> detect_roi_;
    std::shared_ptr<ImageObjectsInfo> last_image_;
    int action_;
    std::map<std::string, int> fall_task_codes;
    std::string add_violation_;
    std::string remove_violation_;
    prometheus::spCounter detect_object_counter_;
    prometheus::spCounter track_object_counter_;
    bool UpdateCfg(ChannelData other) {
      if (other.channel_id_ != channel_id_) {
        return false;
      }
      if (other.detect_roi_) {
        this->detect_roi_.swap(other.detect_roi_);
      }
      if (other.last_image_) {
        this->last_image_.swap(other.last_image_);
      }
      if (!other.add_violation_.empty()) {
        auto it = this->fall_task_codes.find(other.add_violation_);
        if (it == this->fall_task_codes.end()) {
          this->fall_task_codes[other.add_violation_] = 1;
        } else {
          this->fall_task_codes[other.add_violation_]++;
        }
      }
      LOG(INFO) << other.add_violation_ << "  "
                << this->fall_task_codes[other.add_violation_];
      if (!other.remove_violation_.empty()) {
        auto it = this->fall_task_codes.find(other.remove_violation_);
        if (it != this->fall_task_codes.end()) {
          if (this->fall_task_codes[other.remove_violation_] == 1) {
            this->fall_task_codes.erase(it);
          } else {
            this->fall_task_codes[other.remove_violation_]--;
          }
        }
      }
      return true;
    }
  };
  typedef std::shared_ptr<ChannelData> spChannelData;

  class safeChannelDataMap {
   public:
    spChannelData find(const std::string& key) {
      std::unique_lock<std::mutex> lock{lock_};
      auto it = map_.find(key);
      return (it != map_.end()) ? it->second : nullptr;
    }
    spChannelData insert(const std::string& key, spChannelData value) {
      std::unique_lock<std::mutex> lock{lock_};
      auto old_value = map_[key];
      map_[key] = value;
      return old_value;
    }
    spChannelData erase(const std::string& key) {
      std::unique_lock<std::mutex> lock{lock_};
      auto it = map_.find(key);
      spChannelData old_value;
      if (it != map_.end()) {
        old_value = it->second;
        map_.erase(it);
      }
      return old_value;
    }
    typedef std::function<bool(const std::string&, spChannelData)> visiter;
    void visit(visiter v) const {
      std::unique_lock<std::mutex> lock{lock_};
      for (auto& kv : map_) {
        if (!v(kv.first, kv.second)) {
          break;
        }
      }
    }

   protected:
    mutable std::mutex lock_;
    std::unordered_map<std::string, spChannelData> map_;
  };

 protected:
  void FallProcess(const VecImage& images);
  void GetBatchFrames(VecImage& queue, VecImage& image_map,
                      std::function<bool(int)> need_skip, int max_batch) const;
  void GetBatchFramesFall(VecImage& queue, VecImage& image_map);

 protected:
  inference::FallDetect config_;

 protected:
  Profiler fall_profiler_;
  std::mutex fall_lock_;
  std::shared_ptr<Fall::Fall> fall_engine_ = nullptr;

 protected:
  spProfileMetric profile_metric_fall_;

 protected:
  safeChannelDataMap channel_data_map_;
  Queue<spChannelData> channel_data_update_queue_;
};

}  // namespace FLOW

#endif  // TAD_ALG_VEHICLE_ENGINE_HPP
