#ifndef TAD_ALG_ENGINE_FACTORY_HPP
#define TAD_ALG_ENGINE_FACTORY_HPP

#include <memory>
#include <string>
#include <map>
#include <vector>

#include "alg_engine_interface.hpp"

namespace FLOW {
    class ICAlgEngine;
    typedef std::shared_ptr<ICAlgEngine> spICAlgEngine;
    typedef std::vector<spICAlgEngine> VecICAlgEngine;
    typedef std::map<std::string, spICAlgEngine> MapICAlgEngine;

    VecICAlgEngine CreateEngines(const std::string& types);
    MapICAlgEngine CreateEngineMap(const std::string& types, VecICAlgEngine engines);

} // FLOW

#endif //TAD_ALG_ENGINE_FACTORY_HPP