#ifndef TAD_ALG_FLOW_ENGINE_HPP
#define TAD_ALG_FLOW_ENGINE_HPP

#include <memory>
#include <mutex>
#include <atomic>
#include <set>
#include <string>

#include "alg_engine_interface.hpp"

#include "algorithm/detect/detect.hpp"
#include "algorithm/crowd/crowdregion.hpp"
#include "algorithm/wander_retention/videoreid.hpp"

#include "common/Queue.h"
#include "core/flow_dispatch.hpp"
#include "violation/flow/violation_flow_code.hpp"

#include "serving/config.pb.h"

namespace prometheus{
    class Counter;
    typedef std::shared_ptr<Counter> spCounter;
}

namespace FLOW {

    namespace Detect {
        class DetectModule;
	class EAST;
    }
    namespace Track {
        class TADTracker;
    }
    namespace PersonTracker {
        class PersonTracker;
    }
    namespace BodyTracker {
        class BodyTracker;
    }
    namespace CrowdDensity {
        class Crowd;
    }

    namespace FightClassify {
        class FightClassify;
    }

    namespace CrowdRegion {
        class CrowdRegion;
    }

    //namespace WanderRetention {
    //    class VideoReidModel;
    //    class VideoReid;
    //}

    class ProfileMetric;
    typedef std::shared_ptr<ProfileMetric> spProfileMetric;

    // CAlgVehicleEngine
    class CAlgFlowEngine : public ICAlgEngine{
    public:
        enum RENDER_TYPE{
            HEAD_CROSS_LINE,
            ZONE_GUARD,
            HEAD_IN_REGION,
            RETROGRADE,
            RETENTION,
            BANNER,
            DEBUG,
            DENSITY,
            NONE,
        };
    public:
        CAlgFlowEngine() = default;
        virtual ~CAlgFlowEngine() = default;

    public:
        virtual void Init(const inference::EngineConfig &config, int &code);
        virtual void GetBatchFrames(VecImage &queue, VecImage &image_map) const;
        virtual void Process(CFlowDispatch &dsp);
        //virtual void ProcessByName(const std::string& name, const cv::Mat &im_mat, VecBoxF &boxes);

        virtual void AddStream(const std::string &channel_id, const std::string &config);
        virtual void RemoveStream(const std::string &channel_id);
        virtual void AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config);
        virtual void RemoveViolation(const std::string &channel_id, const std::string &violation_id);

        void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) override {}

    public:
        virtual AlgRender GetRender(const std::string &violation_code) const override;

    protected:
        static void MassiveflowRender (const ImageObjectsInfo& image_objects, Mat_Ptr mat, RENDER_TYPE type);

    protected:
        struct ChannelData {
            // std::shared_ptr<Track::TADTracker>  tracker_;
            std::shared_ptr<PersonTracker::PersonTracker>  tracker_;
            std::shared_ptr<BodyTracker::BodyTracker>  body_tracker_;
            std::shared_ptr<RectF>              detect_roi_;
            std::vector<RectF>                  detect_roi_list_; //客流需要多个
            std::shared_ptr<ImageObjectsInfo>   last_image_;
            
            std::vector<std::vector<float>> crowd_violation_roi_;
            std::vector<std::vector<float>> crowd_violation_remove_roi_;
            int min_crowd_num_throd_;
            bool enable_vehicle_detect = false;
            std::shared_ptr<Crowdcount::crowdregion> crowdregion_ ;

            std::string channel_id_;
            int action;
            std::set<std::string> codes;

            std::vector<float>  fight_score_buffer_;

            std::shared_ptr<WanderRetention::VideoReid> Wander_retetion_videoreid_ = nullptr;

            void UpdateCfg(ChannelData other) {
                if ( other.tracker_ ) {
                    this->tracker_.swap(other.tracker_);
                }
                if ( other.body_tracker_ ) {
                    this->body_tracker_.swap(other.body_tracker_);
                }
                if (other.detect_roi_ ) {
                    this->detect_roi_.swap(other.detect_roi_);
                }
                if ( other.detect_roi_list_.size()>0 ) {
                    this->detect_roi_list_ = other.detect_roi_list_;
                }
                if ( other.last_image_ ) {
                    this->last_image_.swap(other.last_image_);
                }
            }	    
	    };

        typedef std::shared_ptr<ChannelData> spChannelData;

        class safeChannelDataMap {
            public:
            spChannelData find(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                return (it != map_.end()) ? it->second : nullptr;
            }
            spChannelData insert(const std::string& key, spChannelData value) {
                std::unique_lock<std::mutex> lock{lock_};
                auto old_value = map_[key];
                map_[key] = value;
                return old_value;
            }
            spChannelData erase(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                spChannelData old_value;
                if (it != map_.end()) {
                    old_value = it->second;
                    map_.erase(it);
                }
                return old_value;
            }
            typedef std::function<bool(const std::string&, spChannelData)> visiter;
            void visit(visiter v) const {
                std::unique_lock<std::mutex> lock{lock_};
                for(auto &kv : map_) {
                    if(!v(kv.first, kv.second)) {
                        break;
                    }
                }
            }
        protected:
            mutable std::mutex lock_;
            std::unordered_map<std::string, spChannelData> map_;
        };

    protected:
        void HeadDetectProcess(const VecImage &images);
        void EastDetectProcess(const VecImage &images);
        void BannerProcess(const VecImage &images);
        void BannerDetectODProcess(const VecImage &images);
        void DensityProcess(const VecImage &images);
        void CrowdProcess(const VecImage &images);
        void FightProcess(const VecImage &images);
        void trackProcess(spChannelData channel, const VecImage &images);
        bool Skip(int64_t count, int interval) const;
        void PrintQueueInfo(int queue_size, int batch, int frames)const;
        void FightBufferProcess(const VecImage &images);
        typedef std::function<bool(const spImageObjectsInfo processedFrame)> fnSkipChecker;
        void FillSkipframe(fnSkipChecker skip, const spImageObjectsInfo processedFrame, spImageObjectsInfo currentFrame);
    protected:
        inference::Flow config_;
        int queue_count_interval_ = 1;
        int crowd_region_count_interval_ = 1;


    // public:
        typedef std::vector<std::vector<RectInfo>> VecRectInfos;
        typedef std::function<bool(int)> TypeFilter;
        typedef struct detect_param {
            VecImage      image_detect;
            VecRectInfos  image_rects;
            VecMat        mat_detect;
            VecShellFrame shell_frame_detect;
            std::vector<cv::Rect> rois;
            std::vector<TypeFilter> det_types;
        } detect_param;
        typedef std::shared_ptr<detect_param> sp_detect_param;
        typedef std::shared_ptr<std::vector<sp_detect_param>> spv_detect_param;

    // protected:
        void ImageResizeProcess(const VecImage &images,const std::vector<RectF>  &detect_roi_list,const VecInt &shape,const int interval, sp_detect_param dp);

        void HeadDetectProcess0(const VecImage &images);
        void HeadDetectProcess1(const VecImage &images);
        std::vector<int> head_shape_;
        spv_detect_param spvhp_;
        
        void DensityResizeProcess(const VecImage &images);
        std::vector<int> crowd_shape_;
        spv_detect_param spv_crowd_;

        void BannerResizeProcess(const VecImage &images);
        std::vector<int> banner_shape_;
        std::vector<int> banner_od_shape_; //可以暂时不考虑od的resize
        spv_detect_param spv_banner_;
        // spv_detect_param spv_banner_od_;

        void WanderRetentionODProcess(const VecImage &images);
        void WanderRetentionVideoreidProcess(const VecImage &images);
        void trackRetentionProcess(spChannelData channel, const VecImage &images);
        long global_counter = 0;

    protected:
        std::mutex head_lock_;
        std::mutex fight_lock_;
        std::mutex density_lock_;
        std::mutex crowd_lock_;
        std::mutex banner_lock_;
        std::mutex banner_od_lock_;
        std::mutex detect_lock_;
        std::mutex retention_od_lock_;
        std::shared_ptr<Detect::DetectModule> Head_detector_ = nullptr;
        std::shared_ptr<Detect::DetectModule> Vehicle_detector_ = nullptr;
        std::shared_ptr<CrowdDensity::Crowd> Crowd_density_ = nullptr;
        std::shared_ptr<FightClassify::FightClassify> Fight_classify_ = nullptr;
        std::shared_ptr<Detect::EAST> East_detector_ = nullptr;
        std::shared_ptr<Detect::DetectModule> Banner_od_detector_ = nullptr;
        std::shared_ptr<Detect::DetectModule> Wander_retention_detector_ = nullptr;


    protected:
        safeChannelDataMap channel_data_map_;
	    Queue<spChannelData> channel_data_update_queue_;

    protected:
	    std::atomic<VecImage*> wait_head_;
        std::atomic<VecImage*> wait_track_;
        std::atomic<VecImage*> wait_east_;
        std::atomic<VecImage*> wait_fight_;
        std::atomic<VecImage*> wait_density_;
        std::atomic<VecImage*> wait_queue_count_;
        std::atomic<VecImage*> wait_crowd_region_count_;

        spProfileMetric profile_metric_head_detector_;
        spProfileMetric profile_metric_east_detector_;
        spProfileMetric profile_metric_banner_od_detector_;
        spProfileMetric profile_metric_crowd_density_;
        spProfileMetric profile_metric_fight_classify_;
        spProfileMetric profile_metric_retention_detector_;

        mutable std::map<std::string, std::vector<std::string> > channelId_violations_;
        std::map<std::string, std::map<std::string, std::string> > violationId_map_;

        std::set<std::string> head_set_ = {FLOW_HEADCOUNT_CODE,FLOW_CROSS_LINE_CODE,FLOW_OVERFENCE_CODE,FLOW_RETROGRADE_CODE,FLOW_ZONE_GUARD_CODE,\
                                        FLOW_QUEUE_COUNT_EXCEED_CODE, BUILDING_HEAD_BODY_DETECT_CODE, \
                                        BUILDING_ZONE_GUARD_CODE}; //需要人头检测的模型列表

        std::set<std::string> head_count_in_region_ = {FLOW_QUEUE_COUNT_EXCEED_CODE}; //区域人头计数渲染
        std::set<std::string> head_cross_line_ = {FLOW_HEADCOUNT_CODE, FLOW_CROSS_LINE_CODE, FLOW_OVERFENCE_CODE, FLOW_RETROGRADE_CODE};

    };

}

#endif //TAD_ALG_FLOW_ENGINE_HPP

