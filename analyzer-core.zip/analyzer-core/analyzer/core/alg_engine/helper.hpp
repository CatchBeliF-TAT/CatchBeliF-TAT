#ifndef TAD_ALG_ENGINE_HELPER_HPP
#define TAD_ALG_ENGINE_HELPER_HPP

#include <map>
#include <vector>

#include "common/base64.hpp"
#include "common/json.hpp"
#include "common/util.hpp"
#include "common/boxes.hpp"
#include "common/tad_internal.hpp"
#include "common/pbjson.hpp"
#include "serving/config.pb.h"
#if defined(USE_OpenCV)

#include "opencv2/opencv.hpp"

#endif

namespace FLOW {

inline void parse_config(const std::string &config_file, inference::AnalyzerConfig *config) {
  if (!config_file.empty()) {
    std::string config_str;
    if (Path(config_file).is_file()) {
      config_str = Util::read_text_from_file(config_file);
    } else {
      config_str = config_file;
    }
    const auto &document = get_document(config_str);

    //std::cout<<"config_str"<<config_str<<std::endl;
    if (document.HasMember("stream_config")) {
        const auto& value = get_value(document, "stream_config");
        std::string err;
        json2pb(value_as_string(value), config->mutable_stream_config(), &err);
        //std::cout<<"stream_config"<<err<<std::endl;
    }else{
        //std::cout<<"no stream_config"<<std::endl;
    }

    if (document.HasMember("engine_config")) {
        const auto& value = get_value(document, "engine_config");
        std::string err;
        json2pb(value_as_string(value), config->mutable_engine_config(), &err);
        //std::cout<<"engine_config"<<err<<std::endl;
    }else{
        //std::cout<<"no engine_config"<<std::endl;
    }

    if (document.HasMember("general_config")) {
        const auto& value = get_value(document, "general_config");
        std::string err;
        json2pb(value_as_string(value), config->mutable_general_config(), &err);
        //std::cout<<"general_config"<<err<<std::endl;
    }else{
        //std::cout<<"no general_config"<<std::endl;
    }
  }
}

inline std::string stream_status_json(std::map<std::string, int> &status) {
  rapidjson::Document document;
  auto &a = document.GetAllocator();
  rapidjson::Value j_result(rapidjson::kObjectType);

  for (auto &statu : status) {
    j_result.AddMember(rapidjson::StringRef(statu.first.c_str()),
                       rapidjson::Value(statu.second), a);
  }

  rapidjson::StringBuffer buffer;
  rapidjson::Writer<rapidjson::StringBuffer> writer(buffer);
  j_result.Accept(writer);
  std::string json_str = std::string(buffer.GetString());

  return json_str;
}

inline bool parse_traffic_light_box_config(const std::string &config, BoxF *box) {
    const std::string FIELD = "traffic_light_box";
    auto root = get_document(config);
    auto data = get_array<float>(root, FIELD);
    if (data.empty()) {
        return false;
    }

    CHECK_GE(data.size(), 2 * 2);
    CHECK_EQ(data.size() % 2, 0);

    box->xmin = data[0];
    box->xmax = data[0];
    box->ymin = data[1];
    box->ymax = data[1];
    for (int i = 1; i < data.size() / 2; i++) {
        box->xmin = std::min(box->xmin, data[i * 2]);
        box->xmax = std::max(box->xmax, data[i * 2]);
        box->ymin = std::min(box->ymin, data[i * 2 + 1]);
        box->ymax = std::max(box->ymax, data[i * 2 + 1]);
    }
    return true;
}

inline bool parse_detect_roi_config(const std::string &config, BoxF *box) {
    const std::string FIELD = "person_detect_roi";
    auto root = get_document(config);
    auto data = get_array<float>(root, FIELD);
    if (data.empty()) {
        return false;
    }

    CHECK_GE(data.size(), 2 * 2);
    CHECK_EQ(data.size() % 2, 0);

    box->xmin = data[0];
    box->xmax = data[0];
    box->ymin = data[1];
    box->ymax = data[1];
    for (int i = 1; i < data.size() / 2; i++) {
        box->xmin = std::min(box->xmin, data[i * 2]);
        box->xmax = std::max(box->xmax, data[i * 2]);
        box->ymin = std::min(box->ymin, data[i * 2 + 1]);
        box->ymax = std::max(box->ymax, data[i * 2 + 1]);
    }
    return true;
}
inline bool face_detect_roi_config(const std::string &config, BoxF *box) {
    const std::string FIELD = "face_detect_roi";
    auto root = get_document(config);
    auto data = get_array<float>(root, FIELD);
    if (data.empty()) {
        return false;
    }

    CHECK_GE(data.size(), 2 * 2);
    CHECK_EQ(data.size() % 2, 0);

    box->xmin = data[0];
    box->xmax = data[0];
    box->ymin = data[1];
    box->ymax = data[1];
    for (int i = 1; i < data.size() / 2; i++) {
        box->xmin = std::min(box->xmin, data[i * 2]);
        box->xmax = std::max(box->xmax, data[i * 2]);
        box->ymin = std::min(box->ymin, data[i * 2 + 1]);
        box->ymax = std::max(box->ymax, data[i * 2 + 1]);
    }
    return true;
}

inline bool parse_violation_code(const std::string &config, std::string &code) {
  const std::string FIELD = "code";
  auto root = get_document(config);
  code = get_string(root, FIELD, "");
  if (code.empty()) {
    return false;
  }
  return true;
}

inline bool parse_ptz_config(const std::string &config, PosInfo *ptz) {
  const std::string FIELD = "ptz_pos";
  auto root = get_document(config);
  auto data = get_array<float>(root, FIELD);
  if ( data.size() < 3 ) {
    return false;
  }
  ptz->angle_x = data[0];
  ptz->angle_y = data[1];
  ptz->scale = data[2];
  return true;
}

}  // namespace FLOW

#endif  // TAD_ALG_ENGINE_HELPER_HPP
