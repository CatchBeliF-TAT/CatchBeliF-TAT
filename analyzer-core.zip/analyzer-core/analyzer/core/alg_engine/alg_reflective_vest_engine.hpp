#ifndef TAD_ALG_REFLECTIVE_VEST_ENGINE_HPP
#define TAD_ALG_REFLECTIVE_VEST_ENGINE_HPP
#include <string>
#include "alg_engine_interface.hpp"
#include "serving/config.pb.h"
#include "algorithm/classify/classify.hpp"
#include "algorithm/detect/detect.hpp"
namespace FLOW {

    enum VestObjectType {
        VEST_OBJECT_TYPE_PERSON = 50,
        VEST_OBJECT_YELLOW_SILVER = 51,
        VEST_OBJECT_ORANGE_YELLOW = 52,
        VEST_OBJECT_ORANGE_WHITE = 53,
        VEST_OBJECT_CROSS = 54,
        VEST_OBJECT_SUSPECTED = 55,
        VEST_OBJECT_NO = 56,
    };
    // CAlgFallEngine
    class CAlgReflectiveVestEngine : public ICAlgEngine {
    public:
        CAlgReflectiveVestEngine() = default;
        virtual ~CAlgReflectiveVestEngine() = default;

        public:
        virtual void Init(const inference::EngineConfig& config, int& code);
        virtual void GetBatchFrames(VecImage& queue, VecImage& image_map) const;
        virtual void Process(CFlowDispatch& dsp){}
        virtual void AddStream(const std::string& channel_id,
                                const std::string& config);
        virtual void RemoveStream(const std::string& channel_id);
        virtual void AddViolation(const std::string& channel_id,
                                    const std::string& violation_id,
                                    const std::string& config){}
        virtual void RemoveViolation(const std::string& channel_id,
                                    const std::string& violation_id){}
        virtual void AddViolation2(const std::string &channel_id, const std::string &violation_id, const std::string &config, CFlowDispatch &dsp);
        virtual void RemoveViolation2(const std::string &channel_id, const std::string &violation_id, CFlowDispatch &dsp);
        void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) override {}
        virtual AlgRender GetRender(const std::string &violation_code) const override;

        static void Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat,
                            bool enable_tracking_debug = false);

    protected:
        void AddEngineInDsp(const std::string &channel_id, const std::string &engine_name, CFlowDispatch &dsp);
        void RemoveEngineInDsp(const std::string &channel_id, const std::string &engine_name, CFlowDispatch &dsp);
        void VestDetectProcess(const VecImage &images);
        void VestClassifyProcess(const VecImage &images);
        bool Skip(int64_t count) const;
    protected:
        inference::Vest config_;
        std::shared_ptr<Detect::DetectModule> vest_detector_ = nullptr;
        std::shared_ptr<classify::ClassifyModule> vest_classify_ = nullptr;

        std::mutex vest_detect_lock_;
        std::mutex vest_attr_lock_;
        //记录已经打开的流, 每个流开启的engine, 每个engine服务的violation
        std::unordered_map<std::string, std::unordered_map<std::string, std::unordered_set<std::string>>> map_;
    };
}
#endif
