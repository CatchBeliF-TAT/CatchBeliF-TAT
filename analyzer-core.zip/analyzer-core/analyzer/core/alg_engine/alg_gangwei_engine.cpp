
#include <vector>
#include <future>

#include "common/io.hpp"
#include "common/pbjson.hpp"

#include "helper.hpp"
#include "alg_gangwei_engine.hpp"

#include "serving/violation_config.pb.h"

#include "algorithm/detect/detect.hpp"
#include "algorithm/duchaMar/duchaMar.hpp"

namespace FLOW {

    using namespace std;

    void CAlgGangweiEngine::PrintDetectInfo(const VecImage& images)const {
        for (auto &image : images) {
            LOG(INFO) << "channel id: " << image->channel_id;
            for (auto &object : image->gangwei_objects) {
            LOG(INFO) << "colour: " << object.ducha_colour.type << ", \t"
                        << "action: " << object.ducha_action.type << ", \t"
                        << "pos: " << object.xmin << " " << object.ymin << " "
                        << object.xmax << " " << object.ymax;                
            }
        }
    }

    void CAlgGangweiEngine::Init(const inference::EngineConfig &config, int &code) {
        config_ = config.gangwei();

        if(true==config_.attribute_on()){
            std::map<std::string, std::pair<std::string, std::vector<char>>> params = {
                {"gangwei_detect_model",        {config_.detect().model_path(),          {}}},
                {"gangwei_attribute_model",     {config_.attribute().model_path(),       {}}},
            };
            for (auto& kv : params) {
                if (!IO::ReadBinaryFile(kv.second.first, &kv.second.second)) {
                    LOG(FATAL) << "Load model " << kv.second.first << " error";
                    return;
                }
            }
            // detect_model
            detector_ = make_shared<Detect::DetectModule>();
            detector_->Setup(params["gangwei_detect_model"].second, config_.detect(), code);
            // attribute_model
            gangweiMar_ = std::make_shared<duchaMar::DuchaMarModule>();
            gangweiMar_->Setup(params["gangwei_attribute_model"].second, config_.attribute(), code);
            // metric init  
            typedef std::map<std::string, std::string> LablesType;
            const prometheus::Summary::Quantiles quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
            profile_metric_detector_    = std::make_shared<ProfileMetric>(LablesType{{"engine", "gangwei"}, {"model", "detector"}}, quantiles);
            profile_metric_gangwei_mar_ = std::make_shared<ProfileMetric>(LablesType{{"engine", "gangwei"}, {"model", "gangweiMar"  }}, quantiles);
        }
    }

    bool CAlgGangweiEngine::Skip(int64_t count, int interval) const {
        return count % interval;
    }

    void CAlgGangweiEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
    }

    void CAlgGangweiEngine::GetBatchFramesDetect(VecImage &queue, VecImage &image_map) const {
        image_map.clear();
        std::unordered_map<string, int> channel_count;
        for (auto it = queue.begin(); it != queue.end() && image_map.size() < config_.attribute().batch_size(); ) {
            auto &frame = *it;
            auto data = channel_data_map_.find(frame->channel_id);
            if (data && data->has_detect_ && !this->Skip(frame->count, data->detect_interval_)) {
                frame->type |= GANGWEI_DETECT_TYPE;
                image_map.push_back(frame);
            }
            it = queue.erase(it);
        }
    }

    void CAlgGangweiEngine::Process(CFlowDispatch &dsp) {
        while(!channel_data_update_queue_.empty()) {
            auto new_data = channel_data_update_queue_.pop();
            auto& channel_id = new_data->channel_id_;
            if (auto old_data = channel_data_map_.find(new_data->channel_id_)) {
                auto old_has_detect = old_data->has_detect_;

                auto copy_data = std::make_shared<ChannelData>(*old_data);
                if (copy_data->UpdateCfg(*new_data, config_)) {
                    channel_data_map_.insert(channel_id, copy_data);
                } else {
                    continue;
                }
                auto new_has_detect = copy_data->has_detect_;

                CFlowDispatch::spNode detect, chin, chout;
                chin = dsp.get_node(channel_id, "in");
                chout = dsp.get_node(channel_id, "out");
                if (!chin || !chout) return;

                if (new_has_detect != old_has_detect) {
                    if (new_has_detect) {
                        detect = dsp.add_node(channel_id, "gangwei-detect", config_.attribute_queue_size(), true);
                        detect->process([this](VecImage& in) {
                                VecImage frames;
                                this->GetBatchFramesDetect(in, frames);
                                if (!frames.empty()) {
                                    this->gangweiProcess(frames);
                                }
                            });
                        chin->next(detect);
                        detect->next(chout);
                    } else {
                        dsp.remove_node(channel_id, "gangwei-detect");
                    }
                }
            } else if (!new_data->add) {
                dsp.remove_node(new_data->channel_id_, "gangwei-detect");
            }
        }
    }

    void CAlgGangweiEngine::ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) {}

    void CAlgGangweiEngine::gangweiProcess(const VecImage &images) {
        std::unique_lock<std::mutex> lock{gangwei_lock_};
        Profiler profiler_detect;
        ProfilerHelper _profiler(&profiler_detect, "gangweiProcess",
        [](Profiler* p){LOG(DEBUG) <<"profiler "<< p->get_stats_str();}
        );

        typedef vector<vector<RectInfo>> VecRectInfos;
        typedef std::function<bool(int)> TypeFilter;
        // detect
        VecImage      image_detect;
        VecRectInfos  image_rects;
        VecShellFrame detect_frames;
        std::vector<cv::Rect> rois;
        std::vector<TypeFilter> det_types;

        for (auto &image : images) {
            image_detect.push_back(image);
            detect_frames.push_back(image->sframe);
            rois.push_back(cv::Rect(0, 0, image->sframe->width(), image->sframe->height()));
            det_types.push_back([](int type) -> bool { return true; });
        }

        int code = -1;
#ifdef USE_MEDIA_UTILS
        if (config_.detect().device_input()) {
            ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
            detector_->Process(detect_frames, rois, image_rects, code);
        } else {
            ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
            detector_->ProcessROIs(detect_frames, rois, image_rects, code);
        }
#else
        {
            ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
            detector_->ProcessROIs(detect_frames, rois, image_rects, code);
        }
#endif
        
        // process detect result
        for (size_t i = 0; i < image_detect.size(); i++) {
            VecBoxF &objects  = image_detect[i]->gangwei_objects;
            const auto &rects = image_rects[i];
            VecBoxF image_boxes;
            for (auto &rect : rects) {
                //if (det_types[i](rect.label)) {
                if (true) {// 建议增加个尺寸过滤
                    BoxF box((float)rect.rect.x, (float)rect.rect.y,
                                (float)(rect.rect.x + rect.rect.width),
                                (float)(rect.rect.y + rect.rect.height));
                    box.label = rect.label;
                    box.score = rect.score;
                    image_boxes.push_back(box);
                }
            }
            objects.insert(objects.end(), image_boxes.begin(), image_boxes.end());
        }

        vector<VecBoxF> vec_boxes_tmp;
        vector<vector<BoxF*>> vec_boxes_addr;
	    VecMat mat_images;

        for (auto image : image_detect) {
            auto &image_objects = *image;
            VecBoxF boxes_tmp;
            vector<BoxF*> boxes_addr;
            for (auto &box : image_objects.gangwei_objects) {
                if (box.ducha_colour.type == -1 &&
                    box.delete_flag == 0) {
                    boxes_tmp.push_back(box);
                    boxes_addr.push_back(&box);
                }
            }
            vec_boxes_tmp.push_back(boxes_tmp);
            mat_images.push_back(image_objects.sframe->getMat());
            vec_boxes_addr.push_back(boxes_addr);
        }
        if (gangweiMar_) {
            ProfileMetric::Helper _metric_helper(*profile_metric_gangwei_mar_);
            gangweiMar_->Predict(mat_images, &vec_boxes_tmp);
        }
        for (int i =0; i < vec_boxes_tmp.size(); ++i) {
            for (int j = 0; j < vec_boxes_tmp.at(i).size(); ++j) {
            *vec_boxes_addr.at(i).at(j) = vec_boxes_tmp.at(i).at(j);
            }
        }

        PrintDetectInfo(images);
    }

    void CAlgGangweiEngine::AddStream(const std::string &channel_id, const std::string &config) {
        auto channel_data = channel_data_map_.find(channel_id);
        if (nullptr == channel_data.get()) {
            channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data->has_detect_= false;
            channel_data_map_.insert(channel_id, channel_data);

        }
    }
    void CAlgGangweiEngine::RemoveStream(const std::string &channel_id) {
        channel_data_map_.erase(channel_id);
    }

    void CAlgGangweiEngine::AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config) {
        if (config_.attribute_on()) {
            auto channel_data_old = channel_data_map_.find(channel_id);
            if (channel_data_old) {
                auto channel_update_data = std::make_shared<ChannelUpdateData>();
                channel_update_data->channel_id_ = channel_id;
                channel_update_data->add = true;
                channel_update_data->violation_id = violation_id;
#ifdef USE_MEDIA_UTILS
                auto cfg = get_document(config);
                auto fps = get_float(cfg, "fps", 0.0f);
                violation_fps_map_[violation_id] = fps;
                auto max_fps = 0.0f;
                for (auto& kv : violation_fps_map_){
                    if (kv.second > max_fps) max_fps = kv.second;
                }
                channel_update_data->fps = max_fps;
#else
                channel_update_data->fps = 0.0f;
#endif
                channel_data_update_queue_.push(channel_update_data);
            }
        }
    }

    void CAlgGangweiEngine::RemoveViolation(const std::string &channel_id, const std::string &violation_id) {
        if (config_.attribute_on()) {
            auto channel_data_old = channel_data_map_.find(channel_id);
            if (channel_data_old) {
                auto channel_update_data = std::make_shared<ChannelUpdateData>();
                channel_update_data->channel_id_ = channel_id;
                channel_update_data->add = false;
                channel_update_data->violation_id = violation_id;
#ifdef USE_MEDIA_UTILS
                violation_fps_map_.erase(violation_id);
                auto max_fps = 0.0f;
                for (auto& kv : violation_fps_map_){
                    if (kv.second > max_fps) max_fps = kv.second;
                }
                channel_update_data->fps = max_fps;
#else
                channel_update_data->fps = 0.0f;
#endif
                channel_data_update_queue_.push(channel_update_data);
            }
        }
    }

} // FLOW

