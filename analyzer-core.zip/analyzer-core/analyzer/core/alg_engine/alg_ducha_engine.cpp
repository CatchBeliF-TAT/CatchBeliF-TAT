#include <vector>
#include <future>

#include "common/io.hpp"
#include "common/pbjson.hpp"

#include "helper.hpp"
#include "alg_ducha_engine.hpp"

#include "serving/violation_config.pb.h"

#include "algorithm/detect/detect.hpp"
#include "algorithm/duchaMar/duchaMar.hpp"
#include "algorithm/duchaMar/duchaHoi.hpp"
#include "algorithm/fight/fight_classify.hpp"

namespace FLOW {

    using namespace std;

    void CAlgDuchaEngine::PrintDetectInfo(const VecImage& images)const {
        for (auto &image : images) {
            LOG(INFO) << "detect result for channel id: " << image->channel_id;
            for (auto &object : image->ducha_objects) {
            LOG(INFO) << "colour: " << object.ducha_colour.type << ", \t"
                        << "action: " << object.ducha_action.type << ", \t"
                          << "sex: " << object.ducha_sex.type << ", \t"
                          << "mask: " << object.ducha_mask.type << ", \t"
                        << "pos: " << object.xmin << " " << object.ymin << " "
                        << object.xmax << " " << object.ymax;                
            }
        }
    }

    void CAlgDuchaEngine::PrintFightInfo(const VecImage& images)const {
        for (auto &image : images) {
            LOG(INFO) << "fight result for channel id: " << image->channel_id;
            LOG(INFO) << "fight: " << image->ducha_fight_event.is_bk_fighting;
        }
    }

    void CAlgDuchaEngine::Init(const inference::EngineConfig &config, int &code) {
        config_ = config.ducha();

        if(true==config_.attribute_on()){
            std::map<std::string, std::pair<std::string, std::vector<char>>> params = {
                {"ducha_detect_model",        {config_.detect().model_path(),          {}}},
                {"ducha_attribute_model",     {config_.attribute().model_path(),       {}}},
            };
            for (auto& kv : params) {
                if (!IO::ReadBinaryFile(kv.second.first, &kv.second.second)) {
                    LOG(FATAL) << "Load model " << kv.second.first << " error";
                    return;
                }
            }
            // detect_model
            detector_ = make_shared<Detect::DetectModule>();
            detector_->Setup(params["ducha_detect_model"].second, config_.detect(), code);
            // attribute_model
            duchaMar_ = std::make_shared<duchaMar::DuchaMarModule>();
            duchaMar_->Setup(params["ducha_attribute_model"].second, config_.attribute(), code);

        }
        if(true==config_.hoi_on()){
          auto param = std::make_pair(config_.hoi().model_path(), std::vector<char>());
          if (!IO::ReadBinaryFile(param.first, &param.second)) {
            LOG(FATAL) << "Load model " << param.first << " error";
            return;
          }
          duchaHoi_ = std::make_shared<duchaHoi::DuchaHoiModule>();
          duchaHoi_->Setup(param.second, config_.hoi(), code);
        }

        if(true==config_.fight_on()){
            auto param = std::make_pair(config_.fight().model_path(), std::vector<char>());
            if (!IO::ReadBinaryFile(param.first, &param.second)) {
                LOG(FATAL) << "Load model " << param.first << " error";
                return;
            }
            Fight_classify_ = std::make_shared<FightClassify::FightClassify>();
            Fight_classify_->Setup(param.second, config_.fight(), code);
        }

        // metric init
        typedef std::map<std::string, std::string> LablesType;
        const prometheus::Summary::Quantiles quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
        profile_metric_detector_        = std::make_shared<ProfileMetric>(LablesType{{"engine", "ducha"}, {"model", "detector"       }}, quantiles);
        profile_metric_ducha_mar_       = std::make_shared<ProfileMetric>(LablesType{{"engine", "ducha"}, {"model", "ducha_mar"      }}, quantiles);
        profile_metric_ducha_hoi_       = std::make_shared<ProfileMetric>(LablesType{{"engine", "ducha"}, {"model", "ducha_hoi"      }}, quantiles);
        profile_metric_figit_classify_  = std::make_shared<ProfileMetric>(LablesType{{"engine", "ducha"}, {"model", "fight_classify" }}, quantiles);
    }

    bool CAlgDuchaEngine::Skip(int64_t count, int interval) const {
        return count % interval;
    }

    void CAlgDuchaEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
    }

    void CAlgDuchaEngine::GetBatchFramesDetect(VecImage &queue, VecImage &image_map) const {
        image_map.clear();
        std::unordered_map<string, int> channel_count;
        for (auto it = queue.begin(); it != queue.end() && image_map.size() < config_.attribute().batch_size(); ) {
            auto &frame = *it;
            auto data = channel_data_map_.find(frame->channel_id);
            if (data && data->has_detect_ && !this->Skip(frame->count, data->detect_interval_)) {
                frame->type |= DUCHA_DETECT_TYPE;
                image_map.push_back(frame);
            }
            it = queue.erase(it);
        }
    }

    void CAlgDuchaEngine::GetBatchFramesFight(VecImage &queue, VecImage &image_map) const {
        image_map.clear();
        std::unordered_map<string, int> channel_count;
        for (auto it = queue.begin(); it != queue.end() && image_map.size() < config_.fight().batch_size(); ) {
            auto &frame = *it;
            auto data = channel_data_map_.find(frame->channel_id);
            if (data && data->has_fight_ && !this->Skip(frame->count, data->fight_interval_)) {
                frame->type |= DUCHA_FIGHT_TYPE;
                image_map.push_back(frame);
            }
            it = queue.erase(it);
        }
    }

    void CAlgDuchaEngine::Process(CFlowDispatch &dsp) {
        while(!channel_data_update_queue_.empty()) {
            auto new_data = channel_data_update_queue_.pop();
            auto& channel_id = new_data->channel_id_;
            if (auto old_data = channel_data_map_.find(new_data->channel_id_)) {
                auto old_has_detect = old_data->has_detect_;
                auto old_has_fight = old_data->has_fight_;

                auto copy_data = std::make_shared<ChannelData>(*old_data);
                if (copy_data->UpdateCfg(*new_data, config_)) {
                    channel_data_map_.insert(channel_id, copy_data);
                } else {
                    continue;
                }
                auto new_has_detect = copy_data->has_detect_;
                auto new_has_fight = copy_data->has_fight_;

                CFlowDispatch::spNode detect, fight, fight_avg, chin, chout;
                chin = dsp.get_node(channel_id, "in");
                chout = dsp.get_node(channel_id, "out");
                if (!chin || !chout) return;

                if (new_has_detect != old_has_detect) {
                    if (new_has_detect) {
                        detect = dsp.add_node(channel_id, "ducha-detect", config_.attribute_queue_size(), true);
                        detect->process([this](VecImage& in) {
                                VecImage frames;
                                this->GetBatchFramesDetect(in, frames);
                                if (!frames.empty()) {
                                    this->duchaProcess(frames);
                                }
                            });
                        chin->next(detect);
                        detect->next(chout);
                    } else {
                        dsp.remove_node(channel_id, "ducha-detect");
                    }
                }
                if (new_has_fight != old_has_fight) {
                    if (new_has_fight) {
                        fight = dsp.add_node(channel_id, "ducha-fight", config_.fight_queue_size(), true);
                        fight->process([this](VecImage& in) {
                                VecImage frames;
                                this->GetBatchFramesFight(in, frames);
                                if (!frames.empty()) {
                                    this->FightProcess(frames);
                                }
                            });
                        fight_avg = dsp.add_node(channel_id, "ducha-fight-avg", config_.fight_queue_size(), true);
                        fight_avg->process([this](VecImage& in) {
                                this->FightBufferProcess(in);
                                in.clear();
                            });
                        chin->next(fight);
                        fight->next(fight_avg);
                        fight_avg->next(chout);
                    } else {
                        dsp.remove_node(channel_id, "ducha-fight");
                        dsp.remove_node(channel_id, "ducha-fight-avg");
                    }
                }
            } else if (!new_data->add) {
                dsp.remove_node(new_data->channel_id_, "ducha-detect");
                dsp.remove_node(new_data->channel_id_, "ducha-fight");
                dsp.remove_node(new_data->channel_id_, "ducha-fight-avg");
            }
        }
    }

    void CAlgDuchaEngine::ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) {}

    void CAlgDuchaEngine::duchaProcess(const VecImage &images) {
        std::unique_lock<std::mutex> lock{ducha_lock_};
        Profiler profiler_detect;
        ProfilerHelper _profiler(&profiler_detect, "duchaProcess",
        [](Profiler* p){LOG(DEBUG) <<"profiler "<< p->get_stats_str();}
        );

        typedef vector<vector<RectInfo>> VecRectInfos;
        typedef std::function<bool(int)> TypeFilter; //？？  督查使用的检测为yolo,输出类别从0开始计数，确认下会有检测输出
        // detect
        VecImage      image_detect;
        VecRectInfos  image_rects;
        VecShellFrame detect_frames;
        std::vector<cv::Rect> rois;
        std::vector<TypeFilter> det_types;

        for (auto &image : images) {
            cv::Rect roi = cv::Rect(0, 0, image->sframe->width(), image->sframe->height());

            image_detect.push_back(image);
            detect_frames.push_back(image->sframe);
            rois.push_back(roi);
            det_types.push_back([](int type) -> bool { return true; });//？？ 督查只有一个类别输出，用不到det_types
        }

        int code = -1;
#ifdef USE_MEDIA_UTILS
        if (config_.detect().device_input()) {
            ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
            detector_->Process(detect_frames,rois,  image_rects, code);
        } else {
            ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
            detector_->ProcessROIs(detect_frames, rois, image_rects, code);
        }
#else
        {
            ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
            detector_->ProcessROIs(detect_frames, rois, image_rects, code);
        }
#endif
        
        // process detect result
        for (size_t i = 0; i < image_detect.size(); i++) {
            VecBoxF &objects  = image_detect[i]->ducha_objects;
            const auto &rects = image_rects[i];
            VecBoxF image_boxes;
            for (auto &rect : rects) {
                //if (det_types[i](rect.label)) {
                if (true) {// 建议增加个尺寸过滤
                    BoxF box((float)rect.rect.x, (float)rect.rect.y,
                                (float)(rect.rect.x + rect.rect.width),
                                (float)(rect.rect.y + rect.rect.height));
                    box.label = rect.label;
                    box.score = rect.score;
                    image_boxes.push_back(box);
                }
            }
            objects.insert(objects.end(), image_boxes.begin(), image_boxes.end());
            auto channel_data = channel_data_map_.find(image_detect[i]->channel_id);
            if(channel_data.get()!=nullptr){
                channel_data->detect_object_counter_->Increment(image_boxes.size());
            }
        }

        // 行为服饰属性位置，所有被检测图都需要进行行为服饰分类
        vector<VecBoxF> vec_boxes_tmp;
        vector<vector<BoxF*>> vec_boxes_addr;
	    VecMat mat_images;

        for (auto image : image_detect) {
            auto &image_objects = *image;
            VecBoxF boxes_tmp;
            vector<BoxF*> boxes_addr;
            for (auto &box : image_objects.ducha_objects) {
                if (box.ducha_colour.type == -1 &&
                    box.delete_flag == 0) {
                    boxes_tmp.push_back(box);
                    boxes_addr.push_back(&box);
                }
            }
            //vec_channel_id.push_back(channel_id);
            vec_boxes_tmp.push_back(boxes_tmp);
            mat_images.push_back(image_objects.sframe->getMat());
            vec_boxes_addr.push_back(boxes_addr);
        }
        if (duchaMar_) {
            ProfileMetric::Helper _metric_helper(*profile_metric_ducha_mar_);
            duchaMar_->Predict(mat_images, &vec_boxes_tmp);
        }
        if (duchaHoi_) {
          ProfileMetric::Helper _metric_helper(*profile_metric_ducha_hoi_);
          duchaHoi_->Predict(mat_images, &vec_boxes_tmp);
        }
        for (int i =0; i < vec_boxes_tmp.size(); ++i) {
            for (int j = 0; j < vec_boxes_tmp.at(i).size(); ++j) {
            *vec_boxes_addr.at(i).at(j) = vec_boxes_tmp.at(i).at(j);
            }
        }

        PrintDetectInfo(images);
    }

    void CAlgDuchaEngine::FightProcess(const VecImage &images) {
        std::unique_lock<std::mutex> lock{fight_lock_};
        Profiler profiler_fight;
        profiler_fight.tic("Fight Process");

        // fight
        VecImage      image_detect;
        VecMat        mat_detect;

        for (auto &image : images) {
            const auto &pic_mat = image->sframe->getMat();

            image_detect.push_back(image);
            mat_detect.push_back(pic_mat);

        }
        int code = -1;
        std::vector<Fight_Event> events;
        {
            ProfileMetric::Helper _metric_helper(*profile_metric_figit_classify_);
            Fight_classify_->Predict(mat_detect, events, code);
        }

        // process fight result
        for (size_t i = 0; i < image_detect.size(); i++) {
            image_detect[i]->ducha_fight_event= events[i];
        }
        profiler_fight.toc("Fight Process");
        LOG(INFO) << profiler_fight.get_stats_str();
        
        PrintFightInfo(images);
    }

    void CAlgDuchaEngine::FightBufferProcess(const VecImage &images) {

        for(auto& image: images){
            auto sp_channel_data = channel_data_map_.find(image->channel_id);
            if(sp_channel_data.get()==nullptr){
                continue;
            }
            if(!image->ducha_fight_event.if_predicted){
                continue;
            }
            auto& score_buffer_ = sp_channel_data->fight_score_buffer_;

            if (score_buffer_.size() < config_.fight().score_buffer()) {
                score_buffer_.push_back(image->ducha_fight_event.predict_score);
            } else {
                score_buffer_.erase(score_buffer_.begin());
                score_buffer_.push_back(image->ducha_fight_event.predict_score);
            }
            float avg_score = 0.f;
            for(auto score: score_buffer_){
                avg_score += score;
            }
            avg_score /= (float)score_buffer_.size();
            if(avg_score>config_.fight().detect_threshold()){
                image->ducha_fight_event.is_bk_fighting=true;
            }
        }
    }

    void CAlgDuchaEngine::AddStream(const std::string &channel_id, const std::string &config) {
        auto channel_data = channel_data_map_.find(channel_id);
        if (nullptr == channel_data.get()) {
            channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data->has_detect_= false;
            channel_data->has_fight_= false;
            typedef std::map<std::string, std::string> LablesType;
            channel_data->detect_object_counter_ =  std::shared_ptr<prometheus::Counter>(
                &Metric::Instance().object_counter->Add(LablesType{
                    {"engine", "ducha"},
                    {"model", "detect"},
                    {"stream_id", channel_id}
                }),
                [](prometheus::Counter* c) {Metric::Instance().object_counter->Remove(c);}
            );
            channel_data_map_.insert(channel_id, channel_data);
        }
    }
    void CAlgDuchaEngine::RemoveStream(const std::string &channel_id) {
        channel_data_map_.erase(channel_id);
    }

    void CAlgDuchaEngine::AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config) {
        if ((config_.attribute_on() && violation_id != DUCHA_FIGHT_CODE)
            || (config_.fight_on() && violation_id == DUCHA_FIGHT_CODE) ) {
            auto channel_data_old = channel_data_map_.find(channel_id);
            if (channel_data_old) {
                auto channel_update_data = std::make_shared<ChannelUpdateData>();
                channel_update_data->channel_id_ = channel_id;
                channel_update_data->add = true;
                channel_update_data->violation_id = violation_id;
#ifdef USE_MEDIA_UTILS
                auto cfg = get_document(config);
                auto fps = get_float(cfg, "fps", 0.0f);
                violation_fps_map_[violation_id] = fps;
                auto max_fps = 0.0f;
                for (auto& kv : violation_fps_map_){
                    if (kv.second > max_fps) max_fps = kv.second;
                }
                channel_update_data->fps = max_fps;
#else
                channel_update_data->fps = 0.0f;
#endif
                channel_data_update_queue_.push(channel_update_data);
            }
        } else {
            LOG(WARNING) << "unsupported violation code : " << violation_id;
        }
    }

    void CAlgDuchaEngine::RemoveViolation(const std::string &channel_id, const std::string &violation_id) {
        if ((config_.attribute_on() && violation_id != DUCHA_FIGHT_CODE)
            || (config_.fight_on() && violation_id == DUCHA_FIGHT_CODE) ) {
            auto channel_data_old = channel_data_map_.find(channel_id);
            if (channel_data_old) {
                auto channel_update_data = std::make_shared<ChannelUpdateData>();
                channel_update_data->channel_id_ = channel_id;
                channel_update_data->add = false;
                channel_update_data->violation_id = violation_id;
#ifdef USE_MEDIA_UTILS
                violation_fps_map_.erase(violation_id);
                auto max_fps = 0.0f;
                for (auto& kv : violation_fps_map_){
                    if (kv.second > max_fps) max_fps = kv.second;
                }
                channel_update_data->fps = max_fps;
#else
                channel_update_data->fps = 0.0f;
#endif
                channel_data_update_queue_.push(channel_update_data);
            }
        } else {
            LOG(WARNING) << "unsupported violation code : " << violation_id;
        }
    }
AlgRender CAlgDuchaEngine::GetRender(const std::string &violation_code) const {
  if (violation_code == "3090") {
    return CAlgDuchaEngine::Render;
  }
  return nullptr;
}

void CAlgDuchaEngine::Render(const ImageObjectsInfo &image_objects, Mat_Ptr mat, bool enable_tracking_debug) {
  const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
  std::vector<std::string> color_name = {"people","police1","police2","police3","bpeople"};
  std::vector<std::string> action_name = {"normal","phone","telephone","smoke","sleep"};
  std::vector<std::string> sex_name = {"male","female"};
  std::vector<std::string> mask_name = {"no_mask","mask","unknown"};
  for (auto &object : image_objects.ducha_objects) {
    cv::Scalar scalar;
    if (object.delete_flag > 0) {
      continue;
    }
    if (object.ducha_action.type) {
      scalar = cv::Scalar(0, 255, 0);
    }
    else{
      scalar = cv::Scalar(0, 0, 255);
    }
    if (object.ducha_action.score == 0) {
      scalar = cv::Scalar(255, 0, 0);
    }

    cv::putText(*mat, color_name[object.ducha_colour.type],
                cv::Point(object.xmin*(mat->cols / (float)image_objects.sframe->width()),
                          (object.ymin - 10)*(mat->rows / (float)image_objects.sframe->height())),
                cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 1);
    cv::putText(*mat, action_name[object.ducha_action.type],
                cv::Point(object.xmax*(mat->cols / (float)image_objects.sframe->width()),
                          (object.ymin - 10)*(mat->rows / (float)image_objects.sframe->height())),
                cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 1);
    cv::putText(*mat, sex_name[object.ducha_sex.type],
                cv::Point(object.xmin*(mat->cols / (float)image_objects.sframe->width()),
                          (object.ymax - 10)*(mat->rows / (float)image_objects.sframe->height())),
                cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 1);
    cv::putText(*mat, mask_name[object.ducha_mask.type],
                cv::Point(object.xmax*(mat->cols / (float)image_objects.sframe->width()),
                          (object.ymax - 10)*(mat->rows / (float)image_objects.sframe->height())),
                cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 1);
//    cv::putText(*mat, to_string(object.ducha_action.score),
//                cv::Point(object.xmax*(mat->cols / (float)image_objects.sframe->width()),
//                          (object.ymax - 10)*(mat->rows / (float)image_objects.sframe->height())),
//                cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 1);
    cv::rectangle(*mat,
                  cv::Point(object.xmin*(mat->cols / (float)image_objects.sframe->width()),
                            (object.ymin)*(mat->rows / (float)image_objects.sframe->height())),
                  cv::Point(object.xmax*(mat->cols / (float)image_objects.sframe->width()),
                            (object.ymax)*(mat->rows / (float)image_objects.sframe->height())), scalar, 2);

  }
}
} // FLOW

