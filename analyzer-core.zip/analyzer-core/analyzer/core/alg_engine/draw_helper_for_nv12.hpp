#ifndef DRAW_HELPER_FOR_NV12_HPP
#define DRAW_HELPER_FOR_NV12_HPP

#include <opencv2/opencv.hpp>

namespace smcv {
    enum Type{
        AUTO = 0,
        BGR,
        NV12,
    };

    static inline void convert_bgr_to_yuv(const cv::Scalar& color_bgr,  cv::Scalar& color_yuv){
        color_yuv.val[0] = 0.289*color_bgr.val[2] + 0.612 * color_bgr.val[1] + 0.117 * color_bgr.val[0];
        color_yuv.val[1] = -0.168*color_bgr.val[2] - 0.330*color_bgr.val[1] + 0.498 * color_bgr.val[0] + 128;
        color_yuv.val[2] = 0.449*color_bgr.val[2] - 0.435*color_bgr.val[1] - 0.083 * color_bgr.val[0] + 128;
    }
    //draw rectangle
    template<int TYPE>
    inline void rectangle(cv::Mat img, cv::Point pt1, cv::Point pt2,
                          const cv::Scalar& color, int thickness = 1,
                          int lineType = cv::LINE_8, int shift = 0) {
        cv::rectangle(img, pt1, pt2, color, thickness, lineType, shift);
    }

    template<>
    inline void rectangle<NV12>(cv::Mat img, cv::Point pt1, cv::Point pt2,
                          const cv::Scalar& color, int thickness,
                          int lineType, int shift) {
        cv::Scalar color_yuv;
        convert_bgr_to_yuv(color, color_yuv);
	    thickness = std::max<int>(2, thickness/2*2);
        cv::rectangle(img, cv::Point(int(pt1.x)/2*2, int(pt1.y)/2*2), cv::Point(int(pt2.x+1)/2*2, int(pt2.y+1)/2*2), cv::Scalar(color_yuv[0]), thickness, lineType, shift);
        int height = img.rows, width = img.cols, step = img.step[0];
        uchar* data = img.ptr<uchar>(0) + height*step;

        cv::Mat mat2(height/2, width/2, CV_8UC2, data, step);
        cv::rectangle(mat2, cv::Point(pt1.x/2, pt1.y/2), cv::Point(pt2.x/2, pt2.y/2), \
            cv::Scalar(color_yuv[1], color_yuv[2]), thickness/2, lineType, shift );
    }

    template<>
    inline void rectangle<AUTO>(cv::Mat img, cv::Point pt1, cv::Point pt2,
                          const cv::Scalar& color, int thickness,
                          int lineType , int shift ) {
        if (img.channels() == 1) {
            rectangle<NV12>(img, pt1, pt2, color, thickness, lineType, shift);
        } else {
            rectangle<BGR>(img, pt1, pt2, color, thickness, lineType, shift);                     
        }
    }
    //draw line
    template<int TYPE>
    inline void line(cv::Mat img, cv::Point pt1, cv::Point pt2, 
                    const cv::Scalar& color, int thickness = 1,
                    int lineType = cv::LINE_8, int shift = 0) {
        cv::line(img, pt1, pt2, color, thickness, lineType, shift);                
    }

    template<>
    inline void line<NV12>(cv::Mat img, cv::Point pt1, cv::Point pt2, 
                    const cv::Scalar& color, int thickness,
                    int lineType, int shift){
        cv::Scalar color_yuv;
        convert_bgr_to_yuv(color, color_yuv);
        thickness = std::max<int>(2, thickness/2*2);
        cv::line(img,cv::Point(int(pt1.x)/2*2, int(pt1.y)/2*2), cv::Point(int(pt2.x+1)/2*2, int(pt2.y+1)/2*2), cv::Scalar(color_yuv[0]), thickness, lineType, shift);
        int height = img.rows, width = img.cols, step = img.step[0];
        uchar* data = img.ptr<uchar>(0) + height*step;

        cv::Mat mat2(height/2, width/2, CV_8UC2, data, step);
        cv::line(mat2, cv::Point(pt1.x/2, pt1.y/2), cv::Point(pt2.x/2, pt2.y/2), \
            cv::Scalar(color_yuv[1], color_yuv[2]), thickness/2, lineType, shift );
    }
    
    template<>
    inline void line<AUTO>(cv::Mat img, cv::Point pt1, cv::Point pt2,
                          const cv::Scalar& color, int thickness,
                          int lineType, int shift) {
        if (img.channels() == 1) {
            line<NV12>(img, pt1, pt2, color, thickness, lineType, shift);
        } else {
            line<BGR>(img, pt1, pt2, color, thickness, lineType, shift);                     
        }
    }
    //draw text
    template<int TYPE> 
    inline void putText(cv::Mat img, std::string text, cv::Point pt,
                        int fontFace, double fontScale, cv::Scalar color,
                        int thickness = 2, int lineType = 8, bool bottomLeftOrigin = false){
        cv::putText(img, text, pt, fontFace, fontScale, color, thickness, lineType, bottomLeftOrigin);
    }

    template<>
    inline void putText<NV12>(cv::Mat img, std::string text, cv::Point pt,
                        int fontFace, double fontScale, cv::Scalar color,
                        int thickness, int lineType, bool bottomLeftOrigin){
        cv::Scalar color_yuv;
        convert_bgr_to_yuv(color, color_yuv);
        thickness = std::max<int>(2, thickness/2*2);
        cv::putText(img, text, pt, fontFace, fontScale, cv::Scalar(color_yuv.val[0]), thickness, lineType, bottomLeftOrigin);

        int height = img.rows, width = img.cols, step = img.step[0];
        uchar* data = img.ptr<uchar>(0) + height*step;

        cv::Mat mat(height/2, width/2, CV_8UC2, data, step);
        cv::putText(mat, text, cv::Point(pt.x/2, pt.y/2), fontFace, fontScale/2, cv::Scalar(color_yuv.val[1], color_yuv.val[2]),\
         thickness/2, lineType, bottomLeftOrigin);
    }

    template<>
    inline void putText<AUTO>(cv::Mat img, std::string text, cv::Point pt,
                        int fontFace, double fontScale, cv::Scalar color,
                        int thickness, int lineType, bool bottomLeftOrigin){
        if (img.channels() == 1) {
            putText<NV12>(img, text, pt, fontFace, fontScale, color, thickness, lineType, bottomLeftOrigin);
        } else {
            putText<BGR>(img, text, pt, fontFace,fontScale, color, thickness, lineType, bottomLeftOrigin);                 
        }
    }

    template<int TYPE>
    inline void circle(cv::Mat img, cv::Point pt, int radius,
                          const cv::Scalar& color, int thickness = 1,
                          int lineType = cv::LINE_8, int shift = 0) {
        cv::circle(img, pt, radius, color, thickness, lineType, shift);
    }

    template<>
    inline void circle<NV12>(cv::Mat img, cv::Point pt, int radius,
                          const cv::Scalar& color, int thickness,
                          int lineType, int shift) {
        cv::Scalar color_yuv;
        convert_bgr_to_yuv(color, color_yuv);
        cv::circle(img, pt, radius, cv::Scalar(color_yuv[0]), thickness, lineType, shift);
        int height = img.rows, width = img.cols, step = img.step[0];
        uchar* data = img.ptr<uchar>(0) + height*step;

        cv::Mat mat(height/2, width/2, CV_8UC2, data, step);
        cv::circle(mat, cv::Point(pt.x/2.0, pt.y/2.0), radius, \
            cv::Scalar(color_yuv[1], color_yuv[2]), thickness, lineType, shift );
    }

    template<>
    inline void circle<AUTO>(cv::Mat img, cv::Point pt, int radius,
                          const cv::Scalar& color, int thickness,
                          int lineType, int shift) {
        if (img.channels() ==1) {
            circle<NV12>(img, pt, radius, color, thickness, lineType, shift);
        } else {
            circle<BGR>(img, pt, radius, color, thickness, lineType, shift);                     
        }
    }
} //namespace smcv
#endif //DRAW_HELPER_FOR_NV12_HPP
