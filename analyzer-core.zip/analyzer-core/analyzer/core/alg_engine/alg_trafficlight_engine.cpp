#include <future>
#include <algorithm>
#include <vector>
#include "common/io.hpp"
#include "common/pbjson.hpp"
#include "common/util_scale.hpp"
#include "common/tad_internal.hpp"

#include "helper.hpp"
#include "alg_trafficlight_engine.hpp"
#include "core/flow_dispatch.hpp"
#include "helper.hpp"

#include "serving/violation_config.pb.h"
#include "algorithm/traffic_light/traffic_light_recog.hpp"


namespace FLOW {

    using namespace std;

    bool CAlgTrafficlightEngine::match_code(const std::string& code) {
        static const std::set<std::string> allCode={"2440"};
        return allCode.count(code.substr(0,4));
    }

    void CAlgTrafficlightEngine::Init(const inference::EngineConfig &config, int &code) {
        code = FLOW::module_status_success;
        config_ = config.traffic_light();
        std::map<std::string, std::pair<inference::Algorithm, std::vector<char>>> params = {
                {"traffic_light",   {config_.traffic_light_model(),     {}}},
        };
        for (auto &kv : params) {
            if (!IO::ReadBinaryFile(kv.second.first.model_path(), &kv.second.second)) {
                LOG(FATAL) << "Load model " << kv.first << " error, path: " << kv.second.first.model_path();
                return;
            }
        }

        trafficlight_engine_ = make_shared<TrafficLight::TrafficLightRecog>();
        trafficlight_engine_->Setup(params["traffic_light"].second, config_.traffic_light_model(), code);

        // metric init1
        typedef std::map<std::string, std::string> LablesType;
        const prometheus::Summary::Quantiles quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
        profile_metric_trafficlight_ = std::make_shared<ProfileMetric>(LablesType{{"engine", "traffic_light"}, {"model", "traffic_light"}}, quantiles);
    }

    void CAlgTrafficlightEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
        LOG(FATAL) << "no implement";
    }

    void CAlgTrafficlightEngine::GetBatchFrames(VecImage &queue, VecImage &images, std::function<bool(int)> need_skip, int max_batch) const {
        int count = 0;
        images.clear();
        for (auto it = queue.begin(); it != queue.end() && count < max_batch; ) {
            auto &frame = *it;
            if (!need_skip(frame->count)){
                count++;
                images.push_back(frame);
            }
            it = queue.erase(it);
        }
    }

    void CAlgTrafficlightEngine::Process(CFlowDispatch &dsp) {
        while (!channel_data_update_queue_.empty()) {
            auto new_data = channel_data_update_queue_.pop();
            auto& channel_id = new_data->channel_id_;
            bool is_new_channel_id = false;
            if (auto old_data = channel_data_map_.find(new_data->channel_id_)) {
                is_new_channel_id = old_data->task_codes.empty();
                auto copy_data = std::make_shared<ChannelData>(*old_data);
                if (copy_data->UpdateCfg(*new_data)) {
                    channel_data_map_.insert(channel_id, copy_data);
                }
            }
            if (auto channel_data = channel_data_map_.find(channel_id)) {
                CFlowDispatch::spNode chin, chout;
                chin = dsp.get_node(channel_id, "in");
                chout = dsp.get_node(channel_id, "out");
                if (!chin || !chout) return;
                if (is_new_channel_id && new_data->action_ == 1) {   // add violation
                    if (match_code(new_data->add_violation_code_)) {
                        auto trafficlight_detect_interval = config_.traffic_light_model().skip_interval();

                        auto need_skip_fn = [trafficlight_detect_interval](int count) -> bool {
                            return count % trafficlight_detect_interval;
                        };
                        auto current = dsp.add_node(channel_id, "traffic_light", config_.detect_queue_size(), true);

                        current->process([this, need_skip_fn](VecImage &in) {
                            VecImage frames;
                            this->GetBatchFrames(in, frames, need_skip_fn, config_.traffic_light_model().batch_size());
                            if (!frames.empty()) {
                                this->TrafficLightProcess(frames);
                            }
                        });
                        chin->next(current);
                        auto fill_skip = dsp.add_node(
                                        channel_id,
                                        "traffic_light-fill-skipframe",
                                        2);
                        auto last_traffic_lights = std::make_shared<TrafficLight_Event>();
                        fill_skip->process([this, last_traffic_lights, need_skip_fn](VecImage &in) {
                            for (auto image : in) {
                                if (!need_skip_fn(image->count)) {
                                    last_traffic_lights->traffic_lights = image->highways.traffic_light_event.traffic_lights;
                                } else {
                                    image->highways.traffic_light_event.traffic_lights = last_traffic_lights->traffic_lights;
                                }
                            }
                            in.clear();
                        });
                        current->next(fill_skip);
                        fill_skip->next(chout);
                    } else {
                        // nop
                    }
                } else if (new_data->action_ == 2) { // remove violation
                    dsp.remove_node(channel_id, "traffic_light");
                    dsp.remove_node(channel_id, "traffic_light-fill-skipframe");
                }
            }
        }
    }

    void CAlgTrafficlightEngine::ProcessByName(const std::string &name,
                                               const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) {
    }

    void CAlgTrafficlightEngine::TrafficLightProcess(const VecImage &images){
        if (nullptr == trafficlight_engine_) { return; }
        std::unique_lock<std::mutex> lock{trafficlight_lock_};
        ProfilerHelper _profiler(&trafficlight_profiler_, "traffic_light", [](Profiler *p) {
            LOG(DEBUG) << "profiler " << p->get_stats_str();
        });

        VecImage images_reuslt;
        VecShellFrame im_mats;
        VecBoxF boxes;
        VecString vids;
        for(const auto image : images) {
            auto channel_data = channel_data_map_.find(image->channel_id);
            if (nullptr == channel_data.get()) {
                continue;
            }
            auto& trafficlight_boxes = channel_data->trafficlight_boxes_;
            if (trafficlight_boxes.empty()) {
                continue;
            }
            for(const auto& box_kv : trafficlight_boxes) {
                for(const auto& box : *(box_kv.second)) {
                    images_reuslt.push_back(image);
                    im_mats.push_back(image->sframe);
                    boxes.push_back(box);
                    vids.push_back(box_kv.first);
                }
            }
        }
        // process
        std::vector<TrafficLight::TrafficLightColor> results;
        {
            ProfileMetric::Helper _metric_helper(*profile_metric_trafficlight_);
            trafficlight_engine_->Predict(im_mats, boxes, &results);
        }

        // result
        for(int i=0; i<images_reuslt.size(); i++ ) {
            BoxF copy_box(boxes[i]);
            copy_box.label = results[i];
            images_reuslt[i]->highways.traffic_light_event.processed = true;
            const auto& vid = vids[i];
            images_reuslt[i]->highways.traffic_light_event.traffic_lights[vid].push_back(copy_box);
        }
    }

    void CAlgTrafficlightEngine::AddStream(const std::string &channel_id,
                                         const std::string &config) {
        int code = 0;
        auto channel_data = channel_data_map_.find(channel_id);
        if (nullptr == channel_data.get()) {
            channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data->last_image_ = std::make_shared<ImageObjectsInfo>();
            channel_data_map_.insert(channel_id, channel_data);
        }
    }
    void CAlgTrafficlightEngine::RemoveStream(const std::string &channel_id) {
        channel_data_map_.erase(channel_id);

        auto vdata = std::make_shared<ChannelData>();
        vdata->channel_id_ = channel_id;
        vdata->action_ = 2;
        channel_data_update_queue_.push(vdata);
    }

    void CAlgTrafficlightEngine::AddViolation(const std::string &channel_id,
                                            const std::string &violation_id,
                                            const std::string &config) {
        auto channel_data_old = channel_data_map_.find(channel_id);
        if (channel_data_old) {
            auto channel_data = std::make_shared<ChannelData>();
            VecBoxF trafficlight_boxes;
            std::string violation_code, background_image_path;
            if(ParseConfig(config, &violation_code, &trafficlight_boxes, &background_image_path)){
                if (!match_code(violation_code)) {
                    return;
                }
                if (trafficlight_boxes.empty()) {
                    LOG(WARNING) << "trafficlight_boxes is empty ";
                    LOG(WARNING) << "cfg:" << config;
                    return;
                }
                channel_data->channel_id_           = channel_id;
                channel_data->action_               = 1;
                channel_data->add_violation_        = violation_id;
                channel_data->add_violation_code_   = violation_code;
                channel_data->trafficlight_boxes_[violation_id]   = std::make_shared<VecBoxF>(trafficlight_boxes);
                channel_data_update_queue_.push(channel_data);
            }
        }
    }

    void CAlgTrafficlightEngine::RemoveViolation(const std::string &channel_id,
                                               const std::string &violation_id) {
        auto channel_data = channel_data_map_.find(channel_id);
        if (channel_data) {
            auto vdata = std::make_shared<ChannelData>();
            vdata->channel_id_ = channel_id;
            vdata->action_ = 2;
            vdata->remove_violation_ = violation_id;
            channel_data_update_queue_.push(vdata);
        }
    }

    AlgRender CAlgTrafficlightEngine::GetRender(const std::string &violation_code) const {
        if(match_code(violation_code)) {
            return CAlgTrafficlightEngine::Render;
        }
        return nullptr;
    }

    void CAlgTrafficlightEngine::Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_debug){
        const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
        for (auto &traffic_lights_kv : image_objects.highways.traffic_light_event.traffic_lights) {
        for (auto &object : traffic_lights_kv.second) {
            if (enable_debug) {
                auto scalar = cv::Scalar(255, 255, 255);
                auto text = TrafficLight::helperGetStringTrafficLightColor(TrafficLight::TrafficLightColor(object.label));
                std::to_string(object.label)
                        + "/" + std::to_string(object.violate_state)
                        + "/" + std::to_string(object.score);
                cv::putText(*mat, text,
                            cv::Point(object.xmin, object.ymin - 10)*scale,
                            cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);
                cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                            cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
            }
        }
        }
    }

    bool CAlgTrafficlightEngine::ParseConfig(const std::string& config, std::string* code, VecBoxF *boxes, std::string* bg_img_path) {
        std::string err;
        auto violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(config, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< config;
            return false;
        }

        auto& cfg = *violation_cfg;
        *code = cfg.code();
        *bg_img_path = cfg.background_image_path();
        boxes->clear();
        for (int i=0; i<cfg.conditions_size(); i++) {
            if (cfg.conditions(i).data_offset().empty()) {
                cfg.mutable_conditions(i)->mutable_data_offset()->Add(
                    cfg.conditions(i).data_size());
            }
            auto& cond = cfg.conditions(i);
            auto& data = cond.data();
            auto& data_offset = cond.data_offset();
            for(int i=0,j=0; i < data_offset.size(); i++) {
                BoxF box;
                const auto offset = data_offset.Get(i);
                if ((offset - j) < 2*2) {
                    continue;
                }
                box.xmin=box.xmax=cond.data(j++);
                box.ymin=box.ymax=cond.data(j++);
                for( ; j < offset; j++){
                    if (j%2 == 0) {
                        box.xmin = std::min(box.xmin, cond.data(j));
                        box.xmax = std::max(box.xmax, cond.data(j));
                    } else {
                        box.ymin = std::min(box.ymin, cond.data(j));
                        box.ymax = std::max(box.ymax, cond.data(j));
                    }
                }
                if (std::abs(box.xmax-box.xmin) < 0.5 ||
                    std::abs(box.ymax-box.ymin) < 0.5){
                    continue;
                }
                boxes->push_back(box);
            }
        }
        return true;
    }
}  // namespace FLOW
