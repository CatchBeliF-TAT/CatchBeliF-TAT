#include <future>
#include <algorithm>
#include <vector>
#include "common/io.hpp"
#include "common/pbjson.hpp"
#include "common/util_scale.hpp"
#include "common/tad_internal.hpp"

#include "helper.hpp"
#include "alg_guardrail_engine.hpp"
#include "core/flow_dispatch.hpp"
#include "helper.hpp"

#include "serving/violation_config.pb.h"
#include "algorithm/guardrail/guardrail.hpp"


namespace FLOW {

    using namespace std;

    bool CAlgGuardrailEngine::match_code(const std::string& code) {
        static const std::set<std::string> allCode={"2460", "2461"};
        return allCode.count(code.substr(0,4));
    }

    void CAlgGuardrailEngine::Init(const inference::EngineConfig &config, int &code) {
        config_ = config.guardrail();

        std::map<std::string, std::pair<inference::Algorithm, std::vector<char>>> params = {
                {"traffic_detect_model", {config_.traffic_detect_model(),   {}}},
        };
        for (auto &kv : params) {
            if (!IO::ReadBinaryFile(kv.second.first.model_path(), &kv.second.second)) {
                LOG(FATAL) << "Load model " << kv.first << " error, path: " << kv.second.first.model_path();
                return;
            }
        }

        guardrail_engine_ = make_shared<Guardrail::Guardrail>();
        guardrail_engine_->Setup_guardrail(params["traffic_detect_model"].second, config_.traffic_detect_model(), code);

        // metric init
        typedef std::map<std::string, std::string> LablesType;
        const prometheus::Summary::Quantiles quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
        profile_metric_guardrail_ = std::make_shared<ProfileMetric>(LablesType{{"engine", "guardrail"}, {"model", "guardrail"}}, quantiles);
    }

    void CAlgGuardrailEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
        LOG(FATAL) << "no implement";
    }

    void CAlgGuardrailEngine::GetBatchFrames(VecImage &queue, VecImage &images, std::function<bool(int)> need_skip, int max_batch) const {
        int count = 0;
        images.clear();
        for (auto it = queue.begin(); it != queue.end() && count < max_batch; ) {
            auto &frame = *it;
            if (!need_skip(frame->count)){
                count++;
                images.push_back(frame);
            }
            it = queue.erase(it);
        }
    }

    void CAlgGuardrailEngine::Process(CFlowDispatch &dsp) {
        while (!channel_data_update_queue_.empty()) {
            auto new_data = channel_data_update_queue_.pop();
            auto& channel_id = new_data->channel_id_;
            bool is_new_channel_id = false;
            if (auto old_data = channel_data_map_.find(new_data->channel_id_)) {
                is_new_channel_id = old_data->guardrail_task_codes.empty();
                auto copy_data = old_data->UpdateCfg(*new_data);
                if (copy_data) {
                    channel_data_map_.insert(channel_id, copy_data);
                }
            } else {
            }
            if (auto channel_data = channel_data_map_.find(channel_id)) {
                CFlowDispatch::spNode guardrail, chin, chout;
                chin = dsp.get_node(channel_id, "in");
                chout = dsp.get_node(channel_id, "out");
                if (!chin || !chout) return;
                if (is_new_channel_id && new_data->action_ == 1) {   // add violation
                    if (match_code(new_data->violation_code_)) {
                        auto guardrail_detect_interval = config_.traffic_detect_interval();

                        auto need_skip_fn = [guardrail_detect_interval](int count) -> bool {
                            return count % guardrail_detect_interval;
                        };
                        guardrail = dsp.add_node(channel_id, "guardrail", config_.detect_queue_size());

                        guardrail->process([this, need_skip_fn, channel_id](VecImage &in) {
                            auto channel_data = this->channel_data_map_.find(channel_id);
                            if(channel_data &&
                                !channel_data->guardrail_boxes_.empty()){
                                VecImage frames;
                                this->GetBatchFrames(in, frames, need_skip_fn, config_.traffic_detect_model().batch_size());
                                    if (!frames.empty()) {
                                        this->GuardrailProcess(channel_data, frames);
                                    }
                            } else {
                                in.clear();
                            }
                        });
                        chin->next(guardrail);
                        auto fill_skip = dsp.add_node(
                                        channel_id,
                                        std::string(typeid(this).name()) + "-fill-skipframe",
                                        2);
                        auto last_guardrail = std::make_shared<Guardrail_Event>();
                        fill_skip->process([this, last_guardrail, need_skip_fn](VecImage &in) {
                            for (auto image : in) {
                                if (!need_skip_fn(image->count)) {
                                    last_guardrail->guardrails = image->guardrails.guardrails;
                                } else {
                                    image->guardrails.guardrails = last_guardrail->guardrails;
                                }
                            }
                            in.clear();
                        });
                        guardrail->next(fill_skip);
                        fill_skip->next(chout);
                    } else {
                        // nop
                    }
                } else if (new_data->action_ == 2) { // remove violation
                    dsp.remove_node(channel_id, "guardrail");
                }
            }
        }
    }

    void CAlgGuardrailEngine::ProcessByName(const std::string &name,
                                            const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) {
    }

    void CAlgGuardrailEngine::GuardrailProcess(spChannelData channel, const VecImage &images){
        std::unique_lock<std::mutex> lock{guardrail_lock_};
        ProfilerHelper _profiler(
                &guardrail_profiler_, "GuardrailProcess",
                [](Profiler *p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });

        typedef std::function<bool(int)> TypeFilter;
        // detect
        VecImage image_detect;
        VecMat mat_detect;
        std::vector<TypeFilter> det_types;

        for (auto &image : images) {
            auto channel_data = channel_data_map_.find(image->channel_id);
            if (nullptr == channel_data.get()) {
                continue;
            }

            const auto &pic_mat = image->sframe->getMat();
            image_detect.push_back(image);
            mat_detect.push_back(pic_mat);
            det_types.push_back([](int type) -> bool { return true; });
        }

        std::vector<VecBoxF> events;
        {
            ProfileMetric::Helper _metric_helper(*profile_metric_guardrail_);
            guardrail_engine_->Process(mat_detect,
                                        channel->guardrail_boxes_,
                                        channel->guardrail_periods_,
                                        channel->guardrail_origin_roi_mats_,
                                        channel->guardrail_roi_mats_,
                                        channel->guardrail_wrong_frames_,
                                        channel->guardrail_wrong_frame_durations_,
                                        channel->guardrail_thresholds_,
                                        channel->guardrail_max_socres_,
                                        events);

        }

        for (size_t i = 0; i < image_detect.size(); i++) {
            auto& guardrails_map = image_detect[i]->guardrails.guardrails;
            const auto& guardrails_violation_ids = channel->guardrail_violation_ids_;
            for (size_t j = 0; j < events[i].size(); j++) {
                guardrails_map[guardrails_violation_ids[j]].push_back(events[i][j]);
            }
        }

    }


    void CAlgGuardrailEngine::AddStream(const std::string &channel_id,
                                         const std::string &config) {
        int code = 0;
        auto channel_data = channel_data_map_.find(channel_id);
        if (nullptr == channel_data.get()) {
            channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data->last_image_ = std::make_shared<ImageObjectsInfo>();
            channel_data_map_.insert(channel_id, channel_data);
        }
    }
    void CAlgGuardrailEngine::RemoveStream(const std::string &channel_id) {
        channel_data_map_.erase(channel_id);

        auto vdata = std::make_shared<ChannelData>();
        vdata->channel_id_ = channel_id;
        vdata->action_ = 2;
        channel_data_update_queue_.push(vdata);
    }

    void CAlgGuardrailEngine::AddViolation(const std::string &channel_id,
                                            const std::string &violation_id,
                                            const std::string &config) {
        auto channel_data_old = channel_data_map_.find(channel_id);
        if (channel_data_old) {
            auto channel_data = std::make_shared<ChannelData>();
            VecBoxF guardrail_boxes;
            std::vector<std::shared_ptr<cv::Mat>> guardrail_roi_mats;
            std::string violation_code, background_image_path;
            float similar_threshold = 0;
            int period=0;
            if(ParseConfig(config, &violation_code, &guardrail_boxes, &background_image_path, &similar_threshold, &period)){
                if (!match_code(violation_code)) {
                    return;
                }
                if (background_image_path.empty()) {
                    LOG(WARNING) << "background_image_path is empty ";
                    LOG(WARNING) << "cfg:" << config;
                    return;
                }
                if (guardrail_boxes.empty()) {
                    LOG(WARNING) << "guardrail_boxes is empty ";
                    LOG(WARNING) << "cfg:" << config;
                    return;
                }
                cv::Mat first_frame_mat = cv::imread(background_image_path, cv::IMREAD_COLOR);
                for(auto &guardrail_box : guardrail_boxes){
                    cv::Mat guardrail_box_img = first_frame_mat(cv::Rect(guardrail_box.xmin, guardrail_box.ymin,
                    guardrail_box.xmax - guardrail_box.xmin, guardrail_box.ymax - guardrail_box.ymin));
                    std::shared_ptr<cv::Mat> guardrail_box_img_resize= std::make_shared<cv::Mat>();
                    cv::resize(guardrail_box_img, *guardrail_box_img_resize, cv::Size(256, 256));
                    guardrail_roi_mats.push_back(guardrail_box_img_resize);
                }
                channel_data->channel_id_           = channel_id;
                channel_data->action_               = 1;
                channel_data->add_violation_        = violation_id;
                channel_data->violation_code_       = violation_code;
                channel_data->guardrail_boxes_      = guardrail_boxes;
                channel_data->guardrail_roi_mats_   = guardrail_roi_mats;
                channel_data->guardrail_origin_roi_mats_       = guardrail_roi_mats;
                channel_data->guardrail_violation_ids_         = VecString(guardrail_boxes.size(), violation_id);
                channel_data->guardrail_thresholds_            = VecFloat(guardrail_boxes.size(), similar_threshold);
                channel_data->guardrail_max_socres_            = VecFloat(guardrail_boxes.size(), 0);
                channel_data->guardrail_periods_               = VecInt(guardrail_boxes.size(), period*3);
                channel_data->guardrail_wrong_frames_          = VecPtrMat(guardrail_boxes.size(), nullptr);
                channel_data->guardrail_wrong_frame_durations_ = VecInt(guardrail_boxes.size(),0);
                channel_data_update_queue_.push(channel_data);
            }
        }
    }

    void CAlgGuardrailEngine::RemoveViolation(const std::string &channel_id,
                                               const std::string &violation_id) {
        auto channel_data = channel_data_map_.find(channel_id);
        if (channel_data) {
            auto vdata = std::make_shared<ChannelData>();
            vdata->channel_id_ = channel_id;
            vdata->action_ = 2;
            vdata->remove_violation_ = violation_id;
            channel_data_update_queue_.push(vdata);
        }
    }

    AlgRender CAlgGuardrailEngine::GetRender(const std::string &violation_code) const {
        if(match_code(violation_code)) {
            return CAlgGuardrailEngine::Render;
        }
        return nullptr;
    }

    void CAlgGuardrailEngine::Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_debug){
        const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
        for (auto &violation_kv : image_objects.guardrails.guardrails) {
        for (auto &object : violation_kv.second) {
            if (enable_debug) {
                auto scalar = cv::Scalar(255, 255, 255);
                auto text = std::to_string(object.label)
                        + "/" + std::to_string(object.violate_state)
                        + "/" + std::to_string(object.score);
                cv::putText(*mat, text,
                            cv::Point(object.xmin, object.ymin - 10)*scale,
                            cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);
                cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                            cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
            }
            if (object.violate_state >0) {
                cv::Scalar scalar(0, 0, 0);
                if(object.violate_state==2){
                    scalar = cv::Scalar(0, 0, 255); // red
                }else if(object.violate_state==1){
                    scalar = cv::Scalar(0, 255, 0); // green
                }
                cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                            cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
            }
        }
        }
    }

    bool CAlgGuardrailEngine::ParseConfig(const std::string& config, std::string* code, VecBoxF *boxes, std::string* bg_img_path, float* similar_threshold, int* period) {
        std::string err;
        auto violation_cfg = std::make_shared<inference::ViolationConfig>();
        json2pb(config, violation_cfg.get(), &err);
        if (!err.empty()){
            LOG(WARNING) << err <<", json= "<< config;
            return false;
        }

        auto& cfg = *violation_cfg;
        *code = cfg.code();
        *bg_img_path = cfg.background_image_path();
        if(*bg_img_path==""){
            *bg_img_path = "/tmp/123.png";
        }
        boxes->clear();
        for (int i=0; i<cfg.conditions_size(); i++) {
            if (cfg.conditions(i).data_offset().empty()) {
                cfg.mutable_conditions(i)->mutable_data_offset()->Add(
                    cfg.conditions(i).data_size());
            }
            auto& cond = cfg.conditions(i);
            auto& data = cond.data();
            auto& data_offset = cond.data_offset();
            *similar_threshold = cond.threshold();
            *period = cond.has_parking_second() ? cond.parking_second() : 60;
            for(int i=0,j=0; i < data_offset.size(); i++) {
                BoxF box;
                const auto offset = data_offset.Get(i);
                if ((offset - j) < 2*2) {
                    continue;
                }
                box.xmin=box.xmax=cond.data(j++);
                box.ymin=box.ymax=cond.data(j++);
                for( ; j < offset; j++){
                    if (j%2 == 0) {
                        box.xmin = std::min(box.xmin, cond.data(j));
                        box.xmax = std::max(box.xmax, cond.data(j));
                    } else {
                        box.ymin = std::min(box.ymin, cond.data(j));
                        box.ymax = std::max(box.ymax, cond.data(j));
                    }
                }
                if (std::abs(box.xmax-box.xmin) < 0.5 ||
                    std::abs(box.ymax-box.ymin) < 0.5){
                    continue;
                }
                boxes->push_back(box);
            }
        }
        return true;
    }
}  // namespace FLOW
