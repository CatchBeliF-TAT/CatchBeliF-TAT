#include <future>
#include <vector>

#include "alg_sharedbike_engine.hpp"
#include "algorithm/sharedbike/sharedbike.hpp"
#include "common/io.hpp"
#include "common/json.hpp"
#include "common/pbjson.hpp"
#include "common/tad_internal.hpp"
#include "core/metric.hpp"
#include "helper.hpp"
#include "serving/violation_config.pb.h"

namespace FLOW {

    using namespace std;
    
    const std::string XHGXDC_CODE("2462"); //徐汇共享单车

    const std::string GXDC_ENGINE_NAME("sharedbike");
    const std::unordered_map<std::string, std::string> GXDC_VIOLATION_MAP = {
        {XHGXDC_CODE, GXDC_ENGINE_NAME}
    }; 

    void CAlgSharedBikeEngine::Init(const inference::EngineConfig &config, int &code) {
        config_ = config.sharedbike();
        std::map<std::string, std::pair<std::string, std::vector<char>>> params = {
            {"sharedbike_detect_tronmodel", {config_.detect().model_path(), std::vector<char>()}},
        };
        for (auto& kv : params) {
            if (kv.second.first == ""){
                LOG(WARNING) << "Skip load model " << kv.first << ", path(\"" <<  kv.second.first <<"\") configed";
                code = module_status_parse_model_error;
                return;
            }
            if (!IO::ReadBinaryFile(kv.second.first, &kv.second.second)) {
                LOG(FATAL) << "Load model " <<kv.first << ", path " << kv.second.first << " error";
                code = module_status_parse_model_error;
                return;
            }
        }

        // detect_model
        detector_ = make_shared<SharedBike::SharedBike>();
        detector_->Setup(params["sharedbike_detect_tronmodel"].second, config_.detect());
        code = module_status_success;

    

        // metric init
        typedef std::map<std::string, std::string> LablesType;
        const prometheus::Summary::Quantiles quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
        profile_metric_detector_ = std::make_shared<ProfileMetric>(LablesType{{"engine", "sharedbike"}, {"model", "detect"}}, quantiles);
    }

    bool CAlgSharedBikeEngine::Skip(int64_t count, int interval) const {
        return count % interval;
    }

    void CAlgSharedBikeEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
        image_map.clear();
        std::unordered_map<string, int> channel_count;
        for (auto it = queue.begin(); it != queue.end() && image_map.size() < config_.detect().batch_size(); ) {
            auto &frame = *it;
            if (!this->Skip(frame->count, config_.detect_interval())) {
                image_map.push_back(frame);
            }
            it = queue.erase(it);
        }
    }

    void CAlgSharedBikeEngine::GetBatchFrames(VecImage &queue, VecImage &image_map, int interval, int batch_size) const {
        image_map.clear();
        std::unordered_map<string, int> channel_count;
        for (auto it = queue.begin(); it != queue.end() && image_map.size() < batch_size; ) {
            auto &frame = *it;
            if (!this->Skip(frame->count, interval)) {
                image_map.push_back(frame);
            }
            it = queue.erase(it);
        }
    }

    void CAlgSharedBikeEngine::Process(CFlowDispatch &dsp) {}
    void CAlgSharedBikeEngine::ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) {

    }

    void CAlgSharedBikeEngine::detectProcess(const VecImage& images) {
      std::unique_lock<std::mutex> lock{SharedBike_detcte_lock_};
      Profiler profiler_detect;
      int batch_size = 0;
      ProfilerHelper _profiler(&profiler_detect, "SharedBike DetectionProcess",
                              [&](Profiler* p) {
                                LOG(DEBUG) << "profiler batch_size:" << batch_size
                                            << ", " << p->get_stats_str();
                              });

  // typedef vector<vector<RectInfo>> VecRectInfos;
  typedef std::function<bool(int)> TypeFilter;
  // detect
  VecImage image_detect;
  // VecRectInfos image_rects;
  VecMat mat_detect;
  std::vector<cv::Rect> rois;
  std::vector<prometheus::spCounter> counters;
  std::vector<SharedBike_Event> res_events;

  for (auto& image : images) {
    if (this->Skip(image->count, config_.detect_interval())) {
      continue;
    }
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }

    counters.push_back(channel_data->detect_object_counter_);
    const auto &pic_mat = image->sframe->getMat();
    cv::Rect roi(0, 0, image->sframe->width(), image->sframe->height());
    image_detect.push_back(image);
    mat_detect.push_back(pic_mat);
    res_events.push_back(image->sharedbike_objs);
    rois.push_back(roi);
  }

  batch_size = mat_detect.size();
  int code = -1;

  ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
  detector_->Process(mat_detect, rois, res_events);

  // process detect result
  for (size_t i = 0; i < image_detect.size(); i++) {
    VecBoxF& objects = image_detect[i]->sharedbike_objs.objs;
    const auto& rects = res_events[i].objs;
    VecBoxF image_boxes;
    for (auto& rect : rects) {
      image_boxes.push_back(rect);
    }
    objects.insert(objects.end(), image_boxes.begin(), image_boxes.end());
  }

  // PrintDetectInfo(images);
}

    void CAlgSharedBikeEngine::AddEngineInDsp(const std::string &channel_id, const std::string &engine_name, CFlowDispatch &dsp){
        CFlowDispatch::spNode chin, chout;
        chin = dsp.get_node(channel_id, "in");
        chout = dsp.get_node(channel_id, "out");
        if (!chin || !chout){
            return;
        }
        //处理各个engine
        if (engine_name == GXDC_ENGINE_NAME) {
            CFlowDispatch::spNode current, last;
            last = chin;
            current = dsp.add_node(channel_id, "SharedBike-detect",
                                          config_.detect_queue_size(), true);
            current->process([this](VecImage& in) {
              VecImage frames;
              this->GetBatchFrames(in, frames);
              if (!frames.empty()) {
                this->detectProcess(frames);
              }
              });
            last->next(current);
            last = current;

            current = dsp.add_node(channel_id, "SharedBike-fill-skipframe", 2);
            auto last_SharedBike_objects = std::make_shared<ImageObjectsInfo>();
            last_SharedBike_objects->channel_id = channel_id;
            auto checker = [this](const spImageObjectsInfo frame)->bool{ return this->Skip(frame->count, config_.detect_interval()); };
            current->process([this, checker, last_SharedBike_objects](VecImage &in) {
              for (auto image : in) {
                  CAlgSharedBikeEngine::FillSkipframe(checker, last_SharedBike_objects, image);
              }
              in.clear();
            });
            last->next(current);
            last = current;

            last->next(chout);
  }
}

    void CAlgSharedBikeEngine::RemoveEngineInDsp(const std::string &channel_id, const std::string &engine_name, CFlowDispatch &dsp){
        //处理各个engine
        if(engine_name==GXDC_ENGINE_NAME){
            dsp.remove_node(channel_id, "SharedBike-detect");
            dsp.remove_node(channel_id, "SharedBike-fill-skipframe");
        }
    }

    void CAlgSharedBikeEngine::AddStream(const std::string &channel_id, const std::string &config) {
        std::unique_lock<std::mutex> metriclock{metric_lock_};
        static int uid=0;
        auto it = map_.find(channel_id);
        if(it!=map_.end()){
            LOG(WARNING)<<"AddStream failed, channel "<<channel_id<<" already exist in map_";
        }else{
            auto channel = map_[channel_id];
        }
        auto i = map_metric_.find(channel_id);
        if(i!=map_metric_.end()){
            LOG(WARNING)<<"AddStream failed, channel "<<channel_id<<" already exist in map_metric_";
        }else{
            typedef std::map<std::string, std::string> LablesType;
            map_metric_[channel_id] = std::shared_ptr<prometheus::Counter>(
                &Metric::Instance().object_counter->Add(LablesType{
                    {"engine", "SharedBike"},
                    {"model", "SharedBike"},
                    {"stream_id", channel_id},
                    {"uid", to_string(uid++)},
                }),
                [](prometheus::Counter* c) {Metric::Instance().object_counter->Remove(c);}
            );
        }
    }

    //remove stream时flow_engine里清除所有node, 这里不需要
    void CAlgSharedBikeEngine::RemoveStream(const std::string &channel_id) {
        std::unique_lock<std::mutex> metriclock{metric_lock_};
        auto it = map_.find(channel_id);
        if (it != map_.end()){
            map_.erase(it);
        }else{
            LOG(WARNING)<<"RemoveStream failed, channel "<<channel_id<<" not exist in map_";
        }

        auto i = map_metric_.find(channel_id);
        if(i!=map_metric_.end()){
            map_metric_.erase(i);
        }else{
            LOG(WARNING)<<"RemoveStream failed, channel "<<channel_id<<" not exist in map_metric_";
        }
    }

    void CAlgSharedBikeEngine::AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config){}
    
    void CAlgSharedBikeEngine::RemoveViolation(const std::string &channel_id, const std::string &violation_id){}

    void CAlgSharedBikeEngine::AddViolation2(const std::string &channel_id, const std::string &violation_id, const std::string &config, CFlowDispatch &dsp) {
        auto root = get_document(config);
        auto violation_code = get_string(root, "code", "");
        auto engine_name = GXDC_VIOLATION_MAP.find(violation_code);
        if(engine_name == GXDC_VIOLATION_MAP.end()){
            //不是SharedBike相关的violation
            return;
        } else {
          auto channel_update_data = std::make_shared<ChannelUpdateData>();
          channel_update_data->channel_id_ = channel_id;
          channel_update_data->add = true;
          auto old_data = channel_data_map_.find(channel_id);
          if (old_data){
              auto copy_data = std::make_shared<ChannelData>(*old_data);
              if (copy_data->UpdateCfg(*channel_update_data)) {
                channel_data_map_.insert(channel_id, copy_data);
              } else {
                // continue;
              }
          } else {
            auto channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data->last_image_ = std::make_shared<ImageObjectsInfo>();
            channel_data_map_.insert(channel_id, channel_data);
          }
          auto channel = map_.find(channel_id);
          if (channel == map_.end()) {
            LOG(ERROR) << "stream not found, channel id: " << channel_id
                      << ", violation id: " << violation_id;
          } else {
            auto engine = channel->second.find(engine_name->second);
            if (engine == channel->second.end()) {
              (channel->second)[engine_name->second].insert(violation_id);
              AddEngineInDsp(channel_id, engine_name->second, dsp);
            } else {
              engine->second.insert(violation_id);
            }
          }
        }
    }

    void CAlgSharedBikeEngine::RemoveViolation2(const std::string &channel_id, const std::string &violation_id, CFlowDispatch &dsp) {
        auto channel = map_.find(channel_id);
        if(channel==map_.end()){
            LOG(ERROR)<<"stream not found, channel id: "<<channel_id<<", violation id: "<<violation_id;
            return;
        }
        auto channel_data = channel_data_map_.find(channel_id);
  
        // engine is pair<std::string, std::unordered_set<std::string>>
        for (auto engine = channel->second.begin(); engine != channel->second.end();
            engine++) {
          auto violation = engine->second.find(violation_id);
          if (violation != engine->second.end()) {
            // find violation
            //如果engine只服务要删除的这一个violation, 删除engine
            if (engine->second.size() == 1) {
              RemoveEngineInDsp(channel_id, engine->first, dsp);
              channel->second.erase(engine);
            } else {
              engine->second.erase(violation);
            }
            return;
          }
        }
  }  // FLOW


    AlgRender CAlgSharedBikeEngine::GetRender(const std::string &violation_code) const {
        if (violation_code.size()<4) {
            return nullptr;
        }
        if (violation_code == XHGXDC_CODE) {
            return CAlgSharedBikeEngine::Render;
        }
        return nullptr;
    }

    void CAlgSharedBikeEngine::FillSkipframe(fnSkipChecker skip, const spImageObjectsInfo processedFrame, spImageObjectsInfo currentFrame) {
        LOG_IF(FATAL, processedFrame->channel_id != currentFrame->channel_id) 
            << "frame channel_id missmatch, (" << processedFrame->channel_id << "!=" << currentFrame->channel_id <<")";

        if (!skip(currentFrame)) {
            processedFrame->sharedbike_objs = currentFrame->sharedbike_objs;
        } else {
            // fake
            currentFrame->sharedbike_objs = processedFrame->sharedbike_objs;
        }
        
    }

    void CAlgSharedBikeEngine::Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug) {
      if (!enable_tracking_debug) return;
      const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
      const auto scale_w = mat->rows / (float)image_objects.sframe->height();
      const auto scale_h = mat->cols / (float)image_objects.sframe->width();
      for (auto &object : image_objects.sharedbike_objs.objs) {
        cv::Scalar scalar;
        scalar = cv::Scalar(255, 255, 255);

        if (object.delete_flag > 0) {
          continue;
        }
        std::map<int, std::string> ssmap1 = {
          {SharedBike::SharedBikeType::SharedBike_label, "sharedbike"},
        };

        cv::rectangle(*mat, cv::Point(object.xmin * scale_w, object.ymin * scale_h),
                            cv::Point(object.xmax *scale_w, object.ymax * scale_h), scalar, 2);

        cv::putText(*mat, ssmap1.find(object.label)->second,
            cv::Point(object.xmax* scale_w, object.ymin* scale_h),
            cv::FONT_HERSHEY_PLAIN, 1, cv::Scalar(255, 0, 0),
            2);
      }
    }
} // FLOW
