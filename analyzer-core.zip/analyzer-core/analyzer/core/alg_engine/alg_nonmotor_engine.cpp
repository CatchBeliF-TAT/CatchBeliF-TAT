
#include <vector>
#include <future>

#include "common/io.hpp"
#include "common/pbjson.hpp"

#include "helper.hpp"
#include "alg_nonmotor_engine.hpp"

#include "serving/violation_config.pb.h"

#include "algorithm/detect/detect.hpp"
#include "algorithm/track/track_wraper.hpp"
#include "algorithm/plate/waimai_plate.hpp"
#include "algorithm/vehicleattribute/behaviour_attr.hpp"
#include "algorithm/traffic_light/traffic_light_recog.hpp"

namespace FLOW {

    using namespace std;

    void CAlgNonmotorEngine::Init(const inference::EngineConfig &config, int &code) {
        config_ = config.nonmotor();

        std::map<std::string, std::pair<std::string, std::vector<char>>> params = {
            {"detect_model",        {config_.detect().model_path(),          {}}},
            {"plate_model",         {config_.plate().model_path(),           {}}},
            {"traffic_light_model", {config_.traffic_light().model_path(),   {}}},
            {"behaviour_model",     {config_.behavior_attr().model_path(),   {}}},
        };
        for (auto& kv : params) {
            if (kv.second.first == ""){
                LOG(WARNING) << "Skip load model " << kv.second.first << ", no path configed";
            }
            if (!IO::ReadBinaryFile(kv.second.first, &kv.second.second)) {
                LOG(FATAL) << "Load model " << kv.second.first << " error";
                return;
            }
        }

        // detect_model
        detector_ = make_shared<Detect::DetectModule>();
        detector_->Setup(params["detect_model"].second, config_.detect(), code);
        detect_input_shapes = detector_->GetInputShapes();
        // plate_model
        if (config_.plate().model_path() != "") {
            waimai_plate_ = std::make_shared<Plate::WaiMaiPlate>();
            waimai_plate_->Setup(params["plate_model"].second, config_.plate());
        }
        // traffic_light_model
        traffic_light_recog_ = std::make_shared<TrafficLight::TrafficLightRecog>();
        traffic_light_recog_->Setup(params["traffic_light_model"].second, config_.traffic_light(), code);
        // behaviour_model
        behaviour_attr_ = std::make_shared<Attribute::BehaviourAttributeModule>();
        behaviour_attr_->Setup(params["behaviour_model"].second, config_.behavior_attr(), code);
        behaviour_attr2_ = std::make_shared<Attribute::BehaviourAttributeModule>();
        behaviour_attr2_->Setup(params["behaviour_model"].second, config_.behavior_attr(), code);
        // metric init  
        typedef std::map<std::string, std::string> LablesType;
        const prometheus::Summary::Quantiles quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
        profile_metric_waimai_plate_    = std::make_shared<ProfileMetric>(LablesType{{"engine", "nonmotor"}, {"model", "waimai"    }}, quantiles);
        profile_metric_behaviour_attr_  = std::make_shared<ProfileMetric>(LablesType{{"engine", "nonmotor"}, {"model", "behaviour" }}, quantiles);
    }

    void CAlgNonmotorEngine::ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) {
        if (name == "post") {
            if (waimai_plate_ != nullptr) {
                std::unique_lock<std::mutex> lock{attr_lock_};
                ProfileMetric::Helper _metric_helper(*profile_metric_waimai_plate_);
                waimai_plate_->Predict(*shell_frame->getMat(), &boxes);
            }
            if (behaviour_attr_ != nullptr) {
                std::unique_lock<std::mutex> lock{attr_lock_};
                ProfileMetric::Helper _metric_helper(*profile_metric_behaviour_attr_);
                behaviour_attr_->Predict(shell_frame, &boxes);
            }
        }
    }

    bool CAlgNonmotorEngine::needAtrrBox(const BoxF& box) {
        return box.label == OBJECT_TYPE_NONMOTOR && 
                box.attr_type.type == -1 &&
                box.delete_flag == 0 &&
                (box.xmax - box.xmin) > config_.attribute_nonmotor_min_size() &&
                (box.ymax - box.ymin) > config_.attribute_nonmotor_min_size();
    }

    std::vector<int> CAlgNonmotorEngine::GetDetectInputShapes()const {
        return detect_input_shapes;
    }
} // FLOW

