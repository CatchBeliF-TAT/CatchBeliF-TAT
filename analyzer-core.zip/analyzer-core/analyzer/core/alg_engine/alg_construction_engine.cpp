
#include <vector>
#include <future>

#include "common/io.hpp"
#include "common/pbjson.hpp"

#include "helper.hpp"
#include "alg_construction_engine.hpp"

#include "serving/violation_config.pb.h"

#include "algorithm/detect/detect.hpp"

namespace FLOW {

    using namespace std;

    void CAlgConstructionEngine::PrintDetectInfo(const VecImage& images)const {
        for (auto &image : images) {
            LOG(INFO) << "channel id: " << image->channel_id;
            for (auto &object : image->objects) {
            LOG(INFO) << "label: " << object.label << ",\t"
                        << "pos: [" << object.xmin << ", " << object.ymin << ", "
                        << object.xmax << ", " << object.ymax <<"]";                
            }
        }
    }

    void CAlgConstructionEngine::Init(const inference::EngineConfig &config, int &code) {

        config_ = config.construction();

        std::map<std::string, std::pair<std::string, std::vector<char>>> params = {
            {"detect_model", {config_.detect().model_path(), {}}},
        };
        for (auto& kv : params) {
            if (kv.second.first == ""){
                LOG(WARNING) << "Skip load model " << kv.first << ", path(\"" <<  kv.second.first <<"\") configed";
                continue;
            }
            if (!IO::ReadBinaryFile(kv.second.first, &kv.second.second)) {
                LOG(FATAL) << "Load model " <<kv.first << ", path " << kv.second.first << " error";
                return;
            }
        }

        // detect_model
        detector_ = make_shared<Detect::DetectModule>();
        detector_->Setup(params["detect_model"].second, config_.detect(), code);
        detect_input_shapes_ = detector_->GetInputShapes();
        // metric init
        typedef std::map<std::string, std::string> LablesType;
        const prometheus::Summary::Quantiles quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
        profile_metric_detector_ = std::make_shared<ProfileMetric>(LablesType{{"engine", "construction"}, {"model", "detector"           }}, quantiles);
    }

    bool CAlgConstructionEngine::Skip(int64_t count) const {
        return count % config_.detect_interval();
    }

    std::vector<int> CAlgConstructionEngine::GetDetectInputShapes()const {
        return detect_input_shapes_;
    }


    void CAlgConstructionEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
    }

    void CAlgConstructionEngine::GetBatchFramesDetect(VecImage &queue, VecImage &image_map) const {
        image_map.clear();
        std::unordered_map<string, int> channel_count;
        for (auto it = queue.begin(); it != queue.end() && image_map.size() < config_.detect_batch_size(); ) {
            auto &frame = *it;
            auto data = channel_data_map_.find(frame->channel_id);
            if (data && !this->Skip(frame->count)) {
                image_map.push_back(frame);
            }
            it = queue.erase(it);
        }
    }

    void CAlgConstructionEngine::Process(CFlowDispatch &dsp) {
        while(!channel_data_update_queue_.empty()) {
            auto new_data = channel_data_update_queue_.pop();
            auto& channel_id = new_data->channel_id_;
            if (auto old_data = channel_data_map_.find(new_data->channel_id_)) {
                auto copy_data = std::make_shared<ChannelData>(*old_data);
                if (copy_data->UpdateCfg(*new_data)) {
                    channel_data_map_.insert(channel_id, copy_data);
                } else {
                    continue;
                }

                CFlowDispatch::spNode detect, chin, chout;
                chin = dsp.get_node(channel_id, "in");
                chout = dsp.get_node(channel_id, "out");
                if (!chin || !chout) return;

                if (new_data->add) {
                    detect = dsp.add_node(channel_id, "construction-detect", config_.detect_queue_size(), true);
                    detect->process([this](VecImage& in) {
                            VecImage frames;
                            this->GetBatchFramesDetect(in, frames);
                            if (!frames.empty()) {
                                this->detectProcess(frames);
                            }
                        });
                    chin->next(detect);
                    detect->next(chout);
                }
            } else if (!new_data->add) {
                dsp.remove_node(new_data->channel_id_, "construction-detect");
            }
        }
    }

    void CAlgConstructionEngine::ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) {

    }

    void CAlgConstructionEngine::detectProcess(const VecImage &images) {
        std::unique_lock<std::mutex> lock{detect_lock_};
        Profiler profiler_detect;
        int batch_size=0;
        ProfilerHelper _profiler(&profiler_detect, "DetectionProcess",
            [&](Profiler* p){LOG(DEBUG) <<"profiler batch_size:"<<batch_size<<", "<< p->get_stats_str();}
        );

        typedef vector<vector<RectInfo>> VecRectInfos;
        typedef std::function<bool(int)> TypeFilter;
        // detect
        VecImage      image_detect;
        VecRectInfos  image_rects;
        VecShellFrame detect_frames;
        std::vector<cv::Rect> rois;
        std::vector<prometheus::spCounter> counters;

        for (auto &image : images) {
            if (this->Skip(image->count)) {
                continue;
            }
            auto channel_data = channel_data_map_.find(image->channel_id);
            if (nullptr == channel_data.get()) {
                continue;
            }
            
            counters.push_back(channel_data->detect_object_counter_);
            cv::Rect roi(0, 0, image->sframe->width(), image->sframe->height());

            image_detect.push_back(image);
            detect_frames.push_back(image->sframe);
            rois.push_back(roi);
        }

        batch_size = detect_frames.size();
        int code = -1;
#ifdef USE_MEDIA_UTILS
        if (config_.device_input()) {
            ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
            detector_->Process(detect_frames, rois, image_rects, code);
            for (auto &image : images) {
                image->sframe->clearVframe();
            }
        } else {
            ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
            detector_->ProcessROIs(detect_frames, rois, image_rects, code);
        }
#else
        {
            ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
            detector_->ProcessROIs(detect_frames, rois, image_rects, code);
        }
#endif

        // process detect result
        for (size_t i = 0; i < image_detect.size(); i++) {
            VecBoxF &objects  = image_detect[i]->objects;
            const auto &rects = image_rects[i];
            VecBoxF image_boxes;
            for (auto &rect : rects) {
                BoxF box((float)rect.rect.x, (float)rect.rect.y,
                            (float)(rect.rect.x + rect.rect.width),
                            (float)(rect.rect.y + rect.rect.height));
                box.label = rect.label;
                box.score = rect.score;
                image_boxes.push_back(box);
            }
            objects.insert(objects.end(), image_boxes.begin(), image_boxes.end());
            counters[i]->Increment(image_boxes.size());
        }

        PrintDetectInfo(images);
    }

    void CAlgConstructionEngine::AddStream(const std::string &channel_id, const std::string &config) {
        auto channel_data = channel_data_map_.find(channel_id);
        if (nullptr == channel_data.get()) {
            channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data_map_.insert(channel_id, channel_data);

            auto channel_update_data = std::make_shared<ChannelUpdateData>();
            channel_update_data->channel_id_ = channel_id;
            channel_update_data->add= true;
            channel_data_update_queue_.push(channel_update_data);
            
            typedef std::map<std::string, std::string> LablesType;
            channel_data->detect_object_counter_ = std::shared_ptr<prometheus::Counter>(
                &Metric::Instance().object_counter->Add(LablesType{
                    {"engine", "construction"},
                    {"model", "detect"},
                    {"stream_id", channel_id}
                }),
                [](prometheus::Counter* c) {Metric::Instance().object_counter->Remove(c);}
            );
        }
    }
    void CAlgConstructionEngine::RemoveStream(const std::string &channel_id) {
        channel_data_map_.erase(channel_id);
        auto channel_update_data = std::make_shared<ChannelUpdateData>();
        channel_update_data->channel_id_ = channel_id;
        channel_update_data->add= false;
        channel_data_update_queue_.push(channel_update_data);
    }

    void CAlgConstructionEngine::AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config) {
    }

    void CAlgConstructionEngine::RemoveViolation(const std::string &channel_id, const std::string &violation_id) {
    }

} // FLOW

