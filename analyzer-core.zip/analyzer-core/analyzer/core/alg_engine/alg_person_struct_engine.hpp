//
// Created by yankai on 2020/5/27.
//

#ifndef ANALYZER_FLOW_PERSON_STRUCT_HPP
#define ANALYZER_FLOW_PERSON_STRUCT_HPP

#include <atomic>
#include <memory>
#include <mutex>

#include "common/Queue.h"
#include "serving/config.pb.h"
#include "core/flow_dispatch.hpp"

#include "alg_engine_interface.hpp"

namespace FLOW {
namespace PersonStruct {
class PersonDetectModule;
class PersonQualityModule;
class PersonAttributeModule;
class PersonFeatureModule;
}  // namespace PersonStruct
namespace Track {
class TADTracker;
}
// CAlgVehicleEngine
class CAlgPersonEngine : public ICAlgEngine {
 public:
  CAlgPersonEngine() = default;
  virtual ~CAlgPersonEngine() = default;

 public:
  virtual void Init(const inference::EngineConfig& config, int& code);  // init models
  virtual void GetBatchFrames(VecImage& queue, VecImage& image_map)
      const;  // get image from queue into image_map
  virtual void GetBatchFramesWithSize(VecImage &queue, VecImage &image_map, int batch_size) const;
  virtual void Process(
      CFlowDispatch& dsp);  // input process task to dispatch image
  void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame,
                     VecBoxF& boxes) override;

  virtual void AddStream(const std::string& channel_id,
                         const std::string& config);  // add new channel stream
  virtual void RemoveStream(const std::string& channel_id);
  virtual void AddViolation(const std::string& channel_id,
                            const std::string& violation_id,
                            const std::string& config);
  virtual void RemoveViolation(const std::string& channel_id,
                               const std::string& violation_id);
  virtual AlgRender GetRender(const std::string &violation_code) const override;
  static void Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug=false);
  
 protected:
  // 记录每一路流信息
  struct ChannelData {                            // need all ptr
    std::string channel_id_;                      //存放流id
    std::shared_ptr<Track::TADTracker> tracker_;  // 每个流对应有一个跟踪器
    std::shared_ptr<RectF> detect_roi_;           // 该流的检测roi
    std::shared_ptr<std::map<int,float>> max_person_quality_;
    std::string add_violation_;
    int action_;

    bool UpdateCfg(ChannelData other) {
      if (other.channel_id_ != channel_id_) {
        return false;
      }
      if (other.tracker_) {
        this->tracker_.swap(other.tracker_);
      }
      if (other.detect_roi_) {
        this->detect_roi_.swap(other.detect_roi_);
      }
      return true;
    }
  };
  typedef std::shared_ptr<ChannelData> spChannelData;

  class safeChannelDataMap {
   public:
    spChannelData find(const std::string& key) {
      std::unique_lock<std::mutex> lock{lock_};
      auto it = map_.find(key);
      return (it != map_.end()) ? it->second : nullptr;
    }
    spChannelData insert(const std::string& key, spChannelData value) {
      std::unique_lock<std::mutex> lock{lock_};
      auto old_value = map_[key];
      map_[key] = value;
      return old_value;
    }
    spChannelData erase(const std::string& key) {
      std::unique_lock<std::mutex> lock{lock_};
      auto it = map_.find(key);
      spChannelData old_value;
      if (it != map_.end()) {
        old_value = it->second;
        map_.erase(it);
      }
      return old_value;
    }
    typedef std::function<bool(const std::string&, spChannelData)> visiter;
    void visit(visiter v) const {
      std::unique_lock<std::mutex> lock{lock_};
      for (auto& kv : map_) {
        if (!v(kv.first, kv.second)) {
          break;
        }
      }
    }

   protected:
    mutable std::mutex lock_;
    std::unordered_map<std::string, spChannelData> map_;
  };

 protected:
  void personDetectProcess(const VecImage& images);
  void personTrackProcess(spChannelData channel, const VecImage& images);
  void personQualityProcess(const VecImage &images);
  void personAttributeProcess(const VecImage& images);
  void personFeatureProcess(const VecImage& images);

  bool Skip(int64_t count) const;
  void PrintInfo(const VecImage& images) const;
  void PrintQueueInfo(int queue_size, int batch, int frames) const;

 protected:
  inference::PersonStruct config_;

 protected:
  std::mutex person_detect_lock_;
  std::mutex person_track_lock_;
  std::mutex person_quality_lock_;
  std::mutex person_attribute_lock_;
  std::mutex person_feature_lock_;

  std::shared_ptr<PersonStruct::PersonDetectModule> person_detect_engine_ =
      nullptr;
  std::shared_ptr<PersonStruct::PersonQualityModule>
      person_quality_engine_ = nullptr;
  std::shared_ptr<PersonStruct::PersonAttributeModule>
      person_attribute_engine_ = nullptr;
  std::shared_ptr<PersonStruct::PersonFeatureModule> person_feature_engine_ =
      nullptr;

 protected:
  safeChannelDataMap channel_data_map_;
  Queue<spChannelData> channel_data_update_queue_;

};

}  // namespace FLOW

#endif  // ANALYZER_FLOW_PERSON_STRUCT_HPP
