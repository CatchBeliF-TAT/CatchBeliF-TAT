#include <algorithm>
#include <future>
#include <vector>
#include "common/io.hpp"
#include "common/pbjson.hpp"
#include "common/util_scale.hpp"
#include "common/tad_internal.hpp"

#include "alg_fall_engine.hpp"
#include "core/flow_dispatch.hpp"
#include "helper.hpp"

#include "algorithm/fall/fall.hpp"
#include "serving/violation_config.pb.h"

namespace FLOW {
using namespace std;

void CAlgFallEngine::Init(const inference::EngineConfig& config, int& code) {
  config_ = config.falldetect();

  std::map<std::string, std::pair<inference::Algorithm, std::vector<char>>>
      params = {
          {"fall_model", {config_.person_detect_local_model(), {}}},
      };
  for (auto& kv : params) {
    if (!IO::ReadBinaryFile(kv.second.first.model_path(), &kv.second.second)) {
      LOG(FATAL) << "Load model " << kv.first
                 << " error, path: " << kv.second.first.model_path();
      return;
    }
  }

  fall_engine_ = make_shared<Fall::Fall>();
  fall_engine_->Setup(params["fall_model"].second,
                      config_.person_detect_local_model(), code);

  // metric init
  typedef std::map<std::string, std::string> LablesType;
  const prometheus::Summary::Quantiles quantiles{
      {0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
  profile_metric_fall_ = std::make_shared<ProfileMetric>(
      LablesType{{"engine", "cloud"}, {"model", "fall"}}, quantiles);
}

void CAlgFallEngine::GetBatchFrames(VecImage& queue,
                                    VecImage& image_map) const {
  LOG(FATAL) << "no implement";
}

void CAlgFallEngine::GetBatchFrames(VecImage& queue, VecImage& images,
                                    std::function<bool(int)> need_skip,
                                    int max_batch) const {
  int count = 0;
  images.clear();
  for (auto it = queue.begin(); it != queue.end() && count < max_batch;) {
    auto& frame = *it;
    if (!need_skip(frame->count)) {
      count++;
      images.push_back(frame);
    }
    it = queue.erase(it);
  }
}

void CAlgFallEngine::Process(CFlowDispatch& dsp) {
  while (!channel_data_update_queue_.empty()) {
    auto new_data = channel_data_update_queue_.pop();
    auto& channel_id = new_data->channel_id_;
    if (auto old_data = channel_data_map_.find(new_data->channel_id_)) {
      auto copy_data = std::make_shared<ChannelData>(*old_data);
      if (copy_data->UpdateCfg(*new_data)) {
        channel_data_map_.insert(channel_id, copy_data);
      }
    }
    if (auto channel_data = channel_data_map_.find(channel_id)) {
      const std::string FALL_CODE("6003");
      CFlowDispatch::spNode fall, chin, chout;
      chin = dsp.get_node(channel_id, "in");
      chout = dsp.get_node(channel_id, "out");
      if (!chin || !chout) return;
      if (new_data->action_ == 1) {  // add violation
        if (FALL_CODE == new_data->add_violation_ &&
            1 == channel_data->fall_task_codes.count(FALL_CODE)) {
          auto interval = config_.person_detect_interval();
          auto need_skip_fn = [interval](int count) -> bool {
            return count % interval;
          };
          fall = dsp.add_node(channel_id, "cloud-fall",
                              config_.detect_queue_size(), true);
          fall->process([this, need_skip_fn](VecImage& in) {
            VecImage frames;
            this->GetBatchFrames(
                in, frames, need_skip_fn,
                config_.person_detect_local_model().batch_size());
            if (!frames.empty()) {
              this->FallProcess(frames);
            }
          });
          chin->next(fall);
          fall->next(chout);
        } else {
          // nop
        }
      } else if (new_data->action_ == 2) {  // remove violation
        if (FALL_CODE == new_data->remove_violation_ &&
            0 == channel_data->fall_task_codes.count(FALL_CODE)) {
          dsp.remove_node(channel_id, "cloud-fall");
        }
      }
    } else if (new_data->action_ == 2) {
      dsp.remove_node(channel_id, "cloud-fall");
    }
  }
}

void CAlgFallEngine::ProcessByName(const std::string& name,
                                   const ShellFrame_Ptr &shell_frame, VecBoxF& boxes) {}

// fall process
void CAlgFallEngine::FallProcess(const VecImage& images) {
  std::unique_lock<std::mutex> lock{fall_lock_};
  ProfilerHelper _profiler(&fall_profiler_, "fall", [](Profiler* p) {
    LOG(DEBUG) << "profiler " << p->get_stats_str();
  });
  for (auto image : images)
    //LOG(INFO) << "processing image pts = " << image->pts; //log太多了

  typedef std::function<bool(int)> TypeFilter;
  // detect
  VecImage image_detect;
  VecMat mat_detect;

  for (auto& image : images) {
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }

    image_detect.push_back(image);
    mat_detect.push_back(image->sframe->getMat());
  }

  int code = -1;
  std::vector<Fall_Event> events;
  {
    ProfileMetric::Helper _metric_helper(*profile_metric_fall_);
    fall_engine_->Process(mat_detect, events);
  }

  for (size_t i = 0; i < image_detect.size(); i++) {
    image_detect[i]->clouds.fall_event = events[i];
  }
}

void CAlgFallEngine::AddStream(const std::string& channel_id,
                               const std::string& config) {
  int code = 0;
  auto channel_data = channel_data_map_.find(channel_id);
  if (nullptr == channel_data.get()) {
    channel_data = std::make_shared<ChannelData>();
    channel_data->channel_id_ = channel_id;
    channel_data->last_image_ = std::make_shared<ImageObjectsInfo>();
    channel_data_map_.insert(channel_id, channel_data);
  }
}

void CAlgFallEngine::RemoveStream(const std::string& channel_id) {
  channel_data_map_.erase(channel_id);

  auto vdata = std::make_shared<ChannelData>();
  vdata->channel_id_ = channel_id;
  vdata->action_ = 2;
  channel_data_update_queue_.push(vdata);
}

void CAlgFallEngine::AddViolation(const std::string& channel_id,
                                  const std::string& violation_id,
                                  const std::string& config) {
  auto channel_data_old = channel_data_map_.find(channel_id);
  if (channel_data_old) {
    string roi_cfg;
    {
      auto data = std::make_shared<inference::ViolationConfig>();
      string err;
      json2pb(config, data.get(), &err);
      inference::Roi roi;
      *roi.mutable_data() = data->roi();
      pb2json(&roi, &roi_cfg);
    }
    std::string violation_code;
    auto channel_data = std::make_shared<ChannelData>();
    channel_data->channel_id_ = channel_id;
    channel_data->action_ = 1;
    if (parse_violation_code(config, violation_code)) {
      channel_data->add_violation_ = violation_code;
    }
    channel_data_update_queue_.push(channel_data);
  }
}

void CAlgFallEngine::RemoveViolation(const std::string& channel_id,
                                     const std::string& violation_id) {
  auto channel_data = channel_data_map_.find(channel_id);
  if (channel_data) {
    auto vdata = std::make_shared<ChannelData>();
    vdata->channel_id_ = channel_id;
    vdata->action_ = 2;
    vdata->remove_violation_ = violation_id;
    channel_data_update_queue_.push(vdata);
  }
}

AlgRender CAlgFallEngine::GetRender(const std::string &violation_code) const {
  if(violation_code == "6003") {
      return CAlgFallEngine::Render;
  }
  return nullptr;
}

void CAlgFallEngine::Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat,
                            bool enable_tracking_debug) {
  if (!enable_tracking_debug) return;
  const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
  for (auto& object : image_objects.clouds.fall_event.fall) {
    cv::Scalar scalar;
    auto text = std::to_string(object.label);
    if ((1 == object.label) &&
        (image_objects.clouds.fall_event.predict_fall_name == "fall_person")) {
      scalar = cv::Scalar(0, 0, 255);
    }
    cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                  cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
  }
}

}  // namespace FLOW
