#ifndef TAD_ALG_SHAREDBIKE_ENGINE_HPP
#define TAD_ALG_SHAREDBIKE_ENGINE_HPP

#include <memory>
#include <mutex>
#include <atomic>
#include <set>
#include <unordered_set>
#include <unordered_map>

#include "common/Queue.h"
#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

#include "alg_engine_interface.hpp"
#include "core/flow_dispatch.hpp"

namespace prometheus{
    class Counter;
    typedef std::shared_ptr<Counter> spCounter;
}

namespace FLOW {

    namespace SharedBike {
        class SharedBike;
    }

    class ProfileMetric;
    typedef std::shared_ptr<ProfileMetric> spProfileMetric;

    // CAlgSharedBikeEngine
    class CAlgSharedBikeEngine : public ICAlgEngine{
    public:
        CAlgSharedBikeEngine() = default;
        virtual ~CAlgSharedBikeEngine() = default;

        virtual void Init(const inference::EngineConfig &config, int &code);
        virtual void GetBatchFrames(VecImage &queue, VecImage &image_map) const;
        virtual void Process(CFlowDispatch &dsp);
        void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) override;
        virtual void AddStream(const std::string &channel_id, const std::string &config);
        virtual void RemoveStream(const std::string &channel_id);
        virtual void AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config);
        virtual void RemoveViolation(const std::string &channel_id, const std::string &violation_id);
        virtual void AddViolation2(const std::string &channel_id, const std::string &violation_id, const std::string &config, CFlowDispatch &dsp);
        virtual void RemoveViolation2(const std::string &channel_id, const std::string &violation_id, CFlowDispatch &dsp);
        virtual std::vector<int> GetDetectInputShapes()const{ return std::vector<int>(); }
        virtual AlgRender GetRender(const std::string &violation_code) const override;
    
    private:
        struct ChannelUpdateData {
            std::string     channel_id_;
            bool            add;
        };
        typedef std::shared_ptr<ChannelUpdateData> spChannelUpdateData;
        struct ChannelData { // need all ptr
            std::string                         channel_id_;
            prometheus::spCounter               detect_object_counter_;
            std::shared_ptr<ImageObjectsInfo>   last_image_;
            bool UpdateCfg(ChannelUpdateData update) {
                if (update.channel_id_ != channel_id_) {
                    return false;
                }
                return true;
            }
        };
        typedef std::shared_ptr<ChannelData> spChannelData;

        class safeChannelDataMap {
            public:
            spChannelData find(const std::string& key) const {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                return (it != map_.end()) ? it->second : nullptr;
            }
            spChannelData insert(const std::string& key, spChannelData value) {
                std::unique_lock<std::mutex> lock{lock_};
                auto old_value = map_[key];
                map_[key] = value;
                return old_value;
            }
            spChannelData erase(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                spChannelData old_value;
                if (it != map_.end()) {
                    old_value = it->second;
                    map_.erase(it);
                }
                return old_value;
            }
            typedef std::function<bool(const std::string&, spChannelData)> visiter;
            void visit(visiter v) const{
                std::unique_lock<std::mutex> lock{lock_};
                for(auto &kv : map_) {
                    if(!v(kv.first, kv.second)) {
                        break;
                    }
                }
            }
        protected:
            mutable std::mutex lock_;
            std::unordered_map<std::string, spChannelData> map_;
        };


    private:
        spProfileMetric profile_metric_detector_;

    private:
        void AddEngineInDsp(const std::string &channel_id, const std::string &engine_name, CFlowDispatch &dsp);
        void RemoveEngineInDsp(const std::string &channel_id, const std::string &engine_name, CFlowDispatch &dsp);
        void detectProcess(const VecImage &images);
        void detectSignProcess(const VecImage &images);
        void trackProcess(spChannelData channel, const VecImage &images);
        void attrProcess(const VecImage &images);
        void attrMappingProcess(const VecImage &images);
        void detectMetricProcess(const VecImage &images);
        bool Skip(int64_t count, int interval) const;
        void GetBatchFrames(VecImage &queue, VecImage &image_map, int interval, int batch_size) const;

    protected:
        typedef std::function<bool(const spImageObjectsInfo processedFrame)> fnSkipChecker;
        static void FillSkipframe(fnSkipChecker check, const spImageObjectsInfo processedFrame, spImageObjectsInfo currentFrame);
        static void Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug);

    private:
        std::mutex SharedBike_detcte_lock_;
        std::shared_ptr<SharedBike::SharedBike> detector_ = nullptr;     
        inference::Sharedbike  config_;
        //记录已经打开的流, 每个流开启的engine, 每个engine服务的violation
        std::unordered_map<std::string, std::unordered_map<std::string, std::unordered_set<std::string>>> map_;
        std::unordered_map<std::string, prometheus::spCounter> map_metric_;
        std::mutex   metric_lock_;
    protected:
        safeChannelDataMap              channel_data_map_;
        Queue<spChannelUpdateData>      channel_data_update_queue_;
    };
}

#endif //TAD_ALG_SHAREDBIKE_ENGINE_HPP
