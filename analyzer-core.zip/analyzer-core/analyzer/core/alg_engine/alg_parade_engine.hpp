#ifndef TAD_ALG_PARADE_ENGINE_HPP
#define TAD_ALG_PARADE_ENGINE_HPP

#include <memory>
#include <mutex>
#include <atomic>
#include <functional>

#include "common/Queue.h"
#include "alg_engine_interface.hpp"
#include "serving/config.pb.h"
#include "violation/flow/violation_flow_code.hpp"
#include "algorithm/parade/redflag.hpp"
#include "algorithm/parade/whiteflag.hpp"
#include "algorithm/detect/detect.hpp"

namespace FLOW {

    namespace Detect {
        class DetectModule;
    }

    class CAlgParadeEngine : public ICAlgEngine{
    public:
        CAlgParadeEngine() = default;
        virtual ~CAlgParadeEngine() = default;

    public:
        virtual void Init(const inference::EngineConfig &config, int &code);
        virtual void GetBatchFrames(VecImage &queue, VecImage &image_map) const;
        virtual void Process(CFlowDispatch &dsp);
        virtual void AddStream(const std::string &channel_id, const std::string &config);
        virtual void RemoveStream(const std::string &channel_id);
        virtual void AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config){}
        virtual void RemoveViolation(const std::string &channel_id, const std::string &violation_id){}
        virtual void AddViolation2(const std::string &channel_id, const std::string &violation_id, const std::string &config, CFlowDispatch &dsp);
        virtual void RemoveViolation2(const std::string &channel_id, const std::string &violation_id, CFlowDispatch &dsp);
        virtual AlgRender GetRender(const std::string &violation_code) const override;
        static  void Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug=false);
        void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) override {}

    protected:
        void AddEngineInDsp(const std::string &channel_id, const std::string &engine_name, CFlowDispatch &dsp);
        void RemoveEngineInDsp(const std::string &channel_id, const std::string &engine_name, CFlowDispatch &dsp);
        void PersonDetectProcess(const VecImage &images);
        void RedFlagDetectProcess(const VecImage &images);
        void RedFlagfilterProcess(const VecImage &images);
        void WhiteFlagfilterProcess(const VecImage &images);
        bool Skip(int64_t count) const;
        std::vector<int> person_shape_, redflag_shape_;

    protected:
        inference::Parade config_;

    protected:
        std::mutex person_detect_lock_;
        std::mutex redflag_detect_lock_;
        std::mutex redflag_filter_lock_;
        std::mutex whiteflag_filter_lock_;
        std::shared_ptr<Detect::DetectModule> person_detector_ = nullptr;
        std::shared_ptr<Detect::DetectModule> redflag_detector_ = nullptr;
        std::shared_ptr<Parade::RedFlag> redflag_filter_ = nullptr;
        std::shared_ptr<Parade::WhiteFlag> whiteflag_filter_ = nullptr;
        //记录已经打开的流, 每个流开启的engine, 每个engine服务的violation
        std::unordered_map<std::string, std::unordered_map<std::string, std::unordered_set<std::string>>> map_;

    };

}

#endif //TAD_ALG_PARADE_ENGINE_HPP
