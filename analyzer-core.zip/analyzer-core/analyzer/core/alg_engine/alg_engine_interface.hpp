#ifndef TAD_ALG_ENGINE_INTERFACE_HPP
#define TAD_ALG_ENGINE_INTERFACE_HPP

#include <memory>
#include <list>
#include <tuple>

#include "common/tad_internal.hpp"

namespace inference{
    class EngineConfig;
}

template<typename T> class Queue;
namespace FLOW {
    class CFlowDispatch;
    struct MatPts;
    typedef Queue<MatPts> FrameQueue;
    typedef std::shared_ptr<FrameQueue> spFrameQueue;

    typedef struct ImageObjectsInfo_ ImageObjectsInfo;
    typedef std::shared_ptr<ImageObjectsInfo> spImageObjectsInfo;
    typedef std::list<spImageObjectsInfo> ImageQueue;
    typedef std::shared_ptr<ImageQueue> spImageQueue;

    class ICAlgEngine {
    public:
        ICAlgEngine() = default;
        virtual ~ICAlgEngine() = default;
        virtual std::vector<int> GetDetectInputShapes()const{ return std::vector<int>(); }

    public:
        virtual void Init(const inference::EngineConfig &config, int &code)=0;
        virtual void GetBatchFrames(VecImage &queue, VecImage &image_map) const=0;
        virtual void Process(CFlowDispatch &dsp)=0;
        virtual void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes)=0;

        
        virtual void AddStream(const std::string &channel_id, const std::string &config)=0;
        virtual void RemoveStream(const std::string &channel_id)=0;
        virtual void AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config)=0;
        virtual void RemoveViolation(const std::string &channel_id, const std::string &violation_id)=0;
        //在add/remove violation的时候控制engine运行
        virtual void AddViolation2(const std::string &channel_id, const std::string &violation_id, const std::string &config, CFlowDispatch &dsp){}
        virtual void RemoveViolation2(const std::string &channel_id, const std::string &violation_id, CFlowDispatch &dsp){}

        virtual AlgRender GetRender(const std::string &violation_code) const { return nullptr; }
    };

    typedef std::shared_ptr<ICAlgEngine> spICAlgEngine;
}

#endif //TAD_ALG_ENGINE_INTERFACE_HPP
