#include <future>
#include <algorithm>
#include <vector>
#include "common/io.hpp"
#include "common/pbjson.hpp"
#include "common/util_scale.hpp"
#include "common/tad_internal.hpp"

#include "helper.hpp"
#include "alg_parade_engine.hpp"
#include "core/flow_dispatch.hpp"
#include "helper.hpp"
#include "common/json.hpp"
#include "serving/violation_config.pb.h"

namespace FLOW {

using namespace std;

const std::string WHITE_FLAG("white_flag");
const std::string RED_FLAG("red_flag");

const std::unordered_map<std::string, std::string> PARADE_VIOLATION_MAP = {
    //violation_code  <===> engine_name
    {FLOW_PARADE_JUPAI_CODE, WHITE_FLAG},
    {FLOW_PARADE_JUQI_CODE, RED_FLAG},
};
void CAlgParadeEngine::Init(const inference::EngineConfig &config, int &code) {
    config_ = config.parade();
    std::map<std::string, std::pair<inference::Algorithm, std::vector<char>>> params = {
        {"person_detect_model",       {config_.person_detect(),   {}}},
        {"person_redflag_model",      {config_.redflag_detect(),  {}}},
    };
    for (auto &kv : params) {
        if (!IO::ReadBinaryFile(kv.second.first.model_path(), &kv.second.second)) {
            LOG(FATAL) << "Load model " << kv.first << " error, path: " << kv.second.first.model_path();
            return;
        }
    }

    person_detector_ = make_shared<Detect::DetectModule>();
    person_detector_->Setup(params["person_detect_model"].second, config_.person_detect(), code);

    redflag_detector_ = make_shared<Detect::DetectModule>();
    redflag_detector_->Setup(params["person_redflag_model"].second, config_.redflag_detect(), code);

    redflag_filter_ = make_shared<Parade::RedFlag>();
    redflag_filter_->Setup(config_.redflag_filter());

    whiteflag_filter_ = make_shared<Parade::WhiteFlag>();
    whiteflag_filter_->Setup(config_.whiteflag_filter());
}

void CAlgParadeEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
    int count = 0;
    image_map.clear();
    for (auto it = queue.begin(); it != queue.end() && count < config_.detect_batch_size(); count++) {
        auto &frame = *it;
        image_map.push_back(frame); 
        it = queue.erase(it);
    }
}

bool CAlgParadeEngine::Skip(int64_t count) const {
  return count % config_.detect_interval();
}

void CAlgParadeEngine::PersonDetectProcess(const VecImage &images){
    std::unique_lock<std::mutex> lock{person_detect_lock_};
    typedef vector<vector<RectInfo>> VecRectInfos;

    // detect
    VecImage image_detect;
    VecRectInfos image_rects;
    VecShellFrame mat_detect;
    std::vector<cv::Rect> rois;

    for (auto& image : images) {
        if (this->Skip(image->count)) {
            continue;
        }
        image_detect.push_back(image);
        mat_detect.push_back(image->sframe);
        rois.push_back(cv::Rect(0, 0, image->sframe->width(), image->sframe->height()));
    }
    int code = -1;
    person_detector_->ProcessROIs(mat_detect, rois, image_rects, code);
  
    // process detect result
    for (size_t i = 0; i < image_detect.size(); i++) {
        VecBoxF& objects = image_detect[i]->objects;
        const auto& rects = image_rects[i];
        VecBoxF image_boxes;
        for (auto& rect : rects) {
            BoxF box((float)rect.rect.x, (float)rect.rect.y,
                    (float)(rect.rect.x + rect.rect.width),
                    (float)(rect.rect.y + rect.rect.height));
            box.label = rect.label;
            box.score = rect.score;
            image_boxes.push_back(box);
        }
        objects.insert(objects.end(), image_boxes.begin(), image_boxes.end());
    }
}

void CAlgParadeEngine::RedFlagDetectProcess(const VecImage &images){
    std::unique_lock<std::mutex> lock{redflag_detect_lock_};
    typedef vector<vector<RectInfo>> VecRectInfos;

    // detect
    VecImage image_detect;
    VecRectInfos image_rects;
    VecShellFrame mat_detect;
    std::vector<cv::Rect> rois;

    for (auto& image : images) {
        if (this->Skip(image->count)) {
            continue;
        }
        image_detect.push_back(image);
        mat_detect.push_back(image->sframe);
        rois.push_back(cv::Rect(0, 0, image->sframe->width(), image->sframe->height()));
    }
    int code = -1;
    redflag_detector_->ProcessROIs(mat_detect, rois, image_rects, code);
    LOG(WARNING)<<"redflag process code: "<<code;
    // process detect result
    for (size_t i = 0; i < image_detect.size(); i++) {
        VecBoxF& objects = image_detect[i]->parade_info.red_flag_detect_objs_;
        const auto& rects = image_rects[i];
        VecBoxF image_boxes;
        for (auto& rect : rects) {
            BoxF box((float)rect.rect.x, (float)rect.rect.y,
                    (float)(rect.rect.x + rect.rect.width),
                    (float)(rect.rect.y + rect.rect.height));
            box.label = rect.label;
            box.score = rect.score;
            image_boxes.push_back(box);
        }
        objects.insert(objects.end(), image_boxes.begin(), image_boxes.end());
    }
}
void CAlgParadeEngine::RedFlagfilterProcess(const VecImage &images){
    //void RedFlag::Process(const cv::Mat &im_mat, const VecBoxF &objs, ParadeInfo &parade_info)
    std::unique_lock<std::mutex> lock{redflag_filter_lock_};
    for(auto& image:images){
        redflag_filter_->Process(*image->sframe->getMat(), image->objects, image->parade_info);
    }
}
void CAlgParadeEngine::WhiteFlagfilterProcess(const VecImage &images){
    //void WhiteFlag::Process(const cv::Mat &im_mat, const VecBoxF &objs, ParadeInfo &parade_info)
    std::unique_lock<std::mutex> lock{whiteflag_filter_lock_};
    for(auto& image:images){
        whiteflag_filter_->Process(*image->sframe->getMat(), image->objects, image->parade_info);
    }
}

void CAlgParadeEngine::AddEngineInDsp(const std::string &channel_id, const std::string &engine_name, CFlowDispatch &dsp){
    CFlowDispatch::spNode chin, chout;
    chin = dsp.get_node(channel_id, "in");
    chout = dsp.get_node(channel_id, "out");
    if (!chin || !chout){
        LOG(ERROR) << "AddEngineInDsp fail, channel: "<<channel_id;
        return;
    }
    //处理各个engine
    if (engine_name == WHITE_FLAG){
        auto detect = dsp.get_node(channel_id, "parade-person-detect");
        if(!detect){
            detect = dsp.add_node(channel_id, "parade-person-detect", config_.dsp_queue_size(), true);
            detect->process([this](VecImage& in){
                VecImage frames;
                this->GetBatchFrames(in, frames);
                if (!frames.empty()) {
                    this->PersonDetectProcess(frames);
                }
            });
            chin->next(detect);
        }
        CFlowDispatch::spNode white_flag_filter;
        white_flag_filter = dsp.add_node(channel_id, "white_flag_filter", config_.dsp_queue_size(), true);
        white_flag_filter->process([this](VecImage& in) {
            VecImage frames;
            this->GetBatchFrames(in, frames);
            if (!frames.empty()) {
                this->WhiteFlagfilterProcess(frames);
            }
        });
        detect->next(white_flag_filter);
        white_flag_filter->next(chout);
    }else if(engine_name == RED_FLAG){
        auto detect = dsp.get_node(channel_id, "parade-person-detect");
        if(!detect){
            detect = dsp.add_node(channel_id, "parade-person-detect", config_.dsp_queue_size(), true);
            detect->process([this](VecImage& in){
                VecImage frames;
                this->GetBatchFrames(in, frames);
                if (!frames.empty()) {
                    this->PersonDetectProcess(frames);
                }
            });
            chin->next(detect);
        }
        CFlowDispatch::spNode red_flag_detect, red_flag_filter;
        red_flag_detect = dsp.add_node(channel_id, "red_flag_detect", config_.dsp_queue_size(), true);
        red_flag_filter = dsp.add_node(channel_id, "red_flag_filter", config_.dsp_queue_size(), true);
        red_flag_detect->process([this](VecImage& in) {
            VecImage frames;
            this->GetBatchFrames(in, frames);
            if (!frames.empty()) {
                this->RedFlagDetectProcess(frames);
            }
        });
        red_flag_filter->process([this](VecImage& in) {
            VecImage frames;
            this->GetBatchFrames(in, frames);
            if (!frames.empty()) {
                this->RedFlagfilterProcess(frames);
            }
        });
        chin->next(red_flag_detect);
        detect->next(red_flag_filter);
        red_flag_detect->next(red_flag_filter);
        red_flag_filter->next(chout);
    }
}

void CAlgParadeEngine::RemoveEngineInDsp(const std::string &channel_id, const std::string &engine_name, CFlowDispatch &dsp){
    if(engine_name==WHITE_FLAG){
        auto red_flag_filter = dsp.get_node(channel_id, "red_flag_filter");
        if(!red_flag_filter){
            dsp.remove_node(channel_id, "parade-person-detect");
        }
        dsp.remove_node(channel_id, "white_flag_filter");
    }else if(engine_name==RED_FLAG){
        auto white_flag_filter = dsp.get_node(channel_id, "white_flag_filter");
        if(!white_flag_filter){
            dsp.remove_node(channel_id, "parade-person-detect");
        }
        dsp.remove_node(channel_id, "red_flag_detect");
        dsp.remove_node(channel_id, "red_flag_filter");
    }
}

void CAlgParadeEngine::Process(CFlowDispatch &dsp) {}

void CAlgParadeEngine::AddStream(const std::string &channel_id, const std::string &config){
    auto it = map_.find(channel_id);
    if(it!=map_.end()){
        LOG(WARNING)<<"AddStream failed, channel "<<channel_id<<" already exist in map_";
    }else{
        auto channel = map_[channel_id];
    }
}

//remove stream时flow_engine里清除所有node, 这里不需要
void CAlgParadeEngine::RemoveStream(const std::string &channel_id) {
    auto it = map_.find(channel_id);
    if (it != map_.end()){
        map_.erase(it);
    }else{
        LOG(WARNING)<<"RemoveStream failed, channel "<<channel_id<<" not exist in map_";
    }
}

void CAlgParadeEngine::AddViolation2(const std::string &channel_id,
                                    const std::string &violation_id,
                                    const std::string &config,
                                    CFlowDispatch &dsp) {
    auto root = get_document(config);
    auto violation_code = get_string(root, "code", "");
    auto engine_name = PARADE_VIOLATION_MAP.find(violation_code);
    //need fix
    auto channel = map_.find(channel_id);
    if (channel == map_.end()) {
        LOG(ERROR) << "stream not found, channel id: " << channel_id
                    << ", violation id: " << violation_id;
    }else{
        auto engine = channel->second.find(engine_name->second);
        if (engine == channel->second.end()) {
            (channel->second)[engine_name->second].insert(violation_id);
            AddEngineInDsp(channel_id, engine_name->second, dsp);
        } else {
            engine->second.insert(violation_id);
        }
    }
}

void CAlgParadeEngine::RemoveViolation2(const std::string &channel_id,
                                       const std::string &violation_id,
                                       CFlowDispatch &dsp) {
    auto channel = map_.find(channel_id);
    if(channel==map_.end()){
        LOG(ERROR)<<"stream not found, channel id: "<<channel_id<<", violation id: "<<violation_id;
        return;
    }
    // engine is pair<std::string, std::unordered_set<std::string>>
    for (auto engine = channel->second.begin(); engine != channel->second.end(); engine++){
        auto violation = engine->second.find(violation_id);
        if (violation != engine->second.end()) {
            // find violation
            //如果engine只服务要删除的这一个violation, 删除engine
            if (engine->second.size() == 1) {
                RemoveEngineInDsp(channel_id, engine->first, dsp);
                channel->second.erase(engine);
            } else {
                engine->second.erase(violation);
            }
            return;
        }
    }
}

AlgRender CAlgParadeEngine::GetRender(const std::string &violation_code) const {
    if(violation_code == FLOW_PARADE_JUPAI_CODE || violation_code == FLOW_PARADE_JUQI_CODE){
        return CAlgParadeEngine::Render;
    }
    return nullptr;
}

void CAlgParadeEngine::Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug){
    const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
    for (auto &object : image_objects.parade_info.red_flag_objs_) {
        cv::Scalar scalar = cv::Scalar(0, 0, 255);
        cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                      cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
    }
    for (auto &object : image_objects.parade_info.white_flag_objs_) {
        cv::Scalar scalar = cv::Scalar(255, 255, 255);
        cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                      cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
    }
}

}  // namespace FLOW
