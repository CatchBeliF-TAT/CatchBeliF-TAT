#include "alg_person_struct_engine.hpp"

#include <future>
#include <vector>
#include <memory>

#include "algorithm/person_struct/person_attribute.hpp"
#include "algorithm/person_struct/person_detect.hpp"
#include "algorithm/person_struct/person_feature.hpp"
#include "algorithm/person_struct/person_quality.hpp"
#include "algorithm/track/track_wraper.hpp"
#include "common/io.hpp"
#include "common/pbjson.hpp"
#include "common/util_scale.hpp"
#include "common/tad_internal.hpp"
#include "common/type.hpp"
#include "helper.hpp"
#include "serving/violation_config.pb.h"

namespace FLOW {
using namespace std;
void CAlgPersonEngine::Init(const inference::EngineConfig &config, int &code) {
  config_ = config.person_struct();

  std::map<std::string, std::pair<std::string, std::vector<char>>> params = {
      {"person_detect_model",
       {config_.person_det().model_path(), {}}},
      {"person_attribute_model",
       {config_.person_attr().model_path(), {}}},
      {"person_feature_model",
       {config_.person_feature().model_path(), {}}},
      {"person_quality_model",
       {config_.person_quality().model_path(), {}}},
  };
  for (auto &kv : params) {
    if (!IO::ReadBinaryFile(kv.second.first, &kv.second.second)) {
      LOG(FATAL) << "Load model " << kv.second.first << " error";
      return;
    }
  }
  // detect_model
  person_detect_engine_ = std::make_shared<PersonStruct::PersonDetectModule>();
  person_detect_engine_->Setup(params["person_detect_model"].second,
                               config_.person_det(), code);
  // attribute_model
  person_attribute_engine_ =
      std::make_shared<PersonStruct::PersonAttributeModule>();
  person_attribute_engine_->Setup(params["person_attribute_model"].second,
                                  config_.person_attr(), code);

  person_feature_engine_ =
      std::make_shared<PersonStruct::PersonFeatureModule>();
  person_feature_engine_->Setup(params["person_feature_model"].second,
                                config_.person_feature(), code);

  person_quality_engine_ =
      std::make_shared<PersonStruct::PersonQualityModule>();
  person_quality_engine_->Setup(params["person_quality_model"].second,
                                config_.person_quality(), code);

}

void CAlgPersonEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
}

void CAlgPersonEngine::GetBatchFramesWithSize(VecImage &queue, VecImage &image_map,
                                              int batch_size) const {
  // std::cout<<"get images batch :"<<queue.size()<<std::endl;
  image_map.clear();
  int count = 0;
  for (auto it = queue.begin(); it != queue.end() && count < batch_size;) {
    auto &frame = *it;
    if (!this->Skip(frame->count)) count++;
    image_map.push_back(frame);
    it = queue.erase(it);
  }

  /*if (!image_map->empty()) {
      PrintQueueInfo(queue_size, count, image_map->size());
  }*/
}

void CAlgPersonEngine::Process(CFlowDispatch &dsp) {
  if (!channel_data_update_queue_.empty()) {
    auto new_data = channel_data_update_queue_.pop();
    auto &channel_id = new_data->channel_id_;
    if (auto old_data = channel_data_map_.find(new_data->channel_id_)) {
      auto copy_data = std::make_shared<ChannelData>(*old_data);
      if (copy_data->UpdateCfg(*new_data)) {
        channel_data_map_.insert(channel_id, copy_data);
      }
    }
    if (auto channel_data = channel_data_map_.find(channel_id)) {
      const std::string PERSON_STRUCT_CODE("5200");
      CFlowDispatch::spNode detect, track, quality, feature, attribute, chin, chout;
      chin = dsp.get_node(channel_id, "in");
      chout = dsp.get_node(channel_id, "out");
      if (!chin || !chout) return;

      if (new_data->action_ == 1 && chin && chout) {  // add violation
        if (new_data->add_violation_ == PERSON_STRUCT_CODE) {
          detect = dsp.add_node(channel_id,
                                std::string(typeid(this).name()) + "-detect",
                                config_.person_detect_queue_size(), true);
          detect->process([this](VecImage &in) {
            VecImage frames;
            this->GetBatchFramesWithSize(in, frames, config_.person_det().batch_size());
            this->personDetectProcess(frames);
          });
          chin->next(detect);

          track = dsp.add_node(channel_id,
                               std::string(typeid(this).name()) + "-track",
                               config_.person_detect_queue_size());
          track->process([this, channel_data](VecImage &in) {
            this->personTrackProcess(channel_data, in);
            in.clear();
          });
          detect->next(track);

          quality = dsp.add_node(
              channel_id, std::string(typeid(this).name()) + "-quality",
              config_.person_quality_queue_size(), true);
          quality->process([this](VecImage &in) {
            VecImage frames;
            this->GetBatchFramesWithSize(in, frames, config_.person_quality().batch_size());
            this->personQualityProcess(frames);
          });
          track->next(quality);

          feature = dsp.add_node(channel_id,
                                 std::string(typeid(this).name()) + "-feature",
                                 config_.person_feature_queue_size(), true);
          feature->process([this](VecImage &in) {
            VecImage frames;
            this->GetBatchFramesWithSize(in, frames, config_.person_feature().batch_size());
            this->personFeatureProcess(frames);
          });
          quality->next(feature);

          attribute = dsp.add_node(
              channel_id, std::string(typeid(this).name()) + "-attribute",
              config_.person_attribute_queue_size(), true);
          attribute->process([this](VecImage &in) {
            VecImage frames;
            this->GetBatchFramesWithSize(in, frames, config_.person_attr().batch_size());
            this->personAttributeProcess(frames);
          });
          feature->next(attribute);

          auto fill_skip = dsp.add_node(
              channel_id, std::string(typeid(this).name()) + "-fill-skipframe",
              2);
          auto last_person_objects = std::make_shared<ImageObjectsInfo>();
          fill_skip->process([this, last_person_objects](VecImage &in) {
            for (auto image : in) {
              if (!this->Skip(image->count)) {
                last_person_objects->person_objects = image->person_objects;
              } else {
                for(auto& person : last_person_objects->person_objects) {
                  if(person.create_flag) {
                    person.create_flag = 0;
                    person.person_feature.clear();
                  }
                }
                image->person_objects = last_person_objects->person_objects;
              }
            }
            in.clear();
          });
          attribute->next(fill_skip);
          
          fill_skip->next(chout);
        }

      } else if (new_data->action_ == 2) {  // remove violation
        if (new_data->add_violation_ == PERSON_STRUCT_CODE) {
          dsp.remove_node(channel_id,
                          std::string(typeid(this).name()) + "-detect");
          dsp.remove_node(channel_id,
                          std::string(typeid(this).name()) + "-quality");
          dsp.remove_node(channel_id,
                          std::string(typeid(this).name()) + "-feature");
          dsp.remove_node(channel_id,
                          std::string(typeid(this).name()) + "-attribute");
          dsp.remove_node(channel_id,
                          std::string(typeid(this).name()) + "-track");
          dsp.remove_node(channel_id,
                          std::string(typeid(this).name()) + "-fill-skipframe");
        }
      }
    }
  }
}

void CAlgPersonEngine::ProcessByName(const std::string &name,
                                     const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) {
  if (name == "post") {
    std::vector<RectF> rois = {RectF(0, 0, shell_frame->width(), shell_frame->height())};
    VecMat mats = {shell_frame->getMat()};
    std::vector<VecBoxF> person_infos = {boxes};
    int code = -1;
    if (person_detect_engine_ != nullptr) {
      std::unique_lock<std::mutex> lock{person_detect_lock_};
      person_detect_engine_->Predict(mats, rois, person_infos, code);
    }
    if (person_quality_engine_ != nullptr) {
      std::unique_lock<std::mutex> lock{person_quality_lock_};
      person_quality_engine_->Predict(mats, person_infos, code);
    }
    if (person_feature_engine_ != nullptr) {
      std::unique_lock<std::mutex> lock{person_feature_lock_};
      person_feature_engine_->Predict(mats, person_infos, code);
    }
    if (person_attribute_engine_ != nullptr) {
      std::unique_lock<std::mutex> lock{person_attribute_lock_};
      person_attribute_engine_->Predict(mats, person_infos, code);
    }
  }
}

void CAlgPersonEngine::AddStream(const std::string &channel_id,
                                 const std::string &config) {
  int code = 0;
  auto channel_data = channel_data_map_.find(channel_id);
  if (nullptr == channel_data.get()) {
    channel_data = std::make_shared<ChannelData>();
    channel_data->channel_id_ = channel_id;
    channel_data->max_person_quality_ = std::make_shared<std::map<int,float>>();
    auto tracker_ptr = make_shared<Track::TADTracker>();
    LOG(INFO) << "New tracker with " << channel_id;
    tracker_ptr->Setup(config_.track(), config, code);
    CHECK(0 == code);
    channel_data->tracker_ = tracker_ptr;
    // prase
    BoxF box;

    if (parse_detect_roi_config(config, &box)) {
      channel_data->detect_roi_ = std::make_shared<RectF>(box.RectFloat());
    }
    channel_data_map_.insert(channel_id, channel_data);
  }
}

void CAlgPersonEngine::RemoveStream(const std::string &channel_id) {
  channel_data_map_.erase(channel_id);
}

// 读取违法的布控配置信息，以及跟踪的参数信息。
void CAlgPersonEngine::AddViolation(const std::string &channel_id,
                                    const std::string &violation_id,
                                    const std::string &config) {
  if (config_.person_struct_on()) {
    auto channel_data_old = channel_data_map_.find(channel_id);
    if (channel_data_old) {
      string roi_cfg;
      {
        auto data = std::make_shared<inference::ViolationConfig>();
        string err;
        json2pb(config, data.get(), &err);
        inference::Roi roi;
        *roi.mutable_data() = data->roi();
        pb2json(&roi, &roi_cfg);
      }
      channel_data_old->tracker_->AddStreamRoiConfig(violation_id, roi_cfg);
      channel_data_old->tracker_->AddStreamTrackingType(violation_id, config);

      std::string violation_code;
      auto channel_data = std::make_shared<ChannelData>();
      channel_data->channel_id_ = channel_id;
      channel_data->action_ = 1;
      if (parse_violation_code(config, violation_code)) {
        channel_data->add_violation_ = violation_code;
      }
      channel_data_update_queue_.push(channel_data);
    }
  }
}

void CAlgPersonEngine::RemoveViolation(const std::string &channel_id,
                                       const std::string &violation_id) {
  auto channel_data = channel_data_map_.find(channel_id);
  if (channel_data) {
    channel_data->tracker_->RemoveStreamRoiConfig(violation_id);

    auto vdata = std::make_shared<ChannelData>();
    vdata->channel_id_ = channel_id;
    vdata->action_ = 2;
    channel_data_update_queue_.push(vdata);
  }
}

void CAlgPersonEngine::personTrackProcess(
    CAlgPersonEngine::spChannelData channel, const VecImage &images) {
  std::unique_lock<std::mutex> lock{person_track_lock_};
  int code = -1;
  // Profiler profiler_track;
  // ProfilerHelper _profiler(&profiler_track, "trackProcess", [](Profiler* p) {
  //   LOG(INFO) << "profiler " << p->get_stats_str();
  // });
  for (auto image : images) {
    if (!this->Skip(image->count)) {
      channel->tracker_->Process(image->sframe, image->person_objects, &code);
    } else {
      continue;
    }
  }
}

void CAlgPersonEngine::personDetectProcess(const VecImage &images) {
  std::unique_lock<std::mutex> lock{person_detect_lock_};
  // Profiler profiler_detect;
  // ProfilerHelper _profiler(
  //     &profiler_detect, "DetectionProcess",
  //     [](Profiler* p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });
  // detect
  VecMat mats;
  std::vector<RectF> rois;
  std::vector<VecBoxF> person_infos;
  VecImage image_detect;
  // std::cout<<"detect "<<images.size()<<std::endl;
  for (auto &image : images) {
    if (this->Skip(image->count)) {
      continue;
    }
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }
    const auto &pic_mat = image->sframe->getMat();
    RectF roi;
    if (channel_data->detect_roi_) {
      const auto &detect_roi = *(channel_data->detect_roi_);
      roi = RectF(detect_roi.x, detect_roi.y, detect_roi.w, detect_roi.h);
    } else {
      roi = RectF(0, 0, image->sframe->width(), image->sframe->height());
    }
    mats.push_back(pic_mat);
    rois.push_back(roi);
    person_infos.push_back(image->person_objects);
    image_detect.push_back(image);
  }

  int code = -1;
  if (mats.empty() || rois.empty()) return;
  person_detect_engine_->Predict(mats, rois, person_infos, code);
  int j = 0;
  CHECK_EQ(person_infos.size(), image_detect.size());
  for (int i = 0; i < image_detect.size(); i++) {
    image_detect[i]->person_objects = person_infos[i];
  }
}

void CAlgPersonEngine::personQualityProcess(const VecImage &images) {
  std::unique_lock<std::mutex> lock{person_quality_lock_};
  // Profiler profiler_detect;
  // ProfilerHelper _profiler(
  //     &profiler_detect, "PersonAttributeProcess",
  //     [](Profiler* p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });

  // attribute
  VecMat mats;
  std::vector<VecBoxF> person_infos;
  std::vector<std::vector<BoxF*>> person_origin_box;

  for (auto &image : images) {
    if (this->Skip(image->count)) {
      continue;
    }
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }
    const auto &pic_mat = image->sframe->getMat();

    mats.push_back(pic_mat);

    person_infos.emplace_back();
    person_origin_box.emplace_back();
    for (auto& person_box : image->person_objects) {
      if (!person_box.delete_flag) {
        person_infos.back().push_back(person_box);
        person_origin_box.back().push_back(&person_box);
      }
    }
  }

  int code = -1;
  if (mats.empty() || person_infos.empty()) return;
  person_quality_engine_->Predict(mats, person_infos, code);

  // copy result
  CHECK_EQ(person_origin_box.size(), person_infos.size());
  for (int j=0; j<person_origin_box.size(); j++) {
    CHECK_EQ(person_origin_box[j].size(), person_infos[j].size());
    for (int k=0; k<person_origin_box[j].size(); k++) {
      person_origin_box[j][k]->person_quality = person_infos[j][k].person_quality;
    }
  }
}

void CAlgPersonEngine::personAttributeProcess(const VecImage &images) {
  std::unique_lock<std::mutex> lock{person_attribute_lock_};
  // Profiler profiler_detect;
  // ProfilerHelper _profiler(
  //     &profiler_detect, "PersonAttributeProcess",
  //     [](Profiler* p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });

  // attribute
  VecMat mats;
  std::vector<VecBoxF> person_infos;
  std::vector<std::vector<BoxF*>> person_origin_box;

  for (auto &image : images) {
    if (this->Skip(image->count)) {
      continue;
    }
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }

    mats.push_back(image->sframe->getMat());

    person_infos.push_back(VecBoxF());
    person_origin_box.push_back(std::vector<BoxF*>());
    for (auto& person_box : image->person_objects) {
      if (!person_box.delete_flag) {
        person_infos.back().push_back(person_box);
        person_origin_box.back().push_back(&person_box);
      }
    }
  }

  int code = -1;
  if (mats.empty() || person_infos.empty()) return;
  person_attribute_engine_->Predict(mats, person_infos, code);

  // copy result
  CHECK_EQ(person_origin_box.size(), person_infos.size());
  for (int j=0; j<person_origin_box.size(); j++) {
    CHECK_EQ(person_origin_box[j].size(), person_infos[j].size());
    for (int k=0; k<person_origin_box[j].size(); k++) {
      person_origin_box[j][k]->person_attr = person_infos[j][k].person_attr;
    }
  }
}

void CAlgPersonEngine::personFeatureProcess(const VecImage &images) {
  std::unique_lock<std::mutex> lock{person_feature_lock_};
  // Profiler profiler_detect;
  // ProfilerHelper _profiler(
  //     &profiler_detect, "PersonFeatureProcess",
  //     [](Profiler* p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });
  // feature
  VecMat mats;
  std::vector<VecBoxF> person_infos;
  std::vector<std::vector<BoxF*>> person_origin_box;

  for (auto &image : images) {
    if (this->Skip(image->count)) {
      continue;
    }
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }
    const auto &pic_mat = image->sframe->getMat();
    mats.push_back(pic_mat);
    person_infos.push_back(VecBoxF());
    person_origin_box.push_back(std::vector<BoxF*>());
    for (auto& person_box : image->person_objects) {
      // skip delete box
      if (person_box.delete_flag) {
        channel_data->max_person_quality_->erase(person_box.uid);
        continue;
      }
      if (person_box.person_quality[0].type>0) continue;
      if (person_box.person_quality[2].type>0) continue;
      if (channel_data->max_person_quality_->count(person_box.uid) > 0){
        auto& max_person_quality_score = channel_data->max_person_quality_->at(person_box.uid);
        if (max_person_quality_score >= person_box.person_quality[0].score) {
          continue;
        }
      }
      // update max_person_quality_
      (*(channel_data->max_person_quality_))[person_box.uid] = person_box.person_quality[0].score;
      person_infos.back().push_back(person_box);
      person_origin_box.back().push_back(&person_box);
    }
  }

  int code = -1;
  if (mats.empty() || person_infos.empty()) return;
  person_feature_engine_->Predict(mats, person_infos, code);

  // copy result
  CHECK_EQ(person_origin_box.size(), person_infos.size());
  for (int j=0; j<person_origin_box.size(); j++) {
    CHECK_EQ(person_origin_box[j].size(), person_infos[j].size());
    for (int k=0; k<person_origin_box[j].size(); k++) {
      person_origin_box[j][k]->person_feature = person_infos[j][k].person_feature;
    }
  }
}

bool CAlgPersonEngine::Skip(int64_t count) const {
  return count % config_.person_struct_interval();
}

void CAlgPersonEngine::PrintInfo(const VecImage &images) const {
  LOG(INFO) << "Objects Info";
  LOG(INFO) << "---------------------------------------------";

  for (auto &image : images) {
    auto &image_objects = *image;
    LOG(INFO) << "channel id: " << image_objects.channel_id;
    for (auto &object : image_objects.person_objects) {
      LOG(INFO) << "object type: " << object.label << ", \t"
                << "track id: " << object.uid << ", \t"
                << "pos: " << object.xmin << " " << object.ymin << " "
                << object.xmax << " " << object.ymax;
    }
  }
  LOG(INFO) << "---------------------------------------------";
}

void CAlgPersonEngine::PrintQueueInfo(int queue_size, int batch,
                                      int frames) const {
  LOG(INFO) << "Queue Info";
  LOG(INFO) << "frame queue---------------------------------------------";
  LOG(INFO) << "Raw frame queue: " << queue_size << " batch: " << batch << "/"
            << frames;
  channel_data_map_.visit(
      [](const std::string &channel_id, spChannelData channel_data) {
        LOG(INFO) << "Trc frame queue: " << channel_id << "\t";
        return true;
      });
  LOG(INFO) << "frame queue---------------------------------------------";
}

AlgRender CAlgPersonEngine::GetRender(const std::string &violation_code) const {
  if (violation_code == "5200") {
    return CAlgPersonEngine::Render;
  }
  return nullptr;
}

void CAlgPersonEngine::Render(const ImageObjectsInfo &image_objects, Mat_Ptr mat, bool enable_tracking_debug) {
  const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
  std::vector<VecString> attribute_name{
    {"man", "female"},
    {"forward", "backward", "sideward"},
    {"child", "adult"},
    {"no_hat", "hat"},
    {"no_shoulderbag", "shoulderbag"},
    {"no_backpack", "backpack"},
    {"no_handtrunk", "handtrunk"},
    {"ub_green", "ub_blue", "ub_black", "ub_gray", "ub_white", "ub_purple", "ub_yellow", "ub_red", "ub_brown", "ub_pink",
     "ub_orange", "ub_darkblue", "ub_multi", "ub_other"},
    {"lb_orange", "lb_black", "lb_white", "lb_gray", "lb_red", "lb_green", "lb_blue", "lb_yellow", "lb_brown", "lb_shorts", "two_piece", "lb_other"}
  };
  std::vector<VecString> quality_name{
      {"clear", "blur", "invalid"},
      {"no_occlusion", "occlusion"},
      {"complete", "incomplete"},
      {"single", "multi"},
      {"center", "no_center"}
  };
  for (auto &object : image_objects.person_objects) {
    cv::Scalar scalar;
    if (object.delete_flag > 0) {
      continue;
    }
    if (object.person_quality[2].type || object.person_quality[0].type) {
      scalar = cv::Scalar(0, 255, 0);
    }
    else{
      scalar = cv::Scalar(0, 0, 255);
    }

    auto text_id = std::to_string(object.uid);
/*    auto text_sex = object.person_attr.size()>0 ? attribute_name[0][object.person_attr[0].type] : "UNDEFINE";
    auto text_hat = object.person_attr.size()>1 ? attribute_name[1][object.person_attr[1].type] : "UNDEFINE";*/
    auto text_sex = object.person_quality.size()>0 ? quality_name[0][object.person_quality[0].type] : "UNDEFINE";
    auto text_hat = object.person_quality.size()>2 ? quality_name[2][object.person_quality[2].type] : "UNDEFINE";
    cv::putText(*mat, text_id,
                cv::Point(object.xmin, object.ymin - 10)*scale,
                cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 1);
    cv::putText(*mat, text_sex,
                cv::Point(object.xmax, object.ymin - 10)*scale,
                cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 1);
    cv::putText(*mat, text_hat,
                cv::Point(object.xmax, object.ymax + 10)*scale,
                cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 1);
    cv::rectangle(*mat,
                  cv::Point(object.xmin, object.ymin)*scale,
                  cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
  }
}

}// namespace FLOW
