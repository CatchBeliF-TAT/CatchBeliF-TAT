#ifndef TAD_ALG_HELPER_HPP
#define TAD_ALG_HELPER_HPP

#include <thread>
#include <functional>

#include "common/Queue.h"

namespace FLOW {

    template <class _DataType> 
    class FnEmpty {
        public: 
        bool operator()(const _DataType &data) {
            return data.empty();
        }
    };

    template <class _Rp, class _ArgType>
    class AlgProcesserT {
    public:
        typedef std::function<_Rp(_ArgType)> _OpFn;
        typedef FnEmpty<_ArgType> _default_OpFnCheckEmpty;
        typedef std::function<bool(_ArgType)> _OpFnCheckEmpty;
        typedef Queue<_ArgType> _ArgTypeQueue;
        typedef Queue<_Rp>      _RpQueue;
        typedef std::shared_ptr<_ArgTypeQueue>  _SpArgTypeQueue;
        typedef std::shared_ptr<_RpQueue>       _SpRpQueue;
        AlgProcesserT(std::string name="", size_t queue_size=8) 
            : name_(name)
            , queue_size_(std::max(queue_size,1ul))
        {
        }
        ~AlgProcesserT() {
            Stop();
        }
        bool Start(_OpFn fun, _SpArgTypeQueue spArgQ = nullptr, _SpRpQueue spRpQueue= nullptr, _OpFnCheckEmpty checker = _default_OpFnCheckEmpty()) {
            if (thread_.joinable()) {
                return false;
            }
            // thread_ = std::thread(std::bind(Alg_ProcesserT<_Rp, _ArgType)>::work, this, fun, spArgQ, spRpQueue, checker));
            thread_ = std::thread([this, fun, spArgQ, spRpQueue, checker](){
                this->work(fun, spArgQ, spRpQueue, checker);
            });
            return true;
        }
        bool Stop(){
            arg_queue_.cancel_pops();
            if(thread_.joinable()) {
                thread_.join();
            }
        }

    protected:
        void work(_OpFn fun, _SpArgTypeQueue spArgQ, _SpRpQueue spRpQueue, _OpFnCheckEmpty checker){
            if ( spArgQ == nullptr) {
                arg_queue_ = std::make_shared<_ArgTypeQueue>(queue_size_);
            }
            if (!name_.empty()) { SET_THREAD_NAME(name_); }
            for(auto arg = arg_queue_.pop(); checker(arg); arg = arg_queue_.pop()) {
                const _RpQueue rep = fun(arg);
                if(spRpQueue) {
                    spRpQueue->push(rep);
                }
            }
        }

    protected:
        std::string         name_;
        std::thread         thread_;
        size_t              queue_size_;
        _SpArgTypeQueue     arg_queue_;
        _SpRpQueue          rep_queue_;
    };

} // namespace TAD

#endif //TAD_ALG_HELPER_HPP
