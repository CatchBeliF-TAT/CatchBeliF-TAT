#ifndef TAD_ALG_GUARDRAIL_ENGINE_HPP
#define TAD_ALG_GUARDRAIL_ENGINE_HPP

#include <memory>
#include <mutex>
#include <atomic>
#include <functional>

#include "common/Queue.h"
#include "alg_engine_interface.hpp"
#include "serving/config.pb.h"

namespace prometheus{
    class Counter;
    typedef std::shared_ptr<Counter> spCounter;
}

namespace FLOW {

    namespace Detect {
        class DetectModule;
    }
    namespace Guardrail {
        class Guardrail;
    }

    class ProfileMetric;
    typedef std::shared_ptr<ProfileMetric> spProfileMetric;

    // CAlgGuardrailEngine
    class CAlgGuardrailEngine : public ICAlgEngine{
    public:
        CAlgGuardrailEngine() = default;
        virtual ~CAlgGuardrailEngine() = default;

    public:
        virtual void Init(const inference::EngineConfig &config, int &code);
        virtual void GetBatchFrames(VecImage &queue, VecImage &image_map) const;
        virtual void Process(CFlowDispatch &dsp);

        void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) override;
        virtual void AddStream(const std::string &channel_id, const std::string &config);
        virtual void RemoveStream(const std::string &channel_id);
        virtual void AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config);
        virtual void RemoveViolation(const std::string &channel_id, const std::string &violation_id);
        virtual AlgRender GetRender(const std::string &violation_code) const override;
        
    protected:
        typedef std::vector<std::shared_ptr<cv::Mat>> VecPtrMat;
        struct ChannelData { // need all ptr
            std::string                         channel_id_;
            std::shared_ptr<RectF>              detect_roi_;
            std::shared_ptr<ImageObjectsInfo>   last_image_;
            int action_;
            std::map<std::string,int>           guardrail_task_codes;
            std::string                         add_violation_;
            std::string                         remove_violation_;
            std::string                         violation_code_;

            VecString                           guardrail_violation_ids_;
            VecBoxF                             guardrail_boxes_;
            VecFloat                            guardrail_thresholds_;
            VecInt                              guardrail_periods_;
            VecFloat                            guardrail_max_socres_;
            VecPtrMat                           guardrail_origin_roi_mats_;
            VecPtrMat                           guardrail_roi_mats_;
            VecPtrMat                           guardrail_wrong_frames_;
            VecInt                              guardrail_wrong_frame_durations_;


            std::shared_ptr<ChannelData> UpdateCfg(ChannelData other) const {
                if ( other.channel_id_ != channel_id_ ) {
                    return nullptr;
                }

                auto retv = std::make_shared<ChannelData>(*this);
                if ( other.detect_roi_ ) {
                    retv->detect_roi_ = other.detect_roi_;
                }
                if ( other.last_image_ ) {
                    retv->last_image_ = other.last_image_;
                }

                if ( ! other.add_violation_.empty() ) {
                    retv->guardrail_task_codes[other.violation_code_]++;
                    #define APPEND_FROM_TO(FROM,TO) \
                        FROM.insert(FROM.end(), TO.begin(), TO.end())
                    APPEND_FROM_TO(retv->guardrail_violation_ids_, other.guardrail_violation_ids_);
                    APPEND_FROM_TO(retv->guardrail_boxes_, other.guardrail_boxes_);
                    APPEND_FROM_TO(retv->guardrail_origin_roi_mats_, other.guardrail_origin_roi_mats_);
                    APPEND_FROM_TO(retv->guardrail_thresholds_, other.guardrail_thresholds_);
                    APPEND_FROM_TO(retv->guardrail_max_socres_, other.guardrail_max_socres_);
                    APPEND_FROM_TO(retv->guardrail_roi_mats_, other.guardrail_roi_mats_);
                    APPEND_FROM_TO(retv->guardrail_periods_, other.guardrail_periods_);
                    APPEND_FROM_TO(retv->guardrail_wrong_frames_, other.guardrail_wrong_frames_);
                    APPEND_FROM_TO(retv->guardrail_wrong_frame_durations_, other.guardrail_wrong_frame_durations_);
                    #undef APPEND_FROM_TO
                }
                if ( ! other.remove_violation_.empty() ) {
                    retv->guardrail_task_codes[other.violation_code_]--;
                    //TODO need delete data
                }
                return retv;
            }
        };
        typedef std::shared_ptr<ChannelData> spChannelData;

        class safeChannelDataMap {
            public:
            spChannelData find(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                return (it != map_.end()) ? it->second : nullptr;
            }
            spChannelData insert(const std::string& key, spChannelData value) {
                std::unique_lock<std::mutex> lock{lock_};
                auto old_value = map_[key];
                map_[key] = value;
                return old_value;
            }
            spChannelData erase(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                spChannelData old_value;
                if (it != map_.end()) {
                    old_value = it->second;
                    map_.erase(it);
                }
                return old_value;
            }
        protected:
            mutable std::mutex lock_;
            std::unordered_map<std::string, spChannelData> map_;
        };

    protected:
        static void Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug=false);
        void GuardrailProcess(spChannelData channel, const VecImage &images);
        void GetBatchFrames(VecImage &queue, VecImage &image_map, std::function<bool(int)> need_skip, int max_batch) const;
        bool ParseConfig(const std::string& json, std::string* code, VecBoxF *boxes, std::string* bg_img_path, float* similar_threshold, int* period);
        static bool match_code(const std::string& code);

    protected:
        inference::Guardrail config_;

    protected:
        Profiler guardrail_profiler_;

        std::mutex guardrail_lock_;
        std::shared_ptr<Guardrail::Guardrail> guardrail_engine_ = nullptr;

    protected:
        spProfileMetric profile_metric_guardrail_;

    protected:
        safeChannelDataMap      channel_data_map_;
        Queue<spChannelData>    channel_data_update_queue_;

    };

}

#endif //TAD_ALG_GUARDRAIL_ENGINE_HPP
