
#include <vector>
#include <future>
#include <tuple>
#include <sstream>

#include "common/io.hpp"
#include "common/pbjson.hpp"
#include "common/util_scale.hpp"
#include "common/tad_internal.hpp"

#include "core/metric.hpp"
#include "helper.hpp"
#include "draw_helper_for_nv12.hpp"
#include "alg_vehicle_engine.hpp"

#include "serving/violation_config.pb.h"

#include "algorithm/detect/detect.hpp"
#include "algorithm/track/track_wraper.hpp"
#include "algorithm/vehicleattribute/vehicle_attr.hpp"
#include "algorithm/vehicleattribute/behaviour_attr.hpp"
#include "algorithm/vehicleattribute/construct_attr.hpp"
#include "algorithm/plate/waimai_plate.hpp"
#include "algorithm/plate/vehicle_plate.hpp"
#include "algorithm/traffic_light/traffic_light_recog.hpp"

namespace FLOW {

    using namespace std;

    void CAlgVehicleEngine::PrintInfo(const VecImage& images) const {
        LOG(INFO) << "Objects Info";
        LOG(INFO) << "---------------------------------------------";

        for (auto &image : images) {
            auto &image_objects = *image;
            LOG(INFO) << "channel id: " << image_objects.channel_id;
            for (auto &object : image_objects.objects) {
            LOG(INFO) << "object type: " << object.label << ", \t"
                        << "attr type: " << object.attr_type.type << ", \t"
                        << "track id: " << object.uid << ", \t"
                        << "pos: " << object.xmin << " " << object.ymin << " "
                        << object.xmax << " " << object.ymax;
            }
        }

        LOG(INFO) << "---------------------------------------------";
    }

    void CAlgVehicleEngine::Init(const inference::EngineConfig &config, int &code) {
        config_ = config.traffic();

        struct _model_config_info{
            bool                must;
            std::string         path;
            std::vector<char>   param;
        };
        
        std::map<std::string, _model_config_info> params = {
            {"detect_model",        {true,  config_.detect().model_path(),          std::vector<char>()}},
            {"attribute_model",     {false, config_.vehicle_attr().model_path(),    std::vector<char>()}},
            {"behaviour_model",     {false, config_.nonmotor_attr().model_path(),   std::vector<char>()}},
            {"person_attr_model",   {false, config_.person_attr().model_path(),     std::vector<char>()}},
            {"plate_model",         {false, config_.vehicle_plate().model_path(),   std::vector<char>()}},
            {"waimai_plate_model",  {false, config_.nonmotor_plate().model_path(),  std::vector<char>()}},
            {"traffic_light_model", {false, config_.traffic_light().model_path(),   std::vector<char>()}},
        };
        for (auto& kv : params) {
            if (kv.second.path == "" && !kv.second.must){
                LOG(WARNING) << "Skip load model " << kv.first << ", path(\"" <<  kv.second.path <<"\") configed";
                continue;
            }
            if (!IO::ReadBinaryFile(kv.second.path, &kv.second.param)) {
                LOG(FATAL) << "Load model " <<kv.first << ", path :" << kv.second.path << " error";
                return;
            } else {
                LOG(INFO) << "Load model " <<kv.first << ", path :" << kv.second.path << ", size :" << kv.second.param.size();
            }
        }

        // detect_model
        detector_ = make_shared<Detect::DetectModule>();
        detector_->Setup(params["detect_model"].param, config_.detect(), code);
        detector2_ = make_shared<Detect::DetectModule>();
        auto detect_config2 = config_.detect();
        detect_config2.set_batch_size(1);
        detect_config2.set_device_input(false);
        detector2_->Setup(params["detect_model"].param, detect_config2, code);
        // vehicle_attr
        if (!params["attribute_model"].path.empty()) {
            vehicle_attr_ = std::make_shared<Attribute::VehicleAttributeModule>();
            vehicle_attr_->Setup(params["attribute_model"].param, config_.vehicle_attr(), code);
            vehicle_attr2_ = std::make_shared<Attribute::VehicleAttributeModule>();
            vehicle_attr2_->Setup(params["attribute_model"].param, config_.vehicle_attr(), code);
        }
        // nonmotor_attr
        if (!params["behaviour_model"].path.empty()) {
            behaviour_attr_ = std::make_shared<Attribute::BehaviourAttributeModule>();
            behaviour_attr_->Setup(params["behaviour_model"].param, config_.nonmotor_attr(), code);
            behaviour_attr2_ = std::make_shared<Attribute::BehaviourAttributeModule>();
            behaviour_attr2_->Setup(params["behaviour_model"].param, config_.nonmotor_attr(), code);
        }
        // person_attr
        if (!params["person_attr_model"].path.empty()) {
            person_attr_ = std::make_shared<Attribute::ConstructionAttributeModule>();
            person_attr_->Setup(params["person_attr_model"].param, config_.person_attr(), code);
            person_attr2_ = std::make_shared<Attribute::ConstructionAttributeModule>();
            person_attr2_->Setup(params["person_attr_model"].param, config_.person_attr(), code);
        }
        // plate_model
        if (!params["plate_model"].path.empty()) {
            vehicle_plate_ = std::make_shared<Plate::VehiclePlate>();
            vehicle_plate_->Setup(params["plate_model"].param, config_.vehicle_plate(), code);
        }
        // waimai_plate
        if (!params["waimai_plate_model"].path.empty()) {
            waimai_plate_ = std::make_shared<Plate::WaiMaiPlate>();
            waimai_plate_->Setup(params["waimai_plate_model"].param, config_.nonmotor_plate());
        }

        // traffic_light_model
        if (!params["traffic_light_model"].path.empty()) {
            traffic_light_recog_ = std::make_shared<TrafficLight::TrafficLightRecog>();
            traffic_light_recog_->Setup(params["traffic_light_model"].param, config_.traffic_light(), code);
        }

        // metric init
        typedef std::map<std::string, std::string> LablesType;
        const prometheus::Summary::Quantiles quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
        profile_metric_detector_        = std::make_shared<ProfileMetric>(LablesType{{"engine", "traffic"}, {"model", "detector"           }}, quantiles);
        profile_metric_vehicle_plate_   = std::make_shared<ProfileMetric>(LablesType{{"engine", "traffic"}, {"model", "vehicle_plate"      }}, quantiles);
        profile_metric_waimai_plate_    = std::make_shared<ProfileMetric>(LablesType{{"engine", "traffic"}, {"model", "nonmotor_palte"     }}, quantiles);
        profile_metric_vehicle_attr_    = std::make_shared<ProfileMetric>(LablesType{{"engine", "traffic"}, {"model", "vehicle_attr_post"  }}, quantiles);
        profile_metric_vehicle_attr2_   = std::make_shared<ProfileMetric>(LablesType{{"engine", "traffic"}, {"model", "vehicle_attr"       }}, quantiles);
        profile_metric_nonmotor_attr_   = std::make_shared<ProfileMetric>(LablesType{{"engine", "traffic"}, {"model", "nonmotor_attr_post" }}, quantiles);
        profile_metric_nonmotor_attr2_  = std::make_shared<ProfileMetric>(LablesType{{"engine", "traffic"}, {"model", "nonmotor_attr"      }}, quantiles);
        profile_metric_person_attr_     = std::make_shared<ProfileMetric>(LablesType{{"engine", "traffic"}, {"model", "person_attr_post"   }}, quantiles);
        profile_metric_person_attr2_    = std::make_shared<ProfileMetric>(LablesType{{"engine", "traffic"}, {"model", "nonmotor_attr"      }}, quantiles);
        profile_metric_traffic_light_   = std::make_shared<ProfileMetric>(LablesType{{"engine", "traffic"}, {"model", "traffic_light"      }}, quantiles);
    }

    std::vector<int> CAlgVehicleEngine::GetDetectInputShapes()const {
        return detector_->GetInputShapes();
    }

    bool CAlgVehicleEngine::Skip(int64_t count) const {
        return count % config_.detect_interval();
    }

    void CAlgVehicleEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
        image_map.clear();
        int count = 0;
        for (auto it = queue.begin(); it != queue.end() && count < config_.detect().batch_size(); ) {
            auto &frame = *it;
            if (!this->Skip(frame->count)) count++;
            image_map.push_back(frame); 
            it = queue.erase(it);
        }
    }

    // 0 do nothing, 1 add, 2: remove
    void CAlgVehicleEngine::Process(CFlowDispatch &dsp) {
        while (!channel_data_update_queue_.empty()) {
            auto new_data = channel_data_update_queue_.pop();
            LOG(INFO) << "CAlgVehicleEngine::Process get a new data, action: "<<new_data->action_;
            auto& channel_id = new_data->channel_id_;
            auto old_data = channel_data_map_.find(new_data->channel_id_);
            //已经有了就更新，新的就插入
            if (old_data) {
                auto copy_data = std::make_shared<ChannelData>(*old_data);
                if (copy_data->UpdateCfg(*new_data)) {
                    channel_data_map_.insert(channel_id, copy_data);
                }
            }else{
                if(new_data->action_==ChannelData::ACTION::ACTION_ADD_STREAM){
                    channel_data_map_.insert(channel_id, new_data);
                }else{
                    return;
                }
            }
            
            //updated_data肯定不为空
            auto updated_data = channel_data_map_.find(new_data->channel_id_);
            switch (new_data->action_)
            {
            case ChannelData::ACTION::ACTION_ADD:
                if (updated_data->if_already_updated_topo_==false) {
                    updated_data->if_already_updated_topo_=true;
                    CFlowDispatch::spNode detect, track, attr, attr2, chin, chout;
                    chin = dsp.get_node(channel_id, "in");
                    chout = dsp.get_node(channel_id, "out");
                    auto last = chin;
                    if (!chin || !chout) return;
                    if (auto channel_data = channel_data_map_.find(channel_id)) {
                        detect = dsp.add_node(channel_id, "traffic-detect", config_.detect_queue_size(), true);
                        detect->process([this](VecImage &in) {
                                VecImage frames;
                                this->GetBatchFrames(in, frames);
                                if (!frames.empty()) {
                                    this->detectProcess(frames);
                                }
                        });
                        last->next(detect);
                        last = detect;

                        if(config_.has_tracking()){
                            track = dsp.add_node(channel_id, "traffic-track", config_.tracking_queue_size());
                            track->process([this, channel_id](VecImage &in) {
                                    auto channel_data = this->channel_data_map_.find(channel_id);
                                    if (!in.empty()) {
                                        if (channel_data) { this->trackProcess(channel_data, in); }
                                        in.clear();
                                    }
                            });
                            last->next(track);
                            last = track;
                        }
                        
                        if(config_.has_vehicle_attr()){
                            attr = dsp.add_node(channel_id, "traffic-vehicle-attr", config_.attr_queue_size(), true);
                            attr->process([this](VecImage &in) {
                                    if (!in.empty()) {
                                        this->attrProcessV2(in, OBJECT_TYPE_VEHICLE);
                                        in.clear();
                                    }
                            });
                            last->next(attr);
                            last = attr;
                        }

                        if(config_.has_nonmotor_attr()){
                            attr2 = dsp.add_node(channel_id, "traffic-nonmotor-attr", config_.attr_queue_size(), true);
                            attr2->process([this](VecImage &in) {
                                    if (!in.empty()) {
                                        this->attrProcessV2(in, OBJECT_TYPE_NONMOTOR);
                                        in.clear();
                                    }
                            });
                            last->next(attr2);
                            last = attr2;
                        }

                        if(config_.has_person_attr()){
                            auto attr3 = dsp.add_node(channel_id, "traffic-person-attr", config_.attr_queue_size(), true);
                            attr3->process([this](VecImage &in) {
                                    if (!in.empty()) {
                                        this->attrProcessV2(in, OBJECT_TYPE_PERSON);
                                        in.clear();
                                    }
                            });
                            last->next(attr3);
                            last = attr3;
                        }
                        {
                            auto current = dsp.add_node(channel_id, "traffic-fill-skipframe", 2);
                            auto last_objects = std::make_shared<ImageObjectsInfo>();
                            last_objects->channel_id = channel_id;
                            auto checker = [this](const spImageObjectsInfo frame)->bool{ return this->Skip(frame->count); };
                            current->process([this, checker, last_objects](VecImage &in) {
                                for (auto image : in) {
                                    CAlgVehicleEngine::FillSkipframe(checker, last_objects, image);
                                }
                                in.clear();
                            });
                            last->next(current);
                            last = current;
                        }

                        last->next(chout);
                    }
                }
                break;
            case ChannelData::ACTION::ACTION_REMOVE_STREAM:
                channel_data_map_.erase(channel_id);
                dsp.remove_node(channel_id, "traffic-detect");
                dsp.remove_node(channel_id, "traffic-track");
                dsp.remove_node(channel_id, "traffic-vehicle-attr");
                dsp.remove_node(channel_id, "traffic-nonmotor-attr");
                dsp.remove_node(channel_id, "traffic-fill-skipframe");
                break;
            default:
                break;
            }
        }
    }

    void CAlgVehicleEngine::ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) {
        if (boxes.empty()) {
            return;
        }
        if (name == "post") {
            // attr
            if (vehicle_attr_ != nullptr && boxes[0].label==OBJECT_TYPE_VEHICLE) {
                ProfileMetric::Helper _metric_helper(*profile_metric_vehicle_attr_);
                std::unique_lock<std::mutex> lock{attr_lock_};
                vehicle_attr_->Predict(shell_frame, &boxes);
            }
            if (behaviour_attr_ != nullptr && boxes[0].label==OBJECT_TYPE_NONMOTOR) {
                ProfileMetric::Helper _metric_helper(*profile_metric_nonmotor_attr_);
                std::unique_lock<std::mutex> lock{attr_lock_};
                behaviour_attr_->Predict(shell_frame, &boxes);
            }
            if (person_attr_ != nullptr && boxes[0].label==OBJECT_TYPE_PERSON) {
                ProfileMetric::Helper _metric_helper(*profile_metric_person_attr_);
                std::unique_lock<std::mutex> lock{attr_lock_};
                person_attr_->Predict(shell_frame, &boxes);
            }

            // plate
            if (vehicle_plate_ != nullptr && boxes[0].label==OBJECT_TYPE_VEHICLE) {
                ProfileMetric::Helper _metric_helper(*profile_metric_vehicle_plate_);
                std::unique_lock<std::mutex> lock{attr_lock_};
                vehicle_plate_->Predict(*shell_frame->getMat(), &boxes);
            }
            if (vehicle_plate_ != nullptr &&
                boxes[0].label==OBJECT_TYPE_NONMOTOR &&
                boxes[0].nonmotor_type.type == Attribute::NonMotorType::NonMotor_Motor) {
                ProfileMetric::Helper _metric_helper(*profile_metric_vehicle_plate_);
                std::unique_lock<std::mutex> lock{attr_lock_};
                vehicle_plate_->Predict(*shell_frame->getMat(), &boxes);
            }
            if (waimai_plate_ != nullptr &&
                boxes[0].label==OBJECT_TYPE_NONMOTOR &&
                boxes[0].nonmotor_type.type != Attribute::NonMotorType::NonMotor_Motor) {
                ProfileMetric::Helper _metric_helper(*profile_metric_waimai_plate_);
                std::unique_lock<std::mutex> lock{attr_lock_};
                waimai_plate_->Predict(*shell_frame->getMat(), &boxes);
            }
        }
        else if (name == "plate") {
            //detect
            {
                std::unique_lock<std::mutex> lock{detect_lock_};
                VecShellFrame shell_frames{shell_frame};
                std::vector<cv::Rect>rois{cv::Rect(
                    boxes[0].xmin,
                    boxes[0].ymin,
                    boxes[0].xmax-boxes[0].xmin,
                    boxes[0].ymax-boxes[0].ymin)
                };
                std::vector<std::vector<RectInfo>> image_rects;
                int code=0;
                // call
                detector2_->ProcessROIs(shell_frames, rois, image_rects, code);
                const auto p0 = cv::Point(shell_frame->width() / 2, shell_frame->height() / 2);
                auto near_itr = std::min_element(image_rects.front().begin(), image_rects.front().end(),
                    [p0](const RectInfo& r1, const RectInfo& r2)->bool{
                        const auto p1 = (r1.rect.br() + r1.rect.tl())*0.5 - p0;
                        const auto p2 = (r2.rect.br() + r2.rect.tl())*0.5 - p0;
                        return (p1.x*p1.x + p1.y*p1.y) < (p2.x*p2.x + p2.y*p2.y);
                    });
                if (near_itr != image_rects.front().end()) {
                    boxes[0].xmin = near_itr->rect.x;
                    boxes[0].ymin = near_itr->rect.y;
                    boxes[0].xmax = near_itr->rect.x + near_itr->rect.width;
                    boxes[0].ymax = near_itr->rect.y + near_itr->rect.height;
                    boxes[0].label = near_itr->label;
                    boxes[0].score = near_itr->score;
                } else {
                    boxes[0].label==OBJECT_TYPE_VEHICLE;
                }
            }
            // plate
            if (vehicle_plate_ != nullptr && boxes[0].label==OBJECT_TYPE_VEHICLE) {
                ProfileMetric::Helper _metric_helper(*profile_metric_vehicle_plate_);
                std::unique_lock<std::mutex> lock{attr_lock_};
                vehicle_plate_->Predict(*shell_frame->getMat(), &boxes);
            }
        }
    }

    void CAlgVehicleEngine::detectProcess(const VecImage &images) {
        std::unique_lock<std::mutex> lock{detect_lock_};
        Profiler profiler_detect;
        int batch_size=0;
        ProfilerHelper _profiler(&profiler_detect, "DetectionProcess",
            [&](Profiler* p){
                LOG(DEBUG) <<"profiler batch_size:"<<batch_size<<", "<< p->get_stats_str();
            }
        );

        typedef vector<vector<RectInfo>> VecRectInfos;
        typedef std::function<bool(int)> TypeFilter;
        // detect
        VecImage      image_detect;
        VecRectInfos  image_rects;
        VecShellFrame detect_frames;
        std::vector<cv::Rect> rois;
        std::vector<TypeFilter> det_types;
        std::vector<prometheus::spCounter> counters;
        // traffic light recog
        VecImage      image_tlc;
        VecShellFrame mat_tlc;
        VecBoxF       boxes;
        std::vector<std::string> violation_ids;

        for (auto &image : images) {
            if (this->Skip(image->count)) {
                continue;
            }
            auto channel_data = channel_data_map_.find(image->channel_id);
            if (nullptr == channel_data.get()) {
                continue;
            }

            cv::Rect roi;
            if (channel_data->detect_roi_) {
                const auto& detect_roi = *(channel_data->detect_roi_);
                roi = cv::Rect(detect_roi.x,detect_roi.y, detect_roi.w,detect_roi.h);
            } else {
                roi = cv::Rect(0, 0, image->sframe->width(), image->sframe->height());
            }

            image_detect.push_back(image);
            detect_frames.push_back(image->sframe);
            rois.push_back(roi);
            det_types.push_back([](int type) -> bool { return true; });
            counters.push_back(channel_data->detect_object_counter_);

            // person detect roi
            if (channel_data->person_detect_roi_) {
                const auto& data = *(channel_data->person_detect_roi_);
                image_detect.push_back(image);
                detect_frames.push_back(image->sframe);
                const auto roi = cv::Rect(data.x, data.y, data.w, data.h);
                rois.push_back(roi);
                det_types.back() = [](int type) -> bool {
                    return OBJECT_TYPE_PERSON != type;
                };
                det_types.push_back([](int type) -> bool { 
                    return OBJECT_TYPE_PERSON == type; 
                });
            }

            // tlc
            if (!channel_data->traffic_light_box_.empty()) {
                for(auto& p: channel_data->traffic_light_box_){
                    image_tlc.push_back(image);
                    mat_tlc.push_back(image->sframe);
                    boxes.push_back(p.second);
                    violation_ids.push_back(p.first);
                }
            }
        }

        batch_size = detect_frames.size();
        int code = -1;
#ifdef USE_MEDIA_UTILS
        if (config_.detect().device_input()) {
            ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
            detector_->Process(detect_frames, rois, image_rects, code);
            for (auto &image : images) {
                image->sframe->clearVframe();
            }
        } else {
            ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
            detector_->ProcessROIs(detect_frames, rois, image_rects, code);
        }
#else
        ProfileMetric::Helper _metric_helper(*profile_metric_detector_);
        detector_->ProcessROIs(shell_frames, rois, image_rects, code);
#endif

        std::vector<TrafficLight::TrafficLightColor> colors;
        if (!boxes.empty()) {
            ProfileMetric::Helper _metric_helper(*profile_metric_traffic_light_);
            traffic_light_recog_->Predict(mat_tlc, boxes, &colors);
        }

        // process detect result
        for (size_t i = 0; i < image_rects.size(); i++) {
            VecBoxF &objects  = image_detect[i]->objects;
            const auto &rects = image_rects[i];
            VecBoxF image_boxes;
            for (auto &rect : rects) {
                if (det_types[i](rect.label)) {
                    BoxF box((float)rect.rect.x, (float)rect.rect.y,
                                (float)(rect.rect.x + rect.rect.width),
                                (float)(rect.rect.y + rect.rect.height));
                    box.label = rect.label;
                    box.score = rect.score;
                    image_boxes.push_back(box);
                }
            }
            objects.insert(objects.end(), image_boxes.begin(), image_boxes.end());
            counters[i]->Increment(image_boxes.size());
        }

        // process traffic light result
        for (int i = 0; i < colors.size(); ++i) {
            boxes[i].color = colors[i];
            (image_tlc[i]->tlc)[violation_ids[i]] = boxes[i];//warning
        }
    }

    void CAlgVehicleEngine::trackProcess(spChannelData channel, const VecImage &images) {
        int code = -1;
        // std::unique_lock<std::mutex> lock{tracker_lock_};
        Profiler profiler_track;
        ProfilerHelper _profiler(&profiler_track, "trackProcess",
            [&](Profiler* p){LOG(DEBUG) <<"profiler frame_count:"<<images.size()<<", "<< p->get_stats_str();}
        );
        for( auto image : images){
            if (config_.tracking().max_time_interval()>0 &&
                ( image->time_interval > config_.tracking().max_time_interval() ||
                  image->pts_interval > config_.tracking().max_time_interval())) {
                LOG(WARNING) << "reset tracker"
                            <<",image time_interval="<< image->time_interval
                            <<",image pts_interval=" << image->pts_interval;
                image->ptz_pos.changed = true;
            }
            if (image->ptz_pos.changed){
                channel->tracker_->Reset();
                for(auto& b: image->tlc){
                    b.second.color = TrafficLight::kColorEmpty;
                }
                image->objects.clear();
                continue;
            }
            if (!channel->MatchPtz(image->ptz_pos)) {
                for(auto& b: image->tlc){
                    b.second.color = TrafficLight::kColorEmpty;
                }
                image->objects.clear();
                continue;
            }
            if (!this->Skip(image->count)) {
                ProfileMetric::Helper _metric_helper(*(channel->profile_metric_tracker_));
                channel->tracker_->Process(image->sframe, image->objects, &code);
                channel->track_object_counter_->Increment(image->objects.size());
            } else {
                continue;
            }
        }
    }

    void CAlgVehicleEngine::attrProcess(const VecImage &images) {
        Profiler profiler_attr;
        int count=0;
        ProfilerHelper _profiler(&profiler_attr, "vehicleAttrProcess",
            [&](Profiler* p){LOG(DEBUG) <<"profiler object_count: "<< count <<", "<< p->get_stats_str();}
        );
        vector<std::string> vec_channel_id;
        vector<VecBoxF> vec_boxes_tmp;
        vector<vector<BoxF*>> vec_boxes_addr;
        VecShellFrame mat_images;

        for (auto image : images) {
            auto &channel_id = image->channel_id;
            auto &image_objects = *image;
            VecBoxF boxes_tmp;
            vector<BoxF*> boxes_addr;
            for (auto &box : image_objects.objects) {
                if (box.label == OBJECT_TYPE_VEHICLE && 
                    box.attr_type.type == -1 &&
                    box.delete_flag == 0) {
                    count++;
                    boxes_tmp.push_back(box);
                    boxes_addr.push_back(&box);
                }
            }
            vec_channel_id.push_back(channel_id);
            vec_boxes_tmp.push_back(boxes_tmp);
            mat_images.push_back(image_objects.sframe);
            vec_boxes_addr.push_back(boxes_addr);
        }

        if (vehicle_attr_ && count) {
            std::unique_lock<std::mutex> lock{attr_lock_};
            // Profiler profiler_attr;
            // ProfilerHelper _profiler(&profiler_attr, "vehicleAttrProcess",
            //     [](Profiler* p){LOG(DEBUG) <<"profiler "<< p->get_stats_str();}
            // );
            vehicle_attr_->Predict(mat_images, &vec_boxes_tmp);
        }

        for (int i =0; i < vec_boxes_tmp.size(); ++i) {
            for (int j = 0; j < vec_boxes_tmp.at(i).size(); ++j) {
            *vec_boxes_addr.at(i).at(j) = vec_boxes_tmp.at(i).at(j);
            }
        }
    }

    bool CAlgVehicleEngine::needAtrrBox(const BoxF& box, ObjectType type) {
        float mini_size = 0.0f;
        switch (type){
        case OBJECT_TYPE_PERSON:
            mini_size = config_.nonmotor_attribute_min_size();
            break;
        case OBJECT_TYPE_VEHICLE:
            mini_size = config_.vehicle_attribute_min_size();
            break;
        case OBJECT_TYPE_NONMOTOR:
            mini_size = config_.nonmotor_attribute_min_size();
            break;
        }
        return box.label == type && 
                box.attr_type.type == -1 &&
                box.delete_flag == 0 &&
                (box.xmax - box.xmin) > mini_size &&
                (box.ymax - box.ymin) > mini_size;
    }

    void CAlgVehicleEngine::attrProcessV2(const VecImage &images, ObjectType type) {
        Profiler profiler_attr;
        int count=0;
        ProfilerHelper _profiler(&profiler_attr, "vehicleAttrProcessV2",
            [&](Profiler* p){LOG(DEBUG) <<"profiler object_count: "<< count <<", "<< p->get_stats_str();}
        );
        typedef std::unordered_map<int, BoxF*> object_hash;
        std::unordered_map<std::string, object_hash> first_attr_box_flag;
        for (auto image : images) {
            auto &channel_id = image->channel_id;
            
            VecImage processData;
            if (first_attr_box_flag.count(channel_id) == 0) {
                auto channel_data = this->channel_data_map_.find(channel_id);
                if (nullptr == channel_data) {
                    continue;
                }
                processData.push_back(channel_data->last_attr_image_[type]);
            }
            processData.push_back(image);


            for (auto image : processData) {
                for (auto &box : image->objects) {
                    if (first_attr_box_flag.count(channel_id) > 0 &&
                        first_attr_box_flag[channel_id].count(box.uid) > 0) {
                        box.attr_type = first_attr_box_flag[channel_id][box.uid]->attr_type;
                        box.attr_direction = first_attr_box_flag[channel_id][box.uid]->attr_direction;
                        box.special_car_type = first_attr_box_flag[channel_id][box.uid]->special_car_type;
                        box.nonmotor_type = first_attr_box_flag[channel_id][box.uid]->nonmotor_type;
                        box.behaviour_types = first_attr_box_flag[channel_id][box.uid]->behaviour_types;
                        box.traffic_person_type = first_attr_box_flag[channel_id][box.uid]->traffic_person_type;
                    } else if (box.attr_type.type != -1) {
                        first_attr_box_flag[channel_id][box.uid] = &box;
                    } else {
                        continue;
                    }
                }
            }
        }

        vector<std::string> vec_channel_id;
        vector<VecBoxF> vec_boxes_tmp;
        vector<vector<BoxF*>> vec_boxes_addr;
        VecShellFrame mat_images;
        for (auto image : images) {
            if (this->Skip(image->count)) {
                continue;
            }
            auto &channel_id = image->channel_id;
            auto &image_objects = *image;
            VecBoxF boxes_tmp;
            vector<BoxF*> boxes_addr;
            for (auto &box : image_objects.objects) {
                if (needAtrrBox(box, type)) {
                    count++;
                    boxes_tmp.push_back(box);
                    boxes_addr.push_back(&box);
                }
            }
            vec_channel_id.push_back(channel_id);
            vec_boxes_tmp.push_back(boxes_tmp);
            mat_images.push_back(image_objects.sframe);
            vec_boxes_addr.push_back(boxes_addr);
        }

        if (vehicle_attr2_ && type==OBJECT_TYPE_VEHICLE && count) {
            //std::unique_lock<std::mutex> lock{attr_lock_};
            ProfileMetric::Helper _metric_helper(*profile_metric_vehicle_attr2_);
            vehicle_attr2_->Predict(mat_images, &vec_boxes_tmp);
        }

        if (behaviour_attr2_ && type==OBJECT_TYPE_NONMOTOR && count) {
            //std::unique_lock<std::mutex> lock{attr_lock_};
            ProfileMetric::Helper _metric_helper(*profile_metric_nonmotor_attr2_);
            behaviour_attr2_->Predict(mat_images, &vec_boxes_tmp);
        }

        if (person_attr2_ && type==OBJECT_TYPE_PERSON && count) {
            //std::unique_lock<std::mutex> lock{attr_lock_};
            ProfileMetric::Helper _metric_helper(*profile_metric_person_attr2_);
            person_attr2_->Predict(mat_images, &vec_boxes_tmp);
        }

        for (int i =0; i < vec_boxes_tmp.size(); ++i) {
            for (int j = 0; j < vec_boxes_tmp.at(i).size(); ++j) {
                *vec_boxes_addr.at(i).at(j) = vec_boxes_tmp.at(i).at(j);
            }
        }

        first_attr_box_flag.clear();
        for (auto image : images) {
            auto &channel_id = image->channel_id;
            auto channel_data = this->channel_data_map_.find(channel_id);
            if (nullptr == channel_data) {
                continue;
            } else if (this->Skip(image->count)) {
                continue;
            } else {
                for (auto &box : image->objects) {
                    if (first_attr_box_flag.count(channel_id) > 0 &&
                        first_attr_box_flag[channel_id].count(box.uid) > 0) {
                        box.attr_type = first_attr_box_flag[channel_id][box.uid]->attr_type;
                        box.attr_direction = first_attr_box_flag[channel_id][box.uid]->attr_direction;
                        box.attr_direction = first_attr_box_flag[channel_id][box.uid]->attr_direction;
                        box.special_car_type = first_attr_box_flag[channel_id][box.uid]->special_car_type;
                        box.nonmotor_type = first_attr_box_flag[channel_id][box.uid]->nonmotor_type;
                        box.behaviour_types = first_attr_box_flag[channel_id][box.uid]->behaviour_types;
                        box.traffic_person_type = first_attr_box_flag[channel_id][box.uid]->traffic_person_type;
                    } else if (box.attr_type.type != -1) {
                        first_attr_box_flag[channel_id][box.uid] = &box;
                    } else {
                        continue;
                    }
                }
                channel_data->last_attr_image_[type]->objects = image->objects;
            }
        }
    }

    void CAlgVehicleEngine::AddStream(const std::string &channel_id, const std::string &config) {
        LOG_FUN_IN_OUT(INFO);
        int code = 0;
        auto channel_data = channel_data_map_.find(channel_id);
        if ( nullptr == channel_data.get()) {
            channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data->last_image_ = std::make_shared<ImageObjectsInfo>();
            channel_data->last_attr_image_[OBJECT_TYPE_VEHICLE] = std::make_shared<ImageObjectsInfo>();
            channel_data->last_attr_image_[OBJECT_TYPE_NONMOTOR] = std::make_shared<ImageObjectsInfo>();
            channel_data->last_attr_image_[OBJECT_TYPE_PERSON] = std::make_shared<ImageObjectsInfo>();
            std::stringstream address; address<<channel_data.get();
            typedef std::map<std::string, std::string> LablesType;
            channel_data->profile_metric_tracker_ = std::make_shared<ProfileMetric>(LablesType{
                    {"engine", "traffic"},
                    {"model", "tracker"},
                    {"stream_id", channel_id},
                }, prometheus::Summary::Quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}}
            );
            channel_data->detect_object_counter_ = std::shared_ptr<prometheus::Counter>(
                &Metric::Instance().object_counter->Add(LablesType{
                    {"engine", "traffic"},
                    {"model", "detect"},
                    {"stream_id", channel_id},
                    {"uid", address.str()},
                }),
                [](prometheus::Counter* c) {Metric::Instance().object_counter->Remove(c);}
            );
            channel_data->track_object_counter_ = std::shared_ptr<prometheus::Counter>(
                &Metric::Instance().object_counter->Add(LablesType{
                    {"engine", "traffic"},
                    {"model", "tracker"},
                    {"stream_id", channel_id},
                    {"uid", address.str()},
                }),
                [](prometheus::Counter* c) {Metric::Instance().object_counter->Remove(c);}
            );
            auto tracker_ptr = make_shared<Track::TADTracker>();
            LOG(INFO) << "New tracker with "<<channel_id;
            tracker_ptr->Setup(config_.tracking(), config, code);
            CHECK(0 == code);
            channel_data->tracker_ = tracker_ptr;
            // prase
            BoxF box;
            if (parse_traffic_light_box_config(config, &box)) {
                channel_data->traffic_light_box_["default"] = box;
            }
            if (parse_detect_roi_config(config, &box)) {
                channel_data->person_detect_roi_ = std::make_shared<RectF>(box.RectFloat());
            }

            channel_data->action_ = ChannelData::ACTION::ACTION_ADD_STREAM;
            channel_data_update_queue_.push(channel_data);
        }
    }
    
    void CAlgVehicleEngine::RemoveStream(const std::string &channel_id) {
        LOG_FUN_IN_OUT(INFO);
        auto vdata = std::make_shared<ChannelData>();
        vdata->channel_id_ = channel_id;
        vdata->action_ = ChannelData::ACTION::ACTION_REMOVE_STREAM;
        channel_data_update_queue_.push(vdata);
    }

    void CAlgVehicleEngine::AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config) {
        LOG_FUN_IN_OUT(INFO);
        //step0, 解析配置
        auto data = std::make_shared<inference::ViolationConfig>();
        string err;
        json2pb(config, data.get(), &err);
        inference::Roi roi;
        *roi.mutable_data() = data->roi();
        std::string roi_cfg;
        pb2json(&roi, &roi_cfg);
        

        //step1 判断是不是交通的violation
        if ( !CAlgVehicleEngine::match_code(data->code()) ) {
            return;
        }

        //step2 只要是交通的violation就下达一个addnode的命令，在process里再判断是否已经加过node
        {
            auto channel_data = std::make_shared<ChannelData>();
            channel_data->action_ = ChannelData::ACTION::ACTION_ADD;
            channel_data->channel_id_ = channel_id;
            channel_data_update_queue_.push(channel_data); 
        }

        //step3 更新tracker config
        {
            /*old way, not use again
                auto channel_data_old = channel_data_map_.find(channel_id);
                if (channel_data_old){
                    channel_data_old->tracker_->AddStreamRoiConfig(violation_id, roi_cfg);
                    channel_data_old->tracker_->AddStreamTrackingType(violation_id, config);
                }
            */
            auto channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data->action_ = ChannelData::ACTION::ACTION_UPDATE_TRACKER;
            channel_data->violation_id_ = violation_id;
            channel_data->roi_config_ = roi_cfg;
            channel_data->config_ = config; 
            channel_data_update_queue_.push(channel_data); 
        } 

        //step4 更新traffic_light_box_config
        BoxF box;
        if (parse_traffic_light_box_config(config, &box)) {
            auto channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data->violation_id_ = violation_id;
            channel_data->action_ = ChannelData::ACTION::ACTION_UPDATE_TRAFFIC_LIGHT_BOX;
            channel_data->traffic_light_box_[violation_id] = box;
            channel_data_update_queue_.push(channel_data);
        }

        //step5 更新ptz_cfg
        PosInfo ptz_cfg;
        if (parse_ptz_config(config, &ptz_cfg)) {
            auto channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data->action_ = ChannelData::ACTION::ACTION_ADD_PTZ;
            channel_data->ptz_config_[violation_id] = ptz_cfg;
            channel_data_update_queue_.push(channel_data);
        }
    }

    void CAlgVehicleEngine::RemoveViolation(const std::string &channel_id, const std::string &violation_id) {
        LOG_FUN_IN_OUT(INFO);
        //addviolation加的node在removeViolation时不拆，stopStream时全拆掉
        {
            auto channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data->action_ = ChannelData::ACTION::ACTION_REMOVE_TRACKER_ROI;
            channel_data->violation_id_ = violation_id;
            channel_data_update_queue_.push(channel_data); 
        }

        {
            auto channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data->action_ = ChannelData::ACTION::ACTION_REMOVE_PTZ;
            channel_data->ptz_config_[violation_id] = PosInfo();
            channel_data_update_queue_.push(channel_data); 
        }

        {
            auto channel_data = std::make_shared<ChannelData>();
            channel_data->channel_id_ = channel_id;
            channel_data->action_ = ChannelData::ACTION::ACTION_REMOVE_TRAFFIC_LIGHT_BOX;
            channel_data->violation_id_ = violation_id;
            channel_data_update_queue_.push(channel_data); 
        }
    }

    AlgRender CAlgVehicleEngine::GetRender(const std::string &violation_code) const {
        if (CAlgVehicleEngine::match_code(violation_code)) {
            return CAlgVehicleEngine::Render;
        }
        return nullptr;
    }

    bool CAlgVehicleEngine::match_code(const std::string& violation_code) {
        if (violation_code.size()>=4) {
            auto start2 = violation_code.substr(0,2);
            if (start2 == "21" ||
                start2 == "22" ||
                start2 == "24" ||
                start2 == "27" ||
                start2 == "28" ||
                start2 == "29") {
                return true;
            }

            auto start4 = violation_code.substr(0,4);
            if (start4 == "7005" ||
                start4 == "7010" ){
                return true;
            }
        }
        return false;
    }

    void CAlgVehicleEngine::FillSkipframe(fnSkipChecker skip, const spImageObjectsInfo processedFrame, spImageObjectsInfo currentFrame) {
        LOG_IF(FATAL, processedFrame->channel_id != currentFrame->channel_id) 
            << "frame channel_id missmatch, (" << processedFrame->channel_id << "!=" << currentFrame->channel_id <<")";

        if (!skip(currentFrame)) {
            processedFrame->tlc = currentFrame->tlc;
            processedFrame->objects = currentFrame->objects;
        } else {
            // fake
            currentFrame->tlc = processedFrame->tlc;
            currentFrame->objects = processedFrame->objects;
            currentFrame->fake_objects = true;
        }
    }

    void CAlgVehicleEngine::Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug) {
        const cv::Matx22f scale{mat->cols / (float)image_objects.sframe->width(), 0, 0, mat->rows / (float)image_objects.sframe->height()};
        if (enable_tracking_debug) {
            // drow traffic light
            for(auto& d: image_objects.tlc) {
                static std::map<TrafficLight::TrafficLightColor, cv::Scalar> color_map = {
                    {TrafficLight::kColorEmpty, cv::Scalar(255, 255, 255)},
                    {TrafficLight::kColorGreen, cv::Scalar(0, 255, 0)},
                    {TrafficLight::kColorRed, cv::Scalar(0, 0, 255)},
                    {TrafficLight::kColorYellow, cv::Scalar(0, 255, 255)},
                    {TrafficLight::kColorBlack, cv::Scalar(0, 0, 0)},
                    {TrafficLight::kColorDouble, cv::Scalar(128, 128, 128)},
                };
                const auto color = d.second.color;
                const auto scalar = color_map.count(color) ? color_map.at(color) : cv::Scalar(255, 255, 255);
                auto text = TrafficLight::helperGetStringTrafficLightColor(d.second.color);
                smcv::putText<smcv::AUTO>(*mat, text,
                            cv::Point(d.second.xmin, d.second.ymin)*scale,
                            cv::FONT_HERSHEY_SIMPLEX, 1, scalar, 2);

                smcv::rectangle<smcv::AUTO>(*mat, cv::Point(d.second.xmin, d.second.ymin)*scale,
                                    cv::Point(d.second.xmax, d.second.ymax)*scale, scalar, 2);
            }
            std::string text_status;
            //draw video status
            if (image_objects.jitter_status >= 0) {
                text_status += image_objects.jitter_status  == 0 ? "normal"
                            : image_objects.jitter_status   == 1 ? "shake"
                            : image_objects.jitter_status   == 2 ? "revolve"
                            : std::to_string(image_objects.jitter_status);
            }
            // draw ptz
            if (image_objects.ptz_pos.angle_x != -1 ||
                image_objects.ptz_pos.angle_y != -1 ||
                image_objects.ptz_pos.scale != -1) {
                text_status += std::string("PTZ:(")
                        +std::to_string(image_objects.ptz_pos.angle_x) + ","
                        +std::to_string(image_objects.ptz_pos.angle_y) + ","
                        +std::to_string(image_objects.ptz_pos.scale)   + ")";
            }
            if (!text_status.empty()) {
                auto scalar = cv::Scalar(255, 255, 255);
                smcv::putText<smcv::AUTO>(*mat, text_status,
                        cv::Point(20, 30)*scale,
                        cv::FONT_HERSHEY_SIMPLEX, 1, scalar, 2);
            }
        }
        for (auto &object : image_objects.objects) {
            cv::Scalar scalar;
            if (object.delete_flag) {
                continue;
            }
            if (enable_tracking_debug) {
                scalar = cv::Scalar(255, 255, 255);
                auto text = std::to_string(object.uid) +"/"+ std::to_string(object.label) +"/"+ std::to_string(object.attr_type.type);
                if(object.park_ms!=-1){
                    text = text+"/"+std::to_string(object.park_ms);
                }
                smcv::putText<smcv::AUTO>(*mat, text,
                            cv::Point(object.xmin, object.ymin - 10)*scale,
                            cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);
                smcv::rectangle<smcv::AUTO>(*mat, cv::Point(object.xmin, object.ymin)*scale,
                                    cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
                if (object.auto_center_x >=0 ) {
                    auto green = cv::Scalar(0, 255, 0);
                    smcv::circle<smcv::AUTO>(*mat, cv::Point(object.auto_center_x, object.auto_center_y)*scale, 5, green, -1);
                }
            }

            if (object.violate_state == 0)
                continue;
            if (object.delete_flag > 0) {
                continue;
            }
            if (object.label == OBJECT_TYPE_NONMOTOR) {
                switch (object.attr_type.type) {
                    case Attribute::WaiMai_MEITUAN:
                        scalar = cv::Scalar(0, 255, 255);
                    break;
                    case Attribute::WaiMai_ELE:
                        scalar = cv::Scalar(255, 0, 0);
                    break;
                    case Attribute::WaiMai_OTHER:
                        scalar = cv::Scalar(0, 255, 0);
                    break;
                    default:
                        scalar = cv::Scalar(255, 255, 255);
                }
            }
            else if (object.label == OBJECT_TYPE_VEHICLE) {
                if (object.violate_state == 2)
                    scalar = cv::Scalar(0, 255, 255);
                else if(object.violate_state == 255000)
                    scalar = cv::Scalar(0, 255, 0);
                else if(object.violate_state == 255000000)
                    scalar = cv::Scalar(255, 0, 0);
                else if(object.violate_state == 203192255)
                    scalar = cv::Scalar(203, 192, 255);
                else
                    scalar = cv::Scalar(0, 0, 255);
            } if(object.label == OBJECT_TYPE_HEAD){
                scalar = cv::Scalar(0, 0, 255);
            }else {
                // nop
            }

            smcv::rectangle<smcv::AUTO>(*mat, 
                        cv::Point(object.xmin, object.ymin)*scale,
                        cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
        }
        // auto path = image_objects.locus_->AvgPath();
        for (auto item : image_objects.avg_path_map){
            for (int i =0;i<item.second.size()-2;i++){
                smcv::line<smcv::AUTO>(*mat, cv::Point(int(item.second[i].x), int(item.second[i].y))*scale, \
                    cv::Point(int(item.second[i+1].x), int(item.second[i+1].y))*scale,
                cv::Scalar(0,255,0),2,8,0);
            }
        }

        // path = image_objects.locus_->VoilationPath();
        for (auto item : image_objects.voilation_path_map){
            for (int i =0;i<item.second.size()-2;i++){
                smcv::line<smcv::AUTO>(*mat, cv::Point(int(item.second[i].x), int(item.second[i].y))*scale, \
                    cv::Point(int(item.second[i+1].x), int(item.second[i+1].y))*scale,
                cv::Scalar(0,0,255),2,8,0);
            }
        }
        // path = image_objects.locus_->CorrectPath();
        for (auto item : image_objects.current_path_map){
            for (int i =0;i<item.second.size()-2;i++){
                smcv::line<smcv::AUTO>(*mat, cv::Point(int(item.second[i].x), int(item.second[i].y))*scale, \
                    cv::Point(int(item.second[i+1].x), int(item.second[i+1].y))*scale,
                cv::Scalar(255,0,0),2,8,0);
            }
        }

        return;
    }
} // FLOW

