#include "alg_reflective_vest_engine.hpp"
#include "core/flow_dispatch.hpp"
#include "violation/flow/violation_flow_code.hpp"
#include "common/io.hpp"
#include <memory>
#include "helper.hpp"
#include "common/util_scale.hpp"
namespace FLOW {
    //engine name
    const std::string REFLECTIVE_VEST("reflective_flag");
    const std::unordered_map<std::string, std::string> VEST_VIOLATION_MAP = {
        //violation_code  <===> engine_name
        {BUILDING_REFLECTIVE_VEST_CODE, REFLECTIVE_VEST},
    };
    void CAlgReflectiveVestEngine::Init(const inference::EngineConfig &config, int &code) {
        code = FLOW::module_status_success;
        config_ = config.vest();
        std::map<std::string, std::pair<std::string, std::vector<char>>> params;
	
        params["vest_detect_model"] = {config_.vest_detect().model_path(), {}};
        params["vest_classify_model"] = {config_.vest_classify().model_path(), {}};


        for (auto& kv : params) {
            if (!IO::ReadBinaryFile(kv.second.first, &kv.second.second)) {
                LOG(FATAL) << "Load model " << kv.second.first << " error";
                return;
            }
        }
        
        vest_detector_ = std::make_shared<Detect::DetectModule>();
        vest_detector_->Setup(params["vest_detect_model"].second, config_.vest_detect(), code);
        
        vest_classify_ = std::make_shared<classify::ClassifyModule>();
        vest_classify_->Setup(params["vest_classify_model"].second, config_.vest_classify(), code);
    
    }

    void CAlgReflectiveVestEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
        int count = 0;
        image_map.clear();
        for (auto it = queue.begin(); it != queue.end() && count < config_.detect_batch_size(); count++) {
            auto &frame = *it;
            image_map.push_back(frame); 
            it = queue.erase(it);
        }
    }

    void CAlgReflectiveVestEngine::VestDetectProcess(const VecImage &images){
        std::unique_lock<std::mutex> lock{vest_detect_lock_};
        typedef std::vector<std::vector<RectInfo>> VecRectInfos;

        // detect
        VecImage image_detect;
        VecRectInfos image_rects;
        VecShellFrame mat_detect;
        std::vector<cv::Rect> rois;

        for (auto& image : images) {
            if (this->Skip(image->count)) {
                continue;
            }
            cv::Rect roi(0, 0, image->sframe->width(), image->sframe->height());
            image_detect.push_back(image);
            mat_detect.push_back(image->sframe);
            rois.push_back(roi);
        }
        int code = -1;
        if(!mat_detect.empty()){
            vest_detector_->ProcessROIs(mat_detect, rois, image_rects, code);
        }
    
        // process detect result
        for (size_t i = 0; i < image_detect.size(); i++) {
            VecBoxF& objects = image_detect[i]->vest_objects;
            const auto& rects = image_rects[i];
            VecBoxF image_boxes;
            for (auto& rect : rects) {
                /*
                * read me:
                * 人体检测模型目前用的是和人头检测同一个模型(head_person_yolov5m_v1.tronmodel)
                * label为0是人头，为1是人体
                * 其实可以和客流的人头检测共用一个detect node
                * 但是保不准以后人头人体检测又分成两个模型了
                */
                if(rect.label==0){
                    continue;
                }
                BoxF box((float)rect.rect.x, (float)rect.rect.y,
                        (float)(rect.rect.x + rect.rect.width),
                        (float)(rect.rect.y + rect.rect.height));
                box.label = VEST_OBJECT_TYPE_PERSON;
                box.score = rect.score;
                image_boxes.push_back(box);
            }
            objects.insert(objects.end(), image_boxes.begin(), image_boxes.end());
        }
    }
    void CAlgReflectiveVestEngine::VestClassifyProcess(const VecImage &images){
        std::unique_lock<std::mutex> lock{vest_attr_lock_};

        VecMat                  mat_attr;
        std::vector<VecBoxF>    images_boxes;
        VecImage                input_images;
        for (auto& image : images) {
            if (this->Skip(image->count)) {
                continue;
            }
            input_images.push_back(image);
            const auto &pic_mat = image->sframe->getMat();
            mat_attr.push_back(pic_mat);
            images_boxes.push_back(image->vest_objects);
        }
        if(!images_boxes.empty()){
            vest_classify_->Predict(mat_attr, &images_boxes);
        }
        
        //遍历每帧
        for(int i=0; i< images_boxes.size(); i++){
            //遍历每帧的每个检测目标
            VecBoxF tmp_vest_objects;
            for(int j=0; j<images_boxes[i].size(); j++){
                //遍历每个目标的每个属性
                BoxF tmp_box;
                bool if_valid_box = false; 
                for(int k=0; k<images_boxes[i][j].attr.size(); k++){
                    auto attri_score = images_boxes[i][j].attr[k].score;
                    if ((k==0) && (attri_score > config_.vest_classify().yellow_silver_rv_classify_score_thresh()) && attri_score>tmp_box.score) {
                        tmp_box = images_boxes[i][j];
                        tmp_box.score = attri_score;
                        tmp_box.label = VEST_OBJECT_YELLOW_SILVER;
                        if_valid_box = true;
                    }
                    else if ((k==1) && (attri_score > config_.vest_classify().orange_yellow_rv_classify_score_thresh())&& attri_score>tmp_box.score) {
                        tmp_box = images_boxes[i][j];
                        tmp_box.score = attri_score;
                        tmp_box.label = VEST_OBJECT_ORANGE_YELLOW;
                        if_valid_box = true;
                    }
                    else if ((k==2) && (attri_score > config_.vest_classify().orange_white_rv_classify_score_thresh())&& attri_score>tmp_box.score) {
                        tmp_box = images_boxes[i][j];
                        tmp_box.score = attri_score;
                        tmp_box.label = VEST_OBJECT_ORANGE_WHITE;
                        if_valid_box = true;
                    }
                    else if ((k==3) && (attri_score > config_.vest_classify().cross_rv_classify_score_thresh())&& attri_score>tmp_box.score) {
                        tmp_box = images_boxes[i][j];
                        tmp_box.score = attri_score;
                        tmp_box.label = VEST_OBJECT_CROSS;
                        if_valid_box = true;
                    }
                    else if ((k==4) && (attri_score > config_.vest_classify().suspected_rv_classify_score_thresh())&& attri_score>tmp_box.score) {
                        tmp_box = images_boxes[i][j];
                        tmp_box.score = attri_score;
                        tmp_box.label = VEST_OBJECT_SUSPECTED;
                        if_valid_box = true;
                    }
                    else if ((k==5) && (attri_score > config_.vest_classify().no_rv_classify_score_thresh())) {
                        tmp_box = images_boxes[i][j];
                        tmp_box.no_vest_attr.score = attri_score;
                        tmp_box.no_vest_attr.type = VEST_OBJECT_NO;
                        if_valid_box = true;
                    }   
                }
                if(if_valid_box){
                    tmp_vest_objects.push_back(tmp_box);
                }
                //input_images[i]->vest_objects[j].score = tmp_box.score;
                //input_images[i]->vest_objects[j].label = label;
            }
            input_images[i]->vest_objects.clear();
            input_images[i]->vest_objects.insert(input_images[i]->vest_objects.end(), tmp_vest_objects.begin(), tmp_vest_objects.end());
        }
    }

    bool CAlgReflectiveVestEngine::Skip(int64_t count) const {
        return count % config_.detect_interval();
    }

    void CAlgReflectiveVestEngine::AddEngineInDsp(const std::string &channel_id, const std::string &engine_name, CFlowDispatch &dsp){
        CFlowDispatch::spNode chin, chout;
        chin = dsp.get_node(channel_id, "in");
        chout = dsp.get_node(channel_id, "out");
        if (!chin || !chout){
            LOG(ERROR) << "AddEngineInDsp fail, channel: "<<channel_id;
            return;
        }
        //处理各个engine
        if(engine_name == REFLECTIVE_VEST){
            auto detect = dsp.get_node(channel_id, "vest-detect");
            if(!detect){
                detect = dsp.add_node(channel_id, "vest-detect", config_.detect_queue_size(), true);
                detect->process([this](VecImage& in){
                    VecImage frames;
                    this->GetBatchFrames(in, frames);
                    if (!frames.empty()) {
                        this->VestDetectProcess(frames);
                    }
                });
            
                CFlowDispatch::spNode attr;
                attr = dsp.add_node(channel_id, "vest-attr", config_.detect_queue_size(), true);
                attr->process([this](VecImage& in) {
                    VecImage frames;
                    this->GetBatchFrames(in, frames);
                    if (!frames.empty()) {
                        this->VestClassifyProcess(frames);
                    }
                });

                chin->next(detect);
                detect->next(attr);
                attr->next(chout);
            }
        }
    }

    void CAlgReflectiveVestEngine::RemoveEngineInDsp(const std::string &channel_id, const std::string &engine_name, CFlowDispatch &dsp){
        if(engine_name==REFLECTIVE_VEST){
            auto detect = dsp.get_node(channel_id, "vest-detect");
            if(!detect){
                dsp.remove_node(channel_id, "vest-detect");
                dsp.remove_node(channel_id, "vest-attr");
            }else{
                LOG(WARNING)<<"RemoveEngineInDsp error in stream "<<channel_id;
            }
        }
    }

    void CAlgReflectiveVestEngine::AddStream(const std::string &channel_id, const std::string &config){
        auto it = map_.find(channel_id);
        if(it!=map_.end()){
            LOG(WARNING)<<"AddStream failed, channel "<<channel_id<<" already exist in map_";
        }else{
            auto channel = map_[channel_id];
        }
    }

    //remove stream时flow_engine里清除所有node, 这里不需要
    void CAlgReflectiveVestEngine::RemoveStream(const std::string &channel_id) {
        auto it = map_.find(channel_id);
        if (it != map_.end()){
            map_.erase(it);
        }else{
            LOG(WARNING)<<"RemoveStream failed, channel "<<channel_id<<" not exist in map_";
        }
    }

    void CAlgReflectiveVestEngine::AddViolation2(const std::string &channel_id,
                                        const std::string &violation_id,
                                        const std::string &config,
                                        CFlowDispatch &dsp) {
        auto root = get_document(config);
        auto violation_code = get_string(root, "code", "");
        auto engine_name = VEST_VIOLATION_MAP.find(violation_code);
        if(engine_name==VEST_VIOLATION_MAP.end()){
            return;
        }
        auto channel = map_.find(channel_id);
        if (channel == map_.end()) {
            LOG(ERROR) << "stream not found, channel id: " << channel_id
                        << ", violation id: " << violation_id;
        }else{
            auto engine = channel->second.find(engine_name->second);
            if (engine == channel->second.end()) {
                (channel->second)[engine_name->second].insert(violation_id);
                AddEngineInDsp(channel_id, engine_name->second, dsp);
            } else {
                engine->second.insert(violation_id);
            }
        }
    }

    void CAlgReflectiveVestEngine::RemoveViolation2(const std::string &channel_id,
                                        const std::string &violation_id,
                                        CFlowDispatch &dsp) {
        auto channel = map_.find(channel_id);
        if(channel==map_.end()){
            LOG(ERROR)<<"stream not found, channel id: "<<channel_id<<", violation id: "<<violation_id;
            return;
        }
        // engine is pair<std::string, std::unordered_set<std::string>>
        for (auto engine = channel->second.begin(); engine != channel->second.end(); engine++){
            auto violation = engine->second.find(violation_id);
            if (violation != engine->second.end()) {
                // find violation
                //如果engine只服务要删除的这一个violation, 删除engine
                if (engine->second.size() == 1) {
                    RemoveEngineInDsp(channel_id, engine->first, dsp);
                    channel->second.erase(engine);
                } else {
                    engine->second.erase(violation);
                }
                return;
            }
        }
    }

    AlgRender CAlgReflectiveVestEngine::GetRender(const std::string &violation_code) const {
        if(violation_code == BUILDING_REFLECTIVE_VEST_CODE){
            return CAlgReflectiveVestEngine::Render;
        }
        return nullptr;
    }

    void CAlgReflectiveVestEngine::Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug){
        const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
        cv::Scalar scalar[6] = {cv::Scalar(0, 255, 255), cv::Scalar(0, 165, 255), cv::Scalar(173, 222, 255), cv::Scalar(0, 255, 0), cv::Scalar(255, 255, 255), cv::Scalar(0, 0, 0)};
        
        for (auto &object : image_objects.vest_objects) {
            float score;
            std::string obj_score_str;
            if(object.no_vest_attr.type == VEST_OBJECT_NO){
                cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                                                cv::Point(object.xmax, object.ymax)*scale, scalar[5], 2);
                score = object.no_vest_attr.score;
            }else{
                score = object.score;
                switch (object.label){
                    case VEST_OBJECT_YELLOW_SILVER:
                        cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                                                cv::Point(object.xmax, object.ymax)*scale, scalar[0], 2);
                        break;
                    case VEST_OBJECT_ORANGE_YELLOW:
                        cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                                                cv::Point(object.xmax, object.ymax)*scale, scalar[1], 2);
                        break;
                    case VEST_OBJECT_ORANGE_WHITE:
                        cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                                                cv::Point(object.xmax, object.ymax)*scale, scalar[2], 2);
                        break;
                    case VEST_OBJECT_CROSS:
                        cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                                                cv::Point(object.xmax, object.ymax)*scale, scalar[3], 2);
                        break;
                    case VEST_OBJECT_SUSPECTED:
                        cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                                                cv::Point(object.xmax, object.ymax)*scale, scalar[4], 2);
                        break;
                }
            }
            obj_score_str = std::to_string(score);
            if(obj_score_str.size()>4){
                obj_score_str = obj_score_str.substr(0, 4);
            }
            cv::putText(*mat, obj_score_str, cv::Point(object.xmin, object.ymax + 10)*scale, cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar[5], 2); 
        }
    }
}  // namespace FLOW
