/*
 * @Author: your name
 * @Date: 2021-03-24 16:16:45
 * @LastEditTime: 2021-03-24 16:27:03
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /analyzer-flow/analyzer/core/alg_engine/alg_engine_factory.cpp
 */
#include <regex>

#include "alg_engine_factory.hpp"

#include "alg_vehicle_engine.hpp"
#include "alg_nonmotor_engine.hpp"
#include "alg_ducha_engine.hpp"
#include "alg_flow_engine.hpp"
#include "alg_events_engine.hpp"
#include "alg_gangwei_engine.hpp"
#include "alg_face_struct_engine.hpp"
#include "alg_person_struct_engine.hpp"
#include "alg_construction_engine.hpp"
#include "alg_shigong_engine.hpp"
#include "alg_safehelmet_engine.hpp"
#include "alg_fall_engine.hpp"
#include "alg_guardrail_engine.hpp"
#include "alg_sharedbike_engine.hpp"
#include "alg_parade_engine.hpp"
#include "alg_reflective_vest_engine.hpp"
#include "alg_trafficlight_engine.hpp"

namespace FLOW {

VecICAlgEngine CreateEngines(const std::string& types) {
    VecICAlgEngine retv;
    std::regex split("\\|");
    std::vector<std::string> v_types(std::sregex_token_iterator(types.begin(), types.end(), split, -1),
                                        std::sregex_token_iterator());
    for (auto type : v_types) {
        if (type == "vehicle" || type == "traffic") {
            retv.push_back(std::make_shared<CAlgVehicleEngine>());
        } else if (type == "nonmotor") {
            retv.push_back(std::make_shared<CAlgNonmotorEngine>());
        } else if (type == "ducha") {
            retv.push_back(std::make_shared<CAlgDuchaEngine>());
        } else if (type == "highway" || type == "events") {
            retv.push_back(std::make_shared<CAlgEventsEngine>());
        } else if (type == "flow") {
            retv.push_back(std::make_shared<CAlgFlowEngine>());
        } else if (type == "face_struct") {
            retv.push_back(std::make_shared<CAlgFaceEngine>());
        } else if (type == "person_struct") {
            retv.push_back(std::make_shared<CAlgPersonEngine>());
        } else if (type == "gangwei") {
            retv.push_back(std::make_shared<CAlgGangweiEngine>());
        } else if (type == "construction") {
            retv.push_back(std::make_shared<CAlgConstructionEngine>());
        } else if (type == "shigong") {
            retv.push_back(std::make_shared<CAlgShigongEngine>());
        } else if (type == "safehelmet") {
            retv.push_back(std::make_shared<CAlgSafehelmetEngine>());
        } else if (type == "fall") {
            retv.push_back(std::make_shared<CAlgFallEngine>());
        } else if (type == "guardrail") {
            retv.push_back(std::make_shared<CAlgGuardrailEngine>());
        }  else if (type == "sharedbike") {
            retv.push_back(std::make_shared<CAlgSharedBikeEngine>());
        }else if (type == "parade") {
            retv.push_back(std::make_shared<CAlgParadeEngine>());
        }else if (type == "reflective_vest") {
            retv.push_back(std::make_shared<CAlgReflectiveVestEngine>());
        } else if (type == "traffic_light") {
            retv.push_back(std::make_shared<CAlgTrafficlightEngine>());
        } else {
            LOG(WARNING) << "engine type:" << type <<", not found !";
        }
    }
    return retv;
}

MapICAlgEngine CreateEngineMap(const std::string& types, VecICAlgEngine engines) {
    MapICAlgEngine retv;
    std::regex split("\\|");
    std::vector<std::string> v_types(std::sregex_token_iterator(types.begin(), types.end(), split, -1),
                                        std::sregex_token_iterator());
    for (int i=0; i<std::min(v_types.size(), engines.size()); i++ ) {
        retv[v_types[i]] = engines[i];
    }
    return retv;
}

} // FLOW