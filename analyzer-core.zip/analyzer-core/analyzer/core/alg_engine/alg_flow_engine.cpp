
#include <vector>
#include <future>

#include "common/io.hpp"
#include "common/pbjson.hpp"
#include "common/util_scale.hpp"
#include "common/freetype/freetype.hpp"

#include "helper.hpp"
#include "alg_flow_engine.hpp"

#include "serving/violation_config.pb.h"

#include "algorithm/detect/detect.hpp"
#include "algorithm/detect/east.hpp"
#include "algorithm/crowd/crowd.hpp"
#include "algorithm/fight/fight_classify.hpp"
#include "algorithm/track/track_wraper.hpp"
#include "algorithm/persontrack/persontracker.hpp"
#include "algorithm/persontrack/bodytracker.hpp"
#include "algorithm/wander_retention/videoreid.hpp"
#include "algorithm/parade/flag_common.hpp"
#include "violation/flow/violation_head_count_in_region.hpp"

namespace FLOW {

    using namespace std;
    using namespace cv;

    std::vector<RectF> getROIFromHeadCountLines(inference::HeadcountLine line ,int scene );

    void CAlgFlowEngine::Init(const inference::EngineConfig &config, int &code) {
        code = FLOW::module_status_success;
        config_ = config.flow();
        std::map<std::string, std::pair<std::string, std::vector<char>>> params;
	
        if (config_.head_on()){
            params["head_detect_model"] = {config_.head_detect().model_path(), {}};
            params["vehicle_model"] = {config_.vehicle_detect().model_path(), {}};
        }

        if (config_.banner_on()){
            params["east_detect_model"] = {config_.east().model_path(), {}};
            params["banner_detect_od_model"] = {config_.banner_detect_od_model().model_path(), {}};
        }

        if (config_.crowd_on()){
            params["crowd_density_model"] = {config_.crowd().model_path(), {}};
        }

        if (config_.fight_on()){
            params["fight_classify_model"] = {config_.fight_classify().model_path(), {}};
        }

        if (config_.retention_on()){
            params["wander_retention_det_model"] = {config_.wander_retention_det().model_path(), {}};
            params["wander_retention_person_quality_model"] = {config_.wander_retention_person_quality().model_path(), {}};
            params["wander_retention_reid_model"] = {config_.wander_retention_reid().model_path(), {}};
        }

        for (auto& kv : params) {
            if (!IO::ReadBinaryFile(kv.second.first, &kv.second.second)) {
                LOG(FATAL) << "Load model " << kv.second.first << " error";
                return;
            }
        }

        if (config_.head_on()){
            Head_detector_ = make_shared<Detect::DetectModule>();
            Head_detector_->Setup(params["head_detect_model"].second, config_.head_detect(), code);
            head_shape_ = Head_detector_->GetInputShapes();

            Vehicle_detector_ = make_shared<Detect::DetectModule>();
            Vehicle_detector_->Setup(params["vehicle_model"].second, config_.vehicle_detect(), code);
	    }

        if (config_.banner_on()){
            East_detector_ = make_shared<Detect::EAST>();
            East_detector_->Setup(params["east_detect_model"].second, config_.east());
	        banner_shape_ = East_detector_->GetInputShapes();
            
            Banner_od_detector_ = make_shared<Detect::DetectModule>();
            Banner_od_detector_->Setup(params["banner_detect_od_model"].second, config_.banner_detect_od_model(), code);
	        banner_od_shape_ = Banner_od_detector_->GetInputShapes();
        }

        if (config_.crowd_on()){	
            Crowd_density_ = make_shared<CrowdDensity::Crowd>(params["crowd_density_model"].second, config_.crowd());
            crowd_shape_ = Crowd_density_->GetInputShapes();
        }

        if (config_.fight_on()){
            Fight_classify_ = std::make_shared<FightClassify::FightClassify>();
            Fight_classify_->Setup(params["fight_classify_model"].second, config_.fight_classify(), code);
	    }

        if (config_.retention_on()){
            Wander_retention_detector_ = make_shared<Detect::DetectModule>();
            Wander_retention_detector_->Setup(params["wander_retention_det_model"].second, config_.wander_retention_det(), code);

            auto& Wander_retetion_videoreid_model_ = WanderRetention::VideoReidModel::get_instance();
            Wander_retetion_videoreid_model_.setup(params["wander_retention_person_quality_model"].second, params["wander_retention_reid_model"].second, config_, code);
        }

        // metric init
        typedef std::map<std::string, std::string> LablesType;
        const prometheus::Summary::Quantiles quantiles{{0.5, 0.05}, {0.9, 0.01}, {0.99, 0.001}};
        profile_metric_head_detector_       = std::make_shared<ProfileMetric>(LablesType{{"engine", "flow"}, {"model", "head"       }}, quantiles);
        profile_metric_east_detector_       = std::make_shared<ProfileMetric>(LablesType{{"engine", "flow"}, {"model", "east"       }}, quantiles);
        profile_metric_banner_od_detector_  = std::make_shared<ProfileMetric>(LablesType{{"engine", "flow"}, {"model", "banner_od"  }}, quantiles);
        profile_metric_crowd_density_       = std::make_shared<ProfileMetric>(LablesType{{"engine", "flow"}, {"model", "crowd"      }}, quantiles);
        profile_metric_fight_classify_      = std::make_shared<ProfileMetric>(LablesType{{"engine", "flow"}, {"model", "fight"      }}, quantiles);
        profile_metric_retention_detector_  = std::make_shared<ProfileMetric>(LablesType{{"engine", "flow"}, {"model", "retention"  }}, quantiles);
    }

    bool CAlgFlowEngine::Skip(int64_t count, int interval) const {
        return count % interval;
    }

    void CAlgFlowEngine::GetBatchFrames(VecImage &queue, VecImage &image_map) const {
        int count = 0;
        image_map.clear();
        for (auto it = queue.begin(); it != queue.end() && count < config_.detect_batch_size(); count++) {
            auto &frame = *it;
            image_map.push_back(frame); 
            it = queue.erase(it);
        }
    }

    void CAlgFlowEngine::Process(CFlowDispatch &dsp) {
        if (!channel_data_update_queue_.empty()) {
            auto udata = channel_data_update_queue_.pop();
            auto& channel_id = udata->channel_id_;
            if (udata->action == 3) { // add violation
                auto channel_data = channel_data_map_.find(channel_id);
                if (!channel_data) return;

                CFlowDispatch::spNode resize, head, east, east_od,banner_resize,fight, fight_avg, density,density_resize,crowd,crowd_fill, retention, retention_track, videoreid, queue_count, crowd_region_count, track, chin, chout;
                chin = dsp.get_node(channel_id, "in");
                chout = dsp.get_node(channel_id, "out");
                if (!chin || !chout) return;
                

                for (auto &code: udata->codes) {
                    if (head_set_.count(code) || std::regex_match(code, std::regex(BUILDING_HEAD_BODY_DETECT_PATTERN_CODE))){
                        if (!spvhp_) spvhp_ = std::make_shared<std::vector<sp_detect_param>>();
                        //head类型violatoin共用一组node
                        resize = dsp.get_node(channel_id, "keliu-head-resize");
                        if (resize) continue;

                        resize = dsp.add_node(channel_id, "keliu-head-resize", config_.detect_queue_size());
                        resize->process([this](VecImage& in) {
                                this->HeadDetectProcess0(in);
                                in.clear();
                            });
                        head = dsp.add_node(channel_id, "keliu-head", config_.detect_queue_size(), true);
                        head->process([this](VecImage& in) {
                                this->HeadDetectProcess1(in);
                                in.clear();
                            });
                        track = dsp.add_node(channel_id, "keliu-track", config_.detect_queue_size()); 
                        track->process([this, channel_data] (VecImage& in) {
                                VecImage frames;
                                this->GetBatchFrames(in, frames);
                                this->trackProcess(channel_data, frames);
                            });
                        chin->next(resize);
                        resize->next(head);
                        head->next(track);
                        track->next(chout);
                    } else if (code == FLOW_BANNER_CODE) { //banner
                        if (!spv_banner_) spv_banner_ = std::make_shared<std::vector<sp_detect_param>>();
                        banner_resize = dsp.get_node(channel_id, "keliu-banner-resize");
                        if (banner_resize) continue;

                        banner_resize = dsp.add_node(channel_id, "keliu-banner-resize", config_.detect_queue_size());
                        banner_resize->process([this](VecImage& in) {
                            this->BannerResizeProcess(in);
                            in.clear();
                        });
                        
                        east = dsp.add_node(channel_id, "keliu-east", config_.detect_queue_size(), true);
                        east->process([this](VecImage& in) {
                            this->EastDetectProcess(in);
                            in.clear();
                        });

                        east_od = dsp.add_node(channel_id, "keliu-east-od", config_.detect_queue_size(), true);
                        east_od->process([this](VecImage& in) {
                            VecImage frames;
                            this->GetBatchFrames(in, frames);
                            this->BannerDetectODProcess(frames);
                        });

                        chin->next(banner_resize);
                        banner_resize->next(east);
                        east->next(east_od);
                        east_od->next(chout);
                    } else if (code == FLOW_FIGHT_CODE) { //fight
                        fight = dsp.get_node(channel_id, "keliu-fight");
                        if (fight) continue;

                        fight = dsp.add_node(channel_id, "keliu-fight", config_.detect_queue_size(), true);
                        fight->process([this](VecImage& in) {
                                VecImage frames;
                                this->GetBatchFrames(in, frames);
                                this->FightProcess(frames);
                            });
                        fight_avg = dsp.add_node(channel_id, "keliu-fight-avg", config_.detect_queue_size(), true);
                        fight_avg->process([this](VecImage& in) {
                                this->FightBufferProcess(in);
                                in.clear();
                            });
                        chin->next(fight);
                        fight->next(fight_avg);
                        fight_avg->next(chout);
                    } else if (code==FLOW_CROWD_CODE || code==BUILDING_CROWD_REGION_EXCEED_CODE || code==FLOW_CROWD_REGION_EXCEED_CODE) { 
                        if (!spv_crowd_) spv_crowd_ = std::make_shared<std::vector<sp_detect_param>>();

                        density_resize = dsp.get_node(channel_id, "keliu-density-resize");
                        if (density_resize) continue;

                        density_resize = dsp.add_node(channel_id, "keliu-density-resize", config_.detect_queue_size());
                        density_resize->process([this](VecImage& in) {
                            this->DensityResizeProcess(in);
                            in.clear();
                        });

                        density = dsp.add_node(channel_id, "keliu-density", config_.detect_queue_size(), true);
                        density->process([this](VecImage& in) {
                            this->DensityProcess(in);
                            in.clear();
                        });

                        channel_data->crowdregion_ = std::make_shared<Crowdcount::crowdregion>(channel_data->crowd_violation_roi_, channel_data->crowd_violation_remove_roi_, channel_data->min_crowd_num_throd_);
                        crowd = dsp.add_node(channel_id, "keliu-crowd", config_.detect_queue_size());
                        crowd->process([this](VecImage& in) {
                            this->CrowdProcess(in);
                            in.clear();
                        });
                        
                        crowd_fill = dsp.add_node(channel_id, "crowd-fill-skipframe", config_.detect_queue_size());
                        auto last_crowd_objects = std::make_shared<ImageObjectsInfo>();
                        last_crowd_objects->channel_id = channel_id;
                        auto checker = [this](const spImageObjectsInfo frame)->bool{ return this->Skip(frame->count, config_.crowd_interval()); };
                        crowd_fill->process([this, checker, last_crowd_objects](VecImage &in) {
                            for (auto image : in) {
                                CAlgFlowEngine::FillSkipframe(checker, last_crowd_objects, image);
                            }
                            in.clear();
                        });

                        chin->next(density_resize);
                        density_resize->next(density);
                        density->next(crowd);
                        crowd->next(crowd_fill);
                        crowd_fill->next(chout);
                    } else if (code==FLOW_RETENTION_CODE) {
                        retention = dsp.add_node(channel_id, "keliu-retention", config_.detect_queue_size(), true);
                        retention->process([this](VecImage& in) {
                            this->WanderRetentionODProcess(in);
                            in.clear();
                        });
                        retention_track = dsp.add_node(channel_id, "keliu-retention-track", config_.detect_queue_size()); 
                        retention_track->process([this, channel_data] (VecImage& in) {
                            this->trackRetentionProcess(channel_data, in);
                            in.clear();
                        });
                        videoreid = dsp.add_node(channel_id, "keliu-videoreid", config_.detect_queue_size(), true); 
                        videoreid->process([this] (VecImage& in) {
                            this->WanderRetentionVideoreidProcess(in);
                            in.clear();
                        });
                        chin->next(retention);
                        retention->next(retention_track);
                        retention_track->next(videoreid);
                        videoreid->next(chout);
                    }
                }
            } else if (udata->action == 4) { // remove violation
                //这里面逻辑写错了, 不过目前也没有单独调remove violation的地方, 就先这样吧
                //所有node在stop stream里拆
                /*
                auto channel_data = channel_data_map_.find(channel_id);
                if (!channel_data) return;
                bool remove_head,remove_crowd = true;

                for (auto &code: udata->codes) {
                    if (head_set_.count(code)){
                        remove_head = false;
                    }else if (code == FLOW_BANNER_CODE) { //banner
                        dsp.remove_node(channel_id, "keliu-east");
                        dsp.remove_node(channel_id, "keliu-east-od");
                    } else if (code == FLOW_FIGHT_CODE) { //fight
                        dsp.remove_node(channel_id, "keliu-fight");
                    }else if (code == FLOW_CROWD_CODE) {
                        dsp.remove_node(channel_id, "keliu-crowd");
                        dsp.remove_node(channel_id, "keliu-density");
                        dsp.remove_node(channel_id, "keliu-density-resize");
                    }
                }
                if (remove_head){
                    dsp.remove_node(channel_id, "keliu-head-resize");
                    dsp.remove_node(channel_id, "keliu-head");
                    dsp.remove_node(channel_id, "keliu-track");
                }
                */
            }
        }
    }

    // fight process
    void CAlgFlowEngine::FightProcess(const VecImage &images) {
        std::unique_lock<std::mutex> lock{fight_lock_};
        VecImage      image_detect;
        VecMat        mat_detect;

        for (auto &image : images) {

            if (this->Skip(image->count, config_.fight_interval()) ) {
                continue;
            }
            auto channel_data = channel_data_map_.find(image->channel_id);
            if (nullptr == channel_data.get()) {
                continue;
            }

            image_detect.push_back(image);
            mat_detect.push_back(image->sframe->getMat());
        }
        int code = -1;
        std::vector<Fight_Event> events;
        {
            ProfileMetric::Helper _metric_helper(*profile_metric_fight_classify_);
            Fight_classify_->Predict(mat_detect, events, code);
        }
        // process fight result
        for (size_t i = 0; i < image_detect.size(); i++) {
	        image_detect[i]->flow_info.fight_event_ = events[i];
        }
    }

    void CAlgFlowEngine::FightBufferProcess(const VecImage &images) {

        for(auto& image: images){
            auto sp_channel_data = channel_data_map_.find(image->channel_id);
            if(sp_channel_data.get()==nullptr){
                continue;
            }
            if(!image->flow_info.fight_event_.if_predicted){
                continue;
            }
            auto& score_buffer_ = sp_channel_data->fight_score_buffer_;

            if (score_buffer_.size() < config_.fight_classify().score_buffer()) {
                score_buffer_.push_back(image->flow_info.fight_event_.predict_score);
            } else {
                score_buffer_.erase(score_buffer_.begin());
                score_buffer_.push_back(image->flow_info.fight_event_.predict_score);
            }
            float avg_score = 0.f;
            for(auto score: score_buffer_){
                avg_score += score;
            }
            avg_score /= (float)score_buffer_.size();
            if(avg_score>config_.fight_classify().detect_threshold()){
                image->flow_info.fight_event_.is_bk_fighting=true;
            }
        }
    }

    void CAlgFlowEngine::CrowdProcess(const VecImage &images) {
        std::unique_lock<std::mutex> lock{crowd_lock_};

        for (auto &image : images) {
            if(image->skip_crowd_status){
                continue;
            }
            auto channel_data = channel_data_map_.find(image->channel_id);
            if (nullptr == channel_data.get()) {
                continue;
            }
            {
                std::vector<cv::Rect> crowd_rect;
                std::vector<int> crow_num;

                auto &densityinfo = image->flow_info.densityinfo_;
                float score_tmp=0;
                auto foreground_mask = channel_data->crowdregion_->crowdregion_process(*(image->sframe->getMat()), densityinfo.density_map,crowd_rect, crow_num, score_tmp);
                densityinfo.score = score_tmp;
                int img_w = channel_data->crowdregion_->getImg_w();
                int img_h = channel_data->crowdregion_->getImg_h();

                std::vector<cv::Rect> crowd_rect2;
                for (int i = 0; i < crowd_rect.size(); i++)
                {
                    cv::Rect temp;
                    temp.x = (float)crowd_rect[i].x / img_w * image->sframe->width();
                    temp.width = (float)crowd_rect[i].width / img_w * image->sframe->width();
                    temp.y = (float)crowd_rect[i].y / img_h * image->sframe->height();
                    temp.height = (float)crowd_rect[i].height / img_h * image->sframe->height();
                    crowd_rect2.push_back(temp);
                }
                densityinfo.crowd_rect = std::move(crowd_rect2);
                densityinfo.crowd_num = std::move(crow_num);
                densityinfo.foreground_mask = std::move(foreground_mask);
            }
        }
    }

    // density process
    void CAlgFlowEngine::DensityProcess(const VecImage &images) {
        sp_detect_param dp;
        {
            std::unique_lock<std::mutex> lock{density_lock_};
            if (spv_crowd_->size() == 0) return;
            dp = spv_crowd_->front();
            spv_crowd_->erase(spv_crowd_->begin());
        }

        Profiler profiler_density;
        profiler_density.tic("Density Process");

        int code = -1;
        std::vector<VecFloat> probs;
        std::vector<VecInt> prob_shapes;
        std::vector<cv::Mat> images_result;
        // Crowd_density_->BatchPredict(dp->mat_detect, &probs, &prob_shapes);
        {
            ProfileMetric::Helper _metric_helper(*profile_metric_crowd_density_);
            Crowd_density_->BatchPredict(dp->mat_detect, images_result);
        }

        // process density result
        for (size_t i = 0; i < dp->image_detect.size(); i++) {
            DensityInfo &densityinfo = dp->image_detect[i]->flow_info.densityinfo_;
            // densityinfo.prob = probs.at(i);
            // densityinfo.prob_shape = prob_shapes.at(i);
            densityinfo.density_map = std::move(images_result.at(i));
            /*
                for (int h=0;h<densityinfo.density_map.rows;h++){
                    float *row_data = densityinfo.density_map.ptr<float>(h);
                    for (int w=0;w<densityinfo.density_map.cols;w++){
                        int index = h*densityinfo.density_map.cols+w;
                        POINT point;
                        point.x = w;
                        point.y = h;
                        
                        if ((row_data[w]/100.0)>0.0005f){
                            row_data[w] = 0.f;
                        }
                    }
                }
            */
        }
        profiler_density.toc("Density Process");
//        LOG(INFO) << profiler_density.get_stats_str();
    }


    // banner East process
    void CAlgFlowEngine::EastDetectProcess(const VecImage &images) {
        // std::unique_lock<std::mutex> lock{banner_lock_};
        sp_detect_param hp;
        {
            std::unique_lock<std::mutex> lock{banner_lock_};
            if (spv_banner_->size() == 0) return;
            hp = spv_banner_->front();
            spv_banner_->erase(spv_banner_->begin());
        }

        Profiler profiler_banner;
        profiler_banner.tic("Banner Process");

        std::vector<std::vector<PolygonF>> gpolygons;

        Profiler profiler;
        profiler.tic("$$$$ Banner BatchPredict");
        {
            ProfileMetric::Helper _metric_helper(*profile_metric_east_detector_);
            East_detector_->BatchPredict(hp->mat_detect, &gpolygons);
        }
        profiler.toc("$$$$ Banner BatchPredict");
        //LOG(INFO) << profiler.get_stats_str();

        for (size_t i = 0; i < hp->image_detect.size(); i++) {
            VecBoxF image_boxes2;
            const auto& sframe = hp->image_detect[i]->sframe;

            bool rs = (banner_shape_.size() >= 4);

            for(auto polygon : gpolygons[i]) {
                if(polygon.score<=config_.east().detect_threshold()){
                    continue;
                }
                
                BoxF box = polygon.box();

                box.xmin = (rs && banner_shape_[3] > 0) ? (int)(box.xmin * (1.0 * sframe->width() / banner_shape_[3])) : (float)box.xmin;
                box.ymin =(rs && banner_shape_[2] > 0) ? (int)(box.ymin * (1.0 * sframe->height() / banner_shape_[2])) : (float)box.ymin;
                box.xmax = (rs && banner_shape_[3] > 0) ? (int)(box.xmax * (1.0 * sframe->width() / banner_shape_[3])) : (float)box.xmax;
                box.ymax = (rs && banner_shape_[2] > 0) ? (int)(box.ymax * (1.0 * sframe->height() / banner_shape_[2])) : (float)box.ymax;
                
                box.label = OBJECT_TYPE_BANNER;
                image_boxes2.push_back(box);
            }

            VecBoxF &bannerObjects  = hp->image_detect[i]->flow_info.bannerinfo_.bannerobjects_;
            //images_boxes.push_back(std::move(image_boxes2));
            bannerObjects.insert(bannerObjects.end(), image_boxes2.begin(), image_boxes2.end());
        }
        profiler_banner.toc("Banner Process");
        //LOG(INFO) << profiler_banner.get_stats_str();
    }


    // banner od process
    void CAlgFlowEngine::BannerDetectODProcess(const VecImage &images) {
        std::unique_lock<std::mutex> lock{banner_od_lock_};
        Profiler profiler_banner_od;
        profiler_banner_od.tic("Banner detect od Process");

        typedef vector<vector<RectInfo>> VecRectInfos;
        typedef std::function<bool(int)> TypeFilter;
        // detect
        VecImage      image_detect;
        VecRectInfos  image_rects;
        VecShellFrame mat_detect;
        std::vector<cv::Rect> rois;
        std::vector<TypeFilter> det_types;
	//std::vector<cv::Mat> im_mats;

        for (auto &image : images) {
            //image->east_processed = true;
            if (this->Skip(image->count, config_.banner_interval()) /*|| !(image->type & TYPE_EAST) || image->enable_banner == false*/) {
                continue;
            }
            auto channel_data = channel_data_map_.find(image->channel_id);
            if (nullptr == channel_data.get()) {
                continue;
            }
            //only images with banner should be detected 
            if(image->flow_info.bannerinfo_.bannerobjects_.size() == 0){
               continue;
            }
            const auto &pic_mat = image->sframe->getMat();
            cv::Rect roi;
            if (channel_data->detect_roi_) {
                const auto& detect_roi = *(channel_data->detect_roi_);
                roi = cv::Rect(detect_roi.x,detect_roi.y, detect_roi.w,detect_roi.h);
            } else {
                roi = cv::Rect(0, 0, image->sframe->width(), image->sframe->height());
            }

	    //im_mats.push_back(*pic_mat);
            image_detect.push_back(image);
            mat_detect.push_back(image->sframe);
            rois.push_back(roi);
            det_types.push_back([](int type) -> bool { return true; });

        }
        if (image_detect.size() > 0 ){  
            int code = -1;

            Profiler profiler;
            profiler.tic("$$$$ Banner detect od BatchPredict");
            {
                ProfileMetric::Helper _metric_helper(*profile_metric_banner_od_detector_);
                Banner_od_detector_->ProcessROIs(mat_detect, rois, image_rects, code);
            }
            profiler.toc("$$$$ Banner detect od BatchPredict");
            LOG(INFO) << profiler.get_stats_str();

            // process banner  detect od result
            // process detect result
            for (size_t i = 0; i < image_detect.size(); i++) {
                VecBoxF &objects  = image_detect[i]->objects;
                const auto &rects = image_rects[i];
                VecBoxF image_boxes;
                for (auto &rect : rects) {
                    if (det_types[i](rect.label)) {
                        BoxF box((float)rect.rect.x, (float)rect.rect.y,
                                    (float)(rect.rect.x + rect.rect.width),
                                    (float)(rect.rect.y + rect.rect.height));
                        box.label = rect.label;//todo check
                        // box.label = OBJECT_TYPE_HEAD;
                        box.score = rect.score;
                        image_boxes.push_back(box);
                    }
                }
                objects.insert(objects.end(), image_boxes.begin(), image_boxes.end());
            }
        }else{
            //LOG(INFO) << "no banner detected in these images";
        }
        profiler_banner_od.toc("Banner detect od Process");
        //LOG(INFO) << profiler_banner_od.get_stats_str();
    }

    void CAlgFlowEngine::HeadDetectProcess0(const VecImage &images) {
        sp_detect_param hp = std::make_shared<detect_param>();
        for (auto &image : images) {
	        image->bool_head_exception = true;
            if (this->Skip(image->count, config_.head_interval())) continue;
            auto channel_data = channel_data_map_.find(image->channel_id);
            if (nullptr == channel_data || !channel_data) continue;
            
            const auto &sframe = image->sframe;
            if (channel_data->detect_roi_list_.size() > 0 ) {
                for (int j=0;j<channel_data->detect_roi_list_.size();j++){
                    const auto& detect_roi = channel_data->detect_roi_list_[j];
                    //checker border 
                    int w = (detect_roi.x + detect_roi.w > sframe->width()) ? sframe->width() - detect_roi.x : detect_roi.w ;
                    int h = (detect_roi.y + detect_roi.h > sframe->height()) ? sframe->height() - detect_roi.y : detect_roi.h ;

                    hp->image_detect.push_back(image);
                    hp->mat_detect.push_back(sframe->getMat());
                    hp->shell_frame_detect.push_back(image->sframe);
                    hp->rois.push_back(cv::Rect(detect_roi.x, detect_roi.y, w, h));
                    //目前用的这个检人头人体的模型，人头是0人体是1
                    hp->det_types.push_back([](int type) -> bool {return (type==0);});
                }
            } else {
                hp->image_detect.push_back(image);
                hp->mat_detect.push_back(sframe->getMat());
                hp->shell_frame_detect.push_back(image->sframe);
                hp->rois.push_back(cv::Rect(0, 0, sframe->width(), sframe->height()));
                //目前用的这个检人头人体的模型，人头是0人体是1
                hp->det_types.push_back([](int type) -> bool { return (type==0); });
            }
        }

        {
            std::unique_lock<std::mutex> lock{head_lock_};
            if (spvhp_->size() == 0) {
                spvhp_->push_back(hp);
            } else {
                auto &s = spvhp_->front();
                s->image_detect.insert(s->image_detect.end(), hp->image_detect.begin(), hp->image_detect.end());
                s->mat_detect.insert(s->mat_detect.end(), hp->mat_detect.begin(), hp->mat_detect.end());
                s->shell_frame_detect.insert(s->shell_frame_detect.end(), hp->shell_frame_detect.begin(), hp->shell_frame_detect.end());
                s->rois.insert(s->rois.end(), hp->rois.begin(), hp->rois.end());
                s->det_types.insert(s->det_types.end(), hp->det_types.begin(), hp->det_types.end());
            }
        }
    }

    void CAlgFlowEngine::ImageResizeProcess(const VecImage &images,const vector<RectF>  &detect_roi_list,const VecInt &shape,const int interval,sp_detect_param dp) {
        for (auto &image : images) {
            if (this->Skip(image->count, interval)) continue;
            auto channel_data = channel_data_map_.find(image->channel_id);
            if (nullptr == channel_data || !channel_data) continue;
            
            const auto &sframe = image->sframe;
            if (detect_roi_list.size() > 0 ) {
                for (int j=0;j<detect_roi_list.size();j++){
                    const auto& detect_roi = detect_roi_list[j];
                    //checker border 
                    int w = (detect_roi.x + detect_roi.w > sframe->width()) ? sframe->width() - detect_roi.x -1 : detect_roi.w ;
                    int h = (detect_roi.y + detect_roi.h > sframe->height()) ? sframe->height() - detect_roi.y - 1 :detect_roi.h ;
                    //LOG(INFO)<< "head count detect roi: x:"<< detect_roi.x<<  " y:" << detect_roi.y<<  " w:" << detect_roi.w<<  " h:" << detect_roi.h;

                    cv::Rect roi = cv::Rect(detect_roi.x,detect_roi.y, w,h);
                    std::shared_ptr<cv::Mat> im_resize = sframe->getMat();
                    if (shape.size() >= 4 && (shape[3] != w || shape[2] != h)) {
                        im_resize = std::make_shared<cv::Mat>();
                        cv::resize((*sframe->getMat())(roi), *im_resize, cv::Size(shape[3], shape[2]));
                        roi = cv::Rect(0, 0, shape[3], shape[2]);
                    }

                    dp->image_detect.push_back(image);
                    dp->mat_detect.push_back(im_resize);
                    dp->shell_frame_detect.push_back(image->sframe);
                    dp->rois.push_back(roi);
                    dp->det_types.push_back([](int type) -> bool { return true; });
                }
            } else {
                cv::Rect roi = cv::Rect(0, 0, sframe->width(), sframe->height());
                std::shared_ptr<cv::Mat> im_resize = sframe->getMat();
                if (shape.size() >= 4 && (shape[2] != sframe->height() || shape[3] != sframe->width())) {
                    im_resize = std::make_shared<cv::Mat>();
                    cv::resize(*sframe->getMat(), *im_resize, cv::Size(shape[3], shape[2]));
                    roi = cv::Rect(0, 0, shape[3], shape[2]);
                }

                dp->image_detect.push_back(image);
                dp->mat_detect.push_back(im_resize);
                dp->shell_frame_detect.push_back(image->sframe);
                dp->rois.push_back(roi);
                dp->det_types.push_back([](int type) -> bool { return true; });
            }
        }

    }

    void CAlgFlowEngine::DensityResizeProcess(const VecImage &images){
        Profiler profiler;
        profiler.tic("DensityResizeProcess");

        for (auto &image : images) {
            if (this->Skip(image->count, config_.crowd_interval())) image->skip_crowd_status = true; 
        }
        auto dp = std::make_shared<detect_param>();
        this->ImageResizeProcess(images,vector<RectF>{},crowd_shape_, config_.crowd_interval(),dp);
             
        std::unique_lock<std::mutex> lock{density_lock_};
        if (spv_crowd_->size() == 0) {
            spv_crowd_->push_back(dp);
        } else {
            auto &s = spv_crowd_->front();
            s->image_detect.insert(s->image_detect.end(), dp->image_detect.begin(), dp->image_detect.end());
            s->mat_detect.insert(s->mat_detect.end(), dp->mat_detect.begin(), dp->mat_detect.end());
            s->shell_frame_detect.insert(s->shell_frame_detect.end(), dp->shell_frame_detect.begin(), dp->shell_frame_detect.end());
            s->rois.insert(s->rois.end(), dp->rois.begin(), dp->rois.end());
            s->det_types.insert(s->det_types.end(), dp->det_types.begin(), dp->det_types.end());
        }
        profiler.toc("DensityResizeProcess");
//        LOG(INFO) << profiler.get_stats_str();
    }

    void CAlgFlowEngine::BannerResizeProcess(const VecImage &images){
        Profiler profiler;
        profiler.tic("BannerResizeProcess");

        auto dp = std::make_shared<detect_param>();
        this->ImageResizeProcess(images,vector<RectF>{},banner_shape_,config_.banner_interval(),dp);
            
        std::unique_lock<std::mutex> lock{banner_lock_};
        if (spv_banner_->size() == 0) {
            spv_banner_->push_back(dp);
        } else {
            auto &s = spv_banner_->front();
            s->image_detect.insert(s->image_detect.end(), dp->image_detect.begin(), dp->image_detect.end());
            s->mat_detect.insert(s->mat_detect.end(), dp->mat_detect.begin(), dp->mat_detect.end());
            s->shell_frame_detect.insert(s->shell_frame_detect.end(), dp->shell_frame_detect.begin(), dp->shell_frame_detect.end());
            s->rois.insert(s->rois.end(), dp->rois.begin(), dp->rois.end());
            s->det_types.insert(s->det_types.end(), dp->det_types.begin(), dp->det_types.end());
        }
    
        profiler.toc("BannerResizeProcess");
        //LOG(INFO) << profiler.get_stats_str();
    }

    // head detection process
    void CAlgFlowEngine::HeadDetectProcess1(const VecImage &images) {
        sp_detect_param hp;
        {
            std::unique_lock<std::mutex> lock{head_lock_};
            if (spvhp_->size() == 0) return;
            hp = spvhp_->front();
            spvhp_->erase(spvhp_->begin());
        }

        int code = FLOW::module_status_skip;

        {
            ProfileMetric::Helper _metric_helper(*profile_metric_head_detector_);
            Head_detector_->ProcessROIs(hp->shell_frame_detect, hp->rois, hp->image_rects, code);
        }
        VecRectInfos  image_rects;
        spChannelData channel_data;
        bool enable_vehicle_filter = false;
        if(!images.empty()){
            channel_data = channel_data_map_.find(images[0]->channel_id);
        }

        if (channel_data){
            if(channel_data->enable_vehicle_detect){
                enable_vehicle_filter = true;
                Vehicle_detector_->ProcessROIs(hp->shell_frame_detect, hp->rois, image_rects, code);
            }else{

            }
        }else{
            LOG(ERROR)<<"channel data not found";
        } 
        // process detect result
        for (size_t i = 0; i < hp->image_detect.size(); i++) {
            VecBoxF &objects  = hp->image_detect[i]->keliu_objects;
            VecBoxF &safe_objs  = hp->image_detect[i]->safehelmet_v3_objects;
            const auto &rects = hp->image_rects[i];
            VecBoxF image_boxes;
            VecBoxF image_safe_boxes;
            image_boxes.clear();
            image_safe_boxes.clear();
            for (auto &rect : rects) {
                if(enable_vehicle_filter){
                    bool head_in_car = false;
                    for(auto& car_rect: image_rects[i]){
                        if(car_rect.label!=OBJECT_TYPE_VEHICLE){
                            continue;
                        }
                        if(IOU(car_rect.rect, rect.rect)>0.8){
                            head_in_car = true;
                            LOG(INFO)<<"head in car!";
                            break;
                        }
                    }
                    if(head_in_car){
                        continue;
                    }
                }
                if (hp->det_types[i](rect.label)) {
                    BoxF box( (float)rect.rect.x, 
                              (float)rect.rect.y,
                              (float)(rect.rect.x + rect.rect.width),
                              (float)(rect.rect.y + rect.rect.height) );
                    //box.label = rect.label;
		            box.label = OBJECT_TYPE_HEAD;
                    box.score = rect.score;
                    image_boxes.push_back(box);
                }
                //给晓辉的工地安全帽人工审查做的，以后删掉
                BoxF safe_box( (float)rect.rect.x, 
                            (float)rect.rect.y,
                            (float)(rect.rect.x + rect.rect.width),
                            (float)(rect.rect.y + rect.rect.height) );
                //这里如果换模型要改
                if(rect.label==0){
                    safe_box.label = OBJECT_TYPE_HEAD;
                }else if(rect.label==1){
                    safe_box.label = OBJECT_TYPE_PERSON;
                }else{
                    LOG(WARNING)<<"================> what's this??? <==============";
                }
                safe_box.score = rect.score;
                image_safe_boxes.push_back(safe_box);
            }
            objects.insert(objects.end(), image_boxes.begin(), image_boxes.end());
            safe_objs.insert(safe_objs.end(), image_safe_boxes.begin(), image_safe_boxes.end());
        }
    }

    void CAlgFlowEngine::WanderRetentionODProcess(const VecImage &images) {
        //todo box.label = OBJECT_TYPE_PERSON, 防止冲突
        //LOG(WARNING)<<"WanderRetentionODProcess begin";
        std::unique_lock<std::mutex> lock{retention_od_lock_};
        typedef vector<vector<RectInfo>> VecRectInfos;
        typedef std::function<bool(int)> TypeFilter;
        // detect
        VecImage      image_detect;
        VecRectInfos  image_rects;
        VecShellFrame mat_detect;
        std::vector<cv::Rect> rois;
        std::vector<TypeFilter> det_types;
        //LOG(WARNING)<<"    images size: "<<images.size();
        for (auto &image : images) {
            if (this->Skip(image->count, config_.wander_retention_interval() ) ) {
                //LOG(WARNING)<<"         skip for interval";
                continue;
            }
            auto channel_data = channel_data_map_.find(image->channel_id);
            if (nullptr == channel_data.get()) {
                //LOG(WARNING)<<"         skip for no channel data";
                continue;
            }

            cv::Rect roi;
            if (channel_data->detect_roi_) {
                const auto& detect_roi = *(channel_data->detect_roi_);
                roi = cv::Rect(detect_roi.x,detect_roi.y, detect_roi.w,detect_roi.h);
            } else {
                roi = cv::Rect(0, 0, image->sframe->width(), image->sframe->height());
            }

            image_detect.push_back(image);
            mat_detect.push_back(image->sframe);
            rois.push_back(roi);
            det_types.push_back([](int type) -> bool { return true; });

        }
        if (image_detect.size() > 0 ){
            int code = -1;

            {
                Wander_retention_detector_->ProcessROIs(mat_detect, rois, image_rects, code);
            }

            // process wander retention detect od result
            // process detect result
            for (size_t i = 0; i < image_detect.size(); i++) {
                VecBoxF &objects  = image_detect[i]->objects;
                const auto &rects = image_rects[i];
                VecBoxF image_boxes;
                for (auto &rect : rects) {
                    if (det_types[i](rect.label)) {
                        BoxF box((float)rect.rect.x, (float)rect.rect.y,
                                    (float)(rect.rect.x + rect.rect.width),
                                    (float)(rect.rect.y + rect.rect.height));
                        
                        if(rect.label != OBJECT_TYPE_PERSON){
                            continue;
                        }
                        box.label = OBJECT_TYPE_PERSON;
                        box.score = rect.score;
                        image_boxes.push_back(box);
                    }
                }
                //LOG(WARNING)<<"             image "<<i<<", box size: "<<image_boxes.size();
                objects.insert(objects.end(), image_boxes.begin(), image_boxes.end());
            }
        }else{
            LOG(INFO) << "no Wander Retention detected in these images";
        }
        //LOG(WARNING)<<"WanderRetentionODProcess end";
    }

    void CAlgFlowEngine::WanderRetentionVideoreidProcess(const VecImage &images) {
        //convert box
        //LOG(WARNING)<<"WanderRetentionVideoreidProcess begin";
        for (auto &image : images) {
            auto& channel_id = image->channel_id;
            auto channel_data = channel_data_map_.find(channel_id);
            if(nullptr == channel_data.get()){
                continue;
            }
            float WIDTH = image->sframe->width();
            float HEIGHT = image->sframe->height();
            std::vector<struct FLOW::WanderRetention::TracketBox> track_reuslt_;
            for (const auto &box : image->objects)
            {
                struct FLOW::WanderRetention::TracketBox t_box;
                float x = box.xmin;
                float y = box.ymin;
                float w = box.xmax - x;
                float h = box.ymax - y;
                struct FLOW::WanderRetention::Rect_t rect;
                /*
                rect.x = std::min(std::max(x / WIDTH, 0.f), 1.f);
                rect.y = std::min(std::max(y / HEIGHT, 0.f), 1.f);
                rect.w = std::min(std::max(w / WIDTH, 0.f), 1.f - rect.x);
                rect.h = std::min(std::max(h / HEIGHT, 0.f), 1.f - rect.y);
                */
                rect.x = x;
                rect.y = y;
                rect.w = w;
                rect.h = h;
                t_box.id = box.uid;
                t_box.rect = rect;
                t_box.valid = box.violate_type;
                t_box.label = box.label;
                track_reuslt_.push_back(t_box);
            }
            //LOG(WARNING)<<"     track_reuslt_ size"<<track_reuslt_.size();
            channel_data->Wander_retetion_videoreid_->process(*image->sframe->getMat(), track_reuslt_, OBJECT_TYPE_PERSON);

            // save result into retention info
            for (auto &track_box : track_reuslt_) {
                BoxF retention_box;
                retention_box.xmin = track_box.rect.x;
                retention_box.ymin = track_box.rect.y;
                retention_box.xmax = track_box.rect.x + track_box.rect.w;
                retention_box.ymax = track_box.rect.y + track_box.rect.h;
                retention_box.uid = track_box.id;
                //LOG(WARNING)<<"           xywh: "<<retention_box.xmin<<" "<<retention_box.ymin<<" "<<retention_box.xmax<<" "<<retention_box.ymax;
                image->flow_info.retentioninfo_.retentionobjects_.push_back(retention_box);
            }
            //LOG(WARNING)<<"     retentionobjects_ size"<<image->flow_info.retentioninfo_.retentionobjects_.size();
        }
        //LOG(WARNING)<<"WanderRetentionVideoreidProcess end";
    }

    void CAlgFlowEngine::HeadDetectProcess(const VecImage &images) {
    }

    void CAlgFlowEngine::trackProcess(spChannelData channel, const VecImage &images) {
        int code = -1;
        for( auto image : images){
            if (!this->Skip(image->count, config_.head_interval())) {
                channel->tracker_->Process(*(image->sframe->getMat()),image->keliu_objects, *(channel->last_image_), code);
                channel->last_image_ = image;
            } else {
                image->keliu_objects  = channel->last_image_->keliu_objects;
            }
        }
    }

    void CAlgFlowEngine::trackRetentionProcess(spChannelData channel, const VecImage &images) {
        int code = -1;
        for( auto image : images){
            if (!this->Skip(image->count, config_.wander_retention_interval())) {
                channel->body_tracker_->Process(*(image->sframe->getMat()),image->objects, *(channel->last_image_), code);
                channel->last_image_ = image;
            } else {
                image->objects  = channel->last_image_->objects;
            }
        }
    }


    void CAlgFlowEngine::AddStream(const std::string &channel_id, const std::string &config) {
        int code = 0;
        auto channel_data = channel_data_map_.find(channel_id);
        if ( nullptr == channel_data.get()) {
            channel_data = std::make_shared<ChannelData>();
            channel_data->last_image_ = std::make_shared<ImageObjectsInfo>();
            // auto tracker_ptr = make_shared<Track::TADTracker>();
            auto tracker_ptr = make_shared<PersonTracker::PersonTracker>();
            auto body_tracker_ptr = make_shared<BodyTracker::BodyTracker>();
            channel_data->Wander_retetion_videoreid_ = make_shared<WanderRetention::VideoReid>();
            channel_data->Wander_retetion_videoreid_->setup(config_, channel_id);
            LOG(INFO) << "New tracker with "<<channel_id;
            // tracker_ptr->Setup(config_str_, config, config_.gpu_id, code);
            // CHECK(0 == code);
            channel_data->tracker_ = tracker_ptr;
            channel_data->body_tracker_ = body_tracker_ptr;
            channel_data_map_.insert(channel_id, channel_data);
        }
    }

    void CAlgFlowEngine::RemoveStream(const std::string &channel_id) {
        channel_data_map_.erase(channel_id);
    }
    //需要参照vehicle里面改一下
    void CAlgFlowEngine::AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config) {
        //todo 保存detect_roi_
        auto channel_data = channel_data_map_.find(channel_id);
        if (channel_data) {
            string roi_cfg;
            std::vector<RectF> head_rois;
            std::vector<std::vector<float>> crowd_violation_roi;

            {
                auto data = std::make_shared<inference::MassiveflowViolationConfig>();                
                string err;
                json2pb(config, data.get(), &err);

                if (data->code() == FLOW_HEADCOUNT_CODE || data->code() == FLOW_OVERFENCE_CODE ||  data->code() == FLOW_RETROGRADE_CODE || data->code()==FLOW_CROSS_LINE_CODE) {
                    for ( int i=0;i< data->lines_size();i++){
                        std::vector<RectF> roi_tmp =  getROIFromHeadCountLines(data->lines(i) ,data->headcount_scene() ) ;
                        head_rois.insert(head_rois.end(),roi_tmp.begin(),roi_tmp.end());
                    }   
                }
                if (data->code() == FLOW_CROWD_CODE || data->code() == BUILDING_CROWD_REGION_EXCEED_CODE || data->code() == FLOW_CROWD_REGION_EXCEED_CODE){
                    for (int i = 0; i < data->roi_size(); i++)
                    {
                        std::vector<float> tmp;
                        for (int j = 0; j < data->roi(i).data_size(); j++)
                        {
                            tmp.push_back(data->roi(i).data(j));
                        }
                        crowd_violation_roi.push_back(tmp);
                    }
                    channel_data->min_crowd_num_throd_ = data->min_num_threshold();
                    channel_data->crowd_violation_roi_.swap(crowd_violation_roi);
                }
                //只设置，不删除。
                channel_data->enable_vehicle_detect = data->enable_vehicle_detect();
                LOG(WARNING)<<"======> enable_vehicle_detect "<<channel_data->enable_vehicle_detect<<", channelid "<<channel_id;
                channelId_violations_[channel_id].push_back(data->code());

                auto vdata = std::make_shared<ChannelData>();
                auto chs = channelId_violations_[channel_id];
                vdata->channel_id_ = channel_id;
                vdata->action = 3;
                vdata->codes.insert(data->code());
                channel_data_update_queue_.push(vdata);

                std::map<std::string, std::string> channelId_violation_temp;
                channelId_violation_temp[channel_id] = data->code();
                violationId_map_[violation_id] = channelId_violation_temp;

            }
            // channel_data->tracker_->AddStreamRoiConfig(violation_id, roi_cfg);
            // channel_data->tracker_->AddStreamTrackingType(violation_id, config);
            channel_data->detect_roi_list_.swap(head_rois);
        }else{
            //先加行log算了。
            LOG(ERROR)<<"!!!! ========> add violation faile, please fix me <======  !!!";
        }
    }

    void CAlgFlowEngine::RemoveViolation(const std::string &channel_id, const std::string &violation_id) {
        auto channel_data = channel_data_map_.find(channel_id);
        if (channel_data) {
            // channel_data->tracker_->RemoveStreamRoiConfig(violation_id);

            std::map<std::string, std::string> tempMap = violationId_map_[violation_id];
            std::map<std::string, std::string>::iterator iter;
            for (iter = tempMap.begin(); iter != tempMap.end(); iter++) {
                auto &channelId_violations = channelId_violations_[iter->first];
                // delete violation code from stream channel id, to avoid engine cal
                channelId_violations.erase(remove(channelId_violations.begin(), channelId_violations.end(), iter->second), channelId_violations.end());
            }
            violationId_map_.erase(violation_id);

            auto vdata = std::make_shared<ChannelData>();
            vdata->channel_id_ = channel_id;
            vdata->action = 4;
            vdata->codes.insert(violation_id);
            channel_data_update_queue_.push(vdata);
        }
    }

    //针对大场景和特殊场景需要
    std::vector<RectF> getROIFromHeadCountLines(inference::HeadcountLine headcountLine ,int scene ){
        //todo 需要改
        std::vector<RectF> rects;
        std::vector<int> line_v;

        for (int j = 0; j < headcountLine.line_size(); j++)
        {
            line_v.push_back(headcountLine.line(j));
        }
        if (line_v.size()!=4){
            LOG(ERROR)<< "line len error";
            return rects;
        }

        if (scene == 1 ){

            int roi_l = line_v[0]>line_v[2]?line_v[2]:line_v[0];
            int roi_r = line_v[0]<line_v[2]?line_v[2]:line_v[0];
            int roi_w = roi_r-roi_l;
            int roi_t = line_v[1]>line_v[3]?line_v[3]:line_v[1];
            int roi_b = line_v[1]<line_v[3]?line_v[3]:line_v[1];
            int roi_h = roi_b-roi_t;
            int center_x = (line_v[0]+line_v[2])/2;
            int center_y = (line_v[1]+line_v[3])/2;

            if (roi_w > roi_h){
                roi_t = (center_y-roi_w/2)>=0?(center_y-roi_w/2):0;
                // roi_b = (center_y+roi_w/2)<im_mat.rows?(center_y+roi_w/2):im_mat.rows-1;
                roi_b = center_y+roi_w/2;
                roi_h = roi_b-roi_t;

            }else{
                roi_l = center_x-roi_h/2>=0?center_x-roi_h/2:0;
                // roi_r = center_x+roi_h/2<im_mat.cols?center_x+roi_h/2:im_mat.cols-1;
                roi_r = center_x+roi_h/2;
                roi_w = roi_r-roi_l;
            }
            RectF cut_rect;
            cut_rect.w =roi_w;
            cut_rect.h =roi_h;

            cut_rect.x =roi_l;
            cut_rect.y =roi_t;

            rects.push_back(cut_rect);

        } else if (scene == 2){
            int roi_l = line_v[0]>line_v[2]?line_v[2]:line_v[0];
            int roi_r = line_v[0]<line_v[2]?line_v[2]:line_v[0];
            int roi_w = (int) ((roi_r-roi_l)/2);
            int roi_t = line_v[1]>line_v[3]?line_v[3]:line_v[1];
            int roi_b = line_v[1]<line_v[3]?line_v[3]:line_v[1];
            int roi_h = (int) ((roi_b-roi_t)/2);


            int center_x = (line_v[0]+line_v[2])/2;
            int center_y = (line_v[1]+line_v[3])/2;
            int roi_l1, roi_t1, roi_l2, roi_t2;

            if (roi_w > roi_h){
                roi_t1 = center_y-roi_w/2>=0?center_y-roi_w/2:0;
                roi_t2 = roi_t1;
                // int roi_b_temp = center_y+roi_w/2<im_mat.rows?center_y+roi_w/2:(im_mat.rows-1);
                int roi_b_temp = center_y+roi_w/2;
                roi_h = roi_b_temp - roi_t1;
                roi_l1 = roi_l;
                // roi_l2 = (roi_l+roi_w)<im_mat.cols?(roi_l+roi_w):(im_mat.cols-1);
                roi_l2 = roi_l+roi_w ;
            }else{
                roi_l1 = center_x-roi_h/2>=0?center_x-roi_h/2:0;
                roi_l2 = roi_l1;
                // int roi_r_temp = center_x+roi_h/2<im_mat.cols?center_x+roi_h/2:(im_mat.cols-1);
                int roi_r_temp = center_x+roi_h/2;
                roi_w = roi_r_temp - roi_l1;
                roi_t1 = roi_t;
                // roi_t2 = (roi_t+roi_h)<im_mat.cols?(roi_t+roi_h):(im_mat.rows-1);
                roi_t2 = roi_t+roi_h;
            }

            RectF cut_rect;
            cut_rect.w =roi_w;
            cut_rect.h =roi_h;

            cut_rect.x =roi_l1;
            cut_rect.y =roi_t1;
            rects.push_back(cut_rect);

            cut_rect.x =roi_l2;
            cut_rect.y =roi_t2;
            rects.push_back(cut_rect);
        }


        return std::move(rects);
    }

    AlgRender CAlgFlowEngine::GetRender(const std::string &violation_code) const {
        // always need render
        RENDER_TYPE type;

        if(violation_code==FLOW_RETROGRADE_CODE){
            type = RETROGRADE;
        }else if(head_cross_line_.count(violation_code)){
            type = HEAD_CROSS_LINE;
        }else if(violation_code==FLOW_ZONE_GUARD_CODE || violation_code==BUILDING_ZONE_GUARD_CODE){
            type = ZONE_GUARD;
        }else if(head_count_in_region_.count(violation_code)){
            type = HEAD_IN_REGION;
        }else if(violation_code == FLOW_RETENTION_CODE){
            type = RETENTION;
        }else if(violation_code == FLOW_BANNER_CODE){
            type = BANNER;
        }else if(violation_code == FLOW_CROWD_CODE || violation_code == BUILDING_CROWD_REGION_EXCEED_CODE || violation_code == FLOW_CROWD_REGION_EXCEED_CODE){
            type = DENSITY;
        }else{
            type = DEBUG;
        }
        return [type](const ImageObjectsInfo& frame, Mat_Ptr mat, bool enable_tracking_debug) {
                    if(enable_tracking_debug){
                        CAlgFlowEngine::MassiveflowRender(frame, mat, type);
                    }else{
                        return ;
                    }
                };
    }

    void RetrogradeRender(const ImageObjectsInfo& image_objects, Mat_Ptr mat) {
        if(image_objects.flow_info.retrogradeinfo_.lines_.size()== 0 ){
            return;
        }
        const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
        bool ifWarning = false;
        // for (auto &kv:image_objects.flow_info.retrogradeinfo_){
            auto &retrogradeinfo = image_objects.flow_info.retrogradeinfo_;
            //draw persons
            for(auto &person:retrogradeinfo.persons_){
                ifWarning = true;
                cv::Scalar scalar;
                scalar = cv::Scalar(0, 0, 255);
                cv::rectangle(*mat,
                            cv::Point(person.xmin, person.ymin)*scale,
                            cv::Point(person.xmax, person.ymax)*scale, scalar, 2);
            }
            // draw roi
            auto &rois = retrogradeinfo.rois_;
            for(auto i=0;i< rois.size();i++){
                auto &roi = rois[i];
                // LOG(INFO)<< "roi :" << roi;
                int size_roi = roi.size();
                for (int k=0;k<size_roi/2-1;++k){
                    cv::line(*mat,cv::Point(roi[2*k],roi[2*k+1])*scale,cv::Point(roi[2*k+2],roi[2*k+3])*scale,cv::Scalar(0,255,0),2,8,0);
                }
                cv::line(*mat,cv::Point(roi[0],roi[1])*scale,cv::Point(roi[size_roi-2],roi[size_roi-1])*scale,cv::Scalar(0,255,0),2,8,0);
            }
         
            // // draw line
            // for(auto &line:kv.second.lines_){
            //     cv::line(*mat, cv::Point(line[0], line[1]), cv::Point(line[2], line[3]), Scalar(255, 0, 0), 2);
            // }

            // draw arrow
            for(auto &arrow:retrogradeinfo.arrows_){
                cv::arrowedLine(*mat, cv::Point(arrow[0], arrow[1])*scale, cv::Point(arrow[2], arrow[3])*scale, cv::Scalar(255, 0, 0), 2);
            }
        // }

        //draw warning text
        if(ifWarning){
		    freetype::ft2->putText(*mat, "逆行警告", cv::Point(mat->cols/2-50, 100)*scale, 50, cv::Scalar(0, 0, 255), 3, 8, true);
        }

        return;

    }

    void HeadCrossLineRender(const ImageObjectsInfo& image_objects,Mat_Ptr mat) {
        if(image_objects.flow_info.headcountinfo_.DrawHeadLines_.size() == 0){
            return;
        }
        const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
        auto &headcount_info = image_objects.flow_info.headcountinfo_;
        // for (auto &kv : image_objects.headcountinfo_) { // here only one element
            // draw text area
            cv::Mat roi =(*mat)(cv::Rect(10,10,800,(15+80*headcount_info.DrawHeadLines_.size()))*scale);
            cv::Mat color(roi.size(),CV_8UC3, cv::Scalar( 255, 255, 255));
            double alpha = 0.7;
            cv::addWeighted(color, alpha, roi, 1.0 - alpha , 0.0, roi);

	    // draw lines
            int real_line_index = 0;
            
            for (auto &line :headcount_info.DrawHeadLines_){
		        int line_pro = line[4];
                int line_xl = line[0];
                int line_yt = line[1];
                int line_xr = line[2];
                int line_yb = line[3];

                string logo1,logo2;
                int head1 = 0;
                int head2 = 0;
                string sstart = string("检测线");

                logo1 = string("进入");
                logo2 = string("离开");
		
                if (line_pro == 1 || line_pro == 3){
                    head1 = (int) headcount_info.head_count_[2*real_line_index+1];
                    head2 = (int) headcount_info.head_count_[2*real_line_index];
                }else
                {
                    head1 = (int) headcount_info.head_count_[2*real_line_index+1];
                    head2 = (int) headcount_info.head_count_[2*real_line_index];
                }

                real_line_index ++ ;

                auto text = sstart+to_string(real_line_index) + " : " +logo1+to_string(head1) + " , " + logo2+to_string(head2);
                freetype::ft2->putText(*mat, text, cv::Point(20, (20+70*real_line_index))*scale, 50, freetype::colorplate[real_line_index-1], -1, 8, true);
                text = sstart+to_string(real_line_index);
                freetype::ft2->putText(*mat, text, cv::Point((line_xl+40), (line_yt+40))*scale, 20, freetype::colorplate[real_line_index-1], -1, 8, true);

                cv::line(*mat,cv::Point(line_xl,line_yt)*scale,cv::Point(line_xr,line_yb)*scale,freetype::colorplate[real_line_index-1],2,8,0);
            }

        std::string head_reset = std::string("开始检测时间");
        auto text = head_reset + " : " + headcount_info.startCountTime_;
        cv::Scalar scalar;
        scalar = cv::Scalar(0,183,255);
        freetype::ft2->putText(*mat, text, cv::Point(850, 90)*scale, 20, scalar, -1, 8, true);
            // draw arrow
	    std::vector< std::vector<int> > arrows = headcount_info.arrows_;
            for (int i=0; i<arrows.size(); ++i){
                cv::line(*mat,cv::Point(arrows[i][0],arrows[i][1])*scale,cv::Point(arrows[i][2],arrows[i][3])*scale,freetype::colorplate[i],3,8,0);
                cv::line(*mat,cv::Point(arrows[i][2],arrows[i][3])*scale,cv::Point(arrows[i][4],arrows[i][5])*scale,freetype::colorplate[i],3,8,0);
                cv::line(*mat,cv::Point(arrows[i][2],arrows[i][3])*scale,cv::Point(arrows[i][6],arrows[i][7])*scale,freetype::colorplate[i],3,8,0);

		freetype::ft2->putText(*mat, "进入", cv::Point((arrows[i][2]+10), (arrows[i][3]+10))*scale, 20,freetype::colorplate[i], -1, 8, true);
	    }

        // draw rectangle
        for (auto &object : image_objects.keliu_objects) {
            cv::Scalar scalar;
            if (object.label == OBJECT_TYPE_HEAD) {
                scalar = cv::Scalar(255, 255, 255);

                auto text = std::to_string(object.uid);
                cv::putText(*mat, text,
                            cv::Point(object.xmin, object.ymin - 10)*scale,
                            cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);
                cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                                    cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
            }
        }
        //draw "in"/"out" on each obj cross line
        for(auto &box: headcount_info.in_persons_){
            cv::Scalar scalar;
            scalar = cv::Scalar(255, 255, 255);
            std::string text = "in";
            cv::putText(*mat, text,
                        cv::Point(box.xmin, box.ymax + 10)*scale,
                        cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);
        }
        for(auto &box: headcount_info.out_persons_){
            cv::Scalar scalar;
            scalar = cv::Scalar(255, 255, 255);
            std::string text = "out";
            cv::putText(*mat, text,
                        cv::Point(box.xmin+15, box.ymax + 10)*scale,
                        cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);         
        }
        //draw traceback for obj who cross the line
        for(auto &line: headcount_info.inHeadTrace_){

            cv::Scalar scalar;
            scalar = cv::Scalar(0,183,255);
            cv::line(*mat,cv::Point(line.first.x,line.first.y)*scale,cv::Point(line.second.x,line.second.y)*scale,scalar,2,8,0);        
        }
        for(auto &line: headcount_info.outHeadTrace_){

            cv::Scalar scalar;
            scalar = cv::Scalar(0,183,255);
            cv::line(*mat,cv::Point(line.first.x,line.first.y)*scale,cv::Point(line.second.x,line.second.y)*scale,scalar,2,8,0);        
        }
        return;
    }

    void ZoneGuardRender(const ImageObjectsInfo& image_objects,Mat_Ptr mat) {
        if(image_objects.flow_info.zoneguardinfo_.heads_.size() == 0){
            return;
        }
        const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
        auto &heads = image_objects.flow_info.zoneguardinfo_.heads_;
        auto &tracked_heads = image_objects.flow_info.zoneguardinfo_.tracked_heads_;
        // draw rectangle
        for (auto &object : image_objects.keliu_objects) {
            cv::Scalar scalar;
            if (object.label == OBJECT_TYPE_HEAD) {
                scalar = cv::Scalar(0, 0, 255);//red 
                float score = 100.0*object.score;
                auto text = std::to_string(object.uid)+"_"+std::to_string(int(score));
                cv::putText(*mat, text,
                            cv::Point(object.xmin, object.ymin - 10)*scale,
                            cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);
                cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,
                                    cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
            }
        }

        for(auto &box: heads){
            cv::Scalar scalar = cv::Scalar(0, 0, 0);
            std::string text = "in";
            cv::putText(*mat, text,
                            cv::Point(box.xmin, box.ymax)*scale,
                            cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);
        }
        for(auto &box: tracked_heads){
            cv::Scalar scalar = cv::Scalar(0, 0, 0);
            std::string text = std::to_string(box.label)+"_"+std::to_string(box.uid);
            cv::putText(*mat, text,
                            cv::Point(box.xmin, box.ymax + 10)*scale,
                            cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);
        }
        return;
    }

    void DebugRender(const ImageObjectsInfo& image_objects,Mat_Ptr mat){
        const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
        cv::Scalar scalar = cv::Scalar(0, 0, 255);
        for (auto &object : image_objects.keliu_objects) {
            if (object.label == OBJECT_TYPE_HEAD) {
                cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
            }
        }

        if(image_objects.flow_info.fight_event_.if_predicted){
            auto text = "fight score: "+std::to_string(image_objects.flow_info.fight_event_.predict_score);
            freetype::ft2->putText(*mat, text, cv::Point(20, (20+70))*scale, 50, freetype::colorplate[0], -1, 8, true);
        }
    }
    /*
     void SafeV3Render(const ImageObjectsInfo& image_objects,Mat_Ptr mat){
        cv::Scalar scalar_green = cv::Scalar(255, 0, 0);
        if(object.label==OBJECT_TYPE_HEAD){
            cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
        }else if(object.label==OBJECT_TYPE_PERSON){
            cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,cv::Point(object.xmax, object.ymax)*scale, scalar_green, 2);
        }
     }
    */
    void HeadInRegionRender(const ImageObjectsInfo& image_objects,Mat_Ptr mat){
        const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
        cv::Scalar scalar = cv::Scalar(0, 0, 255);
        //draw head
        for(auto &object : image_objects.keliu_objects) {
            if (object.keliu_head_in_roi == true) {
                cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
            }
        }
        //text
        auto text = "人数：" + to_string(image_objects.flow_info.roisinfo_.head_counts_);
        scalar = cv::Scalar(0,0,0);
        freetype::ft2->putText(*mat, text, cv::Point(20, 65)*scale, 50, scalar, -1, 8, true);
        //roi
        scalar = cv::Scalar(0,183,255);
        int x1=0, y1=0, x2=0, y2=0;
        for(auto &roi: image_objects.flow_info.roisinfo_.rois_){
            for(int i=0; i<roi.size()-1; i++){
                x1 = (int)(roi[i].x);
                y1 = (int)(roi[i].y);
                x2 = (int)(roi[i+1].x);
                y2 = (int)(roi[i+1].y);
                cv::line(*mat,cv::Point(x1,y1)*scale,cv::Point(x2,y2)*scale,scalar,2,8,0);
            }
            x1 = (int)(roi[0].x);
            y1 = (int)(roi[0].y);
            x2 = (int)(roi.back().x);
            y2 = (int)(roi.back().y);
            cv::line(*mat,cv::Point(x1,y1)*scale,cv::Point(x2,y2)*scale,scalar,2,8,0);
        }
    }

    void RetentionRender(const ImageObjectsInfo& image_objects,Mat_Ptr mat){
        const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
        //draw head
        for(auto &object : image_objects.flow_info.retentioninfo_.retentionobjects_) {
            cv::Scalar scalar = cv::Scalar(255, 255, 255);
            cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
            scalar = cv::Scalar(0, 0, 255);
            std::string text = to_string(object.uid);
            cv::putText(*mat, text,
                        cv::Point(object.xmin, object.ymax + 10)*scale,
                        cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);
        }
    }

    void BannerRender(const ImageObjectsInfo& image_objects, Mat_Ptr mat){
        const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
        //draw head
        for(auto &object : image_objects.flow_info.bannerinfo_.bannerobjects_) {
            cv::Scalar scalar = cv::Scalar(0, 0, 255);
            cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
            std::string text = to_string(object.score);
            cv::putText(*mat, text,
                        cv::Point(object.xmin, object.ymax + 15)*scale,
                        cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);
        }
        for(auto &object : image_objects.objects) {
            cv::Scalar scalar = cv::Scalar(255, 255, 255);
            cv::rectangle(*mat, cv::Point(object.xmin, object.ymin)*scale,cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
            std::string text = to_string(object.label)+"/"+to_string(object.score);
            cv::putText(*mat, text,
                        cv::Point(object.xmin, object.ymax + 10)*scale,
                        cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 2);
        }
    }

    void DensityRender(const ImageObjectsInfo& image_objects, Mat_Ptr mat){
         const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
        if(image_objects.flow_info.densityinfo_.foreground_mask.rows==0 || image_objects.flow_info.densityinfo_.foreground_mask.cols==0){
            return;
        }
        int rows = mat->rows;
        int cols = mat->cols;
        cv::Mat res;
        cv::resize(image_objects.flow_info.densityinfo_.foreground_mask, res, cv::Size(cols,rows));
        for (int i=0; i<rows ; i++)  {  
            for (int j=0; j<cols ; j++)  {
                //if(image_objects.flow_info.densityinfo_.foreground_mask.rows<i || image_objects.flow_info.densityinfo_.foreground_mask.cols<j){
                //    return;
                //}
                auto tmp = res.at<uchar>(i, j);
                if(tmp!=0){
                    //mat->at<cv::Vec3b>(i,j)[1] = (mat->at<cv::Vec3b>(i,j)[1])/2+tmp/2;
                    mat->at<cv::Vec3b>(i,j)[1] = 255;
                }
            }  
        }
        auto text = "聚集程度: "+std::to_string(image_objects.flow_info.densityinfo_.score);
        freetype::ft2->putText(*mat, text, cv::Point(20, (20+70))*scale, 50, freetype::colorplate[0], -1, 8, true);
    }
    
    void CAlgFlowEngine::FillSkipframe(fnSkipChecker skip, const spImageObjectsInfo processedFrame, spImageObjectsInfo currentFrame) {
        LOG_IF(FATAL, processedFrame->channel_id != currentFrame->channel_id) 
            << "frame channel_id missmatch, (" << processedFrame->channel_id << "!=" << currentFrame->channel_id <<")";

        if (!skip(currentFrame)) {
            processedFrame->flow_info.densityinfo_.foreground_mask = currentFrame->flow_info.densityinfo_.foreground_mask;
            processedFrame->flow_info.densityinfo_.score = currentFrame->flow_info.densityinfo_.score;
        } else {
            // fake
            currentFrame->flow_info.densityinfo_.foreground_mask = processedFrame->flow_info.densityinfo_.foreground_mask;
            currentFrame->flow_info.densityinfo_.score = processedFrame->flow_info.densityinfo_.score;
        }
        
    }

    void CAlgFlowEngine::MassiveflowRender(const ImageObjectsInfo& image_objects, Mat_Ptr mat, RENDER_TYPE type) {
        switch(type){
            case HEAD_CROSS_LINE:
                HeadCrossLineRender(image_objects, mat);
                break;
            case ZONE_GUARD:
                ZoneGuardRender(image_objects, mat);
                break;
            case HEAD_IN_REGION:
                HeadInRegionRender(image_objects, mat);
                break;
            case RETROGRADE:
                RetrogradeRender(image_objects, mat);
                break;
            case DEBUG:
                DebugRender(image_objects, mat);
                break;
            case RETENTION:
                RetentionRender(image_objects, mat);
            case BANNER:
                BannerRender(image_objects, mat);
            case DENSITY:
                DensityRender(image_objects, mat);
            case NONE:
                break;
        }
        return;
    }
} // FLOW


