#include "alg_face_struct_engine.hpp"

#include <future>
#include <string>
#include <vector>
#include <memory>

#include "algorithm/face_struct/face_attribute.hpp"
#include "algorithm/face_struct/face_detect.hpp"
#include "algorithm/face_struct/face_feature.hpp"
#include "algorithm/face_struct/face_quality.hpp"
#include "algorithm/track/track_wraper.hpp"
#include "common/io.hpp"
#include "common/pbjson.hpp"
#include "common/util_scale.hpp"
#include "common/tad_internal.hpp"
#include "common/type.hpp"
#include "helper.hpp"
#include "serving/violation_config.pb.h"

namespace FLOW {
using namespace std;
void CAlgFaceEngine::Init(const inference::EngineConfig& config, int& code) {
  
  config_ = config.face_struct();

  std::map<std::string, std::pair<std::string, std::vector<char>>> params = {
      {"face_detect_model",
       {config_.face_detect().model_path(), {}}},
      {"face_attribute_model",
       {config_.face_attri().model_path(), {}}},
      {"face_feature_model",
       {config_.face_feature().model_path(), {}}},
      {"face_quality_model",
       {config_.face_quality().model_path(), {}}},
  };
  for (auto& kv : params) {
    if (!IO::ReadBinaryFile(kv.second.first, &kv.second.second)) {
      LOG(FATAL) << "Load model " << kv.second.first << " error";
      return;
    }
  }
  // detect_model
  face_detect_engine_ = std::make_shared<FaceStruct::FaceDetectModule>();
  face_detect_engine_->Setup(params["face_detect_model"].second,
                             config_.face_detect(), code);
  // attribute_model
  face_attribute_engine_ = std::make_shared<FaceStruct::FaceAttributeModule>();
  face_attribute_engine_->Setup(params["face_attribute_model"].second,
                                config_.face_attri(), code);
  // plate_model
  face_feature_engine_ = std::make_shared<FaceStruct::FaceFeatureModule>();
  face_feature_engine_->Setup(params["face_feature_model"].second,
                              config_.face_feature(), code);
  // traffic_light_model
  face_quality_engine_ = std::make_shared<FaceStruct::FaceQualityModule>();
  face_quality_engine_->Setup(params["face_quality_model"].second,
                              config_.face_quality(), code);
}

void CAlgFaceEngine::GetBatchFrames(VecImage& queue, VecImage& image_map) const {
}

void CAlgFaceEngine::GetBatchFramesWithSize(VecImage& queue, VecImage& image_map,
                                            int batch_size) const {
  // std::cout<<"get images batch :"<<queue.size()<<std::endl;
  image_map.clear();
  int count = 0;
  for (auto it = queue.begin(); it != queue.end() && count < batch_size;) {
    auto& frame = *it;
    if (!this->Skip(frame->count)) count++;
    image_map.push_back(frame);
    it = queue.erase(it);
  }

  /*if (!image_map->empty()) {
      PrintQueueInfo(queue_size, count, image_map->size());
  }*/
}

void CAlgFaceEngine::Process(CFlowDispatch& dsp) {
  if (!channel_data_update_queue_.empty()) {
    auto new_data = channel_data_update_queue_.pop();
    auto& channel_id = new_data->channel_id_;
    if (auto old_data = channel_data_map_.find(new_data->channel_id_)) {
      auto copy_data = std::make_shared<ChannelData>(*old_data);
      if (copy_data->UpdateCfg(*new_data)) {
        channel_data_map_.insert(channel_id, copy_data);
      }
    }
    if (auto channel_data = channel_data_map_.find(channel_id)) {
      const std::string FACE_STRUCT_CODE("5100");
      CFlowDispatch::spNode detect, track, quality, feature, attribute, chin,
          chout;
      chin = dsp.get_node(channel_id, "in");
      chout = dsp.get_node(channel_id, "out");
      if (!chin || !chout) return;

      if (new_data->action_ == 1 && chin && chout) {  // add violation
        if (new_data->add_violation_ == FACE_STRUCT_CODE) {
          detect = dsp.add_node(channel_id,
                                std::string(typeid(this).name()) + "-detect",
                                config_.face_detect_queue_size(), true);
          detect->process([this](VecImage& in) {
            VecImage frames;
            this->GetBatchFramesWithSize(in, frames, config_.face_detect().batch_size());
            this->faceDetectProcess(frames);
          });
          chin->next(detect);

          track = dsp.add_node(channel_id,
                               std::string(typeid(this).name()) + "-track",
                               config_.face_detect_queue_size());
          track->process([this, channel_data](VecImage& in) {
            this->faceTrackProcess(channel_data, in);
            in.clear();
          });
          detect->next(track);

          quality = dsp.add_node(channel_id,
                                 std::string(typeid(this).name()) + "-quality",
                                 config_.face_quality_queue_size(), true);
          quality->process([this](VecImage& in) {
            VecImage frames;
            this->GetBatchFramesWithSize(in, frames, config_.face_quality().batch_size());
            this->faceQualityProcess(frames);
          });
          track->next(quality);

          feature = dsp.add_node(channel_id,
                                 std::string(typeid(this).name()) + "-feature",
                                 config_.face_feature_queue_size(), true);
          feature->process([this](VecImage& in) {
            VecImage frames;
            this->GetBatchFramesWithSize(in, frames, config_.face_feature().batch_size());
            this->faceFeatureProcess(frames);
          });
          quality->next(feature);

          attribute = dsp.add_node(
              channel_id, std::string(typeid(this).name()) + "-attribute",
              config_.face_attribute_queue_size(), true);
          attribute->process([this](VecImage& in) {
            VecImage frames;
            this->GetBatchFramesWithSize(in, frames, config_.face_attri().batch_size());
            this->faceAttributeProcess(frames);
          });
          feature->next(attribute);

          auto fill_skip = dsp.add_node(
              channel_id, std::string(typeid(this).name()) + "-fill-skipframe",
              2);
          auto last_face_objects = std::make_shared<ImageObjectsInfo>();
          fill_skip->process([this, last_face_objects](VecImage &in) {
            for (auto image : in) {
              if (!this->Skip(image->count)) {
                last_face_objects->face_objects = image->face_objects;
              } else {
                for(auto& face : last_face_objects->face_objects) {
                  if(face.create_flag) {
                    face.create_flag = 0;
                    face.face_feature.clear();
                  }
                }
                image->face_objects = last_face_objects->face_objects;
              }
            }
            in.clear();
          });
          attribute->next(fill_skip);
          
          fill_skip->next(chout);
        }

      } else if (new_data->action_ == 2) {  // remove violation
        if (new_data->add_violation_ == FACE_STRUCT_CODE) {
          dsp.remove_node(channel_id,
                          std::string(typeid(this).name()) + "-detect");
          dsp.remove_node(channel_id,
                          std::string(typeid(this).name()) + "-quality");
          dsp.remove_node(channel_id,
                          std::string(typeid(this).name()) + "-feature");
          dsp.remove_node(channel_id,
                          std::string(typeid(this).name()) + "-attribute");
          dsp.remove_node(channel_id,
                          std::string(typeid(this).name()) + "-track");
          dsp.remove_node(channel_id,
                          std::string(typeid(this).name()) + "-fill-skipframe");
        }
      }
    }
  }
}

void CAlgFaceEngine::ProcessByName(const std::string& name,
                                   const ShellFrame_Ptr &shell_frame, VecBoxF& boxes) {
  if (name == "post") {
    std::vector<RectF> rois = {RectF(0, 0, shell_frame->width(), shell_frame->height())};
    VecMat mats = {shell_frame->getMat()};
    std::vector<VecBoxF> face_infos = {boxes};
    int code = -1;
    if (face_detect_engine_ != nullptr) {
      std::unique_lock<std::mutex> lock{face_detect_lock_};
      face_detect_engine_->Predict(mats, rois, face_infos, code);
    }
    if (face_quality_engine_ != nullptr) {
      std::unique_lock<std::mutex> lock{face_quality_lock_};
      face_quality_engine_->Predict(mats, face_infos, code);
    }
    if (face_feature_engine_ != nullptr) {
      std::unique_lock<std::mutex> lock{face_feature_lock_};
      face_feature_engine_->Predict(mats, face_infos, code);
    }
    if (face_attribute_engine_ != nullptr) {
      std::unique_lock<std::mutex> lock{face_attribute_lock_};
      face_attribute_engine_->Predict(mats, face_infos, code);
    }
  }
}

void CAlgFaceEngine::AddStream(const std::string& channel_id,
                               const std::string& config) {
  int code = 0;
  auto channel_data = channel_data_map_.find(channel_id);
  if (nullptr == channel_data.get()) {
    channel_data = std::make_shared<ChannelData>();
    channel_data->channel_id_ = channel_id;
    channel_data->max_face_quality_ = std::make_shared<std::map<int,float>>();
    auto tracker_ptr = std::make_shared<Track::TADTracker>();
    LOG(INFO) << "New tracker with " << channel_id;
    tracker_ptr->Setup(config_.track(), config, code);
    CHECK(0 == code);
    channel_data->tracker_ = tracker_ptr;
    // prase
    BoxF box;

    if (face_detect_roi_config(config, &box)) {
      channel_data->detect_roi_ = std::make_shared<RectF>(box.RectFloat());
    }
    channel_data_map_.insert(channel_id, channel_data);
  }
}

void CAlgFaceEngine::RemoveStream(const std::string& channel_id) {
  channel_data_map_.erase(channel_id);
}

// 读取违法的布控配置信息，以及跟踪的参数信息。
void CAlgFaceEngine::AddViolation(const std::string& channel_id,
                                  const std::string& violation_id,
                                  const std::string& config) {
  if (config_.face_struct_on()) {
    auto channel_data_old = channel_data_map_.find(channel_id);
    if (channel_data_old) {
      std::string roi_cfg;
      {
        auto data = std::make_shared<inference::ViolationConfig>();
        std::string err;
        json2pb(config, data.get(), &err);
        inference::Roi roi;
        *roi.mutable_data() = data->roi();
        pb2json(&roi, &roi_cfg);
      }
      channel_data_old->tracker_->AddStreamRoiConfig(violation_id, roi_cfg);
      channel_data_old->tracker_->AddStreamTrackingType(violation_id, config);

      std::string violation_code;
      auto channel_data = std::make_shared<ChannelData>();
      channel_data->channel_id_ = channel_id;
      channel_data->action_ = 1;
      if (parse_violation_code(config, violation_code)) {
        channel_data->add_violation_ = violation_code;
      }
      channel_data_update_queue_.push(channel_data);
    }
  }
}

void CAlgFaceEngine::RemoveViolation(const std::string& channel_id,
                                     const std::string& violation_id) {
  auto channel_data = channel_data_map_.find(channel_id);
  if (channel_data) {
    channel_data->tracker_->RemoveStreamRoiConfig(violation_id);

    auto vdata = std::make_shared<ChannelData>();
    vdata->channel_id_ = channel_id;
    vdata->action_ = 2;
    channel_data_update_queue_.push(vdata);
  }
}

void CAlgFaceEngine::faceTrackProcess(CAlgFaceEngine::spChannelData channel,
                                      const VecImage& images) {
  std::unique_lock<std::mutex> lock{face_track_lock_};
  int code = -1;
  // Profiler profiler_track;
  // ProfilerHelper _profiler(&profiler_track, "trackProcess", [](Profiler* p) {
  //   LOG(DEBUG) << "profiler " << p->get_stats_str();
  // });
  for (auto image : images) {
    if (!this->Skip(image->count)) {
      channel->tracker_->Process(image->sframe, image->face_objects, &code);
    } else {
      continue;
    }
  }
}

void CAlgFaceEngine::faceDetectProcess(const VecImage& images) {
  std::unique_lock<std::mutex> lock{face_detect_lock_};
  // Profiler profiler_detect;
  // ProfilerHelper _profiler(
  //     &profiler_detect, "DetectionProcess",
  //     [](Profiler* p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });
  // detect
  VecMat mats;
  std::vector<RectF> rois;
  std::vector<VecBoxF> face_infos;
  VecImage image_detect;
  // std::cout<<"detect "<<images.size()<<std::endl;
  for (auto& image : images) {
    if (this->Skip(image->count)) {
      continue;
    }
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }
    const auto &pic_mat = image->sframe->getMat();
    RectF roi;
    if (channel_data->detect_roi_) {
      const auto& detect_roi = *(channel_data->detect_roi_);
      roi = RectF(detect_roi.x, detect_roi.y, detect_roi.w, detect_roi.h);
    } else {
      roi = RectF(0, 0, image->sframe->width(), image->sframe->height());
    }
    mats.push_back(pic_mat);
    rois.push_back(roi);
    face_infos.push_back(image->face_objects);
    image_detect.push_back(image);
  }

  int code = -1;
  if (mats.empty() || rois.empty()) return;
  face_detect_engine_->Predict(mats, rois, face_infos, code);
  int j = 0;
  CHECK_EQ(face_infos.size(), image_detect.size());
  for (int i = 0; i < image_detect.size(); i++) {
    image_detect[i]->face_objects = face_infos[i];
  }
}

void CAlgFaceEngine::faceAttributeProcess(const VecImage& images) {
  std::unique_lock<std::mutex> lock{face_attribute_lock_};
  // Profiler profiler_detect;
  // ProfilerHelper _profiler(
  //     &profiler_detect, "FaceAttributeProcess",
  //     [](Profiler* p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });

  // detect
  VecMat mats;
  std::vector<VecBoxF> face_infos;
  std::vector<std::vector<BoxF*>> face_origin_box;

  for (auto& image : images) {
    if (this->Skip(image->count)) {
      continue;
    }
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }
    const auto &pic_mat = image->sframe->getMat();

    mats.push_back(pic_mat);

    face_infos.emplace_back();
    face_origin_box.emplace_back();
    for (auto& face_box : image->face_objects) {
      if (!face_box.delete_flag) {
        face_infos.back().push_back(face_box);
        face_origin_box.back().push_back(&face_box);
      }
    }
  }

  int code = -1;
  if (mats.empty() || face_infos.empty()) return;
  face_attribute_engine_->Predict(mats, face_infos, code);
  
  // copy result
  CHECK_EQ(face_origin_box.size(), face_infos.size());
  for (int j=0; j<face_origin_box.size(); j++) {
    CHECK_EQ(face_origin_box[j].size(), face_infos[j].size());
    for (int k=0; k<face_origin_box[j].size(); k++) {
      face_origin_box[j][k]->face_attr = face_infos[j][k].face_attr;
    }
  }
}

void CAlgFaceEngine::faceFeatureProcess(const VecImage& images) {
  std::unique_lock<std::mutex> lock{face_feature_lock_};
  // Profiler profiler_detect;
  // ProfilerHelper _profiler(
  //     &profiler_detect, "FaceFeatureProcess",
  //     [](Profiler* p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });
  // detect
  VecMat mats;
  std::vector<VecBoxF> face_infos;
  std::vector<std::vector<BoxF*>> face_origin_box;

  for (auto& image : images) {
    if (this->Skip(image->count)) {
      continue;
    }
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }
    const auto &pic_mat = image->sframe->getMat();
    mats.push_back(pic_mat);
    face_infos.push_back(VecBoxF());
    face_origin_box.push_back(std::vector<BoxF*>());
    for (auto& face_box : image->face_objects) {
      // skip delete box
      if (face_box.delete_flag) {
        channel_data->max_face_quality_->erase(face_box.uid);
        continue;
      }
      // skip face_quality small
      if (channel_data->max_face_quality_->count(face_box.uid) > 0){
        auto& max_face_quality_score = channel_data->max_face_quality_->at(face_box.uid);
        if (face_box.face_quality.type>0 || max_face_quality_score >= face_box.face_quality.score) {
          continue;
        }
      }
      // update max_face_quality_
      (*(channel_data->max_face_quality_))[face_box.uid] = face_box.face_quality.score;

      face_infos.back().push_back(face_box);
      face_origin_box.back().push_back(&face_box);
    }
  }

  int code = -1;
  if (mats.empty() || face_infos.empty()) return;
  face_feature_engine_->Predict(mats, face_infos, code);
  
  // copy result
  CHECK_EQ(face_origin_box.size(), face_infos.size());
  for (int j=0; j<face_origin_box.size(); j++) {
    CHECK_EQ(face_origin_box[j].size(), face_infos[j].size());
    for (int k=0; k<face_origin_box[j].size(); k++) {
      face_origin_box[j][k]->face_feature = face_infos[j][k].face_feature;
    }
  }
}

void CAlgFaceEngine::faceQualityProcess(const VecImage& images) {
  std::unique_lock<std::mutex> lock{face_quality_lock_};
  // Profiler profiler_detect;
  // ProfilerHelper _profiler(
  //     &profiler_detect, "FaceQualityProcess",
  //     [](Profiler* p) { LOG(DEBUG) << "profiler " << p->get_stats_str(); });
  // detect
  VecMat mats;
  std::vector<VecBoxF> face_infos;
  std::vector<VecBoxF*> face_origin_box;

  for (auto& image : images) {
    if (this->Skip(image->count)) {
      continue;
    }
    auto channel_data = channel_data_map_.find(image->channel_id);
    if (nullptr == channel_data.get()) {
      continue;
    }
    const auto &pic_mat = image->sframe->getMat();
    mats.push_back(pic_mat);
    face_infos.push_back(image->face_objects);
    face_origin_box.push_back(&(image->face_objects));
  }
  
  int code = -1;
  if (mats.empty() || face_infos.empty()) return;
  face_quality_engine_->Predict(mats, face_infos, code);

  // copy result
  CHECK_EQ(face_origin_box.size(), face_infos.size());
  for (int j=0; j<face_origin_box.size(); j++) {
    CHECK_EQ(face_origin_box[j]->size(), face_infos[j].size());
    for (int k=0; k<face_origin_box[j]->size(); k++) {
      face_origin_box[j]->at(k).face_quality = face_infos[j][k].face_quality;
    }
  }
}

bool CAlgFaceEngine::Skip(int64_t count) const {
  return count % config_.face_struct_interval();
}

void CAlgFaceEngine::PrintInfo(const VecImage& images) const {
  LOG(INFO) << "Objects Info";
  LOG(INFO) << "---------------------------------------------";

  for (auto& image : images) {
    auto& image_objects = *image;
    LOG(INFO) << "channel id: " << image_objects.channel_id;
    for (auto& object : image_objects.face_objects) {
      LOG(INFO) << "object type: " << object.label << ", \t"
                << "attr type: " << object.face_quality.type << ", \t"
                << "track id: " << object.uid << ", \t"
                << "pos: " << object.xmin << " " << object.ymin << " "
                << object.xmax << " " << object.ymax;
    }
  }
  LOG(INFO) << "---------------------------------------------";
}

void CAlgFaceEngine::PrintQueueInfo(int queue_size, int batch,
                                    int frames) const {
  LOG(INFO) << "Queue Info";
  LOG(INFO) << "frame queue---------------------------------------------";
  LOG(INFO) << "Raw frame queue: " << queue_size << " batch: " << batch << "/"
            << frames;
  channel_data_map_.visit(
      [](const std::string& channel_id, spChannelData channel_data) {
        LOG(INFO) << "Trc frame queue: " << channel_id << "\t";
        return true;
      });
  LOG(INFO) << "frame queue---------------------------------------------";
}

AlgRender CAlgFaceEngine::GetRender(const std::string &violation_code) const {
  if(violation_code == "5100") {
      return CAlgFaceEngine::Render;
  }
  return nullptr;
}

void CAlgFaceEngine::Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug){
  const cv::Matx22f scale{mat->rows / (float)image_objects.sframe->height(), 0, 0, mat->cols / (float)image_objects.sframe->width()};
  std::vector<VecString> attribute_name{
      {"female", "male"},
      {"age"},
      {"no_mask", "mask"},
      {"no_glasses", "normal_glasses", "sun_glasses"},
      {"neutral", "happy", "sad", "angry", "fearful", "surprise", "disgusted"},
      {"white", "black", "yellow"},
      {"o_clock_Shadow", "goatee", "mustache", "sideburns", "no_Beard"},
      {"no_weizu", "weizu"},
      {"pos", "neg", "blur", "pose", "cover"}
  };
  for (auto &object : image_objects.face_objects) {
    cv::Scalar scalar;
    if (object.delete_flag > 0) {
      continue;
    }
    scalar = cv::Scalar(0, 255, 0);
    auto text_id = std::to_string(object.uid);
    auto text_sex = object.face_attr.size()>0 ? attribute_name[0][object.face_attr[0].type] : "UNDEFINE";
    auto text_quality = attribute_name[8][object.face_quality.type];
    cv::putText(*mat, text_id,
                cv::Point(object.xmin, object.ymin - 10)*scale,
                cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 1);
    cv::putText(*mat, text_sex,
                cv::Point(object.xmax, object.ymin - 10)*scale,
                cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 1);
    cv::putText(*mat, text_quality,
                cv::Point(object.xmax, object.ymax + 10)*scale,
                cv::FONT_HERSHEY_SIMPLEX, 0.5, scalar, 1);
    cv::rectangle(*mat,
                cv::Point(object.xmin, object.ymin)*scale,
                cv::Point(object.xmax, object.ymax)*scale, scalar, 2);
    cv::circle(*mat, cv::Point(object.face_point.x1, object.face_point.y1)*scale, 1,
               scalar, -1);
    cv::circle(*mat, cv::Point(object.face_point.x2, object.face_point.y2)*scale, 1,
               cv::Scalar(0, 255, 0), -1);
    cv::circle(*mat, cv::Point(object.face_point.x3, object.face_point.y3)*scale, 1,
               cv::Scalar(0, 255, 0), -1);
    cv::circle(*mat, cv::Point(object.face_point.x4, object.face_point.y4)*scale, 1,
               cv::Scalar(0, 255, 0), -1);
    cv::circle(*mat, cv::Point(object.face_point.x5, object.face_point.y5)*scale, 1,
               cv::Scalar(0, 255, 0), -1);
  }
}

}  // namespace FLOW
