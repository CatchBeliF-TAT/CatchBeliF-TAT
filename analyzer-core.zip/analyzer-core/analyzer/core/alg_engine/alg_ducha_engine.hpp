#ifndef TAD_ALG_DUCHA_ENGINE_HPP
#define TAD_ALG_DUCHA_ENGINE_HPP

#include <memory>
#include <mutex>
#include <atomic>
#include <set>

#include "alg_engine_interface.hpp"

#include "core/flow_dispatch.hpp"
#include "common/Queue.h"
#include "violation/ducha/ducha_const.hpp"
#include "serving/config.pb.h"

namespace prometheus{
    class Counter;
    typedef std::shared_ptr<Counter> spCounter;
}

namespace FLOW {

    namespace Detect {
        class DetectModule;
    }
    namespace duchaMar{
        class DuchaMarModule;
    }
    namespace duchaHoi{
        class DuchaHoiModule;
    }
    namespace FightClassify {
        class FightClassify;
    }

    class ProfileMetric;
    typedef std::shared_ptr<ProfileMetric> spProfileMetric;

    // CAlgDuchaEngine
    class CAlgDuchaEngine : public ICAlgEngine{
    public:
        CAlgDuchaEngine() = default;
        virtual ~CAlgDuchaEngine() = default;

    public:
        virtual void Init(const inference::EngineConfig &config, int &code);
        virtual void GetBatchFrames(VecImage &queue, VecImage &image_map) const;
        void GetBatchFramesDetect(VecImage &queue, VecImage &image_map) const; 
        void GetBatchFramesFight(VecImage &queue, VecImage &image_map) const; 
        virtual void Process(CFlowDispatch &dsp);
        void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) override;

        virtual void AddStream(const std::string &channel_id, const std::string &config);
        virtual void RemoveStream(const std::string &channel_id);
        virtual void AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config);
        virtual void RemoveViolation(const std::string &channel_id, const std::string &violation_id);
        virtual AlgRender GetRender(const std::string &violation_code) const override;

        static void Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug=false);
    protected:
        class process_step_data {
        public:
            explicit process_step_data(VecImage data) 
                : data_(data)
                , status_(eWaitProcess)
            {}
            VecImage& Data() { return data_; }
            bool IsProcessing() { auto status = status_.load(); return status == eProcessing; }
            bool IsProcessed() { auto status = status_.load(); return status == eProcessed; }
            void SetProcessing() { status_ = eProcessing; }
            void SetProcessed() { status_ = eProcessed; }

        protected:
            enum _status{
                eWaitProcess, eProcessing, eProcessed,
            };
            VecImage data_;
            std::atomic<_status> status_;
        };
        typedef std::shared_ptr<process_step_data> process_step;

        struct ChannelUpdateData {
            std::string     channel_id_;
            bool            add;
            std::string     violation_id;
            float           fps;
        };
        typedef std::shared_ptr<ChannelUpdateData> spChannelUpdateData;

        struct ChannelData { // need all ptr
            typedef std::set<std::string> string_set;
            std::string         channel_id_;
            bool                has_fight_;
            bool                has_detect_;
            int                 fight_interval_;
            int                 detect_interval_;
            string_set          violations;
            prometheus::spCounter      detect_object_counter_;
            std::vector<float>  fight_score_buffer_;

            bool UpdateCfg(ChannelUpdateData update, const inference::Ducha &config) {
                if (update.channel_id_ != channel_id_) {
                    return false;
                }
                if (update.add) {
                    this->violations.insert(update.violation_id);
                    if (update.violation_id == DUCHA_FIGHT_CODE) {
                        this->has_fight_ = true;
                    } else {
                        this->has_detect_ = true;
                    }
                } else {
                    this->violations.erase(update.violation_id);
                    if (update.violation_id == DUCHA_FIGHT_CODE) {
                        this->has_fight_ = false;
                    } else {
                        this->has_detect_ = false;
                        for(const auto& v : this->violations) {
                            if (v != DUCHA_FIGHT_CODE && v != DUCHA_NOMASK_CODE) {
                                this->has_detect_ = true;
                                break;
                            }
                        }
                    }
                }

                auto fps = update.fps;
                if (fps <= 0.0f) {
                    fps = 25;
                }
                if (this->has_detect_) {
                    auto detect_interval = (int)round(fps / config.attribute_fps());
                    if (detect_interval <= 0) {
                        detect_interval = 1;
                    }
                    this->detect_interval_ = detect_interval;
                }
                if (this->has_fight_) {
                    auto fight_interval = (int)round(fps / config.fight_fps());
                    if (fight_interval <= 0) {
                        fight_interval = 1;
                    }
                    this->fight_interval_ = fight_interval;
                }

                return true;
            }
        };
        typedef std::shared_ptr<ChannelData> spChannelData;

        class safeChannelDataMap {
            public:
            spChannelData find(const std::string& key) const {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                return (it != map_.end()) ? it->second : nullptr;
            }
            spChannelData insert(const std::string& key, spChannelData value) {
                std::unique_lock<std::mutex> lock{lock_};
                auto old_value = map_[key];
                map_[key] = value;
                return old_value;
            }
            spChannelData erase(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                spChannelData old_value;
                if (it != map_.end()) {
                    old_value = it->second;
                    map_.erase(it);
                }
                return old_value;
            }
            typedef std::function<bool(const std::string&, spChannelData)> visiter;
            void visit(visiter v) const{
                std::unique_lock<std::mutex> lock{lock_};
                for(auto &kv : map_) {
                    if(!v(kv.first, kv.second)) {
                        break;
                    }
                }
            }
        protected:
            mutable std::mutex lock_;
            std::unordered_map<std::string, spChannelData> map_;
        };

    protected:
        void duchaProcess(const VecImage &images);
        void FightProcess(const VecImage &images);
        void FightBufferProcess(const VecImage &images);
        bool Skip(int64_t count, int interval) const;
        void PrintDetectInfo(const VecImage& images)const;
        void PrintFightInfo(const VecImage& images)const;

    protected:
        std::string config_str_;
        inference::Ducha config_;

    protected:
        std::mutex ducha_lock_;
        std::mutex fight_lock_;
        std::shared_ptr<Detect::DetectModule> detector_ = nullptr;
        std::shared_ptr<duchaMar::DuchaMarModule> duchaMar_ = nullptr;
        std::shared_ptr<duchaHoi::DuchaHoiModule> duchaHoi_ = nullptr;
        std::shared_ptr<FightClassify::FightClassify> Fight_classify_ = nullptr;

    protected:
        safeChannelDataMap              channel_data_map_;
        Queue<spChannelUpdateData>      channel_data_update_queue_;
#ifdef USE_MEDIA_UTILS
        std::unordered_map<std::string, float> violation_fps_map_;
#endif
    protected:
        spProfileMetric profile_metric_detector_;
        spProfileMetric profile_metric_ducha_mar_;
        spProfileMetric profile_metric_ducha_hoi_;
        spProfileMetric profile_metric_figit_classify_;

    protected:
        std::list<process_step> detect_queue_;
        std::list<process_step> fight_queue_;
    };

}

#endif //TAD_ALG_DUCHA_ENGINE_HPP
