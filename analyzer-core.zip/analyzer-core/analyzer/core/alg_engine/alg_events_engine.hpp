#ifndef TAD_ALG_HIGHWAY_ENGINE_HPP
#define TAD_ALG_HIGHWAY_ENGINE_HPP

#include <memory>
#include <mutex>
#include <atomic>
#include <functional>

#include "common/Queue.h"
#include "alg_engine_interface.hpp"
#include "serving/config.pb.h"

namespace prometheus{
    class Counter;
    typedef std::shared_ptr<Counter> spCounter;
}

namespace FLOW {

    namespace Detect {
        class DetectModule;
    }
    namespace Weather {
        class Weather;
    }
    namespace BreakIn {
        class BreakInDetector;
    }
	namespace Leftobject {
        class Leftobject;
        class LeftobjectDetect;
        class LeftobjectClassify;
    }
    namespace Throwobject {
        class Throwobject;
    }
    namespace TrafficSign {
         class TrafficSign;
    }
    namespace Fire{ 
        class Fire;
    }

    class ProfileMetric;
    typedef std::shared_ptr<ProfileMetric> spProfileMetric;

    // CAlgVehicleEngine
    class CAlgEventsEngine : public ICAlgEngine{
    public:
      CAlgEventsEngine() = default;
        virtual ~CAlgEventsEngine() = default;

    public:
        virtual void Init(const inference::EngineConfig &config, int &code);
        virtual void GetBatchFrames(VecImage &queue, VecImage &image_map) const;
        virtual void Process(CFlowDispatch &dsp);

        //virtual void GetBatchFrames(spImageQueue queue, VecImage *image_map) const;
        //virtual void Process(const VecImage &in, VecImage *out);
        void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) override;
        virtual void AddStream(const std::string &channel_id, const std::string &config);
        virtual void RemoveStream(const std::string &channel_id);
        virtual void AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config);
        virtual void RemoveViolation(const std::string &channel_id, const std::string &violation_id);
        
    protected:
        struct ChannelData { // need all ptr
            enum {
                ACTION_UNDEFINE,
                ACTION_ADD_VIOLATION,
                ACTION_REMOVE_VIOLATION,
                ACTION_REMOVE_STREAM,
            };
            struct violationInfo {
                std::string violation_code_;
                std::string engine_name_;
            };
            std::string                         channel_id_;
            std::shared_ptr<RectF>              detect_roi_;
            std::shared_ptr<ImageObjectsInfo>   last_image_;
            std::shared_ptr<Leftobject::Leftobject> leftobject_engine_;
            std::shared_ptr<Throwobject::Throwobject> throwobject_engine_;
            bool                                leftobject_detect_flag;
            int action_;
            std::map<std::string,int>           highway_engines_;       // engine->ref_count
            std::map<std::string,violationInfo> highway_violations_;    // id->{code,engine}
            std::string                         engine_name_;
            std::string                         violation_code_;
            std::string                         violation_id_;
            prometheus::spCounter               detect_object_counter_;
            prometheus::spCounter               track_object_counter_;
            bool UpdateCfg(ChannelData other) {
                if ( other.channel_id_ != channel_id_ ) {
                    return false;
                }
                if ( other.detect_roi_ ) {
                    this->detect_roi_.swap(other.detect_roi_);
                }
                if ( other.last_image_ ) {
                    this->last_image_.swap(other.last_image_);
                }
                if ( ACTION_ADD_VIOLATION == other.action_ ) {
                    this->highway_engines_[other.engine_name_]++;
                    this->highway_violations_[other.violation_id_].engine_name_     = other.engine_name_;
                    this->highway_violations_[other.violation_id_].violation_code_  = other.violation_code_;
                    LOG(INFO)<<"add after: "<<other.engine_name_<<", "<<this->highway_engines_[other.engine_name_];
                } else if ( ACTION_REMOVE_VIOLATION == other.action_ &&
                            highway_violations_.count(other.violation_id_)) {
                    const auto engine_name      = highway_violations_[other.violation_id_].engine_name_;
                    const auto violation_code   = highway_violations_[other.violation_id_].violation_code_;
                    other.engine_name_      = highway_violations_[other.violation_id_].engine_name_;
                    other.violation_code_   = highway_violations_[other.violation_id_].violation_code_;
                    this->highway_violations_.erase(other.violation_id_);
                    this->highway_engines_[engine_name]--;
                    if (this->highway_engines_[engine_name] <= 0){
                        this->highway_engines_.erase(engine_name);
                    }
                }
                return true;
            }
        };
        typedef std::shared_ptr<ChannelData> spChannelData;

        class safeChannelDataMap {
            public:
            spChannelData find(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                return (it != map_.end()) ? it->second : nullptr;
            }
            spChannelData insert(const std::string& key, spChannelData value) {
                std::unique_lock<std::mutex> lock{lock_};
                auto old_value = map_[key];
                map_[key] = value;
                return old_value;
            }
            spChannelData erase(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                spChannelData old_value;
                if (it != map_.end()) {
                    old_value = it->second;
                    map_.erase(it);
                }
                return old_value;
            }
            typedef std::function<bool(const std::string&, spChannelData)> visiter;
            void visit(visiter v) const{
                std::unique_lock<std::mutex> lock{lock_};
                for(auto &kv : map_) {
                    if(!v(kv.first, kv.second)) {
                        break;
                    }
                }
            }
        protected:
            mutable std::mutex lock_;
            std::unordered_map<std::string, spChannelData> map_;
        };

    protected:
        void weatherProcess(const VecImage &images);
        void FireProcess(const VecImage &images);
        void BreakInProcess(const VecImage &images);
        void LeftobjectVibeProcess(spChannelData channel, const VecImage &images);
        void LeftobjectDetectProcess(const VecImage &images);
        void LeftobjectClassifyProcess(const VecImage &images);
        void ThrowobjectDetectProcess(spChannelData channel, const VecImage &images);
        void ThrowobjectVehicleProcess(const VecImage &images);
        void TrafficSignProcess(const VecImage &images);
        void GetBatchFrames(VecImage &queue, VecImage &image_map, std::function<bool(int)> need_skip, int max_batch) const;
        void GetBatchFramesBreakIn(VecImage &queue, VecImage &image_map);
        void GetBatchFramesLeftobject(VecImage &queue, VecImage &image_map);
        void GetBatchFramesThrowobject(VecImage &queue, VecImage &image_map);
        void GetBatchFramestrafficsign(VecImage &queue, VecImage &image_map);
        bool SkipBreakIn(int64_t count);
        bool match_code(const std::string& violation_code, std::string* engine_name) const;

    protected:
        inference::Events config_;

    protected:
        Profiler weather_profiler_;
        Profiler fire_profiler_;
        Profiler breakin_profiler_;
        Profiler leftobject_profiler_;
        Profiler throwobject_profiler_;
        Profiler traffic_sign_profiler_;
        std::mutex detect_weather_lock_;
        std::mutex detect_fire_lock_;
        std::mutex detect_breakin_lock_;
		std::mutex detect_leftobject_lock_;
		std::mutex detect_leftobject_detect_lock_;
		std::mutex detect_leftobject_classify_lock_;
        std::mutex detect_throwobject_lock_;
        std::mutex throwobject_vehicle_lock_;
		std::mutex traffic_sign_lock_;
        std::shared_ptr<Weather::Weather> weather_engine_ = nullptr;
        std::shared_ptr<Fire::Fire> fire_engine_ = nullptr;
        std::shared_ptr<BreakIn::BreakInDetector> breakin_engine_ = nullptr;

        std::shared_ptr<Leftobject::LeftobjectDetect> leftobject_detect_engine_ = nullptr;
        std::shared_ptr<Leftobject::LeftobjectClassify> leftobject_classify_engine_ = nullptr;
        std::shared_ptr<Throwobject::Throwobject> throwobject_detect_engine_ = nullptr;
        std::shared_ptr<Throwobject::Throwobject> throwobject_vehicle_engine_ = nullptr;
        std::shared_ptr<TrafficSign::TrafficSign > traffic_sign_engine_ = nullptr;

    protected:
        spProfileMetric profile_metric_weather_;
        spProfileMetric profile_metric_fire_;
        spProfileMetric profile_metric_breakin_;
        spProfileMetric profile_metric_left_object_;
        spProfileMetric profile_metric_throw_object_;
        spProfileMetric profile_metric_traffic_sign_;

    protected:
        safeChannelDataMap      channel_data_map_;
        Queue<spChannelData>    channel_data_update_queue_;

    };

}

#endif //TAD_ALG_VEHICLE_ENGINE_HPP
