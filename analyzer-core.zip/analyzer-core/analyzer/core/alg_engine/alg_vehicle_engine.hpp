#ifndef TAD_ALG_VEHICLE_ENGINE_HPP
#define TAD_ALG_VEHICLE_ENGINE_HPP

#include <memory>
#include <mutex>
#include <atomic>

#include "alg_engine_interface.hpp"
#include "core/flow_dispatch.hpp"

#include "common/Queue.h"
#include "common/helper.hpp"
#include "serving/config.pb.h"
#include "violation/flow/violation_flow_code.hpp"
#include "algorithm/track/track_wraper.hpp"
namespace prometheus{
    class Counter;
    typedef std::shared_ptr<Counter> spCounter;
}

namespace FLOW {

    namespace TrafficLight {
        class TrafficLightRecog;
    }

    namespace Detect {
        class DetectModule;
    }
    namespace Plate {
        class VehiclePlate;
        class WaiMaiPlate;
    }
    namespace Attribute {
        class VehicleAttributeModule;
        class BehaviourAttributeModule;
        class ConstructionAttributeModule;
    }

    class ProfileMetric;
    typedef std::shared_ptr<ProfileMetric> spProfileMetric;

    // CAlgVehicleEngine
    class CAlgVehicleEngine : public ICAlgEngine{
    public:
        CAlgVehicleEngine() = default;
        virtual ~CAlgVehicleEngine() = default;
        virtual std::vector<int> GetDetectInputShapes()const;

    public:
        virtual void Init(const inference::EngineConfig &config, int &code);
        virtual void GetBatchFrames(VecImage &queue, VecImage &image_map) const;
        virtual void Process(CFlowDispatch &dsp);
        void ProcessByName(const std::string& name, const ShellFrame_Ptr &shell_frame, VecBoxF &boxes) override;

        virtual void AddStream(const std::string &channel_id, const std::string &config);
        virtual void RemoveStream(const std::string &channel_id);
        virtual void AddViolation(const std::string &channel_id, const std::string &violation_id, const std::string &config);
        virtual void RemoveViolation(const std::string &channel_id, const std::string &violation_id);

        virtual AlgRender GetRender(const std::string &violation_code) const override;

    protected:
        static bool match_code(const std::string& code);
        typedef std::function<bool(const spImageObjectsInfo processedFrame)> fnSkipChecker;
        static void FillSkipframe(fnSkipChecker check, const spImageObjectsInfo processedFrame, spImageObjectsInfo currentFrame);
        static void Render(const ImageObjectsInfo& image_objects, Mat_Ptr mat, bool enable_tracking_debug=false);
        
    protected:
        struct ChannelData { // need all ptr
            typedef std::unordered_map<std::string, PosInfo> PosInfoMap;
            std::string                         channel_id_;
            std::shared_ptr<Track::TADTracker>  tracker_;
            std::unordered_map<std::string, BoxF>  traffic_light_box_;
            std::shared_ptr<RectF>              person_detect_roi_;
            std::shared_ptr<RectF>              detect_roi_;
            std::shared_ptr<ImageObjectsInfo>   last_image_;
            static constexpr int                MAX_ATTR_PROCEE_COUNT = (OBJECT_TYPE_NONMOTOR > OBJECT_TYPE_PERSON ? \
                                                                        OBJECT_TYPE_NONMOTOR : OBJECT_TYPE_PERSON);
            std::shared_ptr<ImageObjectsInfo>   last_attr_image_[MAX_ATTR_PROCEE_COUNT+1];
            PosInfoMap                          ptz_config_;
            spProfileMetric                     profile_metric_tracker_;
            prometheus::spCounter               detect_object_counter_;
            prometheus::spCounter               track_object_counter_;
            //是否已经构建topo
            bool                                if_already_updated_topo_=false;
            //for tracker only
            std::string                         violation_id_;
            std::string                         roi_config_;
            std::string                         config_;
            enum ACTION {
                ACTION_NONE                     =-1,
                ACTION_ADD                      =0,
                ACTION_REMOVE_STREAM            =1,
                ACTION_UPDATE_TRAFFIC_LIGHT_BOX =2,
                ACTION_ADD_PTZ                  =3,
                ACTION_REMOVE_PTZ               =4,
                ACTION_UPDATE_TRACKER           =5,
                ACTION_REMOVE_VIOLATION         =6,
                ACTION_REMOVE_TRACKER_ROI       =7,
                ACTION_ADD_STREAM               =8,
                ACTION_REMOVE_TRAFFIC_LIGHT_BOX =9,
            };
            ACTION action_ = ACTION_NONE;

            bool UpdateCfg(const ChannelData& other) {
                switch (other.action_)
                {
                case ACTION_UPDATE_TRAFFIC_LIGHT_BOX:
                    for (auto& kv : other.traffic_light_box_){
                        traffic_light_box_[kv.first] = kv.second;
                    }
                    break;
                case ACTION_ADD_PTZ:
                    for (auto& kv : other.ptz_config_){
                        ptz_config_[kv.first] = kv.second;
                    }
                    break;
                case ACTION_REMOVE_PTZ:
                    for (auto& kv : other.ptz_config_){
                        ptz_config_.erase(kv.first);
                    }
                    break;
                case ACTION_UPDATE_TRACKER:
                    this->tracker_->AddStreamRoiConfig(other.violation_id_, other.roi_config_);
                    this->tracker_->AddStreamTrackingType(other.violation_id_, other.config_);
                    break; 
                case ACTION_REMOVE_TRACKER_ROI:
                    this->tracker_->RemoveStreamRoiConfig(other.violation_id_);
                    break;
                case ACTION_REMOVE_TRAFFIC_LIGHT_BOX:
                    traffic_light_box_.erase(other.violation_id_);
                    break;
                default:
                    return false;
                    break;
                }
                return true;
            }
            bool MatchPtz(const PosInfo& ptz) const{
                for (auto& kv : ptz_config_)
                {
                    if(Helper::is_same_postion(ptz, kv.second)) {
                        return true;
                    }
                }
                return ptz_config_.empty();
            }
        };
        typedef std::shared_ptr<ChannelData> spChannelData;

        class safeChannelDataMap {
            public:
            spChannelData find(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                return (it != map_.end()) ? it->second : nullptr;
            }
            spChannelData insert(const std::string& key, spChannelData value) {
                std::unique_lock<std::mutex> lock{lock_};
                auto old_value = map_[key];
                map_[key] = value;
                return old_value;
            }
            spChannelData erase(const std::string& key) {
                std::unique_lock<std::mutex> lock{lock_};
                auto it = map_.find(key);
                spChannelData old_value;
                if (it != map_.end()) {
                    old_value = it->second;
                    map_.erase(it);
                }
                return old_value;
            }
            typedef std::function<bool(const std::string&, spChannelData)> visiter;
            void visit(visiter v) const{
                std::unique_lock<std::mutex> lock{lock_};
                for(auto &kv : map_) {
                    if(!v(kv.first, kv.second)) {
                        break;
                    }
                }
            }
        protected:
            mutable std::mutex lock_;
            std::unordered_map<std::string, spChannelData> map_;
        };

    protected:
        void detectProcess(const VecImage &images);
        void trackProcess(spChannelData channel, const VecImage &images);
        void attrProcess(const VecImage &images);
        virtual bool needAtrrBox(const BoxF& box, ObjectType type);
        void attrProcessV2(const VecImage &images, ObjectType type);
        bool Skip(int64_t count) const;
        void PrintInfo(const VecImage& images)const;

    protected:
        inference::Traffic config_;

    protected:
        std::mutex detect_lock_;
        std::mutex attr_lock_;
        std::shared_ptr<Detect::DetectModule> detector_ = nullptr;
        std::shared_ptr<Detect::DetectModule> detector2_ = nullptr;
        std::shared_ptr<Plate::VehiclePlate> vehicle_plate_ = nullptr;
        std::shared_ptr<Plate::WaiMaiPlate> waimai_plate_ = nullptr;
        std::shared_ptr<Attribute::VehicleAttributeModule> vehicle_attr_ = nullptr;
        std::shared_ptr<Attribute::VehicleAttributeModule> vehicle_attr2_ = nullptr;
        std::shared_ptr<Attribute::BehaviourAttributeModule> behaviour_attr_ = nullptr;
        std::shared_ptr<Attribute::BehaviourAttributeModule> behaviour_attr2_ = nullptr;
        std::shared_ptr<Attribute::ConstructionAttributeModule> person_attr_ = nullptr;
        std::shared_ptr<Attribute::ConstructionAttributeModule> person_attr2_ = nullptr;
        std::shared_ptr<TrafficLight::TrafficLightRecog> traffic_light_recog_ = nullptr;

    protected:
        spProfileMetric profile_metric_detector_;
        spProfileMetric profile_metric_vehicle_plate_;
        spProfileMetric profile_metric_waimai_plate_;
        spProfileMetric profile_metric_vehicle_attr_;
        spProfileMetric profile_metric_vehicle_attr2_;
        spProfileMetric profile_metric_nonmotor_attr_;
        spProfileMetric profile_metric_nonmotor_attr2_;
        spProfileMetric profile_metric_person_attr_;
        spProfileMetric profile_metric_person_attr2_;
        spProfileMetric profile_metric_traffic_light_;

    protected:
        //channel_data_map_ 保存流相关信息，只在process里写
        safeChannelDataMap      channel_data_map_;
        //调用接口时将修改操作写到队列里
        Queue<spChannelData>    channel_data_update_queue_;

    };

}

#endif //TAD_ALG_VEHICLE_ENGINE_HPP
