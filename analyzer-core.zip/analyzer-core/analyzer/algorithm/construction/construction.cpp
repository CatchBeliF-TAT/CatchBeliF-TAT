#include "construction.hpp"

#include "common/log.hpp"
#include "common/util.hpp"

namespace FLOW {

namespace Construction {

//#define TRAFFIC_SIGN_MAX_BATCH_SIZE 2

void Construction::Setup(const std::vector<char>& meta_net_data,
                         const inference::Algorithm& config) {
  LOG(INFO) << "Setup Construction Module";
  config_ = config;
  if (config_.detect_thresholds_size() == 0) {
    config_.add_detect_thresholds(config_.detect_threshold());
  }
  Algorithm::Argument arguments;
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size",
                                   config.batch_size());  // 2
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
  engine_ = std::make_shared<Algorithm::Detect>(
      meta_net_data.data(), meta_net_data.size(), arguments);
  LOG(INFO) << "Finished setup Construction Module";
}

void Construction::Process(const std::vector<std::shared_ptr<cv::Mat>>& images,
                           std::vector<cv::Rect> rois,
                           std::vector<Construction_Event>& events) {
  std::vector<cv::Mat> im_mats;
  for (int i = 0; i < images.size(); i++) {
    im_mats.emplace_back(*images[i], rois[i]);
  }

  std::vector<Algorithm::VecBoxF> Gboxes;
  engine_->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecBoxF>&>(
      im_mats, Gboxes);

  events.clear();
  for (int i = 0; i < Gboxes.size(); i++) {
    const auto& roi = rois[i];
    auto& boxes = Gboxes[i];
    Construction_Event event;
    for (auto& box : boxes) {
      auto threshold =
          box.label < config_.detect_thresholds_size()
              ? config_.detect_thresholds(box.label)
              : config_.detect_thresholds(config_.detect_thresholds_size() - 1);
      if (box.score > threshold) {
        BoxF box_t(box.xmin + roi.x, box.ymin + roi.y, box.xmax, box.ymax);
        box_t.shigong_attr.type = box.label + construction_label;
        box_t.shigong_attr.score = box.score;
        event.objs.push_back(box_t);
      }
    }
    events.push_back(event);
  }
}

}  // namespace Construction

}  // namespace FLOW
