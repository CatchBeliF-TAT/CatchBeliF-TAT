#ifndef ANALYZER_ALGORITHM_CONSTRUCTION_CONSTRUCTION_HPP_
#define ANALYZER_ALGORITHM_CONSTRUCTION_CONSTRUCTION_HPP_

#include "common/tad_internal.hpp"

#include "algorithm/algorithm.hpp"
#include "serving/config.pb.h"
namespace FLOW {

namespace Construction {

#ifndef construction_label
#define construction_label 0x0901
#endif

#define ConstructionType_size 10

enum ConstructionDetType {
  Construction_Warning_Sign_det = construction_label,  //施工警告标志
  Construction_Crowd_Control_Barrier_det,              //铁马
  Construction_Guard_Bar_det,                          //护栏
  Construction_Reflective_Road_Cone_det,               //反光路锥
  Construction_Watersafety_Barrier_det,                //水马
};

enum ConstructionType {
  Construction_Worker = construction_label,  //施工人员
  Construction_NonWorker,                    //非施工人员
  Construction_Crowd_Control_Barrier,        //铁马
  Construction_Warning_Sign,                 // 施工警告标志
  Construction_Reflective_Road_Cone,         //反光路锥
  Construction_Watersafety_Barrier,          //水马
  Construction_Truck,                        //施工车辆
  Construction_Guard_Bar,                    //护栏
  Construction_Special_Car,                  //特种车辆
  // Construction_Paver, //铺路车
  // Construction_Road_Roller, //压路车
  // Construction_Excavator, //挖掘车
  // Construction_Long_Arm_car, //施工长臂车
};

inline std::string helperConstructionType(ConstructionType t) {
  switch (t)
  {
  case Construction_Worker:
    return "Worker";
  case Construction_NonWorker:
    return "NonWorker";
  case Construction_Crowd_Control_Barrier:
    return "Crowd_Control_Barrier";
  case Construction_Warning_Sign:
    return "Warning_Sign";
  case Construction_Reflective_Road_Cone:
    return "Reflective_Road_Cone";
  case Construction_Watersafety_Barrier:
    return "Watersafety_Barrier";
  case Construction_Truck:
    return "Paver";
  case Construction_Guard_Bar:
    return "Guard_Bar";
  case Construction_Special_Car:
    return "Special_Car";
  default:
    break;
  }
  char buf[32];
  sprintf(buf, "%d", t);
  return buf;
}

class Construction {
 public:
  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config);

  void Process(const std::vector<std::shared_ptr<cv::Mat>>& images,
               std::vector<cv::Rect> rois,
               std::vector<Construction_Event>& events);

 private:
  std::shared_ptr<Algorithm::Detect> engine_ = nullptr;
  inference::Algorithm config_;
};

}  // namespace Construction

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_TRAFFIC_SIGN_TRAFFIC_SIGN_HPP_
