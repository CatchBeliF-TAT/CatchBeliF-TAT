#ifndef ANALYZER_ALGORITHM_FIRE_FIRE_HPP_
#define ANALYZER_ALGORITHM_FIRE_FIRE_HPP_

#include "common/tad_internal.hpp"

#include "algorithm/algorithm.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace Fire {

class Fire {
 public:
  void Setup(const std::vector<char>& meta_net_data, const inference::Algorithm& config);

  void Process(const std::vector<std::shared_ptr<cv::Mat>>& images,
               std::vector<Fire_Event>& events);

 private:
  std::shared_ptr<Algorithm::Extract> classify_ = nullptr;
};

}  // namespace Fire

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_fire_fire_HPP_
