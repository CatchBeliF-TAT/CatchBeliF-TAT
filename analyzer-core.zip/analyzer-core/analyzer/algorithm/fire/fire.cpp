#include "fire.hpp"

#include "common/log.hpp"

namespace FLOW {

namespace Fire {

void Fire::Setup(const std::vector<char>& meta_net_data, const inference::Algorithm& config) {
  LOG(INFO) << "Setup FireClassifyModule";

  Algorithm::Argument arguments;
  arguments.AddSingleArgument<int>("net_id", 0);
  arguments.AddSingleArgument<std::string>("method", "classify");
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());//16
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddRepeatedArgument<std::string>("categories", {"feature"});
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());

  classify_ = std::make_shared<Algorithm::Extract>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  LOG(INFO) << "Finished setup FireClassifyModule";
}

void Fire::Process(const std::vector<std::shared_ptr<cv::Mat>>& images,
                   std::vector<Fire_Event>& events) {
  std::vector<cv::Mat> im_mats;
  for (auto& image : images) {
    im_mats.push_back(*image);
  }

  std::vector<std::map<std::string, Algorithm::VecFloat>> Gvalues;
  classify_->Run<const std::vector<cv::Mat>&,
                 std::vector<std::map<std::string, Algorithm::VecFloat>>&>(
      im_mats, Gvalues);

  events.clear();
  for (const auto& values : Gvalues) {
    const auto& score = values.at("feature");
    Fire_Event event{};
    event.predict_fire_score = score[0];
    event.predict_fire_name = "fire";
    event.predict_smoke_score = score[1];
    event.predict_smoke_name = "smoke";
    events.push_back(event);
  }
}

}  // namespace Fire

}  // namespace FLOW
