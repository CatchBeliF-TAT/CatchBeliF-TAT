#include "whiteflag.hpp"
#include "common/log.hpp"
#include "flag_common.hpp"

namespace FLOW {
namespace Parade {
void WhiteFlag::Process(const cv::Mat &im_mat, const VecBoxF &objs, ParadeInfo &parade_info) {

  auto& event = parade_info.white_flag_objs_;
  event.clear();

  parsedBoundRect.clear();

  for (const auto &obj : objs) {
    if (obj.label != OBJECT_TYPE_PERSON ) {
      continue;
    }
    //裁剪上半身扩大
    cv::Rect flag_detect_area;
    expandPersonRect(im_mat, obj, flag_detect_area);
    cv::Mat image_cut = cv::Mat(im_mat, flag_detect_area);

    //计算梯度    
    cv::Mat img_gray, grad;
    cv::cvtColor(image_cut, img_gray, cv::COLOR_BGR2GRAY);
    int scale = 1;
    int delta = 0;
    int ddepth = CV_8U;
    cv::Mat grad_x, grad_y;
    cv::Mat abs_grad_x, abs_grad_y;
    Sobel( img_gray, grad_x, ddepth, 1, 0, 3, scale, delta, cv::BORDER_DEFAULT );
    convertScaleAbs( grad_x, abs_grad_x );
    Sobel( img_gray, grad_y, ddepth, 0, 1, 3, scale, delta, cv::BORDER_DEFAULT );
    convertScaleAbs( grad_y, abs_grad_y );
    addWeighted( abs_grad_x, 1, abs_grad_y, 0.5, 0, grad );

    //二值化
	  threshold(grad, grad, 0, 255, cv::THRESH_OTSU);

    //膨胀腐蚀
    cv::Mat structure_element = getStructuringElement(cv::MORPH_RECT, cv::Size(2,2));
    dilate(grad, grad, structure_element);
    erode(grad, grad, structure_element);

    //选出最大连通域
    cv::Mat grad_;
    grad_ = grad.clone();
    std::vector<std::vector<cv::Point> > contours;
	  std::vector<cv::Vec4i> hierarchy;
    cv::findContours(grad_, contours, hierarchy, cv::RETR_TREE, cv::CHAIN_APPROX_SIMPLE, cv::Point(0, 0));
    std::vector<cv::Rect> boundRect(contours.size());
    for (int i = 0; i < contours.size(); i++) {
      boundRect[i] = cv::boundingRect(contours[i]);
      double g_dsrcArea = contourArea(contours[i]);
      double white_perc = double(g_dsrcArea) / double(boundRect[i].area());
      cv::Rect pRect;
      pRect.x = flag_detect_area.x + boundRect[i].x;
      pRect.y = flag_detect_area.y + boundRect[i].y;
      pRect.width = boundRect[i].width;
      pRect.height = boundRect[i].height;
      double w_h = double(boundRect[i].height) / double(boundRect[i].width);
      if (white_perc > WHITE_PERCENT_MIN && w_h > 0.5 && w_h < 2 && boundRect[i].height>20 && boundRect[i].width>20) {
        parsedBoundRect.push_back(pRect);
      }
    }
  }

  nms(parsedBoundRect, 0, im_mat, MIN_FLAG_AREA);

  int flag_number = 0;

  for (auto bound : parsedBoundRect) {
    bool has_intersect = false;
    for (auto bufferbound : bufferBoundRect) {
      double iou_bb = IOU(bound, bufferbound);
      if (iou_bb > 0.2 && iou_bb < 0.8) {
        has_intersect = true;
      }
    }
    if (has_intersect) {
      flag_number++;
      BoxF box;
      box.xmin = bound.x;
      box.ymin = bound.y;
      box.xmax = bound.x + bound.width;
      box.ymax = bound.y + bound.height;
      event.push_back(box);
    }
  }

  if (flag_number < FLAG_NUMBER_THRETHOLD) {
    event.clear();
    report_buffer = std::max(--report_buffer, 0);
    if (report_buffer > 0) {
      for (auto box: bufferBoxes) {
        event.push_back(box);
      }
    }
  } else {
    bufferBoxes = event;
    report_buffer = 5;
  }

  bufferBoundRect.clear();
  bufferBoundRect.assign(parsedBoundRect.begin(), parsedBoundRect.end());
}
}
}  // namespace FlagDetect
