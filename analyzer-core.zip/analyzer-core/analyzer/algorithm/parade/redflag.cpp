#include "redflag.hpp"
#include "common/log.hpp"
#include "flag_common.hpp"

namespace FLOW {
namespace Parade{
void RedFlag::Process(const cv::Mat &im_mat, const VecBoxF &objs, ParadeInfo &parade_info){
    //LOG(WARNING)<<"<===============redflag begin===============>";
    int parade_person_number = 0;
    auto& event = parade_info.red_flag_objs_;
    auto& red_flag_boxes = parade_info.red_flag_detect_objs_;
    //LOG(WARNING)<<"    red_flag_boxes: "<<red_flag_boxes.size();
    event.clear();
    parsedBoundRect.clear();

    for (const auto &obj : objs) {
        cv::Rect flag_detect_area;
        expandPersonRect(im_mat, obj, flag_detect_area);

        cv::Mat image_cut = cv::Mat(im_mat, flag_detect_area);
        cv::Mat img_out;
        cv::cvtColor(image_cut, img_out, cv::COLOR_BGR2HSV);

        cv::Mat hsv_zero = cv::Mat::zeros(img_out.size(), CV_8UC1);
        std::vector<cv::Mat> hsv;
        cv::split(img_out, hsv);
        double H=0.0,S=0.0,V =0.0; 
        int filter_width = (obj.xmax-obj.xmin) * 0.8;
        int filter_height = (obj.ymax-obj.ymin) * 0.8;
        int filter_xmin = (img_out.cols - filter_width) / 2;
        int filter_ymin = img_out.rows - filter_height;
        int filter_xmax = filter_xmin + filter_width;
        auto hsv_zero_ptr = hsv_zero.data;
        for (int i = 0; i < img_out.rows; i++){
            auto img_ptr_h = hsv[0].ptr<uchar>(i);
            auto img_ptr_s = hsv[1].ptr<uchar>(i);
            auto img_ptr_v = hsv[2].ptr<uchar>(i);
            auto hsv_zero_ptr = hsv_zero.ptr<uchar>(i);
            for (int j = 0; j < img_out.cols; j++){
                H = img_ptr_h[j];
                S = img_ptr_s[j];
                V = img_ptr_v[j];
                if ((( H >= 156 && H <= 180) || (H >= 0 && H <= 10)) && (S >= 120 && S <= 255) && (V>120 && V < 255)){
                    if (j > filter_xmin && j < filter_xmax && i > filter_ymin){
                        continue;
                    }else{
                        hsv_zero_ptr[j] = 255;
                    }
                }
            }
        }

        std::vector<std::vector<cv::Point> > contours;
        std::vector<cv::Vec4i> hierarchy;
        cv::findContours(hsv_zero, contours, hierarchy, cv::RETR_TREE, cv::CHAIN_APPROX_SIMPLE, cv::Point(0, 0));
        std::vector<cv::Rect> boundRect(contours.size());
        for (int i = 0; i < contours.size(); i++) {
            boundRect[i] = cv::boundingRect(contours[i]);
        }

        int ivalred = cv::countNonZero(hsv_zero);
        float red_perc = float(ivalred) / float((obj.xmax-obj.xmin)*(obj.ymax-obj.ymin));
        //误报多就用模型过滤一下，误报少就不用了
        if (red_perc > RED_PERCENT_MIN && red_perc < RED_PERCENT_MAX && intersectRect(red_flag_boxes, flag_detect_area, 0)) {
            //LOG(WARNING)<<"    person obj is ok ";
            //LOG(WARNING)<<"    boundRect size "<<boundRect.size();
            parade_person_number++; 
            for (auto bound : boundRect) {
                cv::Rect pRect;
                pRect.x = flag_detect_area.x + bound.x;
                pRect.y = flag_detect_area.y + bound.y;
                pRect.width = bound.width;
                pRect.height = bound.height;
                parsedBoundRect.push_back(pRect);
            }
        }else {
            //LOG(WARNING)<<"    person obj not require percentage ";
        }
    }

    //LOG(WARNING)<<"    parsedBoundRect size before: "<<parsedBoundRect.size();
    nms(parsedBoundRect, 0, im_mat, MIN_FLAG_AREA);
    //LOG(WARNING)<<"    parsedBoundRect size after: "<<parsedBoundRect.size();

    if (parade_person_number >= PARADE_PERSON_THRETHOLD && parsedBoundRect.size() >= FLAG_NUMBER_THRETHOLD) {
        for (auto bound : parsedBoundRect) {
            BoxF box;
            box.xmin = bound.x;
            box.ymin = bound.y;
            box.xmax = bound.x + bound.width;
            box.ymax = bound.y + bound.height;
            event.push_back(box);
        }
        //LOG(WARNING)<<"    event size: "<<event.size();
    }else{
        //LOG(WARNING)<<"    not require threshold "<<event.size();
    }
    //LOG(WARNING)<<"<===============redflag end===============>";
}

}
}

