#include "common/tad_internal.hpp"

namespace FLOW{

inline bool intersectRect(const VecBoxF &vecRectA, const cv::Rect &rectB, const float intersectPercent){
    for (auto rectA : vecRectA) {
        if (rectA.xmin > rectB.x + rectB.width) continue;
        if (rectA.ymin > rectB.y + rectB.height) continue;
        if ((rectA.xmax) < rectB.x) continue;
        if ((rectA.ymax) < rectB.y) continue;
        float colInt = std::min(rectA.xmax, rectB.x + float(rectB.width)) - std::max(rectA.xmin, float(rectB.x));
        float rowInt = std::min(rectA.ymax, rectB.y + float(rectB.height)) - std::max(rectA.ymin, float(rectB.y));
        float intersection = colInt * rowInt;
        float areaA = (rectA.xmax-rectA.xmin) * (rectA.ymax-rectA.ymin);
        float areaB = rectB.width * rectB.height;
        float intersectionPercent = intersection / (areaA + areaB - intersection);
        if (intersectionPercent > intersectPercent) {
            return true;
        }
    }
	return false;
}

//取人的上半身扩大
inline void expandPersonRect(const cv::Mat &im_mat, const BoxF &box, cv::Rect &flag_detect_area) {
  int xmin = 0, ymin = 0;
  int xmax = im_mat.cols;
  int ymax = im_mat.rows;
  auto box_width = box.xmax - box.xmin;
  auto box_height = box.ymax - box.ymin;
  int expand_width = box_width * 0.3;
  int expand_height = box_height * 0.2;
  xmin = std::max(xmin, int(box.xmin - expand_width));
  ymin = std::max(ymin, int(box.ymin - expand_height));
  xmax = std::min(xmax, int(box.xmax + expand_width));
  ymax = std::min(ymax, int(box.ymin + box_height/2 + expand_height));
  flag_detect_area = cv::Rect(xmin, ymin, xmax - xmin, (ymax- ymin)/2);
}

//交叉面积比例
inline double IOU(const cv::Rect& r1, const cv::Rect& r2) {
    int x1 = std::max(r1.x, r2.x);
    int y1 = std::max(r1.y, r2.y);
    int x2 = std::min(r1.x+r1.width, r2.x+r2.width);
    int y2 = std::min(r1.y+r1.height, r2.y+r2.height);
    int w = std::max(0, (x2-x1+1));
    int h = std::max(0, (y2-y1+1));
    double inter = w * h;
    double o = inter / (r1.area() + r2.area() - inter);
    return (o >= 0) ? o : 0;
}

//删除重叠的框
inline void nms(std::vector<cv::Rect>& proposals, const double nms_threshold, const cv::Mat &im_mat, const int min_flag_area) {
    std::vector<int> scores;
    for(auto i : proposals) scores.push_back(i.area());

    std::vector<int> index;
    for(int i = 0; i < scores.size(); ++i){
        index.push_back(i);
    }

    sort(index.begin(), index.end(), [&](int a, int b){
        return scores[a] > scores[b];
    }); 

    std::vector<bool> del(scores.size(), false);
    for(size_t i = 0; i < index.size(); i++){
        if( !del[index[i]]){
            for(size_t j = i+1; j < index.size(); j++){
                if(IOU(proposals[index[i]], proposals[index[j]]) > nms_threshold){
                    del[index[j]] = true;
                }
            }
        }
    }

    std::vector<cv::Rect> new_proposals;
    for(const auto i : index){
        if(!del[i] && proposals[i].area() > min_flag_area) new_proposals.push_back(proposals[i]);
    }
    proposals = new_proposals;
}

}