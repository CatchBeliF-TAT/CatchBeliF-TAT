#ifndef SCOPE_CORE_WHITEFLAG_HPP
#define SCOPE_CORE_WHITEFLAG_HPP

#include "serving/config.pb.h"
#include "common/tad_internal.hpp"
#include <memory>

namespace FLOW {
namespace Parade {
class WhiteFlag {
  public:
    void Process(const cv::Mat &im_mat, const VecBoxF &objs, ParadeInfo &parade_info);
    void Setup(const inference::Algorithm& config){
      config_ = config;
    }
  private:
    inference::Algorithm config_;
    float WHITE_PERCENT_MIN = 0;
    int PARADE_PERSON_THRETHOLD = 5;
    int FLAG_NUMBER_THRETHOLD = 2;
    int MIN_FLAG_AREA = 100;
    std::vector<cv::Rect> parsedBoundRect;
    std::vector<cv::Rect> bufferBoundRect;
    std::vector<BoxF> bufferBoxes;
    int report_buffer = 0;
};
}
}
#endif
