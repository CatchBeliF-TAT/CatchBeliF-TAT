#include "crowdregion.hpp"
#include "common/log.hpp"
#include "common/util.hpp"
#include "mot.hpp"

#include <stdio.h>
#include "common/type.hpp"

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/video/background_segm.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/objdetect/objdetect.hpp>
#include "algorithm/algorithm.hpp"

//#define SAVE_IMG
using namespace cv;
using namespace std;

namespace FLOW {

namespace Crowdcount{

static int PixInPoly(POINT &pp,
	std::vector<int> polys)
{
	// POINT pp;
	// pp.x = point[0];
	// pp.y = point[1];

	POINT p1, p2;                
	int         ncross;               
	double      x;                    
	int         i;

	ncross = 0;

	for (i = 0; i < polys.size()/2; i++)
	{
		p1.x = polys[2*i];
		p1.y = polys[2*i+1];
		
		p2.x = polys[2*(i+1) % polys.size()];
		p2.y = polys[(2*(i+1)+1) % polys.size()];

		if (p1.y == p2.y)                     
		{
			continue;
		}
		if (pp.y >= max(p1.y, p2.y))       
		{
			continue;
		}
		if (pp.y < min(p1.y, p2.y))        
		{
			continue;
		}
		
		x = (double)(pp.y - p1.y) * ((double)(p2.x - p1.x) / (p2.y - p1.y)) + p1.x;

		if (x > pp.x)
		{
			ncross++;
		}
	}
	return (ncross % 2 == 1);
}



// void crowdregion::crowdregion_process(const cv::Mat &im_mat, VecFloat &head, VecInt &head_shape, vector<cv::Rect> &out_rect,vector<int> &jj_roi_num)
cv::Mat crowdregion::crowdregion_process(const cv::Mat &im_mat, cv::Mat &density_map,vector<cv::Rect> &out_rect,vector<int> &jj_roi_num, float& score)

{
    // get jignzhi_fore_groung
    Mat foreground_mask_false(0,0,CV_8UC1);// h  w   type
    // if (head_shape.size() == 0){
	//     return;
    // }
    if (density_map.channels()!= 1 ){
        LOG(ERROR)<< "invalid density map channel nums "<< density_map.channels();
        return foreground_mask_false; 
    }

 //   frame_num++;
 //   if(frame_num==FRAME_SKIP+1)
 //   {
 //      frame_num = 1;
 //   }

    int INNER_MIN_CROWD_EVENT_THROD_NUM = MIN_CROWD_EVENT_THROD_NUM;

    /*ignore time process
        time_t tt = time(NULL);
        tm* t= localtime(&tt);
        printf("*****************\n");
        printf("%d-%2d-%2d %2d:%2d:%2d\n", t->tm_year + 1900,t->tm_mon + 1,t->tm_mday,t->tm_hour,t->tm_min,t->tm_sec);
        printf("*****************\n");
        if(t->tm_hour<6 && t->tm_hour >18)
        {
            INNER_MIN_CROWD_EVENT_THROD_NUM = MIN_CROWD_EVENT_THROD_NUM + 5;
        }
    */

    // img_h=576;
    // img_w=768;    
    img_h=density_map.rows;
    img_w=density_map.cols;
     LOG(INFO)<< "density_map rows ,cols : "<< img_h << "," << img_w;
    
    img_resize_h = img_h;
    img_resize_w = img_w;

    int img_resize_h_scale = img_h/4;
    int img_resize_w_scale = img_w/4;


    // get mv_foreground
    //cv::resize(im_mat, in_mat_resize, cv::Size(img_resize_w,img_resize_h));
    cv::resize(im_mat, in_mat_resize, cv::Size(img_resize_w_scale,img_resize_h_scale));
    cvtColor(in_mat_resize, in_mat_gray, cv::COLOR_BGR2GRAY);
    //bg_model->apply(in_mat_gray, in_mat_mask, 0.01);
    //bg_model( in_mat_gray, in_mat_mask, 0.01 );
    cv::Mat in_mat_mask_scale;
    //bg_model( in_mat_gray, in_mat_mask_scale, 0.01 );

    bg_model->apply(in_mat_gray, in_mat_mask_scale, 0.01);
//    if(FRAME_SKIP != frame_num)
//    {
//        return;
//    }

    // here do valid roi and remove roi check
    // modify head
    if (validrois.size() >0){
        for (int i=0;i<validrois.size();i++){
	    std::vector<int> validPoly;
	    for (int j=0;j<validrois[i].size()/2;j++){
		validPoly.push_back(int(validrois[i][2*j]*img_w/im_mat.cols));
		validPoly.push_back(int(validrois[i][2*j+1]*img_h/im_mat.rows));
	    }
 
	    for (int h=0;h<img_h;h++){
        float *row_data = density_map.ptr<float>(h);
		for (int w=0;w<img_w;w++){
		    int index = h*img_w+w;
            POINT point;
            point.x = w;
            point.y = h;
            
		    if ((row_data[w]/100.0)>0.0005f && (!PixInPoly(point,validPoly))){
		        row_data[w] = 0.f;
		    }
		}
	    }
	}
 
    }




    if (removerois.size() >0){
        for (int h=0;h<img_h;h++){
            float *row_data = density_map.ptr<float>(h);

            for (int w=0;w<img_w;w++){
                int index = h*img_w+w;
                if ((row_data[w]/100.0)<0.0005f)
			        continue;

            // std::vector<int> point;
            //         point.push_back(w);
            //         point.push_back(h);
                POINT point;
                point.x = w;
                point.y = h;
                bool if_in_remove = false;

                for (int i=0;i<removerois.size();i++){
                    std::vector<int> removePoly;
                    for (int j=0;j<removerois[i].size()/2;j++){
                    removePoly.push_back(int(removerois[i][2*j]*img_w/im_mat.cols));
                    removePoly.push_back(int(removerois[i][2*j+1]*img_h/im_mat.rows));
                    }

                    if_in_remove = PixInPoly(point,removePoly);
                    if (if_in_remove)
                        break;
                }
                if (if_in_remove)
                    row_data[w] = 0.f;
            } // w
        } // h
    } // remove roi

     
    //threshold( in_mat_mask, in_mat_mask, 10, 255, CV_THRESH_BINARY );
    //dilate(in_mat_mask, in_mat_mask, Mat(), cv::Point(-1,-1),1);
    //erode(in_mat_mask, in_mat_mask, Mat(), cv::Point(-1,-1), 1);
 
    threshold( in_mat_mask_scale, in_mat_mask_scale, 10, 255, cv::THRESH_BINARY );
    dilate(in_mat_mask_scale, in_mat_mask_scale, Mat(), cv::Point(-1,-1),1);
    erode(in_mat_mask_scale, in_mat_mask_scale, Mat(), cv::Point(-1,-1), 1);
    cv::resize(in_mat_mask_scale, in_mat_mask, cv::Size(img_w,img_h));
    
    // get jignzhi_fore_groung
    Mat foreground_mask(img_h,img_w,CV_8UC1);// h  w   type
    for (int i = 0; i<img_h; ++i)
    {
        float *row_data = density_map.ptr<float>(i);

        for (int j = 0; j<img_w; ++j)
        {
            // int index =  i*img_w + j; 
            if((row_data[j]/100.0)>0.0005f && in_mat_mask.at<uchar>(i, j)<255)
            {
                foreground_mask.at<uchar>(i, j) = 255;  
            }
            else
            {
                foreground_mask.at<uchar>(i, j) = 0;  
            } 
        }
    }   
    
 #ifdef SAVE_IMG
     char save_p[64];
    
     memset(save_p,'\0',64*sizeof(char)); //mv_foreground
     int frame_n=0;
     sprintf(save_p,"output_%d.jpg",frame_n);
     cv::imwrite(save_p, in_mat_mask); 
    
     memset(save_p,'\0',64*sizeof(char)); //jignzhi_foreground
     frame_n=1;
     sprintf(save_p,"output_%d.jpg",frame_n);
     cv::imwrite(save_p, foreground_mask); 
 #endif
    
    // get rect of jingzhi_foreground
    //threshold( foreground_mask, foreground_mask, 10, 255, CV_THRESH_BINARY );
    dilate(foreground_mask, foreground_mask, Mat(), cv::Point(-1,-1),1);
    erode(foreground_mask, foreground_mask, Mat(), cv::Point(-1,-1), 1);
    //dilate(foreground_mask, foreground_mask, Mat(), cv::Point(-1,-1),3);    
 
 #ifdef SAVE_IMG
     memset(save_p,'\0',64*sizeof(char));
     frame_n=2;
     sprintf(save_p,"output_%d.jpg",frame_n);
     cv::imwrite(save_p, foreground_mask); 

     cv::Size dsize = cv::Size(768, 576);
     Mat im_mat2;
     resize(im_mat, im_mat2, dsize);
 #endif
    
    vector<cv::Rect> roi_rect1;
    Mat contours_image;
    foreground_mask.copyTo( contours_image );
    vector<vector<cv::Point>> contours;
    vector<Vec4i> hierarchy;
    findContours( contours_image, contours, hierarchy,cv::RETR_EXTERNAL,cv::CHAIN_APPROX_SIMPLE, cv::Point(0, 0) );
    for( int i = 0; i< contours.size(); i++ )
    {
        cv::Rect r;
        r = boundingRect( contours[i] );
        if( r.height<30 || r.width<30 )//////////////////////////
            continue;
        roi_rect1.push_back(r);
 #ifdef SAVE_IMG
         cv::Scalar color = cv::Scalar( 155, 155, 155 );
         cv::rectangle( foreground_mask, r.tl(), r.br(), color, 3, 8, 0 );
         cv::rectangle( im_mat2, r.tl(), r.br(), color, 3, 8, 0 );
 #endif
    }  
    
 #ifdef SAVE_IMG
     memset(save_p,'\0',64*sizeof(char));
     frame_n=3;
     sprintf(save_p,"output_%d.jpg",frame_n);
     cv::imwrite(save_p, im_mat2); 
    
     memset(save_p,'\0',64*sizeof(char));
     frame_n=4;
     sprintf(save_p,"output_%d.jpg",frame_n);
     cv::imwrite(save_p, foreground_mask);
 #endif
    
    //erode(foreground_mask, foreground_mask, Mat(), cv::Point(-1,-1), 3); // for get real number
    
 #ifdef SAVE_IMG
     memset(save_p,'\0',64*sizeof(char));
     frame_n=5;
     sprintf(save_p,"output_%d.jpg",frame_n);
     cv::imwrite(save_p, foreground_mask);
 #endif    
    // get crowd_rect & num of 
    out_rect.clear(); 
    jj_roi_num.clear();
    for( int k = 0; k< roi_rect1.size(); k++ )
    {
        float sum =0.f;
        int yb = roi_rect1[k].y+roi_rect1[k].height;
        int xr = roi_rect1[k].x+roi_rect1[k].width;
        for(int j=roi_rect1[k].y;j<yb; j++)
        {
            int n = j*img_w;
            for(int i=roi_rect1[k].x;i<xr; i++)
            {
                if(foreground_mask.at<uchar>(j, i) ==255)
                {
                    //printf("%.2f,",head[n+i]);
                    sum = sum + density_map.ptr<float>(j)[i];// * accelarate
                }
                
            }
        }
        sum = sum / 100.0;
        //printf("sum=%f\n",sum);
        if(sum > INNER_MIN_CROWD_EVENT_THROD_NUM )//////////////////////////
        {
           {
               out_rect.push_back(roi_rect1[k]); 
               jj_roi_num.push_back((int)sum);
               //printf("cluster occur!\n");
           }
        }
    }
        score= 0.0;
        for(int j=0;j<foreground_mask.rows; j++)
        {
            
            for(int i=0;i<foreground_mask.cols; i++)
            {
                //if(foreground_mask.at<uchar>(j, i) ==255)
                {
                    //printf("%.2f,",head[n+i]);
                    foreground_mask.at<uchar>(j, i) = density_map.ptr<float>(j)[i];// * accelarate
                    score += density_map.ptr<float>(j)[i];
                }
                
            }
        }
    //LOG(INFO)<<"foreground_mask channel: "<<foreground_mask.channels()<<"rows: "<<foreground_mask.rows<<"cols: "<<foreground_mask.cols;
    return foreground_mask;
}
int crowdregion::getImg_h()
{
    return img_h;
}
int crowdregion::getImg_w()
{
    return img_w;
}

}    
}  

