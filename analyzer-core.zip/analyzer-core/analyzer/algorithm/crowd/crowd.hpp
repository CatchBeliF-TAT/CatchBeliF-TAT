#ifndef ANALYZER_ALGORITHM_CROWD_CROWD_HPP_
#define ANALYZER_ALGORITHM_CROWD_CROWD_HPP_

#include <memory>
#include "common/type.hpp"
#include "common/tad_internal.hpp"
#include "algorithm/algorithm.hpp"
#include "serving/config.pb.h"

namespace FLOW {
namespace CrowdDensity{

class Crowd {
 public:
  Crowd(const std::vector<char>& meta_net_data, const inference::Algorithm& config);

  void BatchPredict(const VecMat &images,std::vector<cv::Mat> &images_result);

  void Release(); 
  
  VecInt GetInputShapes() { return in_shape_; }

 private:

  VecInt in_shape_;

  std::shared_ptr<Algorithm::Map> engine_ = nullptr;
};

}  // namespace
}

#endif  // ANALYZER_ALGORITHM_CROWD_CROWD_HPP_

