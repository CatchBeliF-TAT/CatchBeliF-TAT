#include "crowd.hpp"
#include "common/util.hpp"

namespace FLOW {

namespace CrowdDensity{

//#define MAX_BATCH_SIZE 12


Crowd::Crowd(const std::vector<char>& meta_net_data, const inference::Algorithm& config) 
{
    Algorithm::Argument trt_arguments;
    trt_arguments.AddSingleArgument<int>("net_id", 0);
    trt_arguments.AddSingleArgument<std::string>("method", "density");
    trt_arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
    trt_arguments.AddSingleArgument<int>("device_id", config.gpu_id());
    trt_arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());//12
    trt_arguments.AddSingleArgument<bool>("use_fp16", true);
    trt_arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
    trt_arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());

    engine_ = std::make_shared<Algorithm::Map>(meta_net_data.data(), meta_net_data.size(), trt_arguments);

    std::vector<VecInt> network_input_shapes;
    engine_->Run<const std::string &, std::vector<VecInt> &>(
        "GetNetworkInputShapes", network_input_shapes);
    in_shape_ = network_input_shapes[0];

}

  
void Crowd::Release() {}
    
void Crowd::BatchPredict(const VecMat &images, std::vector<cv::Mat> &images_result){

  std::vector<cv::Mat> images2;
  for (auto i = 0 ;i< images.size(); i++){
    images2.push_back(*images[i]);
  }

  Profiler profiler_crowd;
  profiler_crowd.tic("Crowd::BatchPredic");
  engine_->Run<const std::vector<cv::Mat> &, std::vector<cv::Mat> &>(images2, images_result);
  profiler_crowd.toc("Crowd::BatchPredic");
//  LOG(INFO) << profiler_crowd.get_stats_str();
 // LOG(INFO) << "size:"<< images.size();

}

    
}  // namespace Detection

}  // namespace Scope

