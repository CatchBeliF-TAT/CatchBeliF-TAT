#ifndef ANALYZER_ALGORITHM_CROWD_MOT_HPP_
#define ANALYZER_ALGORITHM_CROWD_MOT_HPP_

#define LEVEL1_IOU_ONLY 
//#define LEVEL2_LESS_TRACK 
//#define LEVEL3_TRACK 

#ifndef LEVEL1_IOU_ONLY
    #include"staple/staple_tracker.hpp"
#endif

#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include<stdio.h>
#include<math.h>
#include<vector>

namespace FLOW {
namespace Crowdcount{

#ifdef WIN32
#define max(x,y) (x)>(y)?(x):(y)
#define min(x,y) (x)>(y)?(y):(x)
#endif

#ifdef LEVEL3_TRACK
#define MIN_PAIR_RATIO  0.3
#else
#define MIN_PAIR_RATIO  0.25
#endif


#define MAX_NUM_PERSON 20
#define MAX_DIS_NUM_PERSON 5//
#define UPDATE_INTER 1
#define TRACK_J_NUM 32

#define VCA_MAX_VERTEX_NUM 100

typedef struct _VCA_POINT_I_ {
	int x;
	int y;
} VCA_POINT_I;

typedef struct _VCA_POLYGON_I_ {
	unsigned int vertex_num;
	bool valid;
        std::vector<VCA_POINT_I> point;
} VCA_POLYGON_I;

typedef struct _POINT_ {
	float x;
	float y;
} POINT;

typedef struct _DST_LIST_ {
	float xl;
	float yt;
	float xr;
	float yb;
    int roi_num = 0;
} DST_LIST;

//
typedef struct _TRACK_LIST_ {
	int idd = 0;
	int dis = 0;
	int valid = 0;
	float xl = 0.0;
	float yt = 0.0;
	float xr = 0.0;
	float yb = 0.0;
	int dec_num = 0;
	int track_num = 0;
	int nonUpdateNum = 0;//
    int roi_num = 0;
#ifndef LEVEL1_IOU_ONLY
	STAPLE_TRACKER staple;
#endif
} TRACK_LIST;

// for event
typedef struct _TRACK_RES_ {
	int idd = 0;
	int dis = 0;
	int valid = 0;
	float xl = 0.0;
	float yt = 0.0;
	float xr = 0.0;
	float yb = 0.0;

    int roi_num = 0;
	int track_j_num = 0;
	POINT track_j[TRACK_J_NUM];

	int event_1_ed = 8;//must not 0~7 ,for event 1
	int event_2_track_j_num = 0;
} TRACK_RES;


void QN_MOT_staple_for_person(std::vector<DST_LIST> &in_dst_list, cv::Mat &img, TRACK_LIST person_list[MAX_NUM_PERSON],
								TRACK_RES res_person_list[MAX_NUM_PERSON],
							  int scene_change_sign);

}
}
#endif  // ANALYZER_ALGORITHM_CROWD_MOT_HPP_

