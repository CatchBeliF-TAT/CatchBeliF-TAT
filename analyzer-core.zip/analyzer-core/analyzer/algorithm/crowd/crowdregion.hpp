#ifndef ANALYZER_ALGORITHM_CROWD_CROWDREGION_HPP_
#define ANALYZER_ALGORITHM_CROWD_CROWDREGION_HPP_

#include <memory>
#include <vector>

#include <opencv2/opencv.hpp>

namespace FLOW {
namespace Crowdcount{

class crowdregion {
public:
    
    crowdregion(std::vector<std::vector<float> > validRois, std::vector<std::vector<float> > removeRois, int min_crowd_num_throd){
      MIN_CROWD_EVENT_THROD_NUM = min_crowd_num_throd;
      validrois = validRois;
      removerois = removeRois;
    }
    
    cv::Mat crowdregion_process(const cv::Mat &im_mat, cv::Mat &density_map,std::vector<cv::Rect> &out_rect,std::vector<int> &jj_roi_num, float& score);
    int getImg_h();
    int getImg_w();
    
    cv::Ptr<cv::BackgroundSubtractorMOG2> bg_model = cv::createBackgroundSubtractorMOG2();

    int frame_num=-1;
private:
    

    int img_h;
    int img_w;
    int img_resize_h; 
    int img_resize_w;
    cv::Mat in_mat_resize;
    cv::Mat in_mat_gray;
    cv::Mat in_mat_mask;
    int FRAME_SKIP = 5;
    int MIN_CROWD_EVENT_THROD_NUM = 10;
    std::vector<std::vector<float> > validrois;
    std::vector<std::vector<float> > removerois;

};
  
}  
    
}

#endif  // ANALYZER_ALGORITHM_CROWD_CROWDREGION_HPP_

