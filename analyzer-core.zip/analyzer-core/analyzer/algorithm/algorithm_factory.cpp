#include <regex>

#include "common/io.hpp"
#include "algorithm_factory.hpp"

#include "detect/detect.hpp"
#include "plate/vehicle_plate.hpp"
#include "traffic_light/traffic_light_recog.hpp"
#include "vehicleattribute/vehicle_attr.hpp"

namespace FLOW {

template<typename T>
void init_with_config(T& engine, const inference::Algorithm& config) {
    std::vector<char> data;
    if ( ! IO::ReadBinaryFile(config.model_path(), &data)) {
        LOG(FATAL) << "Load model " << config.type() << ", path :" << config.model_path() << " error";
        return;
    }
    LOG(INFO) << "Load model " << config.type() << ", path :" << config.model_path() << ", size :" << data.size();
    int code=0;
    engine.set_up(data, config, code);
    return;
}

sp_flow_process_base CreateAlgorithm(const inference::Algorithm& config) {
    sp_flow_process_base retv;
    if (config.type() == "detect_general") {
        auto origin_process = std::make_shared<Detect::sync_detect_general>();
        init_with_config(*origin_process, config);
        retv = origin_process;
    } else if (config.type() == "traffic_light") {
        auto origin_process = std::make_shared<TrafficLight::sync_traffic_light>();
        init_with_config(*origin_process, config);
        retv = origin_process;
    } else if (config.type() == "vehicle_attribute"){
        auto origin_process = std::make_shared<Attribute::sync_vehicle_attr>();
        init_with_config(*origin_process, config);
        retv = origin_process;
    } else if (config.type() == "attribute"){
        auto origin_process = std::make_shared<Attribute::sync_attr>();
        init_with_config(*origin_process, config);
        retv = origin_process;
    } else if (config.type() == "vehicle_plate") {
        auto origin_process = std::make_shared<Plate::sync_vehicle_plate>();
        init_with_config(*origin_process, config);
        retv = origin_process;
    } else {
        LOG(WARNING) << "algorithm type:" << config.type() <<", not found !";
    }

    return retv;
}

map_process_base  CreateAlgorithm(const algorithm_config& configs) {
    map_process_base retv;
    for (auto config : configs) {
        if (config.name()!="" && retv.count(config.name())==0 ){
            retv[config.name()] = CreateAlgorithm(config);
        }
    }
    return retv;
}

} // FLOW