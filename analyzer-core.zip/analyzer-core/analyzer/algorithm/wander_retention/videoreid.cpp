/*
 * @Author: qiushuang
 * @Date: 2020-11-05 11:18:56
 * @LastEditTime: 2020-12-14 17:14:37
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /analyzer-flow/analyzer/algorithm/videoreid/videoreid.cpp
 */

#include "videoreid.hpp"

namespace FLOW {

namespace WanderRetention {

void VideoReid::save_images(const cv::Mat &frame, std::vector<TracketBox> &reuslt) {
    for (auto &it : miss){
        it.second = true;
    }
    std::vector<cv::Mat> v_Mat;
    std::vector<int> v_id;

    for (auto &box : reuslt){
        if (box.label != label_type || box.valid == 0){
            continue;
        }
        if (box.rect.w < 20 || box.rect.h < 20){
            continue;
        }

        auto it = miss.find(box.id);
        if (it != miss.end()){
            miss[box.id] = false;
            miss[real_id[box.id]] = false;
            end_time[real_id[box.id]] = frame_num;
            end_time[box.id] = frame_num;
        }

        cv::Rect rect(box.rect.x,
                    box.rect.y,
                    box.rect.w,
                    box.rect.h);
        cv::Mat im_crop = frame(rect).clone();
        cv::cvtColor(im_crop, im_crop, cv::COLOR_BGR2RGB);
        cv::Mat im_resize;
        cv::resize(im_crop, im_resize, scale);
        v_id.push_back(box.id);
        v_Mat.push_back(im_resize);
    }
    std::vector<std::map<std::string, std::vector<float>>> person_quality_out;
    auto& person_quality_model = VideoReidModel::get_instance().person_quality_model;
    person_quality_model->Run<const std::vector<cv::Mat>&, std::vector<std::map<std::string, std::vector<float>>>&>(v_Mat, person_quality_out);
    
    forward_or_not = false;
    old_mapping.clear();

    for (int i=0; i<v_id.size(); i++){
        if (person_quality_out[i].at("feature")[1] < person_quality_out[i].at("feature")[0]){
            continue;
        }
        auto it = id_image_list.find(v_id[i]);
        if (it == id_image_list.end()){
            std::vector<cv::Mat> Mat;
            Mat.push_back(v_Mat[i]);
            id_image_list.insert({v_id[i], Mat});
            
            end_time[v_id[i]] = frame_num;
            real_id[v_id[i]] = v_id[i];
            miss[v_id[i]] = false;
            start_time[v_id[i]] = frame_num;
        }else{
            id_image_list[v_id[i]].push_back(v_Mat[i]);
            if (id_image_list[v_id[i]].size() == aggregation_num){
                forward_or_not = true;
            }
            if (id_image_list[v_id[i]].size() > aggregation_num){
                // int rand_num = std::rand() % (aggregation_num+2);
                // id_image_list[v_id[i]].erase(id_image_list[v_id[i]].begin() + rand_num);
                // id_image_list[v_id[i]].erase(id_image_list[v_id[i]].begin() + aggregation_num);
                id_image_list[v_id[i]].erase(id_image_list[v_id[i]].begin());
                if (frame_num % (5 * FRAMERATE) == 0){
                    // id_image_list[v_id[i]].erase(id_image_list[v_id[i]].begin());
                    forward_or_not = true;
                    if (real_id[v_id[i]]!=v_id[i]){
                        miss[real_id[v_id[i]]] = true;
                        old_mapping.insert({v_id[i], real_id[v_id[i]]});
                        real_id[v_id[i]] = v_id[i];
                    }
                }
            }
        }
    }
}

void VideoReid::run_and_replace(std::vector<TracketBox> &reuslt){
#ifdef USE_FAISS
    std::vector<float> query_features;
    std::vector<int> query_id;
    std::vector<int> extra_base_id;
    std::vector<cv::Mat> query_indata, extra_base_indata;
    // profiler.tic("videoreid");
    for (auto &image : id_image_list){
        int nRet = std::count(base_id.begin(), base_id.end(), image.first);
        if (miss[real_id[image.first]] && nRet == 0){
            if (image.second.size() == aggregation_num){
                for (int i=0; i<aggregation_num; i++){
                    cv::Mat mat = image.second[i].clone();
                    extra_base_indata.push_back(mat);
                }
                base_id.push_back(image.first);
                extra_base_id.push_back(image.first);
            }  
        }
        if (!miss[image.first] && image.second.size()==aggregation_num && end_time[image.first] == frame_num){
            for (int i=0; i<aggregation_num; i++){
                cv::Mat mat = image.second[i].clone();
                query_indata.push_back(mat);
            }
            query_id.push_back(image.first);
        }
    }
    
    std::vector<std::map<std::string, std::vector<float>>> query_out, extra_base_out;
    auto& videoreid_model = VideoReidModel::get_instance().videoreid_model;
    videoreid_model->Run<const std::vector<cv::Mat>&, std::vector<std::map<std::string, std::vector<float>>>&>(query_indata, query_out);
    if (extra_base_id.size() > 0){
        videoreid_model->Run<const std::vector<cv::Mat>&, std::vector<std::map<std::string, std::vector<float>>>&>(extra_base_indata, extra_base_out);
    }
    for (int i=0; i<query_id.size(); i++){
        query_features.insert(query_features.end(), 
                            query_out[i*aggregation_num].at("feature").begin(), 
                            query_out[i*aggregation_num].at("feature").end());
    }
    for (int i=0; i<extra_base_id.size(); i++){
        base_features.insert(base_features.end(),
                            extra_base_out[i*aggregation_num].at("feature").begin(),
                            extra_base_out[i*aggregation_num].at("feature").end());
    }

    // int d = query_out[0].at("feature").size();
    size_t nq = query_id.size();
    size_t nb = base_id.size();
    if (base_id.size() == 0){
        return;
    }
    
    // profiler.toc("videoreid");
    // profiler.tic("search");
    faiss::IndexFlatIP index(feature_dim);
    index.add(nb, base_features.data());
    int k = 1;
    std::vector<faiss::Index::idx_t> nns (k * nq);
    std::vector<float>               dis (k * nq);
    index.search(nq, query_features.data(), k, dis.data(), nns.data());
    for (int i=0; i<query_id.size(); i++){
        if (dis[i] > threshold && miss[real_id[base_id[nns[i]]]] && start_time[base_id[nns[i]]] < start_time[query_id[i]]){
            real_id[query_id[i]] = real_id[base_id[nns[i]]];
            end_time[base_id[nns[i]]] = end_time[query_id[i]];
            end_time[real_id[base_id[nns[i]]]] = end_time[query_id[i]];
            miss[real_id[base_id[nns[i]]]] = false;
            std::cout<<query_id[i]<<" "<<base_id[nns[i]]<<" "<<real_id[base_id[nns[i]]]<<" "<<dis[i]<<std::endl;
        }
    }
    for (auto om : old_mapping){
        if (real_id[om.first] == om.first && miss[om.second]){
            real_id[om.first] = om.second;
        }
    }
    // profiler.toc("search");
#endif
}

void VideoReid::forget(std::vector<TracketBox> &reuslt){
    for (auto it = end_time.begin();it!=end_time.end();){
        if (frame_num - it->second > forget_time){
            for (auto it_i = id_image_list.begin(); it_i!=id_image_list.end(); it_i++){
                if (it_i->first == it->first){
                    id_image_list.erase(it_i);
                    break;
                }
            }
            for (auto it_m = miss.begin(); it_m!=miss.end(); it_m++){
                if (it_m->first == it->first){
                    miss.erase(it_m);
                    break;
                }
            }
            for (auto it_r = real_id.begin(); it_r!=real_id.end(); it_r++){
                if (it_r->first == it->first){
                    real_id.erase(it_r);
                    break;
                }
            }
            for (auto it_s = start_time.begin(); it_s != start_time.end(); it_s++){
                if (it_s->first == it->first){
                    start_time.erase(it_s);
                    break;
                }
            }
            for (int i=0; i<base_id.size(); i++){
                if (base_id[i] == it->first){
                    base_id.erase(base_id.begin()+i);
                    base_features.erase(base_features.begin()+i*feature_dim, base_features.begin()+(i+1)*feature_dim);
                    break;
                }
            }
            it = end_time.erase(it);
        }else{
            it++;
        }
    }
    std::vector<TracketBox> reuslt_copy;
    for (int i=0; i<reuslt.size(); i++){
        if (reuslt[i].label != label_type || reuslt[i].valid == 0){
            continue;
        }
        if (reuslt[i].rect.w  < 20 || reuslt[i].rect.h < 20){
            continue;
        }
        auto it_r = real_id.find(reuslt[i].id);
        // auto it_om = old_mapping.find(reuslt[i].id);
        // if (it_om != old_mapping.end()){
        //     if (real_id[it_om->first] != it_om->second && real_id[it_om->first] != it_om->first){
        //         std::cout<<"forget id:"<<it_om->first<<" "<<real_id[it_om->first]<<" "<<it_om->second<<" "<<frame_num<<std::endl;
        //         continue;
        //     }
        // }
        if (it_r != real_id.end()){
            reuslt_copy.push_back(reuslt[i]);
        }
    }
    reuslt = reuslt_copy;
}

void VideoReid::process(const cv::Mat &frame, std::vector<TracketBox> &reuslt, int _label_type){
    frame_num++;
    label_type = _label_type;
    // profiler.tic("save");
    save_images(frame, reuslt);
    // profiler.toc("save");
    
    if (forward_or_not){
        // profiler.tic("run");
        run_and_replace(reuslt);
        // profiler.toc("run");
    }
    // profiler.tic("forget");
    forget(reuslt);
    // profiler.toc("forget");
}

void VideoReid::setup(const inference::Flow &config, const std::string stream_id){
    auto config_person_quality = config.wander_retention_person_quality();
    scale = cv::Size(config_person_quality.img_resize_w_scale(), config_person_quality.img_resize_h_scale());
    forget_time = config.wander_retention_reid().reid_forget_time();
    stream_id_ = stream_id;
}

void VideoReidModel::setup(const std::vector<char>& meta_net_data_person_quality, const std::vector<char>& meta_net_data_videoreid, const inference::Flow& config, int& code){

    config_person_quality_ = config.wander_retention_person_quality();
    config_reid_ = config.wander_retention_reid();


    LOG(INFO) << "Setup VideoReid Module";

    Algorithm::Argument reid_arguments;
    reid_arguments.AddSingleArgument<std::string>("backend_type", "Native");
    reid_arguments.AddSingleArgument<int>("max_batch_size", config_reid_.batch_size());
    reid_arguments.AddRepeatedArgument<std::string>("categories", {"feature"});
    reid_arguments.AddSingleArgument<bool>("cache_engine", config_reid_.cache_engine());
    reid_arguments.AddSingleArgument<std::string>("cache_engine_dir", config_reid_.cache_engine_dir());

    Algorithm::Argument person_quality_arguments;
    person_quality_arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
    person_quality_arguments.AddSingleArgument<int>("device_id", config_person_quality_.gpu_id());
    person_quality_arguments.AddSingleArgument<int>("max_batch_size", config_person_quality_.batch_size());
    person_quality_arguments.AddRepeatedArgument<std::string>("categories", {"feature"});
    person_quality_arguments.AddSingleArgument<bool>("cache_engine", config_person_quality_.cache_engine());
    person_quality_arguments.AddSingleArgument<std::string>("cache_engine_dir", config_person_quality_.cache_engine_dir());

    std::vector<char> videoreid_meta_net_data;
    Algorithm::ReadBinaryFile(config_reid_.model_path(), &videoreid_meta_net_data);
    videoreid_model = std::make_shared<Algorithm::Extract>(videoreid_meta_net_data.data(), videoreid_meta_net_data.size(), reid_arguments);
    std::shared_ptr<Algorithm::Extract> videoreid_model = std::make_shared<Algorithm::Extract>(meta_net_data_videoreid.data(), meta_net_data_videoreid.size(), reid_arguments);

    std::vector<char> pq_meta_net_data;
    Algorithm::ReadBinaryFile(config_person_quality_.model_path(), &pq_meta_net_data);
    person_quality_model = std::make_shared<Algorithm::Extract>(pq_meta_net_data.data(), pq_meta_net_data.size(), person_quality_arguments);
    std::shared_ptr<Algorithm::Extract> person_quality_model = std::make_shared<Algorithm::Extract>(
    meta_net_data_person_quality.data(), meta_net_data_person_quality.size(), person_quality_arguments);
    
    code = FLOW::module_status_success;
}

} // namespace WanderRetention

} //namespace FLOW
