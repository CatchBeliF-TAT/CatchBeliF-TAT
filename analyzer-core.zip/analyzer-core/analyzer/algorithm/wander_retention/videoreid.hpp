/*
 * @Author: qiushuang
 * @Date: 2020-11-05 11:19:03
 * @LastEditTime: 2020-12-14 17:14:15
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /analyzer-flow/analyzer/algorithm/wander_retention/videoreid.hpp
 */
#ifndef ANALYZER_ALGORITHM_WANDER_RETENTION_VIDEOREID_HPP_
#define ANALYZER_ALGORITHM_WANDER_RETENTION_VIDEOREID_HPP_

#include <iostream>
#include <opencv2/opencv.hpp>
#include <vector>

#include "algorithm/algorithm.hpp"
#include "serving/config.pb.h"
#include "common/log.hpp"
#include "common/util.hpp"
#include "common/tad_internal.hpp"

#include "time.h"

#ifdef USE_FAISS
#include "faiss/IndexFlat.h"
#endif
namespace FLOW {

namespace WanderRetention {

struct Rect_t{
    float x;
    float y;
    float w;
    float h;
};

struct TracketBox{
    int id;
    int label;
    int valid;
    struct Rect_t rect;
};

class VideoReid{
    public:
    std::map<int, int> real_id;
    std::map<int, int> end_time;
    std::map<int, int> start_time;
    std::string        stream_id_;
    void setup(const inference::Flow &config, const std::string stream_id);

    void process(const cv::Mat &frame, std::vector<TracketBox> &reuslt, int _label_type);

    private:
    cv::Size scale;
    cv::Size *reid_size;
    int forget_time;
    int FRAMERATE = 30;
    int label_type;
    bool forward_or_not;
    int frame_num = 0;
    float threshold = 0.7;
    int max_retention_time;
    int aggregation_num = 8;
    int feature_dim = 4096;
    // Algorithm::Extract *videoreid_model;
    // Algorithm::Extract *person_quality_model;
    std::map<int, std::vector<cv::Mat>> id_image_list;
    // std::map<int, cv::Mat> id_src_image;
    std::map<int, bool> miss;
    std::map<int, int> old_mapping;
    std::vector<float> base_features;
    std::vector<int> base_id;

    void save_images(const cv::Mat &frame, std::vector<TracketBox> &reuslt);
    void run_and_replace(std::vector<TracketBox> &reuslt);
    void forget(std::vector<TracketBox> &reuslt);

};

class VideoReidModel{
    public:
    void setup(const std::vector<char>& meta_net_data_person_quality, const std::vector<char>& meta_net_data_videoreid, const inference::Flow &config, int& code);

    VideoReidModel(const VideoReidModel&)=delete;
    VideoReidModel& operator=(const VideoReidModel&)=delete;

    static VideoReidModel& get_instance(){
        static VideoReidModel instance;
        return instance;
    }

    inference::Algorithm config_person_quality_;
    inference::Algorithm config_reid_;

    std::shared_ptr<Algorithm::Extract> videoreid_model = nullptr;
    std::shared_ptr<Algorithm::Extract> person_quality_model = nullptr;

    private:
    VideoReidModel()=default;
};
} // namespace WanderRetention

} //namespace FLOW

#endif  // ANALYZER_ALGORITHM_WANDER_RETENTION_VIDEOREID_HPP_