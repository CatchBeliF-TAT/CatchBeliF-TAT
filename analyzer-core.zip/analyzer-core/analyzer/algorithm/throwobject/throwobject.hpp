#ifndef ANALYZER_ALGORITHM_THROWOBJECT_THROWOBJECT_HPP_
#define ANALYZER_ALGORITHM_THROWOBJECT_THROWOBJECT_HPP_

#include <memory>
#include <opencv2/opencv.hpp>
#include "algorithm/algorithm.hpp"
#include "common/boxes.hpp"
#include "common/tad_internal.hpp"
#include "common/type.hpp"
#include "common/util.hpp"
#include "serving/config.pb.h"

#define THROWOBJECT_MAX_BATCH_SIZE 16

namespace FLOW {

namespace Throwobject {

class Throwobject {
 public:
  void Setup(const std::vector<char>& meta_net_data,
                         const inference::Algorithm& config, int& code);
  void SetupVehicle(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

  //#ifdef USE_MEDIA_UTILS
  //  void Process(VecMat& images, VecVframe& frames,
  //               std::vector<std::vector<RectInfo>>& images_boxes, int& code);
  //#endif

  std::vector<int> GetInputShapes() { return input_shapes_; }
  inference::Algorithm config_;

  void Process(const std::vector<std::shared_ptr<cv::Mat>> images,
               std::vector<ThrowObject_Event>& events);
  void VehicleProcess(const std::vector<std::shared_ptr<cv::Mat>> images,
                      std::vector<VecBoxF> Cboxes,
                      std::vector<ThrowObject_Event>& events);

 private:
  std::shared_ptr<Algorithm::Detect> engine_throwobject_ = nullptr;
  std::shared_ptr<Algorithm::Detect> engine_vehicle_ = nullptr;
  std::vector<int> input_shapes_;
  float throwobject_detect_threshold;
};

}  // namespace Throwobject
}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_THROWOBJECT_THROWOBJECT_HPP_
