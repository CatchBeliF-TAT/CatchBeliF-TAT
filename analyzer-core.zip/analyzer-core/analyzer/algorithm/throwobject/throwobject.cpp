#include "throwobject.hpp"
#include "common/io.hpp"
#include "common/json.hpp"
#include "common/log.hpp"
#include "document.h"
#include "prettywriter.h"
#include "stringbuffer.h"

namespace FLOW {

namespace Throwobject {

bool centerpoint_interior_box(BoxF box1, BoxF box2) {
  float center_x = (box1.xmin + box1.xmax) / 2;
  float center_y = (box1.ymin + box1.ymax) / 2;

  if ((center_x > box2.xmin) && (center_x < box2.xmax) &&
      (center_y > box2.ymin) && (center_y < box2.ymax)) {
    return true;
  } else {
    return false;
  }
}

void DetectNFiliter(VecBoxF& Gboxes,
                    VecBoxF& throwobject_boxes_buffer,
                    int still_time) {

}

void Throwobject::Setup(const std::vector<char>& meta_net_data,
                                   const inference::Algorithm& config,
                                   int& code) {
  LOG(INFO) << "Setup Throwobject Detect Module";
  config_ = config;
  Algorithm::Argument arguments;
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("device_id", config_.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config_.batch_size());
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
#ifdef USE_MEDIA_UTILS
  arguments.AddSingleArgument<bool>("device_input", false);
#else
  arguments.AddSingleArgument<bool>("device_input", false);
#endif

  engine_throwobject_ = std::make_shared<Algorithm::Detect>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  std::vector<VecInt> network_input_shapes;
  engine_throwobject_->Run<const std::string&, std::vector<VecInt>&>(
      "GetNetworkInputShapes", network_input_shapes);
  input_shapes_ = network_input_shapes[0];

  throwobject_detect_threshold = config_.detect_threshold();

  code = FLOW::module_status_success;

  LOG(INFO) << "Finished setup Throwobject Detect Module";
}

void Throwobject::SetupVehicle(const std::vector<char>& meta_net_data,
                        const inference::Algorithm& config,
                        int& code) {
  LOG(INFO) << "Setup Throwobject Vehicle Module";
  config_ = config;
  Algorithm::Argument arguments;
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("device_id", config_.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config_.batch_size());
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
#ifdef USE_MEDIA_UTILS
  arguments.AddSingleArgument<bool>("device_input", false);
#else
  arguments.AddSingleArgument<bool>("device_input", false);
#endif

  engine_vehicle_ = std::make_shared<Algorithm::Detect>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  std::vector<VecInt> network_input_shapes;
  engine_vehicle_->Run<const std::string&, std::vector<VecInt>&>(
      "GetNetworkInputShapes", network_input_shapes);
  input_shapes_ = network_input_shapes[0];

  code = FLOW::module_status_success;

  LOG(INFO) << "Finished setup Throwobject Vehicle Module";
}

// Throwobject Process
void Throwobject::Process(
    const std::vector<std::shared_ptr<cv::Mat>> images,
    std::vector<ThrowObject_Event>& events) {
  events.clear();
  Profiler Throwobject_profile;
        Throwobject_profile.tic("Throwobject Process");

  std::vector<cv::Mat> im_mats;
  std::vector<Algorithm::VecBoxF> Gboxes_throwobject;

  for (auto& image : images) {
    im_mats.push_back(*image);
  }
  engine_throwobject_
      ->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecBoxF>&>(
          im_mats, Gboxes_throwobject);

  // 同一位置连续检测到still_time_config帧，才报警
  for (auto& boxes : Gboxes_throwobject) {
    BoxF pbox;
    VecBoxF boxes_throwobject;
    for (auto& box : boxes) {
      pbox.xmin = box.xmin;
      pbox.ymin = box.ymin;
      pbox.xmax = box.xmax;
      pbox.ymax = box.ymax;
      pbox.score = box.score;
      pbox.label = box.label;
      if ((pbox.label == 0) && (pbox.score > throwobject_detect_threshold)) {
        boxes_throwobject.push_back(pbox);
      }
    }
    ThrowObject_Event event;
    event.throw_objects = boxes_throwobject;
    events.push_back(event);
  }

  Throwobject_profile.toc("Throwobject Process");
  LOG(DEBUG) << Throwobject_profile.get_stats_str();
}

// Throwobject VehicleProcess
void Throwobject::VehicleProcess(
    const std::vector<std::shared_ptr<cv::Mat>> images, 
    std::vector<VecBoxF> Cboxes, std::vector<ThrowObject_Event>& events) {
  events.clear();
  Profiler Throwobject_vehicle_profile;
  Throwobject_vehicle_profile.tic("Throwobject_vehicle Process");
  VecInt throwobject_flags;
  std::vector<cv::Mat> im_vehicle_mats;
  std::vector<Algorithm::VecBoxF> Gboxes_vehicle;

  for (int i = 0; i < Cboxes.size(); i++) {
    int throwobject_flag = 0;
    if(Cboxes[i].size() > 0) {
      throwobject_flag = 1;
    }
    throwobject_flags.push_back(throwobject_flag);
    if (throwobject_flag) {
      im_vehicle_mats.push_back(*(images[i]));
    }
  }

  if (!im_vehicle_mats.empty()) {
    engine_vehicle_
        ->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecBoxF>&>(
        im_vehicle_mats, Gboxes_vehicle);
  }

  int vehicle_count = 0;
  for (int i = 0; i < Cboxes.size(); i++) {
    ThrowObject_Event event;
    
    if ( 1 == throwobject_flags[i]) {
      for (auto box_vehicle : Gboxes_vehicle[vehicle_count]) {
        if(2 == box_vehicle.label){
          BoxF pbox_vehicle;
          pbox_vehicle.xmin = box_vehicle.xmin;
          pbox_vehicle.ymin = box_vehicle.ymin;
          pbox_vehicle.xmax = box_vehicle.xmax;
          pbox_vehicle.ymax = box_vehicle.ymax;
          pbox_vehicle.score = box_vehicle.score;
          event.vehicle_objects.push_back(pbox_vehicle);
        }
      }
      ++vehicle_count;
    }
    events.push_back(event);
  }

  Throwobject_vehicle_profile.toc("Throwobject_vehicle Process");
  LOG(DEBUG) << Throwobject_vehicle_profile.get_stats_str();
}

}  // namespace Throwobject

}  // namespace FLOW
