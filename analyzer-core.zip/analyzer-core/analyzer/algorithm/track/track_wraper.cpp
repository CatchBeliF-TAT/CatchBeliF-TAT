#include <iterator>
#include <algorithm>

#include "track_wraper.hpp"
#include "common/json.hpp"
#include "trackers/kalman_tracker.hpp"

namespace FLOW {

namespace Track {

using namespace std;
//如果roi不是用“data”或者“rois”字段是解析不到的，比如客流用的是“roi”
inline void TADTracker::ParseRoiConfig(const string &roi_id, const string &roi_cfg) {
  
  const auto &document = get_document(roi_cfg);
  //condition里的data，remove violation的时候会删掉
  if (document.HasMember("data")) {
    const auto &roi = document["data"];

    cl::Path path;
    CHECK(roi.Size() % 2 == 0);
    for (int j = 0; j < roi.Size() / 2; ++j) {
      path.push_back(
          cl::IntPoint(roi[2 * j].GetFloat(), roi[2 * j + 1].GetFloat()));
    }
    if (roi.Size()) {
      rois_[roi_id] = path;
    }
  } else if (document.HasMember("rois")) {//布控最外层的roi
    CHECK(document["rois"].IsArray());
    const auto &rois = document["rois"];
    for (int i = 0; i < rois.Size(); ++i) {
      const auto &roi = rois[i];
      CHECK(roi.IsArray());
      cl::Path path;
      CHECK(roi.Size() % 2 == 0);
      for (int j = 0; j < roi.Size() / 2; ++j) {
        path.push_back(
            cl::IntPoint(roi[2 * j].GetFloat(), roi[2 * j + 1].GetFloat()));
      }
      if (roi.Size()) {
        stringstream ss;
        ss << "__rois__" << i << roi_cfg;
        //key不是violation_id，remove violation的时候删不掉
        rois_[ss.str()] = path;
      }
    }
  }
  return;
}

void TADTracker::AddStreamRoiConfig(const string &roi_id,
                                    const string &roi_cfg) {
  ParseRoiConfig(roi_id, roi_cfg);
}

void TADTracker::RemoveStreamRoiConfig(const string &roi_id) {
  rois_.erase(roi_id);
}
//重复接口
void TADTracker::AddStreamTrackingType(const string &roi_id,
                                       const string &roi_cfg) {
  ParseRoiConfig(roi_id, roi_cfg);
}


void TADTracker::Setup(const inference::TrackingConfig &config, const string &rois_cfg,
                       int &code) {
    config_ = config;
    ParseRoiConfig("", rois_cfg);
    mot::MotConfig mot_config;
    if (config_.mot_type() == "face"){
        mot_config.initFrame = 5;
        mot_config.maxTrackerNum=config_.max_tracker_count();
        mot_config.maxLife = 15;
        mot_config.useReid = 0;
        mot_config.numClass = 2;
        mot_config.firstStageThres = {0.32,0.32};
        mot_config.secondStageThres = {0.55,0.55};
        mot_config.lastStageThres = {0.7,0.7};
    }
    else if (config_.mot_type() == "person"){
        mot_config.initFrame = 15;
        mot_config.maxTrackerNum=config_.max_tracker_count();
        mot_config.maxLife = 10;
        mot_config.useReid = 0;
        mot_config.numClass = 2;
        mot_config.firstStageThres = {0.35,0.35};
        mot_config.secondStageThres = {0.5,0.5};
        mot_config.lastStageThres = {0.7,0.7};
    }
    else if (config_.mot_type() == "traffic") {
        mot_config.initFrame = 3;
        mot_config.maxTrackerNum=config_.max_tracker_count();
        mot_config.maxLife = 50;
        mot_config.useReid = 0;
        mot_config.numClass = 4;
        // mot_config.classList = {0, 1, 2, 3};
        mot_config.firstStageThres = {0.3,0.3,0.3,0.3};
        mot_config.secondStageThres = {0.5,0.5,0.5,0.5};
        mot_config.lastStageThres = {0.7,0.7,0.7,0.7};
        // mot_config.miniAssign = {0.04,0.07,0.10,0.07};
        mot_config.mergeList = {
          {mot::ClassType::PERSON,mot::ClassType::NON_MOTOR},
          {mot::ClassType::PERSON,mot::ClassType::TRICYCLE},
          // {mot::ClassType::PERSON,mot::ClassType::CAR},
        };
        // mot_config.mergeIouThres = 0.2;
        // mot_config.dynaThres = true;
        // mot_config.level = 2;
        mot_config.mergeIouThres = {0.9, 0.9}; 
    }
    else{
        code = -1;
        return;
    }
    {
      #define ADD_PROTO_COPY(PROTO, FIELD) \
        if (config_.has_##PROTO()) { \
            mot_config.FIELD = config_.PROTO(); \
        }
        ADD_PROTO_COPY(init_frame,      initFrame)
        ADD_PROTO_COPY(max_tracker,     maxTrackerNum)
        ADD_PROTO_COPY(max_life,        maxLife)
        ADD_PROTO_COPY(use_reid,        useReid)
        ADD_PROTO_COPY(num_class,       numClass)
        // ADD_PROTO_COPY(merge_iou_thres, mergeIouThres)
        // ADD_PROTO_COPY(dyna_thres,      dynaThres)
        // ADD_PROTO_COPY(level,           level)
      #undef ADD_PROTO_COPY
      #define ADD_PROTO_COPY_ARRAY(PROTO, FIELD) \
        if (config_.PROTO##_size()) { \
            mot_config.FIELD.clear(); \
            std::copy(config_.PROTO().begin(), config_.PROTO().end(), std::back_inserter(mot_config.FIELD)); \
        }
        // ADD_PROTO_COPY_ARRAY(class_list,        classList)
        // ADD_PROTO_COPY_ARRAY(cls_local_thres,   clsLocalThres)
        // ADD_PROTO_COPY_ARRAY(cls_global_thres,  clsGlobalThres)
        // ADD_PROTO_COPY_ARRAY(mini_assign,       miniAssign)
      #undef ADD_PROTO_COPY_ARRAY
      if (config_.merge_list_size()) {
          mot_config.mergeList.clear();
          for(int i=1;i<config_.merge_list_size();i+=2){
              mot_config.mergeList.push_back({config_.merge_list(i-1),config_.merge_list(i)});
          }
      }
      
    }
    engine_ = make_shared<mot::TestTracker>(mot_config);


//  engine_ = make_shared<Tracker::Tracker>(
//            3,30,10, { TAD::MOT::PERSON,TAD::MOT::CAR,TAD::MOT::BYCYCLE});

  //  Tracker tracker(3,30,10,{    PERSON,CAR,BYCYCLE});
}

static VecBoxF filter_new_object(const VecBoxF &boxes, VecBool *check_boxes) {
  VecBoxF new_boxes;

  for (int n = 0; n < boxes.size(); ++n) {
    auto box = boxes[n];
    if (check_boxes->at(n)) continue;
    new_boxes.push_back(box);
  }

  return new_boxes;
}

inline bool check_roi_in(const cl::Path& path, const BoxF& box) {
  const cl::IntPoint pt((box.xmin + box.xmax) / 2, (box.ymin + box.ymax) / 2);
  return (cl::PointInPolygon(pt, path));
}

inline bool check_roi_in(const std::map<std::string, cl::Path>& path_map, const BoxF& box) {
  auto itr = std::find_if(path_map.begin(), path_map.end(), [&box](const std::map<std::string, cl::Path>::value_type& kv){
    return check_roi_in(kv.second, box);
  });
  return path_map.empty() || itr != path_map.end();
}

inline bool check_type(const std::vector<int>& types, const BoxF& box) {
  auto itr = std::find(types.begin(), types.end(), box.label);
  return (itr != types.end());
}

inline bool check_type(const std::map<std::string, std::vector<int>>& types, const BoxF& box) {
  auto itr = std::find_if(types.begin(), types.end(), [&box](const std::map<std::string, std::vector<int>>::value_type& kv){
    return check_type(kv.second, box);
  });
  return types.empty() || itr != types.end();
}

inline bool valid_box_in_range(const BoxF& box, const cv::Mat &image, float percent) {
    const float x = image.cols;
    const float y = image.rows;
    const float minx = x*percent;
    const float miny = y*percent;
    return (box.xmin > minx && box.xmax < (x-minx) &&
           box.ymin > miny && box.ymax < (y-miny));
}

int type_mapping(int t, int def, string mot_type, bool order=true) {
    if (mot_type == "traffic") {
      static const std::unordered_map<int,int> ObjectType2TrackerType = {
          {ObjectType::OBJECT_TYPE_PERSON,    mot::ClassType::PERSON },
          {ObjectType::OBJECT_TYPE_NONMOTOR,  mot::ClassType::NON_MOTOR},
          {ObjectType::OBJECT_TYPE_VEHICLE,   mot::ClassType::CAR},
          {ObjectType::OBJECT_TYPE_TRICYCLE,  mot::ClassType::TRICYCLE},
      };
      static const std::unordered_map<int,int> TrackerType2ObjectType = {
          {mot::ClassType::PERSON,      ObjectType::OBJECT_TYPE_PERSON},
          {mot::ClassType::NON_MOTOR,   ObjectType::OBJECT_TYPE_NONMOTOR},
          {mot::ClassType::CAR,         ObjectType::OBJECT_TYPE_VEHICLE},
          {mot::ClassType::TRICYCLE,  ObjectType::OBJECT_TYPE_TRICYCLE},
      };
      const auto& usingMap = order ? ObjectType2TrackerType : TrackerType2ObjectType;
      auto itr = usingMap.find(t);
      if (itr == usingMap.end()) {
        return def;
      }
      return itr->second;
    }
    return t;
}

static void convert(const string& mot_type,
             const int cols, const int rows,
             const BoxF& in, mot::DetBox *out){
    out->rect.x = ((float)in.xmin)/cols;
    out->rect.y = ((float)in.ymin)/rows;
    out->rect.w = ((float)(in.xmax - in.xmin))/cols;
    out->rect.h = ((float)(in.ymax- in.ymin))/rows;
    out->label = type_mapping(in.label, mot::ClassType::TRICYCLE, mot_type);
    out->confidence = in.score*1e4;
    out->status = mot::FAIL;
}

static void convert(const string& mot_type,
             const int cols, const int rows,
             const mot::TracketBox& in, BoxF *out, const std::map<int, mot::TracketBox> &tracketBoxes){
      out->uid = in.id;
      out->label = type_mapping(in.label, OBJECT_TYPE_NONE, mot_type, false);
      out->xmin = MIN(MAX(in.rect.x * cols, 0), cols-3);
      out->xmax = MIN(out->xmin + MAX(in.rect.w * cols, 2), cols-1);
      out->ymin = MIN(MAX(in.rect.y * rows, 0), rows-3);;
      out->ymax = MIN(out->ymin + MAX(in.rect.h * rows, 2), rows -1);
      out->score = in.confidence / 1e4;
      for ( const auto &merge_id : in.merge_ids ) {
        mergedBoxInfo mergeBox;
        mergeBox.uid = merge_id;
        auto itr = tracketBoxes.find(merge_id);
        if (itr != tracketBoxes.end()) {
          mergeBox.lable = type_mapping(itr->second.label, OBJECT_TYPE_NONE, mot_type, false);;
        }
        out->mergedBoxes.push_back(mergeBox);
      }
      // out->create_flag = b_new_box;
      // out->delete_flag = (in.status == mot::TRACKET_DEAD);
      // if(res.det_corre_index != -1) {
      //   engine_box.face_point = in_out_boxes[res.det_corre_index].face_point;
      // }
}

void TADTracker::Process(const ShellFrame_Ptr &sframe, VecBoxF &in_out_boxes, int *code) {
    vector<vector<mot::DetBox>> det_boxes(10,vector<mot::DetBox>());
    for (const auto &box : in_out_boxes) {
        mot::DetBox tmp;
        convert(config_.mot_type(), sframe->width(), sframe->height(), box, &tmp);
        det_boxes[tmp.label].push_back(std::move(tmp));
    }

    // tracking process
    vector<mot::TracketBox> result = engine_->update(det_boxes);
    
    const auto MIN_IOU_FILTER = config_.has_min_iou_filter() ? config_.min_iou_filter() : -1;
    VecBoxF out_boxes;
    std::set<int> tracked_ids;
    out_boxes.reserve(result.size());
    
    map<int, mot::TracketBox> tracket_boxes;
    for (auto &res : result) {
      tracket_boxes.insert(make_pair(res.det_corre_index,res));
    } 

    for (auto &res : result) {
      BoxF out_box;
      convert(config_.mot_type(), sframe->width(), sframe->height(), res, &out_box, tracket_boxes);
      if (res.status != mot::TRACKET_DEAD){
        if(res.status != mot::TRACKET_KEEP) continue;
        if(res.valid == 0) continue;
        // drop no detect box object
        if(res.det_corre_index == -1) continue;
        // drop type miss match object
        // BoxF box_only_label;
        // box_only_label.label=type_mapping(res.label, OBJECT_TYPE_NONE, false);;
        // if(!check_type(config_.tracking_types_, box_only_label)) continue;
        // drop small or big new object
        if ( object_records_.count(res.id) == 0 ) {
          if ((res.rect.w) < config_.min_box_size() && (res.rect.h) < config_.min_box_size()) continue;
          if ((res.rect.w) > config_.max_box_size() && (res.rect.h) > config_.max_box_size()) continue;
          object_records_[res.id].status = Status::eTrackingNew;
          object_records_[res.id].box = out_box;
        }
        // process status
        switch (object_records_[res.id].status)
        {
        case Status::eTrackingNew:
          object_records_[res.id].status = check_roi_in(rois_, out_box) ? Status::eRoiTrackingNew : Status::eTrackingNew;
          if (object_records_[res.id].status == Status::eRoiTrackingNew){
            out_box.create_flag = true;
          }
          break;
        case Status::eRoiTrackingNew:
        case Status::eRoiTracking:
          if(config_.has_disable_roi_filter() && config_.disable_roi_filter() &&
            !check_roi_in(rois_, out_box)) {
            object_records_[res.id].status = Status::eRoiTrackingEnd;
          } else if(MIN_IOU_FILTER > 0 && Boxes::IoU(object_records_[res.id].box, out_box) < MIN_IOU_FILTER) {
            object_records_[res.id].status = Status::eRoiTrackingMiss;
          } else {
            object_records_[res.id].box = out_box;
            object_records_[res.id].status = Status::eRoiTracking;
          }
          break;
        case Status::eRoiTrackingMiss:
          if(MIN_IOU_FILTER > 0 && Boxes::IoU(object_records_[res.id].box, out_box) < MIN_IOU_FILTER) {
            // nop 
          } else {
            object_records_[res.id].box = out_box;
            object_records_[res.id].status = Status::eRoiTracking;
          }
          break;
        case Status::eRoiTrackingEnd:
          if (config_.has_disable_roi_filter() && config_.disable_roi_filter()) {
            object_records_[res.id].status = check_roi_in(rois_, out_box) ? Status::eRoiTracking : Status::eRoiTrackingEnd;
          }
          break;
        }
        const auto status = object_records_[res.id].status;
        if (status != Status::eRoiTracking) {
          continue;
        }
      } else {
        object_records_.erase(res.id);
        out_box.delete_flag = true;
      }

      // TODO need delete
      // copy face_point
      if(res.det_corre_index != -1) {
        out_box.face_point = in_out_boxes[res.det_corre_index].face_point;
      }

      out_boxes.push_back(out_box);
      tracked_ids.insert(res.id);
    }
    // update tracking_path
    for (auto itr=object_records_.begin(); itr != object_records_.end(); itr++){
      if (itr->second.tracking_path.size() >= 1024*2){
        itr->second.tracking_path.pop_front();
      }
      if (tracked_ids.count(itr->first) > 0 ) {
        itr->second.tracking_path.push_back(itr->second.box);
      } else {
        itr->second.tracking_path.push_back(BoxF());
      }
    }
    // output
    in_out_boxes.swap(out_boxes);
    *code = 0;
}

void TADTracker::Release() {}

void TADTracker::Reset() {
  engine_->reset();
  object_records_.clear();
}

void TADTracker::DrawTrackingROI(cv::Mat &im) {
  for (const auto &roi : rois_) {
    auto pt0 = roi.second[0];
    auto pte = roi.second[roi.second.size() - 1];
    for (int i = 0; i < roi.second.size() - 1; i++) {
      auto pt_s = roi.second[i];
      auto pt_e = roi.second[i + 1];
      cv::line(im, cv::Point(pt_s.X, pt_s.Y), cv::Point(pt_e.X, pt_e.Y),
               cv::Scalar(255, 0, 0), 2);
    }
    cv::line(im, cv::Point(pte.X, pte.Y), cv::Point(pt0.X, pt0.Y),
             cv::Scalar(255, 0, 0), 2);
  }
}
}  // namespace Track
}  // namespace FLOW
