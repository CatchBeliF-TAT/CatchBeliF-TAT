#ifndef ANALYZER_ALGORITHM_TRACK_TRACK_WRAPER_HPP_
#define ANALYZER_ALGORITHM_TRACK_TRACK_WRAPER_HPP_

#include <map>
#include <memory>
#include <list>
#include <string>
#include <vector>

#include "common/tad_internal.hpp"
#include "common/clipper.hpp"
#include "serving/config.pb.h"

namespace mot {
  class KalmanTracker;
  typedef KalmanTracker TestTracker;
}

namespace FLOW {


    namespace cl = ClipperLib;

    namespace Track {

        class TADTracker {
        public:
            TADTracker() = default;

            ~TADTracker() = default;

            void Setup(const inference::TrackingConfig &config, const std::string &rois_cfg,
                       int &code);

            void Process(const ShellFrame_Ptr &sframe, VecBoxF &in_out_boxes, int *code);

            void Release();

            void Reset();

            void AddStreamRoiConfig(const std::string &roi_id, const std::string &rois_cfg);

            void RemoveStreamRoiConfig(const std::string &roi_id);

            void AddStreamTrackingType(const std::string &roi_id, const std::string &rois_cfg);

            void DrawTrackingROI(cv::Mat &im);

            inline void ParseRoiConfig(const std::string &roi_id, const std::string &roi_cfg);

        private:
            enum Status {
                eTrackingNew = 0,
                eRoiTrackingNew,
                eRoiTracking,
                eRoiTrackingMiss,
                eRoiTrackingEnd,
            };
            struct ObjectInfo
            {
                Status status=Status::eTrackingNew;
                BoxF   box;
                std::list<BoxF> tracking_path;
            };

        private:
            std::shared_ptr<mot::TestTracker> engine_ = nullptr;
            inference::TrackingConfig config_;
            std::map<std::string, cl::Path> rois_;
            std::map<std::string, std::vector<int>> tracking_types_;
            std::map<int, ObjectInfo> object_records_;
        };
    }  // namespace Track
}  // namespace FLOW


#endif  // ANALYZER_ALGORITHM_TRACK_TRACK_WRAPER_HPP_
