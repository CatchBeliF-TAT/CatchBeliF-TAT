/*
 * @Author: your name
 * @Date: 2021-01-06 10:24:42
 * @LastEditTime: 2021-01-07 12:34:19
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /analyzer-flow/analyzer/algorithm/sharedbike/sharedbike.cpp
 */
#include "sharedbike.hpp"

#include "common/log.hpp"
#include "common/util.hpp"

namespace FLOW {

namespace SharedBike {

//#define TRAFFIC_SIGN_MAX_BATCH_SIZE 2

void SharedBike::Setup(const std::vector<char>& meta_net_data,
                       const inference::Algorithm& config) {
  LOG(INFO) << "Setup SharedBike Module";
  Algorithm::Argument arguments;
  // arguments.AddSingleArgument<std::string>("method", "yolov5");
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size",
                                   config.batch_size());  // 2
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
  engine_ = std::make_shared<Algorithm::Detect>(
      meta_net_data.data(), meta_net_data.size(), arguments);
  LOG(INFO) << "Finished setup SharedBike Module";
}

void SharedBike::Process(const std::vector<std::shared_ptr<cv::Mat>>& images,
                         std::vector<cv::Rect> rois,
                         std::vector<SharedBike_Event>& events) {
  std::vector<cv::Mat> im_mats;
  for (int i = 0; i < images.size(); i++) {
    im_mats.emplace_back(*images[i], rois[i]);
  }

  std::vector<Algorithm::VecBoxF> Gboxes;
  engine_->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecBoxF>&>(
      im_mats, Gboxes);

  events.clear();
  for (int i = 0; i < Gboxes.size(); i++) {
    const auto& roi = rois[i];
    auto& boxes = Gboxes[i];
    SharedBike_Event event;
    for (auto& box : boxes) {
      BoxF box_t(box.xmin + roi.x, box.ymin + roi.y, box.xmax, box.ymax);
      if (box.label == 0) {
        box_t.label = SharedBikeType::SharedBike_label;
        box_t.score = box.score;
        event.objs.push_back(box_t);
      }
    }
    events.push_back(event);
  }
}

}  // namespace SharedBike

}  // namespace FLOW
