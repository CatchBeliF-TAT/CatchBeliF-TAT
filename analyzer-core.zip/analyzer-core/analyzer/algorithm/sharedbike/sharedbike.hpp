/*
 * @Author: your name
 * @Date: 2021-01-06 10:24:42
 * @LastEditTime: 2021-01-07 12:29:27
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: /analyzer-flow/analyzer/algorithm/sharedbike/sharedbike.hpp
 */
#ifndef ANALYZER_ALGORITHM_SHAREDBIKE_SHAREDBIKE_HPP_
#define ANALYZER_ALGORITHM_SHAREDBIKE_SHAREDBIKE_HPP_

#include "common/tad_internal.hpp"

#include "algorithm/algorithm.hpp"
#include "serving/config.pb.h"
namespace FLOW {

namespace SharedBike {

// #ifndef SharedBike_label
// #define SharedBike_label 0x0a01
// #endif

#define SharedBikeType_size 10

enum SharedBikeType {
  SharedBike_label = 0x0a01,  //共享单车
};

class SharedBike {
 public:
  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config);

  void Process(const std::vector<std::shared_ptr<cv::Mat>>& images,
               std::vector<cv::Rect> rois,
               std::vector<SharedBike_Event>& events);

 private:
  std::shared_ptr<Algorithm::Detect> engine_ = nullptr;
};

}  // namespace SharedBike

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_SHAREDBIKE_SHAREDBIKE_HPP_
