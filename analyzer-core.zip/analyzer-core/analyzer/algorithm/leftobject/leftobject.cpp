#include "leftobject.hpp"
#include "common/io.hpp"
#include "common/json.hpp"
#include "common/log.hpp"
#include "document.h"
#include "prettywriter.h"
#include "stringbuffer.h"

namespace FLOW {

namespace Leftobject {

/// compare the similarity of between two images
static float cmp_imgs_similarity(cv::Mat& img1, cv::Mat& img2) {
  int pixel_threshold = 30;
  cv::Mat im_abs, im_threshold, im_gray;
  auto p1= img1.data , p2= img2.data; 
  int non_zero_pixels = 0;
  for (int i =0;i<img1.rows* img1.cols;i++){
    if (abs(*p1 - *p2) > pixel_threshold){
      non_zero_pixels ++;
    }
    p1++; p2++;
  }
  return 1 - static_cast<float>(non_zero_pixels) /
                 static_cast<float>(img1.rows * img1.cols);
  // absdiff(img1, img2, im_abs);
  // threshold(im_abs, im_threshold, pixel_threshold, 255.0, cv::THRESH_BINARY);
  // cvtColor(im_threshold, im_gray, cv::COLOR_BGR2GRAY);
  // int non_zero_pixels = cv::countNonZero(im_gray);
  // return 1 - static_cast<float>(non_zero_pixels) /
  //                static_cast<float>(im_gray.rows * im_gray.cols);
}

static double psnr(cv::Mat& I1, cv::Mat& I2) {
  cv::Mat s1;
  absdiff(I1, I2, s1);
  s1.convertTo(s1, CV_32F);  //转换为32位的float类型，8位不能计算平方
  s1 = s1.mul(s1);
  cv::Scalar s = sum(s1);  //计算每个通道的和
  double sse = s.val[0] + s.val[1] + s.val[2];
  if (sse <= 1e-10)  // for small values return zero
    return 0;
  else {
    double mse = sse / (double)(I1.channels() * I1.total());  //  sse/(w*h*3)
    double psnr = 10.0 * log10((255 * 255) / mse);
    return psnr;
  }
}

static float ssim(cv::Mat& i1, cv::Mat& i2) {
  const double C1 = 6.5025, C2 = 58.5225;
  int d = CV_32F;
  cv::Mat I1, I2;
  i1.convertTo(I1, d);
  i2.convertTo(I2, d);
  cv::Mat I1_2 = I1.mul(I1);
  cv::Mat I2_2 = I2.mul(I2);
  cv::Mat I1_I2 = I1.mul(I2);
  cv::Mat mu1, mu2;
  GaussianBlur(I1, mu1, cv::Size(11, 11), 1.5);
  GaussianBlur(I2, mu2, cv::Size(11, 11), 1.5);
  cv::Mat mu1_2 = mu1.mul(mu1);
  cv::Mat mu2_2 = mu2.mul(mu2);
  cv::Mat mu1_mu2 = mu1.mul(mu2);
  cv::Mat sigma1_2, sigam2_2, sigam12;
  GaussianBlur(I1_2, sigma1_2, cv::Size(11, 11), 1.5);
  sigma1_2 -= mu1_2;

  GaussianBlur(I2_2, sigam2_2, cv::Size(11, 11), 1.5);
  sigam2_2 -= mu2_2;

  GaussianBlur(I1_I2, sigam12, cv::Size(11, 11), 1.5);
  sigam12 -= mu1_mu2;
  cv::Mat t1, t2, t3;
  t1 = 2 * mu1_mu2 + C1;
  t2 = 2 * sigam12 + C2;
  t3 = t1.mul(t2);

  t1 = mu1_2 + mu2_2 + C1;
  t2 = sigma1_2 + sigam2_2 + C2;
  t1 = t1.mul(t2);

  cv::Mat ssim_map;
  divide(t3, t1, ssim_map);
  cv::Scalar mssim = mean(ssim_map);

  float ssim = (mssim.val[0] + mssim.val[1] + mssim.val[2]) / 3;
  return ssim;
}

// cal IOU
static float IOU(const cv::Rect& b1, const BoxF& box2) {
  BoxF box1;

  box1.xmin = b1.x;
  box1.ymin = b1.y;
  box1.xmax = b1.x + b1.width;
  box1.ymax = b1.y + b1.height;

  if (box1.xmin > box2.xmax) {
    return 0.0;
  }
  if (box1.ymin > box2.ymax) {
    return 0.0;
  }
  if (box1.xmax < box2.xmin) {
    return 0.0;
  }
  if (box1.ymax < box2.ymin) {
    return 0.0;
  }

  float area1 = static_cast<float>(box1.xmax - box1.xmin + 1) *
                static_cast<float>(box1.ymax - box1.ymin + 1);
  float area2 = static_cast<float>(box2.xmax - box2.xmin + 1) *
                static_cast<float>(box2.ymax - box2.ymin + 1);
  int x11 = std::max(box1.xmin, box2.xmin);
  int y11 = std::max(box1.ymin, box2.ymin);
  int x22 = std::min(box1.xmax, box2.xmax);
  int y22 = std::min(box1.ymax, box2.ymax);
  float intersection =
      static_cast<float>(x22 - x11 + 1) * static_cast<float>(y22 - y11 + 1);
  return intersection / (area1 + area2 - intersection);
}

// cal IOU boxes
static float IOU_boxes(const BoxF& box1, const BoxF& box2) {
    if (box1.xmin > box2.xmax) {
        return 0.0;
    }
    if (box1.ymin > box2.ymax) {
        return 0.0;
    }
    if (box1.xmax < box2.xmin) {
        return 0.0;
    }
    if (box1.ymax < box2.ymin) {
        return 0.0;
    }

    float area1 = static_cast<float>(box1.xmax - box1.xmin + 1) *
                  static_cast<float>(box1.ymax - box1.ymin + 1);
    float area2 = static_cast<float>(box2.xmax - box2.xmin + 1) *
                  static_cast<float>(box2.ymax - box2.ymin + 1);
    int x11 = std::max(box1.xmin, box2.xmin);
    int y11 = std::max(box1.ymin, box2.ymin);
    int x22 = std::min(box1.xmax, box2.xmax);
    int y22 = std::min(box1.ymax, box2.ymax);
    float intersection =
            static_cast<float>(x22 - x11 + 1) * static_cast<float>(y22 - y11 + 1);
    return intersection / (area1 + area2 - intersection);
}

// cal interratio
static float interratio(const cv::Rect& b1, const BoxF& box2) {
  BoxF box1;

  box1.xmin = b1.x;
  box1.ymin = b1.y;
  box1.xmax = b1.x + b1.width;
  box1.ymax = b1.y + b1.height;

  if (box1.xmin > box2.xmax) {
    return 0.0;
  }
  if (box1.ymin > box2.ymax) {
    return 0.0;
  }
  if (box1.xmax < box2.xmin) {
    return 0.0;
  }
  if (box1.ymax < box2.ymin) {
    return 0.0;
  }

  float area1 = static_cast<float>(box1.xmax - box1.xmin + 1) *
                static_cast<float>(box1.ymax - box1.ymin + 1);
  int x11 = std::max(box1.xmin, box2.xmin);
  int y11 = std::max(box1.ymin, box2.ymin);
  int x22 = std::min(box1.xmax, box2.xmax);
  int y22 = std::min(box1.ymax, box2.ymax);
  float intersection =
      static_cast<float>(x22 - x11 + 1) * static_cast<float>(y22 - y11 + 1);
  return intersection / area1;
}

// cal interratio
static float interratio2(const BoxF& box1, const BoxF& box2) {
    if (box1.xmin > box2.xmax) {
        return 0.0;
    }
    if (box1.ymin > box2.ymax) {
        return 0.0;
    }
    if (box1.xmax < box2.xmin) {
        return 0.0;
    }
    if (box1.ymax < box2.ymin) {
        return 0.0;
    }

    float area1 = static_cast<float>(box1.xmax - box1.xmin + 1) *
                  static_cast<float>(box1.ymax - box1.ymin + 1);
    int x11 = std::max(box1.xmin, box2.xmin);
    int y11 = std::max(box1.ymin, box2.ymin);
    int x22 = std::min(box1.xmax, box2.xmax);
    int y22 = std::min(box1.ymax, box2.ymax);
    float intersection =
            static_cast<float>(x22 - x11 + 1) * static_cast<float>(y22 - y11 + 1);
    return intersection / area1;
}

// remove too big or too small contours
static void RemoveSizeContours(std::vector<std::vector<cv::Point>>& contours,
                               const inference::Algorithm &cfg) {
  int cmin = cfg.leftobject_min_size();
  int cmax = cfg.leftobject_max_size();
  std::vector<std::vector<cv::Point>>::const_iterator itc = contours.begin();
  while (itc != contours.end()) {
    if ((itc->size()) < cmin || (itc->size()) > cmax) {
      itc = contours.erase(itc);
    } else
      ++itc;
  }
}

// remove motion contours
static void RemoveMotionrect(std::vector<BoxF>& boxes,
                             std::list<std::shared_ptr<cv::Mat>>& imgs_history,
                             int still_time_config) {
  float imgs_similarity_threshold = 0.3;

  std::vector<BoxF>::const_iterator box = boxes.begin();
  while (box != boxes.end()) {
    cv::Rect roi;
    std::shared_ptr<cv::Mat> img1, img2;
    roi.x = box->xmin;
    roi.y = box->ymin;
    roi.width = box->xmax - box->xmin;
    roi.height = box->ymax - box->ymin;

    if (box->uid == still_time_config) {


      img1 = *imgs_history.begin();
      img2 = *imgs_history.end();
      // img1 = imgs_history.at(0)(roi);
      // img2 = imgs_history.at(still_time_config)(roi);



      //                    if (ssim(img1, img2) < imgs_similarity_threshold){
      if (cmp_imgs_similarity(*img1, *img2) < imgs_similarity_threshold) {
        box = boxes.erase(box);
      } else {
        box++;
      }
    } else {
      box++;
    }
  }
}

// remove motion contours frame by frame
static void RemoveMotionrect_FrameByFrame(std::vector<BoxLeftobject>& boxs_leftobject_buffer,
                                          std::list<std::shared_ptr<cv::Mat>>& imgs_history,
                                          int still_time_config,
                                          VecBoxF& detected_boxes){
    int unsame_count_threshold = 2;
    float imgs_similarity_threshold = 0.3;

    auto box_leftobject = boxs_leftobject_buffer.begin();
    while (box_leftobject != boxs_leftobject_buffer.end()) {
        cv::Rect roi;
        cv::Mat img1, img2;



        roi.x = box_leftobject->pbox.xmin;
        roi.y = box_leftobject->pbox.ymin;
        roi.width = box_leftobject->pbox.xmax - box_leftobject->pbox.xmin;
        roi.height = box_leftobject->pbox.ymax - box_leftobject->pbox.ymin;

        bool box_in_detectedboxes = false;

        for (const auto& detected_box : detected_boxes) {
            float iou = IOU_boxes(box_leftobject->pbox, detected_box);
            if (iou > 0) {
                box_in_detectedboxes = true;
                break;
            }
        }

        if(!box_in_detectedboxes){

            // img2 = imgs_history.back();
            auto iter = imgs_history.begin();
            img1 = *(*iter++);
            img2 = *(*iter++);

            img1 = img1(roi);
            img2 = img2(roi);

            // img1 = imgs_history.at() still_time_config - 1](roi);
            // img2 = imgs_history.at(still_time_config)(roi);
            if(cmp_imgs_similarity(img1, img2) < imgs_similarity_threshold){
                box_leftobject->unsame_count++;
            } else{
                box_leftobject->same_count++;
            }
        }

        if (box_leftobject->exist_time < still_time_config){
            box_leftobject++;
        }
        else {
            if (box_leftobject->unsame_count >= unsame_count_threshold) {
                box_leftobject = boxs_leftobject_buffer.erase(box_leftobject);
            } else {
                box_leftobject++;
            }
        }
    }

}

// remove vehicles detected
static void RemoveDetectBoxes(std::vector<cv::Rect>& boundRect,
                              VecBoxF& boxes) {
  float iou;
  std::vector<cv::Rect>::const_iterator itc = boundRect.begin();

  while (itc != boundRect.end()) {
    int remove_flag = 0;

    for (const auto& detected_box : boxes) {
      //                    iou = IOU(*itc, detected_box);
      iou = interratio(*itc, detected_box);

      // delete fg box of iou>0.1
      if (iou > 0.3) {
        itc = boundRect.erase(itc);
        remove_flag = 1;
        break;
      }
    }

    if (remove_flag == 0) {
      itc++;
    }
  }
}

void Leftobject::Setup(const std::vector<char>& meta_net_data,
                       const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Setup LeftobjectModule";
  config_ = config;
  Algorithm::Argument arguments;
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("device_id", config_.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config_.batch_size());
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
#ifdef USE_MEDIA_UTILS
  arguments.AddSingleArgument<bool>("device_input", false);
#else
  arguments.AddSingleArgument<bool>("device_input", false);
#endif

  // engine_ = std::make_shared<Algorithm::Detect>(
  //     meta_net_data.data(), meta_net_data.size(), arguments);

  // std::vector<VecInt> network_input_shapes;
  // engine_->Run<const std::string&, std::vector<VecInt>&>(
  //     "GetNetworkInputShapes", network_input_shapes);
  // input_shapes_ = network_input_shapes[0];

  code = FLOW::module_status_success;

  LOG(INFO) << "Finished setup LeftobjectModule";
}

void LeftobjectDetect::Setup(const std::vector<char>& meta_net_data,
                       const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Setup LeftobjectModule";
  config_ = config;
  Algorithm::Argument arguments;
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("device_id", config_.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config_.batch_size());
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
#ifdef USE_MEDIA_UTILS
  arguments.AddSingleArgument<bool>("device_input", false);
#else
  arguments.AddSingleArgument<bool>("device_input", false);
#endif

  engine_ = std::make_shared<Algorithm::Detect>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  std::vector<VecInt> network_input_shapes;
  engine_->Run<const std::string&, std::vector<VecInt>&>(
      "GetNetworkInputShapes", network_input_shapes);
  input_shapes_ = network_input_shapes[0];

  code = FLOW::module_status_success;

  LOG(INFO) << "Finished setup LeftobjectModule";
}

void LeftobjectClassify::Setup(const std::vector<char>& meta_net_data,
                                const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Setup Leftobject Classify Module";
  config_ = config;

  engine_ = std::make_shared<Attribute::AttributeEngine>(meta_net_data, config_);
  
  code = FLOW::module_status_success;

  LOG(INFO) << "Finished Leftobject Classify Module";
}

// leftobject reset
void Leftobject::Reset() { 
  do_inference_frame_num_ = -1;
  Clear();
}

// leftobject process
void Leftobject::Process(const VecShellFrame& shell_frames,
                         std::vector<bool>    need_detect_flags,
                         std::vector<VecBoxF> detected_boxes,
                         std::vector<LeftObject_Event>& events) {
  Profiler Leftobject_profile;
  Leftobject_profile.tic("Leftobject Process");

  for (int mat_i = 0; mat_i < shell_frames.size(); mat_i++) {
    do_inference_frame_num_ = do_inference_frame_num_ + 1;
    auto im_mat = shell_frames[mat_i]->getMat();
    LeftObject_Event event;
    std::vector<std::vector<cv::Point>> contours;
    std::vector<cv::Vec4i> hierarchy;

    // background model module
    float resize_ration_w = 0.25;
    float resize_ration_h = 0.25;
    int img_resize_w =
        std::max(config_.img_resize_w_scale(),
                 static_cast<int>(im_mat->cols * resize_ration_w));
    int img_resize_h =
        std::max(config_.img_resize_h_scale(),
                 static_cast<int>(im_mat->rows * resize_ration_h));
    resize_ration_w =
        static_cast<float>(img_resize_w) / static_cast<float>(im_mat->cols);
    resize_ration_h =
        static_cast<float>(img_resize_h) / static_cast<float>(im_mat->rows);
    cv::resize(*im_mat, in_mat_resize, cv::Size(img_resize_w, img_resize_h));
    cv::cvtColor(in_mat_resize, in_mat_gray, cv::COLOR_BGR2GRAY);

    if (0 == do_inference_frame_num_) {
      vibe.init(in_mat_gray);
      vibe.ProcessFirstFrame(in_mat_gray);
    } else {
      vibe.Run(in_mat_gray);
    }

    if (do_inference_frame_num_ < config_.bg_short_history()) {
      events.push_back(event);
      continue;
    } else if (do_inference_frame_num_ == config_.bg_short_history()) {
      for (int i = 0; i <= config_.still_time_config(); i++) {
        imgs_history.push_back(im_mat);
      }
      events.push_back(event);
      continue;
    }

    if(!need_detect_flags[mat_i]){
      events.push_back(event);
      continue;
    }


   // queue
   if(0 == do_inference_frame_num_ % 12){
       imgs_history.pop_front();
       imgs_history.push_back(im_mat);
   }
    // for (int i = 0; i < config_.still_time_config(); i++) {
    //   imgs_history[i] = imgs_history[i + 1].clone();
    // }
    // imgs_history[config_.still_time_config()] = im_mat->clone();


     // vibe 
    in_mat_mask_short = vibe.getFGModel();

    // for (auto& box_leftobject : boxs_leftobject_buffer) {
    //     box_leftobject.exist_time++;
    // }

    // std::vector<BoxLeftobject>::const_iterator box_leftobject = boxs_leftobject_buffer.begin();
    // while (box_leftobject != boxs_leftobject_buffer.end()) {
    //     if (1 == box_leftobject->pbox.label) {
    //         box_leftobject = boxs_leftobject_buffer.erase(box_leftobject);
    //     } else {
    //         box_leftobject++;
    //     }
    // }

    // Find contours
    morphologyEx(in_mat_mask_short, in_mat_mask_short, cv::MORPH_CLOSE,
                 getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3)));

    findContours(in_mat_mask_short, contours, hierarchy, cv::RETR_TREE,
                 cv::CHAIN_APPROX_SIMPLE);

    // Rule filter
    RemoveSizeContours(contours, config_);

    std::vector<cv::Rect> boundRect(contours.size());
    for (unsigned long contour_idx = 0; contour_idx < contours.size();
         contour_idx++) {
      boundRect[contour_idx] = boundingRect(cv::Mat(contours[contour_idx]));
    }


    // detect box 
    VecBoxF boxes;
    for (auto& detected_box : detected_boxes[mat_i]) {
      BoxF box;
      box.xmin = int(detected_box.xmin * resize_ration_w);
      box.ymin = int(detected_box.ymin * resize_ration_h);
      box.xmax = int(detected_box.xmax * resize_ration_w);
      box.ymax = int(detected_box.ymax * resize_ration_h);
      boxes.push_back(box);
    }

    RemoveDetectBoxes(boundRect, boxes);

//    RemoveMotionrect(box_buffer, imgs_history, config_.still_time_config());
    RemoveMotionrect_FrameByFrame(boxs_leftobject_buffer, imgs_history, config_.still_time_config(), boxes);

//    for (const auto& rect : boundRect) {
//      BoxF pbox;
//      pbox.xmin = int(float(rect.x) / resize_ration_w);
//      pbox.ymin = int(float(rect.y) / resize_ration_h);
//      pbox.xmax = int(float(rect.x + rect.width) / resize_ration_w);
//      pbox.ymax = int(float(rect.y + rect.height) / resize_ration_h);
//      pbox.label = 0;
//      pbox.uid = 0;
//      box_buffer.push_back(pbox);
//    }

    // for (const auto& rect : boundRect) {
    //     BoxLeftobject box_leftobject;
    //     box_leftobject.pbox.xmin = int(float(rect.x) / resize_ration_w);
    //     box_leftobject.pbox.ymin = int(float(rect.y) / resize_ration_h);
    //     box_leftobject.pbox.xmax = int(float(rect.x + rect.width) / resize_ration_w);
    //     box_leftobject.pbox.ymax = int(float(rect.y + rect.height) / resize_ration_h);
    //     box_leftobject.pbox.label = 0;
    //     box_leftobject.exist_time = 0;
    //     box_leftobject.same_count = 0;
    //     box_leftobject.unsame_count = 0;
    //     boxs_leftobject_buffer.push_back(box_leftobject);
    // }

//    for (auto& leftobject_box : box_buffer) {
//      if (leftobject_box.uid == config_.still_time_config()) {
//        leftobject_box.label = 1;
//        leftobject_box.oc_state = 1;
//        event.leftobjects.push_back(leftobject_box);
//      }
//    }

    // post process 
    for (auto iter = boxs_leftobject_buffer.begin(); iter!= boxs_leftobject_buffer.end();){
         if ((iter->exist_time == config_.still_time_config()) && (iter->same_count > 0)) {
            //  iter->pbox.label = 1;
            // 删除3秒前触发的框与当前车辆框重合的部分
             int remove_flag = 0;
             for (const auto& detected_box : detected_boxes[mat_i]) {
                 float iou = interratio2(iter->pbox, detected_box);

                 // delete fg box of iou>0.1
                 if (iou > 0.2) {
                     remove_flag = 1;
                     break;
                 }
             }

             if (remove_flag == 0) {
                 iter->pbox.create_flag = 1;
                 event.left_objects.push_back(iter->pbox);
             }
             iter = boxs_leftobject_buffer.erase(iter);
         }else{
             iter->exist_time++;
             iter++;
         }
    }

    for (const auto& rect : boundRect) {
        BoxLeftobject box_leftobject;
        box_leftobject.pbox.xmin = int(float(rect.x) / resize_ration_w);
        box_leftobject.pbox.ymin = int(float(rect.y) / resize_ration_h);
        box_leftobject.pbox.xmax = int(float(rect.x + rect.width) / resize_ration_w);
        box_leftobject.pbox.ymax = int(float(rect.y + rect.height) / resize_ration_h);
        // box_leftobject.pbox.label = 0;
        box_leftobject.exist_time = 0;
        box_leftobject.same_count = 0;
        box_leftobject.unsame_count = 0;
        boxs_leftobject_buffer.push_back(box_leftobject);
    }



    //  for (auto& leftobject_box : boxs_leftobject_buffer) {
    //      if ((leftobject_box.exist_time == config_.still_time_config()) && (leftobject_box.same_count > 0)) {
    //          leftobject_box.pbox.label = 1;
    //          leftobject_box.pbox.oc_state = 1;
    //          event.leftobjects.push_back(leftobject_box.pbox);
    //      }
    //  }
    events.push_back(event);
  }

  Leftobject_profile.toc("Leftobject Process");
  LOG(DEBUG) << Leftobject_profile.get_stats_str();
}


void LeftobjectDetect::Process(const VecShellFrame& shell_frames,
                               std::vector<LeftObject_Event>& events) {
  Profiler Leftobject_profile;
  Leftobject_profile.tic("Leftobject Process");
  events.clear();

  std::vector<cv::Mat> im_mats;
  std::vector<Algorithm::VecBoxF> Gboxes;
  for (auto shell_frame: shell_frames){
    im_mats.emplace_back(*shell_frame->getMat());
  }
  engine_->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecBoxF>&>(
        im_mats, Gboxes);
  events.clear();
  for (int i= 0;i<Gboxes.size(); i++){
    auto& boxes = Gboxes[i];
    LeftObject_Event event;
    for (auto box : Gboxes[i]){
      BoxF box_t(box.xmin , box.ymin , box.xmax, box.ymax);
      box_t.label = box.label;
      box_t.score = box.score;
      event.left_objects.push_back(box_t);
    }
    events.push_back(event);
  }
}

void LeftobjectClassify::Process(const VecShellFrame& shell_frames,
                                 std::vector<VecBoxF> vibe_boxes,
                                 std::vector<LeftObject_Event>& events) {
  Profiler Leftobject_profile;
  Leftobject_profile.tic("Leftobject Process");

  do_inference_frame_num_ = do_inference_frame_num_ + 1;

  std::vector<VecRectF> vec_boxes_tmp;
  std::vector<std::vector<BoxF*>> vec_boxes_addr;
  int count =0;
  for (int i =0; i< shell_frames.size();i++) {
      VecRectF boxes_tmp;
      std::vector<BoxF*> boxes_addr;
      for (auto &box : vibe_boxes[i]) {
          if (box.create_flag == 1 ) {
              count++;
              boxes_tmp.push_back(RectF{box.xmin, box.ymin, box.xmax - box.xmin, box.ymax - box.ymin});
              boxes_addr.push_back(&box);
          }
      }
      vec_boxes_tmp.push_back(boxes_tmp);
      vec_boxes_addr.push_back(boxes_addr);
  }
  std::vector<std::vector<Attribute::AttributeInfos>> attributes;
  if (count) {
      engine_->Predict(shell_frames, vec_boxes_tmp, attributes);
  }

  for (int i =0; i < vec_boxes_tmp.size(); ++i) {
      LeftObject_Event event;
      for (int j = 0; j < vec_boxes_tmp.at(i).size(); ++j) {
          BoxF box_t(vec_boxes_addr.at(i).at(j)->xmin, vec_boxes_addr.at(i).at(j)->ymin ,
                     vec_boxes_addr.at(i).at(j)->xmax, vec_boxes_addr.at(i).at(j)->ymax);
          box_t.label  = attributes.at(i).at(j).at(0).label;
          box_t.score = attributes.at(i).at(j).at(0).score;
          event.left_objects.push_back(box_t);
      }
      events.push_back(event);
  }
}
}  // namespace Leftobject
}  // namespace FLOW
