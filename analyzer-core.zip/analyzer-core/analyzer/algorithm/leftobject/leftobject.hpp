#ifndef ANALYZER_ALGORITHM_LEFTOBJECT_LEFTOBJECT_HPP_
#define ANALYZER_ALGORITHM_LEFTOBJECT_LEFTOBJECT_HPP_

#include <memory>
#include <opencv2/opencv.hpp>
#include "algorithm/algorithm.hpp"
#include "common/boxes.hpp"
#include "common/tad_internal.hpp"
#include "common/type.hpp"
#include "common/util.hpp"
#include "vibe.hpp"
#include "serving/config.pb.h"
#include "algorithm/vehicleattribute/attributeClass.hpp"

#define LEFTOBJECT_MAX_BATCH_SIZE 16

namespace FLOW {

namespace Leftobject {

struct RectInfo {
  cv::Rect rect;
  float score;
  int label;
};

struct BoxLeftobject {
    BoxF pbox;
    int  same_count;     // 潜在抛洒物当前帧与前一帧比对相似次数
    int  unsame_count;   // 潜在抛洒物当前帧与前一帧比对不相似次数
    int  exist_time;     // 潜在抛洒物存在时间
};

class Leftobject {
 public:
  void Setup(const std::vector<char>& meta_net_data, 
              const inference::Algorithm& config, int& code);
  // void Setup_Classify(const std::vector<char>& meta_net_data,
  //                     const inference::Algorithm& config, int& code);


  std::vector<int> GetInputShapes() { return input_shapes_; }
  inference::Algorithm config_;

  void Reset();

  void Clear(){imgs_history.clear();box_buffer.clear();boxs_leftobject_buffer.clear();};

  void Process(const VecShellFrame& shell_frames,
               std::vector<bool>    need_detect_flags,
               std::vector<VecBoxF> detected_boxes,
               std::vector<LeftObject_Event>& events);

  int64_t do_inference_frame_num_ = -1;
  cv::Mat in_mat_resize, in_mat_gray, in_mat_mask_short;
  ViBe vibe;

 private:
  // std::shared_ptr<Algorithm::Detect> engine_ = nullptr;
  // std::shared_ptr<Algorithm::Extract> engine_classify_ = nullptr;
  std::list<std::shared_ptr<cv::Mat>> imgs_history;
  std::vector<BoxF> box_buffer;
  std::vector<BoxLeftobject> boxs_leftobject_buffer;
  std::vector<int>  input_shapes_;
  };


class LeftobjectClassify {
 public:
  void Setup(const std::vector<char>& meta_net_data, 
              const inference::Algorithm& config, int& code);

  inference::Algorithm config_;

  void Process(const VecShellFrame& shell_frames,
               std::vector<VecBoxF> vibe_boxes,
               std::vector<LeftObject_Event>& events);

  int64_t do_inference_frame_num_ = -1;

 private:

  std::shared_ptr<Attribute::AttributeEngine> engine_ = nullptr;
  std::vector<int>  input_shapes_;
};


class LeftobjectDetect {
 public:
  void Setup(const std::vector<char>& meta_net_data, 
              const inference::Algorithm& config, int& code);

  std::vector<int> GetInputShapes() { return input_shapes_; }
  inference::Algorithm config_;

  void Process(const VecShellFrame& shell_frames,
               std::vector<LeftObject_Event>& events);

 private:
  std::shared_ptr<Algorithm::Detect> engine_ = nullptr;
  std::vector<int>  input_shapes_;
};


}  // namespace Leftobject
}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_LEFTOBJECT_LEFTOBJECT_HPP_
