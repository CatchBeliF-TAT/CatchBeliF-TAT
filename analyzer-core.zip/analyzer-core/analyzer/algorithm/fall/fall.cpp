#include "fall.hpp"

#include "common/log.hpp"
#include "common/util.hpp"

namespace FLOW {

namespace Fall {

void Fall::Setup(const std::vector<char>& meta_net_data,
                 const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Setup Fall Moudle";

  Algorithm::Argument arguments;
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());  // 2
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
  engine_ = std::make_shared<Algorithm::Detect>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  code = FLOW::module_status_success;
  LOG(INFO) << "Finished setup Fall Moudle";
}

void Fall::Process(const std::vector<std::shared_ptr<cv::Mat>>& images,
                   std::vector<Fall_Event>& events) {
  std::vector<cv::Mat> im_mats;
  for (auto& image : images) {
    im_mats.push_back(*image);
  }

  std::vector<Algorithm::VecBoxF> Gboxes;
  engine_->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecBoxF>&>(
      im_mats, Gboxes);
  events.clear();
  for (auto boxes : Gboxes) {
    Fall_Event event;
    for (auto& box : boxes) {
      BoxF box_t(box.xmin, box.ymin, box.xmax, box.ymax);
      if ((box.label == 1)) {
        box_t.label = box.label;
        box_t.score = box.score;
        event.fall.push_back(box_t);
        event.predict_fall_name = "fall_person";
      }
    }
    std::cout << event.predict_fall_name;
    events.push_back(event);
  }
}

}  // namespace Fall

}  // namespace FLOW
