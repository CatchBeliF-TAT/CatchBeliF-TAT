#ifndef ANALYZER_ALGORITHM_FALL_FALL_HPP_
#define ANALYZER_ALGORITHM_FALL_FALL_HPP_

#include "algorithm/algorithm.hpp"
#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace Fall {

class Fall {
 public:
  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

  void Process(const std::vector<std::shared_ptr<cv::Mat>>& images,
               std::vector<Fall_Event>& events);

 private:
  std::shared_ptr<Algorithm::Detect> engine_ = nullptr;

 protected:
  inference::FallDetect config_;
};

}  // namespace Fall

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_FALL_FALL_HPP_