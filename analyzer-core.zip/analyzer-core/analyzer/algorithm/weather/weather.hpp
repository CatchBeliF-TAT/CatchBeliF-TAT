#ifndef ANALYZER_ALGORITHM_WEATHER_WEATHER_HPP_
#define ANALYZER_ALGORITHM_WEATHER_WEATHER_HPP_

#include <set>

#include "common/tad_internal.hpp"
#include "algorithm/algorithm.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace Weather {

class Weather {
 public:
  void Setup(const std::vector<char>& meta_net_data, const inference::Algorithm& config);

  void Process(const std::vector<std::shared_ptr<cv::Mat>> &images,
               std::vector<Weather_Event> &events);

 private:
  inference::Algorithm                config_;
  std::set<std::string>               categories_;
  std::shared_ptr<Algorithm::Extract> classify_ = nullptr;
};

}  // namespace Weather

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_WEATHER_WEATHER_HPP_
