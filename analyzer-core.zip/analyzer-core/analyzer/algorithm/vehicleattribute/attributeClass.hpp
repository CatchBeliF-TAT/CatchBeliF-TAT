#ifndef ANALYZER_ALGORITHM_VEHICLEATTRIBUTE_ATTRIBUTECLASS_HPP_
#define ANALYZER_ALGORITHM_VEHICLEATTRIBUTE_ATTRIBUTECLASS_HPP_

#include "common/flow/flow_process.hpp"
#include "common/tad_internal.hpp"

#include "algorithm/algorithm.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace Attribute {

struct AttributeInfo {
  int label;
  float score;
  std::string label_str;
};

using AttributeInfos = std::vector<AttributeInfo>;

class AttributeEngine {
 public:
  AttributeEngine() = default;
  AttributeEngine(const std::vector<char>& meta_net_data,
                  const inference::Algorithm& config);

  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);
  void Predict(const VecShellFrame& shell_frames, std::vector<VecRectF>& boxes,
               std::vector<std::vector<AttributeInfos>>& attributes);

  // add for flow_process
 public:
  typedef std::tuple<cv::Mat, VecRectF> input_type;
  typedef std::vector<AttributeInfos> result_type;
  typedef result_type output_type;

 public:
  size_t MaxBatchSize() const;
  void Process(const input_type& in, output_type* out);
  void ProcessBatch(const std::vector<input_type>& in,
                    const std::vector<output_type*>* out);
  static input_type ConvertInput(const cv::Mat& mat,
                                 const inference::PictureReq& req);
  static inference::PictureResp ConvertOutput(const output_type& results);

 private:
  std::shared_ptr<Algorithm::Extract> classify_ = nullptr;
  std::vector<std::string> categories_;
  inference::Algorithm config_;
};

class sync_attr : public flow_process_sync<AttributeEngine> {
 public:
  typedef flow_process_sync<AttributeEngine> processer_type;
  typedef std::shared_ptr<processer_type> sync_handle;

 public:
  sync_attr() : processer_type("fp_attr") {}
};

}  // namespace Attribute

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_VEHICLEATTRIBUTE_ATTRIBUTECLASS_HPP_
