#ifndef ANALYZER_ALGORITHM_VEHICLEATTRIBUTE_BEHAVIOUR_ATTR_HPP_
#define ANALYZER_ALGORITHM_VEHICLEATTRIBUTE_BEHAVIOUR_ATTR_HPP_

#include <memory>
#include <opencv2/opencv.hpp>
#include <string>
#include <vector>
#include "attributeClass.hpp"
#include "algorithm/detect/detect.hpp"
#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace Attribute {


enum NonMotorType {
    NonMotor_Begin = 0x500,
    NonMotor_Bike,
    NonMotor_EBike,
    NonMotor_Motor,
    NonMotor_Tricycle,
    NonMotor_Others,
    NonMotor_Police_Motor,
    NonMotor_End,
};

enum NoMotorBehaviourType {
    BeHaviour_Non_Helmet = 0x0511,
    BeHaviour_Helmet,
    BeHaviour_Non_Manned = 0x0521,
    BeHaviour_Manned,
    BeHaviour_Non_Promoting = 0x0531,
    BeHaviour_Promoting,
};

inline std::string helperGetStringNoMotorBehaviourType(NoMotorBehaviourType t) {
  switch (t)
  {
  case BeHaviour_Non_Helmet:
    return "no_helmet";
  case BeHaviour_Manned:
    return "manned";
  case BeHaviour_Promoting:
    return "promoting";
  default:
    break;
  }
  char buf[32];
  sprintf(buf, "%d", t);
  return buf;
}

inline std::string helperGetStringNoMotorType(NonMotorType t) {
  switch (t)
  {
  case NonMotor_Bike:
    return "bike";
  case NonMotor_EBike:
    return "ebike";
  case NonMotor_Motor:
    return "motor";
  case NonMotor_Tricycle:
    return "tricycle";
  case NonMotor_Others:
    return "others";
  case NonMotor_Police_Motor:
    return "policemotor";
  default:
    break;
  }
  char buf[32];
  sprintf(buf, "%d", t);
  return buf;
}

enum WaimaiType {
  WaiMai_MEITUAN = 0x0201,
  WaiMai_ELE,
  WaiMai_OTHER,
  WaiMai_PERSON,
  WaiMai_SHUNFENG,
  WaiMai_JINGDONG,
  WaiMai_SUSPECT,
};

inline std::string helperGetStringWaimaiType(WaimaiType t) {
  switch (t) {
    case WaiMai_MEITUAN:
      return "Meituan";
    case WaiMai_ELE:
      return "Ele";
    case WaiMai_OTHER:
      return "Nonmotor_Other";
    case WaiMai_PERSON:
      return "Person";
    case WaiMai_SHUNFENG:
      return "Shunfeng";
    case WaiMai_JINGDONG:
      return "Jingdong";
    case WaiMai_SUSPECT:
      return "Nonmotor_Suspect";
    default:
      break;
  }
  char buf[32];
  sprintf(buf, "%d", t);
  return buf;
}

class BehaviourAttributeModule {
 public:
  BehaviourAttributeModule() = default;

  ~BehaviourAttributeModule();

 public:
  void Setup(const std::vector<char>& meta_net_data, const inference::Algorithm &config, int &code);

  void Predict(const ShellFrame_Ptr& shell_frame, VecBoxF *boxes);

  void Predict(const VecShellFrame& shell_frames, std::vector<VecBoxF> *vec_boxes);

  void Process(const VecShellFrame& shell_frames, std::vector<std::vector<RectInfo>> &images_boxes,
               std::vector<std::vector<AttributeInfos>> &attributes, int &code);

  void Release();

 public:
  inference::Algorithm config_;

 private:
  std::shared_ptr<void> engine_ = nullptr;
};
}  // namespace Attribute
}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_VEHICLEATTRIBUTE_BEHAVIOUR_ATTR_HPP_
