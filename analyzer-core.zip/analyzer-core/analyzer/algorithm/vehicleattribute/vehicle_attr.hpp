#ifndef ANALYZER_ALGORITHM_VEHICLEATTRIBUTE_VEHICLE_ATTR_HPP_
#define ANALYZER_ALGORITHM_VEHICLEATTRIBUTE_VEHICLE_ATTR_HPP_

#include <memory>
#include <opencv2/opencv.hpp>
#include <string>
#include <vector>
#include "common/flow/flow_process.hpp"
#include "algorithm/detect/detect.hpp"
#include "attributeClass.hpp"
#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace Attribute {

enum VehicleSpecialType {
  Vehicle_Taxi = 0x0401,
  Vehicle_Police,
  Vechile_Engineering_Truck,
  Vehicle_Emergency,
  Vehicle_Ambulance,
  Vehicle_Fire,
  Vehicle_Garbage,
  Vehicle_Sweeper,
  Vehicle_Watering,
  Vehicle_Cementmix,
  Vehicle_Cash,
  Vehicle_Muck_Truck,
  Vehicle_Tank_Truck,
  Vehicle_Bus_sp,
  Vehicle_NoSpechialCar,
  Vehicle_NoSpechialTruck,
  Vehicle_Others,
};

enum VehicleType {
  Vehicle_Car = 0x0101,
  Vehicle_Pick_up,
  Vehicle_Light_bus,
  Vehicle_Bus,
  Vehicle_Light_Truck,
  Vehicle_Middle_Truck,
  Vehicle_Heavy_Truck,
  Vehicle_Van_Truck,
};

enum VehicleDirectionType {
  Vehicle_Front = 0x0301,
  Vehicle_Rear,
  Vehicle_No_Direction,
};

inline std::string helperGetStringVehicleDirectionType(VehicleDirectionType t) {
  switch (t) {
    case Vehicle_Front:
      return "Front";
    case Vehicle_Rear:
      return "Rear";
    case Vehicle_No_Direction:
      return "No_Direction";
    default:
      break;
  }
  char buf[32];
  sprintf(buf, "%d", t);
  return buf;
}

inline bool helperIsLargeVehicle(VehicleType t) {
  switch (t) {
    case Vehicle_Car:
    case Vehicle_Pick_up:
    case Vehicle_Light_bus:
    case Vehicle_Light_Truck:
      return false;
    case Vehicle_Bus:
    case Vehicle_Middle_Truck:
    case Vehicle_Heavy_Truck:
    case Vehicle_Van_Truck:
      return true;

    default:
      return true;
  }
}

inline std::string helperGetStringVehicleType(VehicleType t) {
  switch (t) {
    case Vehicle_Car:
      return "Car";
    case Vehicle_Pick_up:
      return "Pick_Up";
    case Vehicle_Light_bus:
      return "Light_Bus";
    case Vehicle_Bus:
      return "Bus";
    case Vehicle_Light_Truck:
      return "Light_Truck";
    case Vehicle_Middle_Truck:
      return "Middle_Truck";
    case Vehicle_Heavy_Truck:
      return "Heavy_Truck";
    case Vehicle_Van_Truck:
      return "Van_Truck";
    default:
      break;
  }
  char buf[32];
  sprintf(buf, "%d", t);
  return buf;
}

inline std::string helperGetStringVehicleSpecialType(VehicleSpecialType t) {
  switch (t) {
    case Vehicle_Taxi:
      return "Taxi";
    case Vehicle_Police:
      return "Police_Car";
    case Vechile_Engineering_Truck:
      return "Engineer_Truck";
    case Vehicle_Emergency:
      return "Emergency_Car";
    case Vehicle_Ambulance:
      return "Ambulance";
    case Vehicle_Fire:
      return "Fire_Car";
    case Vehicle_Garbage:
      return "Garbage_Car";
    case Vehicle_Sweeper:
      return "Sweeper_Car";
    case Vehicle_Watering:
      return "Watering_Car";
    case Vehicle_Cementmix:
      return "CementMix_Car";
    case Vehicle_Cash:
      return "Cash_Car";
    case Vehicle_Muck_Truck:
      return "Muck_Truck";
    case Vehicle_Tank_Truck:
      return "Tank_Truck";
    case Vehicle_Bus_sp:
      return "Bus_Spechial";
    case Vehicle_NoSpechialCar:
      return "NoSpechialCar";
    case Vehicle_NoSpechialTruck:
      return "NoSpechialTruck";
    case Vehicle_Others:
      return "Others";
    default:
      break;
  }
  char buf[32];
  sprintf(buf, "%d", t);
  return buf;
}

class VehicleAttributeModule {
 public:
  VehicleAttributeModule() = default;

  ~VehicleAttributeModule();

 public:
  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

  void Predict(const ShellFrame_Ptr& shell_frame, VecBoxF* boxes);

  void Predict(const VecShellFrame& shell_frames, std::vector<VecBoxF>* vec_boxes);

  void Process(const VecShellFrame& shell_frames, std::vector<std::vector<RectInfo>>& images_boxes,
               std::vector<std::vector<AttributeInfos>>& attributes, int& code);

  void Release();

  // add for flow_process
  public:
      typedef std::tuple<cv::Mat, BoxF> input_type;
      typedef BoxF                      result_type;
      typedef result_type               output_type;
  public:
      size_t MaxBatchSize() const;
      void Process(const input_type& in, output_type* out);
      void ProcessBatch(const std::vector<input_type>& in, const std::vector<output_type*>* out);
      static input_type ConvertInput(const cv::Mat& mat, const inference::PictureReq& req);
      static inference::PictureResp ConvertOutput(const output_type& results);

  protected:
      inference::Algorithm  config_;
      std::shared_ptr<void> engine_;
};
class sync_vehicle_attr
    : public flow_process_sync<VehicleAttributeModule>
{
public:
    typedef flow_process_sync<VehicleAttributeModule>   processer_type;
    typedef std::shared_ptr<processer_type>             sync_handle;

public:
    sync_vehicle_attr()
        : processer_type("fp_vehicle_attr")
    {}
};
}  // namespace Attribute
}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_VEHICLEATTRIBUTE_VEHICLE_ATTR_HPP_
