/*
 * @Author: your name
 * @Date: 2020-10-15 17:46:58
 * @LastEditTime: 2020-10-30 12:01:09
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath:
 * /analyzer-flow/analyzer/algorithm/vehicleattribute/attributeClass.cpp
 */
#include "attributeClass.hpp"

#include "common/json.hpp"
#include "common/log.hpp"
#include "common/type.hpp"
#include "common/util.hpp"

namespace FLOW {

namespace Attribute {

inline cv::Rect convert_roi(const RectF& box, const cv::Size& size) {
  auto w_ = size.width;
  auto h_ = size.height;

  if (box.w <= 1 && box.h <= 1) {
    if (box.x < 0 || box.y < 0 || box.x + box.w > 1 || box.y + box.h > 1) {
      LOG(ERROR) << "Crop region overflow!";
      auto box_copy = box;
      box_copy.x = std::max<float>(box.x, 0);
      box_copy.y = std::max<float>(box.y, 0);
      box_copy.w = std::min<float>(box.w, 1 - box.x);
      box_copy.h = std::min<float>(box.h, 1 - box.y);
      return cv::Rect(box_copy.x * w_, box_copy.y * h_, box_copy.w * w_,
                      box_copy.h * h_);
    }
    return cv::Rect(box.x * w_, box.y * h_, box.w * w_, box.h * h_);
  } else if (box.w > 1 && box.h > 1) {
    if (box.x < 0 || box.y < 0 || box.x + box.w > w_ || box.y + box.h > h_) {
      LOG(ERROR) << "Crop region overflow!";
      auto box_copy = box;
      box_copy.x = std::max<float>(box.x, 0);
      box_copy.y = std::max<float>(box.y, 0);
      box_copy.w = std::min<float>(box.w, w_ - box.x);
      box_copy.h = std::min<float>(box.h, h_ - box.y);
      return cv::Rect(box_copy.x, box_copy.y, box_copy.w, box_copy.h);
    }
    return cv::Rect(box.x, box.y, box.w, box.h);
  } else {
    LOG(ERROR) << "Crop scale must be the same!";
    return cv::Rect(0, 0, 2, 2);
  }
}

AttributeEngine::AttributeEngine(const std::vector<char>& meta_net_data,
                                 const inference::Algorithm& config) {
  int code = 0;
  AttributeEngine::Setup(meta_net_data, config, code);
  LOG_IF(FATAL, code != 0) << "Init failed!";
}

void AttributeEngine::Setup(const std::vector<char>& meta_net_data,
                            const inference::Algorithm& config, int& code) {
  code = 0;
  config_ = config;
  for (int n = 0; n < config.num_attributes(); ++n) {
    categories_.push_back("attr_" + std::to_string(n));
  }

  bool disable_fp16 = std::ifstream("disable_fp16").is_open();

  Algorithm::Argument arguments;
  arguments.AddSingleArgument<int>("net_id", 0);
  arguments.AddSingleArgument<std::string>("method", "classify");
  arguments.AddSingleArgument<bool>("use_fp16", !disable_fp16);
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());
  arguments.AddRepeatedArgument<std::string>("categories", categories_);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir",
                                           config.cache_engine_dir());

  classify_ = std::make_shared<Algorithm::Extract>(
      meta_net_data.data(), meta_net_data.size(), arguments);
}

void AttributeEngine::Predict(
    const VecShellFrame& shell_frames, std::vector<VecRectF>& boxes,
    std::vector<std::vector<AttributeInfos>>& attributes) {
  CHECK_EQ(shell_frames.size(), boxes.size());

  std::vector<cv::Mat> objects;
  for (int n = 0; n < shell_frames.size(); ++n) {
    const auto& im_mat = *shell_frames[n]->getMat();
    for (const auto& box : boxes[n]) {
      objects.emplace_back(im_mat, convert_roi(box, im_mat.size()));
    }
  }

  std::vector<std::map<std::string, VecFloat>> Gvalues;
  classify_->Run<const std::vector<cv::Mat>&,
                 std::vector<std::map<std::string, VecFloat>>&>(objects,
                                                                Gvalues);

  CHECK_EQ(Gvalues.size(), objects.size());

  int count = 0;
  for (const auto& image_boxes : boxes) {
    std::vector<AttributeInfos> attribute_infos;
    for (const auto& image_box : image_boxes) {
      const auto& values = Gvalues[count++];
      CHECK_EQ(values.size(), categories_.size());
      AttributeInfos infos;
      for (int i = 0; i < categories_.size(); i++) {
        const auto& category = categories_[i];
        const int top_index = Util::top_k(values.at(category), 1)[0];
        const auto socre = values.at(category)[top_index];
        const int lable =
            config_.thresholds_size() > i && socre < config_.thresholds(i)
                ? -1
                : top_index;
        const auto lable_str =
            lable < 0 ? ""
            : config_.label_str_mappings_size() > i &&
                    config_.label_str_mappings(i).data_size() > top_index
                ? config_.label_str_mappings(i).data(top_index)
                : std::to_string(top_index);
        infos.push_back({top_index, socre, lable_str});
      }
      attribute_infos.push_back(infos);
    }
    attributes.push_back(attribute_infos);
  }

  CHECK_EQ(count, objects.size());
}

size_t AttributeEngine::MaxBatchSize() const { return config_.batch_size(); }

void AttributeEngine::Process(const input_type& in, output_type* out) {
  std::vector<output_type*> outs{out};
  ProcessBatch({in}, &outs);
}

void AttributeEngine::ProcessBatch(const std::vector<input_type>& in,
                                   const std::vector<output_type*>* out) {
  LOG_IF(FATAL, in.size() != out->size()) << "size error";

  VecShellFrame images;
  std::vector<VecRectF> rects_vec;
  // input
  for (int i = 0; i < in.size(); i++) {
    const auto& mat = std::get<0>(in[i]);
    const auto& rect_vec = std::get<1>(in[i]);
    images.push_back(std::make_shared<ShellFrame>(std::make_shared<cv::Mat>(mat)));
    rects_vec.push_back(rect_vec);
  }

  // output
  std::vector<std::vector<AttributeInfos>> attributes;
  Predict(images, rects_vec, attributes);

  for (int i = 0; i < attributes.size(); i++) {
    out->at(i)->swap(attributes.at(i));
  }
}

AttributeEngine::input_type AttributeEngine::ConvertInput(
    const cv::Mat& mat, const inference::PictureReq& req) {
  RectF rect = req.has_rect() ? RectF(req.rect().x(), req.rect().y(),
                                      req.rect().w(), req.rect().h())
                              : RectF(0, 0, mat.cols, mat.rows);
  return input_type{mat, VecRectF{rect}};
}

inference::PictureResp AttributeEngine::ConvertOutput(
    const output_type& results) {
  inference::PictureResp resp;
  if (results.empty()) {
    return std::move(resp);
  }
  for (auto attr : results[0]) {
    resp.add_attribute(attr.label_str);
    resp.add_score(attr.score);
  }
  return resp;
}

}  // namespace Attribute

}  // namespace FLOW
