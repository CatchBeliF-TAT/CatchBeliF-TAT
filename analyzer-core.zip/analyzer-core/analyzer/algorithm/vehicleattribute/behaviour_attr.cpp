#include "behaviour_attr.hpp"
#include "common/json.hpp"
#include "common/log.hpp"
#include "common/util.hpp"
#include "document.h"
#include "common/type.hpp"

using namespace std;
using namespace FLOW;
using namespace FLOW::Attribute;

inline RectF cvrect2RectF(const cv::Rect& rect) {
  return RectF(rect.x, rect.y, rect.width, rect.height);
}

void BehaviourAttributeModule::Setup(const std::vector<char>& meta_net_data,
                                   const inference::Algorithm &config, int &code) {
  LOG(INFO) << "Create BehaviourAttributeModule";

  config_ = config;
  constexpr int NONMOTOR_ATTRIBUTE_NUM = 5;
  if (!config_.has_num_attributes()){
    config_.set_num_attributes(NONMOTOR_ATTRIBUTE_NUM);
  }
  engine_ = std::make_shared<AttributeEngine>(meta_net_data, config_);
  code = FLOW::module_status_success;

  LOG(INFO) << "Finished create BehaviourAttributeeModule!";
}

void BehaviourAttributeModule::Predict(const ShellFrame_Ptr& shell_frame, VecBoxF *boxes) {
  const VecShellFrame vec_mat{shell_frame};
  vector<VecBoxF> vec_boxes{*boxes};
  Predict(vec_mat, &vec_boxes);
  boxes->swap(vec_boxes.at(0));
}

void BehaviourAttributeModule::Predict(const VecShellFrame& shell_frames, vector<VecBoxF> *vec_boxes) {
  int code;
  vector<std::vector<RectInfo>> OD_boxes;
  for (auto & boxes : *vec_boxes) {
    std::vector<RectInfo> od_boxes;
    for (int i = 0; i < boxes.size(); i++) {
      RectInfo temprect;
      temprect.rect = cv::Rect{int(boxes.at(i).xmin), int(boxes.at(i).ymin),
                               int(boxes.at(i).xmax - boxes.at(i).xmin + 1),
                               int(boxes.at(i).ymax - boxes.at(i).ymin + 1)};
      temprect.label = boxes.at(i).label;
      temprect.score = boxes.at(i).score;
      od_boxes.push_back(temprect);
    }
    OD_boxes.push_back(od_boxes);
  }

  vector<vector<Attribute::AttributeInfos>> vec_attributeout;
  Process(shell_frames, OD_boxes, vec_attributeout, code);

  for (int i = 0; i < vec_attributeout.size(); i++) {
    auto &boxes = vec_boxes->at(i);
    auto &attributeout = vec_attributeout.at(i);
    for (int j = 0; j < attributeout.size(); ++j) {
      auto &box = boxes.at(j);
      box.behaviour_types.clear();
      auto &attributes = attributeout.at(j);
      std::map<int, AttributeInfo> attributeMap;
      for (int k = 0; k < attributes.size(); ++k) {
        attributeMap[attributes[k].label] = attributes[k];
      }
      if (attributeMap.count(WaiMai_PERSON)) {
        continue;
      }
      for (auto waimai = attributeMap.lower_bound(WaiMai_MEITUAN);
          waimai != attributeMap.upper_bound(WaiMai_SUSPECT);
          waimai++) {
          box.attr_type.type = waimai->second.label;
          box.attr_type.score = waimai->second.score;
      }
      for (auto nonmotor = attributeMap.lower_bound(NonMotor_Begin+1);
          nonmotor != attributeMap.upper_bound(NonMotor_End);
          nonmotor++) {
          box.nonmotor_type.type = nonmotor->second.label;
          box.nonmotor_type.score = nonmotor->second.score;
      }
      if (box.nonmotor_type.type != -1) {
        for( auto behaviour : std::vector<int>{BeHaviour_Non_Helmet, BeHaviour_Manned, BeHaviour_Promoting} ) {
          if (attributeMap.count(behaviour)) {
            const auto& attr = attributeMap[behaviour];
            Attr temp_behaviour;
            temp_behaviour.type = attr.label;
            temp_behaviour.score =attr.score;
            box.behaviour_types.push_back(temp_behaviour);
          }
        }
      }
    }
  }
}

void BehaviourAttributeModule::Process(
    const VecShellFrame& shell_frames, vector<std::vector<RectInfo>> &OD_boxes,
    vector<std::vector<AttributeInfos>> &attributes, int &code) {
  attributes.clear();
  auto *engine = reinterpret_cast<AttributeEngine *>(engine_.get());
  std::vector<VecRectF> roi_boxes;
  for (int i = 0; i < OD_boxes.size(); i++) {
    VecRectF temp;
    for (int j = 0; j < OD_boxes[i].size(); j++) {
      temp.push_back(cvrect2RectF(OD_boxes[i][j].rect));
    }
    roi_boxes.push_back(temp);
  }
  engine->Predict(shell_frames, roi_boxes, attributes);

  auto fn_check_threshold = [&](int index, float socre)->bool {
    const float DEFAULT_THRESHOLD = 0.7;
    if (config_.thresholds_size() > index) {
      return socre >= config_.thresholds(index);
    } else {
      return socre >= DEFAULT_THRESHOLD;
    }
  };

  for (int i = 0; i < attributes.size(); i++) {
    for (int j = 0; j < attributes[i].size(); j++) {
        if (fn_check_threshold(0, attributes[i][j][0].score)){
          attributes[i][j][0].label += 0x0501;
        }else{
          attributes[i][j][0].label = -1;
        }
        if (fn_check_threshold(1, attributes[i][j][1].score)){
          attributes[i][j][1].label += 0x0511;
        }else{
          attributes[i][j][1].label = -1;
        }
        if (fn_check_threshold(2, attributes[i][j][2].score)){
            attributes[i][j][2].label += 0x0521;
        }else{
            attributes[i][j][2].label = -1;
        }
        if (fn_check_threshold(3, attributes[i][j][3].score)){
            attributes[i][j][3].label += 0x0531;
        }else{
            attributes[i][j][3].label = -1;
        }
        if (fn_check_threshold(4, attributes[i][j][4].score)){
            attributes[i][j][4].label += 0x0201;
        }else{
            attributes[i][j][4].label = -1;
        }
    }
  }

  code = FLOW::module_status_success;
}

void BehaviourAttributeModule::Release() {
  LOG(INFO) << "Release BehaviourAttributeModule";
}
BehaviourAttributeModule::~BehaviourAttributeModule() {
  LOG(INFO) << "Deconstruct BehaviourAttributeModule";
}
