#ifndef ANALYZER_ALGORITHM_VEHICLEATTRIBUTE_CONSTRUCT_ATTR_HPP_
#define ANALYZER_ALGORITHM_VEHICLEATTRIBUTE_CONSTRUCT_ATTR_HPP_

#include <memory>
#include <opencv2/opencv.hpp>
#include <string>
#include <vector>
#include "algorithm/construction/construction.hpp"
#include "algorithm/detect/detect.hpp"
#include "attributeClass.hpp"
#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace Attribute {

#ifndef construction_label_attr
#define construction_label_attr 0x0a01
#endif

enum ConstructionCLSType {
  Construction_Worker_cls = construction_label_attr + 5,     //施工人员
  Construction_NonWorker_cls,                           //非施工人员
  Construction_Other_Worker_cls,                        //其他(用于过滤)
  Construction_LEO_Worker_cls,                          //执法人员 law_enforcement_officer
  Construction_Truck_cls = construction_label_attr + 0x010,  //施工车辆
  Construction_Normal_Car_cls,                          //普通车辆
  Construction_Other_Car_cls,                           //其他(用于过滤)
};

inline std::string helperGetStringConstructionCLSType(ConstructionCLSType t) {
  switch (t) {
    case Construction_Worker_cls:
      return "Worker";
    case Construction_NonWorker_cls:
      return "NonWorker";
    case Construction_Other_Worker_cls:
      return "Other";
    case Construction_LEO_Worker_cls:
      return "LEOWorker";
    case Construction_Truck_cls:
      return "Truck";
    case Construction_Normal_Car_cls:
      return "Normal";
    case Construction_Other_Car_cls:
      return "Other";
    default:
      break;
  }
  char buf[32];
  sprintf(buf, "%d", t);
  return buf;
}

class ConstructionAttributeModule {
 public:
  ConstructionAttributeModule() = default;

  ~ConstructionAttributeModule();

 public:
  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

  void Predict(const ShellFrame_Ptr& shell_frame, VecBoxF* boxes);
  void Predict(const VecShellFrame& shell_frames, std::vector<VecBoxF> *vec_boxes);

  void Predict(const VecShellFrame& shell_frames,
               std::vector<Construction_Event>* events);

  void Process(const VecShellFrame& shell_frames, const std::vector<std::vector<RectInfo>>& images_boxes,
               std::vector<std::vector<AttributeInfos>>& attributes, int& code);

  void Release();

 public:
  inference::Algorithm config_;

 private:
  std::shared_ptr<void> engine_ = nullptr;
};
}  // namespace Attribute
}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_VEHICLEATTRIBUTE_CONSTRUCT_ATTR_HPP_
