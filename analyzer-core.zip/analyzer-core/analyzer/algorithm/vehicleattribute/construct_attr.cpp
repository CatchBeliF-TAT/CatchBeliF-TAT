#include "construct_attr.hpp"
#include "attributeClass.hpp"
#include "common/json.hpp"
#include "common/log.hpp"
#include "common/type.hpp"
#include "common/util.hpp"
#include "document.h"

using namespace std;

namespace FLOW {

namespace Attribute {

using namespace Construction;

inline RectF cvrect2RectF(const cv::Rect& rect) {
  return RectF(rect.x, rect.y, rect.width, rect.height);
}

void ConstructionAttributeModule::Setup(const std::vector<char>& meta_net_data,
                                        const inference::Algorithm& config,
                                        int& code) {
  LOG(INFO) << "Create ConstructionAttributeModule";
  config_ = config;
  constexpr int CONSTRUCTION_ATTRIBUTE_NUM = 2;
  if (!config_.has_num_attributes()) {
    config_.set_num_attributes(CONSTRUCTION_ATTRIBUTE_NUM);
  }
  engine_ = std::make_shared<AttributeEngine>(meta_net_data, config_);
  code = FLOW::module_status_success;

  LOG(INFO) << "Finished create ConstructionAttributeModule!";
}

void ConstructionAttributeModule::Predict(const ShellFrame_Ptr& shell_frame, VecBoxF* boxes) {
  VecShellFrame vec_mat({shell_frame});
  std::vector<VecBoxF> vec_boxes(1);
  vec_boxes[0].swap(*boxes);
  Predict(vec_mat, &vec_boxes);
  boxes->swap(vec_boxes[0]);
}

void ConstructionAttributeModule::Predict(const VecShellFrame& shell_frames, std::vector<VecBoxF> *vec_boxes) {
  std::vector<std::vector<RectInfo>> od_boxes;
  for (const auto& boxes : *vec_boxes) {
    od_boxes.reserve(vec_boxes->size());
    od_boxes.resize(od_boxes.size()+1);
    for (int i = 0; i < boxes.size(); i++) {
      RectInfo temprect;
      temprect.rect = cv::Rect{int(boxes[i].xmin), int(boxes[i].ymin),
                              int(boxes[i].xmax - boxes[i].xmin + 1),
                              int(boxes[i].ymax - boxes[i].ymin + 1)};
      temprect.label = boxes[i].label;
      temprect.score = boxes[i].score;
      od_boxes.back().push_back(temprect);
    }
  }

  int code;
  vector<vector<Attribute::AttributeInfos>> vec_attributeout;
  // process
  Process(shell_frames, od_boxes, vec_attributeout, code);

  // result
  for (int i = 0; i < vec_attributeout.size(); i++) {
    auto& attributeout = vec_attributeout.at(i);
    for (int j = 0; j < attributeout.size(); ++j) {
      auto& box = (*vec_boxes)[i][j];
      if (box.label == OBJECT_TYPE_PERSON) {
        box.traffic_person_type.type  = attributeout.at(j)[0].label;
        box.traffic_person_type.score = attributeout.at(j)[0].score;
      }
    }
  }
}

void ConstructionAttributeModule::Predict(
    const VecShellFrame& shell_frames, std::vector<Construction_Event>* events) {
  int code;
  vector<std::vector<RectInfo>> OD_boxes;
  for (auto& boxes : *events) {
    std::vector<RectInfo> od_boxes;
    for (int i = 0; i < boxes.objs.size(); i++) {
      RectInfo temprect;
      temprect.rect =
          cv::Rect{int(boxes.objs.at(i).xmin), int(boxes.objs.at(i).ymin),
                   int(boxes.objs.at(i).xmax - boxes.objs.at(i).xmin + 1),
                   int(boxes.objs.at(i).ymax - boxes.objs.at(i).ymin + 1)};
      temprect.label = boxes.objs.at(i).label;
      temprect.score = boxes.objs.at(i).score;
      od_boxes.push_back(temprect);
    }
    OD_boxes.push_back(od_boxes);
  }

  vector<vector<Attribute::AttributeInfos>> vec_attributeout;
  Process(shell_frames, OD_boxes, vec_attributeout, code);

  for (int i = 0; i < vec_attributeout.size(); i++) {
    auto& event = events->at(i);
    auto& attributeout = vec_attributeout.at(i);
    for (int j = 0; j < attributeout.size(); ++j) {
      auto& box = event.objs.at(j);
      if (box.label == OBJECT_TYPE_VEHICLE) {
        if(attributeout.at(j)[1].label!=-1){
          box.shigong_attr.type = attributeout.at(j)[1].label;
          box.shigong_attr.score = attributeout.at(j)[1].score;
        }
      }
      if (box.label == OBJECT_TYPE_PERSON) {
        if(attributeout.at(j)[1].label!=-1){
          box.shigong_attr.type = attributeout.at(j)[0].label;
          box.shigong_attr.score = attributeout.at(j)[0].score;
        }
      }
    }
  }
}

void ConstructionAttributeModule::Process(
    const VecShellFrame& shell_frames, const vector<std::vector<RectInfo>>& OD_boxes,
    vector<std::vector<AttributeInfos>>& attributes, int& code) {
  attributes.clear();
  auto* engine = reinterpret_cast<AttributeEngine*>(engine_.get());
  std::vector<VecRectF> roi_boxes;
  for (int i = 0; i < OD_boxes.size(); i++) {
    VecRectF temp;
    for (int j = 0; j < OD_boxes[i].size(); j++) {
      temp.push_back(cvrect2RectF(OD_boxes[i][j].rect));
    }
    roi_boxes.push_back(temp);
  }
  engine->Predict(shell_frames, roi_boxes, attributes);

  for (int i = 0; i < attributes.size(); i++) {
    for (int j = 0; j < attributes[i].size(); j++) {
      if (attributes[i][j][0].score > config_.detect_thresholds()[0]) {
        attributes[i][j][0].label += construction_label_attr + 5;
      } else {
        attributes[i][j][0].label = -1;
      }
      if (attributes[i][j][1].score > config_.detect_thresholds()[1]) {
        attributes[i][j][1].label += construction_label_attr + 0x010;
      } else {
        attributes[i][j][1].label = -1;
      }
    }
  }

  code = FLOW::module_status_success;
}

void ConstructionAttributeModule::Release() {
  LOG(INFO) << "Release ConstructionAttributeModule";
}

ConstructionAttributeModule::~ConstructionAttributeModule() {
  LOG(INFO) << "Deconstruct DetectModule";
}

}  // namespace Attribute

}  // namespace FLOW
