#include "vehicle_attr.hpp"
#include "attributeClass.hpp"
#include "common/json.hpp"
#include "common/log.hpp"
#include "common/type.hpp"
#include "common/util.hpp"
#include "document.h"

using namespace FLOW;
using namespace Attribute;
using namespace std;

inline RectF cvrect2RectF(const cv::Rect& rect) {
  return RectF(rect.x, rect.y, rect.width, rect.height);
}

void VehicleAttributeModule::Setup(const std::vector<char>& meta_net_data,
                                   const inference::Algorithm& config,
                                   int& code) {
  LOG(INFO) << "Create vehicleAttributeModule";
  config_ = config;
  constexpr int VEHICLE_ATTRIBUTE_NUM = 3;
  if (!config_.has_num_attributes()) {
    config_.set_num_attributes(VEHICLE_ATTRIBUTE_NUM);
  }
  engine_ = std::make_shared<AttributeEngine>(meta_net_data, config_);
  code = FLOW::module_status_success;

  LOG(INFO) << "Finished create vehicleAttributeModule!";
}

void VehicleAttributeModule::Predict(const ShellFrame_Ptr& shell_frame, VecBoxF* boxes) {
  int code;
  std::vector<RectInfo> od_boxes;
  for (int i = 0; i < boxes->size(); i++) {
    RectInfo temprect;
    temprect.rect = cv::Rect{int(boxes->at(i).xmin), int(boxes->at(i).ymin),
                             int(boxes->at(i).xmax - boxes->at(i).xmin + 1),
                             int(boxes->at(i).ymax - boxes->at(i).ymin + 1)};
    temprect.label = boxes->at(i).label;
    temprect.score = boxes->at(i).score;
    od_boxes.push_back(temprect);
  }

  vector<std::vector<RectInfo>> OD_boxes;
  OD_boxes.push_back(od_boxes);

  VecShellFrame im_in;
  im_in.push_back(shell_frame);
  vector<vector<Attribute::AttributeInfos>> attributeout;
  Process(im_in, OD_boxes, attributeout, code);

  for (int i = 0; i < attributeout[0].size(); i++) {
    auto& box = boxes->at(i);
    box.attr_type.type = attributeout[0][i][1].label;
    box.attr_type.score = attributeout[0][i][1].score;
    box.attr_direction.type = attributeout[0][i][0].label;
    box.attr_direction.score = attributeout[0][i][0].score;
    box.special_car_type.type = attributeout[0][i][2].label;
    box.special_car_type.score = attributeout[0][i][2].score;
  }
}

void VehicleAttributeModule::Predict(const VecShellFrame& shell_frames,
                                     vector<VecBoxF>* vec_boxes) {
  int code;
  vector<std::vector<RectInfo>> OD_boxes;
  for (auto& boxes : *vec_boxes) {
    std::vector<RectInfo> od_boxes;
    for (int i = 0; i < boxes.size(); i++) {
      RectInfo temprect;
      temprect.rect = cv::Rect{int(boxes.at(i).xmin), int(boxes.at(i).ymin),
                               int(boxes.at(i).xmax - boxes.at(i).xmin + 1),
                               int(boxes.at(i).ymax - boxes.at(i).ymin + 1)};
      temprect.label = boxes.at(i).label;
      temprect.score = boxes.at(i).score;
      od_boxes.push_back(temprect);
    }
    OD_boxes.push_back(od_boxes);
  }

  vector<vector<Attribute::AttributeInfos>> vec_attributeout;
  Process(shell_frames, OD_boxes, vec_attributeout, code);

  for (int i = 0; i < vec_attributeout.size(); i++) {
    auto& boxes = vec_boxes->at(i);
    auto& attributeout = vec_attributeout.at(i);
    for (int j = 0; j < attributeout.size(); ++j) {
      auto& box = boxes.at(j);
      box.attr_type.type = attributeout.at(j)[1].label;
      box.attr_type.score = attributeout.at(j)[1].score;
      box.attr_direction.type = attributeout.at(j)[0].label;
      box.attr_direction.score = attributeout.at(j)[0].score;
      box.special_car_type.type = attributeout.at(j)[2].label;
      box.special_car_type.score = attributeout.at(j)[2].score;
    }
  }
}

void VehicleAttributeModule::Process(
    const VecShellFrame& shell_frames, vector<std::vector<RectInfo>>& OD_boxes,
    vector<std::vector<AttributeInfos>>& attributes, int& code) {
  attributes.clear();
  auto* engine = reinterpret_cast<AttributeEngine*>(engine_.get());
  std::vector<VecRectF> roi_boxes;
  for (int i = 0; i < OD_boxes.size(); i++) {
    VecRectF temp;
    for (int j = 0; j < OD_boxes[i].size(); j++) {
      temp.push_back(cvrect2RectF(OD_boxes[i][j].rect));
    }
    roi_boxes.push_back(temp);
  }
  engine->Predict(shell_frames, roi_boxes, attributes);

  auto fn_check_threshold = [&](int index, float socre)->bool {
    const float DEFAULT_THRESHOLD = 0.7;
    if (config_.thresholds_size() > index) {
      return socre >= config_.thresholds(index);
    } else {
      return socre >= DEFAULT_THRESHOLD;
    }
  };
  for (int i = 0; i < attributes.size(); i++) {
    for (int j = 0; j < attributes[i].size(); j++) {
      if (fn_check_threshold(0, attributes[i][j][0].score)) {
        attributes[i][j][0].label += 0x0301;
      } else {
        attributes[i][j][0].label = -1;
      }
      if (fn_check_threshold(1, attributes[i][j][1].score)) {
        attributes[i][j][1].label += 0x0101;
      } else {
        attributes[i][j][1].label = -1;
      }
      if (fn_check_threshold(2, attributes[i][j][2].score)) {
        attributes[i][j][2].label += 0x0401;
      } else {
        attributes[i][j][2].label = -1;
      }
    }
  }

  code = FLOW::module_status_success;
}

void VehicleAttributeModule::Release() {
  LOG(INFO) << "Release VehicleAttributeModule";
}
VehicleAttributeModule::~VehicleAttributeModule() {
  LOG(INFO) << "Deconstruct DetectModule";
}

size_t VehicleAttributeModule::MaxBatchSize() const {
    return config_.batch_size(); 
}

void VehicleAttributeModule::Process(const input_type& in, output_type* out) {
    std::vector<output_type*> outs{out};
    ProcessBatch({in}, &outs);
}

void VehicleAttributeModule::ProcessBatch(const std::vector<input_type>& in, const std::vector<output_type*>* out) {
  LOG_IF(FATAL, in.size() != out->size()) <<"size error";

  VecShellFrame images;
  std::vector<VecBoxF> boxes;
  // input
  for (int i = 0; i < in.size(); i++) {
    const auto& mat = std::get<0>(in[i]);
    const auto& box = std::get<1>(in[i]);
    images.push_back(std::make_shared<ShellFrame>(std::make_shared<cv::Mat>(mat)));
    boxes.push_back(VecBoxF{box});
  }

  Predict(images, &boxes);

  for (int i = 0; i < boxes.size(); i++) {
    *(out->at(i)) = boxes[i].front();
  }
}

VehicleAttributeModule::input_type VehicleAttributeModule::ConvertInput(const cv::Mat& mat, const inference::PictureReq& req) 
{
    BoxF box = req.has_rect() 
            ? BoxF(req.rect().x(), req.rect().y(),req.rect().x()+req.rect().w()-1,req.rect().y()+req.rect().h()-1)
            : BoxF(0,0, mat.cols-1, mat.rows-1);
    return input_type{mat, box};
}

inference::PictureResp VehicleAttributeModule::ConvertOutput(const output_type& results) 
{
    inference::PictureResp resp;
    const std::string attr_type = (results.attr_type.type==-1) 
        ? "" : helperGetStringVehicleType((VehicleType)results.attr_type.type);
    resp.add_attribute(attr_type);
    resp.add_score(results.attr_type.score);
    const std::string special_car_type = (results.special_car_type.type==-1) 
        ? "" : helperGetStringVehicleSpecialType((VehicleSpecialType)results.special_car_type.type);
    resp.add_attribute(special_car_type);
    resp.add_score(results.special_car_type.score);
    const std::string attr_direction = (results.attr_direction.type==-1) 
        ? "" : helperGetStringVehicleDirectionType((VehicleDirectionType)results.attr_direction.type);
    resp.add_attribute(attr_direction);
    resp.add_score(results.attr_direction.score);
    return resp;
}
