#include "mot.hpp"
#include "common/log.hpp"

namespace FLOW
{
namespace PersonTracker
{

using namespace std;
using namespace cv;

//int MAX_ID_PERSON = 0;
//TRACK_LIST person_list[MAX_NUM_PERSON];
//vector<DST_LIST> pre_person_list;

int is_on_boader(DST_LIST &dst, int w, int h)
{
	if (dst.xl < 20 || dst.yt < 20 || dst.xr > w - 20 || dst.yb > h - 20)
	{
		return 1;
	}
	return 0;
}

float get_pair_ratio(DST_LIST &dst, TRACK_LIST &target)
{
	float x_l = max(dst.xl, target.xl);
	float y_t = max(dst.yt, target.yt);
	float x_r = min(dst.xr, target.xr);
	float y_b = min(dst.yb, target.yb);
	//printf("%f,%f,%f,%f\n", dst.xl, dst.yt, dst.xr, dst.yb);
	//printf("%f,%f,%f,%f", target.xl, target.yt, target.xr, target.yb);
	//printf("%f,%f,%f,%f", x_l, y_t, x_r, y_b);

	float dst_area = float(dst.xr - dst.xl) * float(dst.yb - dst.yt);
	float target_area = float(target.xr - target.xl) * float(target.yb - target.yt);

	if (x_r > x_l && y_b > y_t)
	{
		float inter_area = float(x_r - x_l) * float(y_b - y_t);
		if (dst_area > 2.5 * target_area || target_area > 2.5 * dst_area)
			return 0.0;
		float ratio = max(float(inter_area) / dst_area, float(inter_area) / target_area);
		if (ratio >= 0.99)
		{
			ratio = min(float(inter_area) / dst_area, float(inter_area) / target_area);
		}
		return ratio;
	}
	else
	{
		return 0.0;
	}
}

float get_pair_ratio_2(DST_LIST &dst, TRACK_LIST &target)
{
	float x_l = max(dst.xl, target.xl);
	float y_t = max(dst.yt, target.yt);
	float x_r = min(dst.xr, target.xr);
	float y_b = min(dst.yb, target.yb);

	float dst_area = float(dst.xr - dst.xl) * float(dst.yb - dst.yt);
	float target_area = float(target.xr - target.xl) * float(target.yb - target.yt);
	if (x_r > x_l && y_b > y_t)
	{
		float inter_area = float(x_r - x_l) * float(y_b - y_t);
		float ratio = max(float(inter_area) / dst_area, float(inter_area) / target_area);
		return ratio;
	}
	else
	{
		return 0.0;
	}
}

float get_pair_ratio_3(DST_LIST &dst, DST_LIST &target)
{
	float x_l = max(dst.xl, target.xl);
	float y_t = max(dst.yt, target.yt);
	float x_r = min(dst.xr, target.xr);
	float y_b = min(dst.yb, target.yb);

	float dst_area = float(dst.xr - dst.xl) * float(dst.yb - dst.yt);
	float target_area = float(target.xr - target.xl) * float(target.yb - target.yt);

	if (x_r > x_l && y_b > y_t)
	{
		float inter_area = float(x_r - x_l) * float(y_b - y_t);
		if (dst_area > 2.5 * target_area || target_area > 2.5 * dst_area)
			return 0.0;
		float ratio = max(float(inter_area) / dst_area, float(inter_area) / target_area);
		if (ratio >= 0.99)
		{
			ratio = min(float(inter_area) / dst_area, float(inter_area) / target_area);
		}
		return ratio;
	}
	else
	{
		return 0.0;
	}
}

void find_max_pair(DST_LIST &dst, int MAX_NUM, TRACK_LIST *target_list, float *ratio, int *n)
{
	float max_ratio = 0.0;
	int max_i = 0;

	for (int i = 0; i < MAX_NUM; i++)
	{
		if (target_list[i].valid == 1)
		{
			float ratio = get_pair_ratio(dst, target_list[i]);
			//printf("ratio=%f\n",ratio);
			if (ratio > 0.000001 && ratio > max_ratio)
			{
				max_ratio = ratio;
				max_i = i;
			}
		}
	}
	if (max_ratio < 0.000001)
	{
		max_ratio = 0.0;
		max_i = 0;
	}
	*ratio = max_ratio;
	*n = max_i;
}

// 检测使用
void find_max_pair_2(DST_LIST dst, int MAX_NUM, vector<DST_LIST> &target_list, float *ratio, int *n)
{
	float max_ratio = 0.0;
	int max_i = 0;

	for (int i = 0; i < MAX_NUM; i++)
	{
		float ratio = get_pair_ratio_3(dst, target_list[i]);
		if (ratio > 0.000001 && ratio > max_ratio)
		{
			max_ratio = ratio;
			max_i = i;
		}
	}
	if (max_ratio < 0.000001)
	{
		max_ratio = 0.0;
		max_i = 0;
	}
	*ratio = max_ratio;
	*n = max_i;
}

void staple_track_for_person(vector<DST_LIST> &in_dst_list, TRACK_LIST person_list[MAX_NUM_PERSON], int *MAX_ID_PERSON, Mat &img)
{
	int in_num = in_dst_list.size();
	vector<int> track_id;

	//vector<DST_LIST> temp_pre_person_list;
	//for (int i = 0; i < pre_person_list.size(); i++)
	//{
	//	temp_pre_person_list.push_back(pre_person_list[i]);
	//}
	//pre_person_list.clear();

	for (int i = 0; i < in_num; i++)
	{
		float max_ratio;
		int max_i;
		find_max_pair(in_dst_list[i], MAX_NUM_PERSON, person_list, &max_ratio, &max_i);
		// printf("i=%d\nmax_ratio=%f\n", i, max_ratio);
		if (max_ratio > MIN_PAIR_RATIO)
		{
			track_id.push_back(max_i);
			person_list[max_i].dis = 0;
			person_list[max_i].xl = in_dst_list[i].xl;
			person_list[max_i].yt = in_dst_list[i].yt;
			person_list[max_i].xr = in_dst_list[i].xr;
			person_list[max_i].yb = in_dst_list[i].yb;
			person_list[max_i].dec_num++;
			person_list[max_i].track_num++;
			person_list[max_i].nonUpdateNum++;
		 
			if (person_list[max_i].nonUpdateNum >= UPDATE_INTER)
			{
				// #ifndef LEVEL1_IOU_ONLY
				// 				Rect_<float> location(person_list[max_i].xl, person_list[max_i].yt,
				// 									  person_list[max_i].xr - person_list[max_i].xl,
				// 									  person_list[max_i].yb - person_list[max_i].yt);
				// 				person_list[max_i].staple.tracker_staple_correct(location);
				// 				person_list[max_i].staple.tracker_staple_train(img, false);
				// #endif
				person_list[max_i].nonUpdateNum = 0;
			}
		}
		else
		{
			//find_max_pair_2(in_dst_list[i], temp_pre_person_list.size(), temp_pre_person_list, &max_ratio, &max_i);
			//if (max_ratio < MIN_PAIR_RATIO)
			//{
			//	pre_person_list.push_back(in_dst_list[i]);
			//	continue;
			//}
			for (int j = 0; j < MAX_NUM_PERSON; j++)
			{
				if (person_list[j].valid == 0)
				{
					*MAX_ID_PERSON += 1;
					track_id.push_back(j);
					person_list[j].idd = *MAX_ID_PERSON;
					person_list[j].dis = 0;
					person_list[j].valid = 1;
					person_list[j].xl = in_dst_list[i].xl;
					person_list[j].yt = in_dst_list[i].yt;
					person_list[j].xr = in_dst_list[i].xr;
					person_list[j].yb = in_dst_list[i].yb;
					person_list[j].track_num = 1;
					person_list[j].dec_num = 1;
					person_list[j].nonUpdateNum++;
					// #ifndef LEVEL1_IOU_ONLY
					// 					Rect_<float> location(person_list[j].xl, person_list[j].yt,
					// 										  person_list[j].xr - person_list[j].xl,
					// 										  person_list[j].yb - person_list[j].yt);
					// 					person_list[j].staple.tracker_staple_initialize(img, location);
					// 					person_list[j].staple.tracker_staple_train(img, true);
					// #endif
					break;
				}
			}
		}
	}
	for (int k = 0; k < MAX_NUM_PERSON; k++)
	{
		int equ_sign = 0;
		for (int j = 0; j < track_id.size(); j++)
		{
			if (k == track_id[j])
			{
				equ_sign = 1;
			}
		}
		if (equ_sign == 1)
		{
			continue;
		}
		if (person_list[k].valid == 1)
		{
			person_list[k].dis = person_list[k].dis + 1;
			if (person_list[k].dis >= MAX_DIS_NUM_PERSON)
			{
				person_list[k].idd = 0;
				person_list[k].dis = 0;
				person_list[k].valid = 0;
				person_list[k].xl = 0.0;
				person_list[k].yt = 0.0;
				person_list[k].xr = 0.0;
				person_list[k].yb = 0.0;
				person_list[k].dec_num = 0;
				person_list[k].track_num = 0;
				person_list[k].nonUpdateNum = 0;
			}
			else
			{
				person_list[k].track_num++;
				person_list[k].nonUpdateNum++;
				// #ifdef LEVEL2_LESS_TRACK
				// 				Rect_<float> location = person_list[k].staple.tracker_staple_estimate(img);
				// 				if (location.width < 0.0001f && location.height < 0.0001f) {
				// 					person_list[k].idd = 0;
				// 					person_list[k].dis = 0;
				// 					person_list[k].valid = 0;
				// 					person_list[k].xl = 0.0;
				// 					person_list[k].yt = 0.0;
				// 					person_list[k].xr = 0.0;
				// 					person_list[k].yb = 0.0;
				// 					person_list[k].dec_num = 0;
				// 					person_list[k].track_num = 0;
				// 				} else {
				// 					if (person_list[k].nonUpdateNum >= UPDATE_INTER) {
				// 						person_list[k].staple.tracker_staple_train(img, false);
				// 						person_list[k].nonUpdateNum = 0;
				// 					}
				// 					person_list[k].xl = location.x;
				// 					person_list[k].yt = location.y;
				// 					person_list[k].xr = location.x + location.width;
				// 					person_list[k].yb = location.y + location.height;
				// 				}
				// #endif
				// #ifdef LEVEL3_TRACK
				// 				if (person_list[k].nonUpdateNum >= UPDATE_INTER)
				// 				{
				// 					person_list[k].staple.tracker_staple_train(img, false);
				// 					person_list[k].nonUpdateNum = 0;
				// 				}
				// #endif
			}
		}
	}

	// track disappear
	for (int i = 0; i < MAX_NUM_PERSON; i++)
	{
			// LOG(INFO)<< "-------------";
			// LOG(INFO)<< person_list[i].dis ;
			// LOG(INFO)<< person_list[i].xl ;
			// LOG(INFO)<< person_list[i].yt ;
			// LOG(INFO)<< person_list[i].xr;
			// LOG(INFO)<< person_list[i].yb;
			// LOG(INFO)<< person_list[i].dec_num;
			// LOG(INFO)<< person_list[i].track_num;
			// LOG(INFO)<< person_list[i].nonUpdateNum;

		// printf("i=%d\nmax_ratio=%f\n", i, max_ratio);
		// LOG(INFO)<< person_list[i];
		if (person_list[i].valid == 1)
		{
			DST_LIST temp;
			temp.xl = person_list[i].xl;
			temp.yt = person_list[i].yt;
			temp.xr = person_list[i].xr;
			temp.yb = person_list[i].yb;
			if (is_on_boader(temp, img.cols, img.rows) == 1 && person_list[i].dis >= 3)
			{
				person_list[i].idd = 0;
				person_list[i].dis = 0;
				person_list[i].valid = 0;
				person_list[i].xl = 0.0;
				person_list[i].yt = 0.0;
				person_list[i].xr = 0.0;
				person_list[i].yb = 0.0;
				person_list[i].dec_num = 0;
				person_list[i].track_num = 0;
			}
		}
	}

	// error detect
	for (int i = 0; i < MAX_NUM_PERSON; i++)
	{
		if (person_list[i].valid == 1)
		{
			if (person_list[i].track_num == 2 && person_list[i].dec_num < 2)
			{
				person_list[i].idd = 0;
				person_list[i].dis = 0;
				person_list[i].valid = 0;
				person_list[i].xl = 0.0;
				person_list[i].yt = 0.0;
				person_list[i].xr = 0.0;
				person_list[i].yb = 0.0;
				person_list[i].dec_num = 0;
				person_list[i].track_num = 0;
			}
		}
	}
}

void QN_MOT_staple_for_person(vector<DST_LIST> &in_dst_list, Mat &img, TRACK_LIST person_list[MAX_NUM_PERSON], TRACK_RES res_person_list[MAX_NUM_PERSON], int *MAX_ID_PERSON, int scene_change_sign)
{
	//scene change, clean
	if (1 == scene_change_sign)
	{
		for (int i = 0; i < MAX_NUM_PERSON; i++)
		{
			if (person_list[i].valid == 1)
			{
				person_list[i].idd = 0;
				person_list[i].dis = 0;
				person_list[i].valid = 0;
				person_list[i].xl = 0.0;
				person_list[i].yt = 0.0;
				person_list[i].xr = 0.0;
				person_list[i].yb = 0.0;
				person_list[i].dec_num = 0;
				person_list[i].track_num = 0;
			}
		}
	}

	// #ifdef LEVEL3_TRACK
	// 	for (int i = 0; i < MAX_NUM_PERSON; i++)
	// 	{
	// 		if (person_list[i].valid == 1)
	// 		{
	// 			Rect_<float> location = person_list[i].staple.tracker_staple_estimate(img);

	// 			if (location.width<0.0001f && location.height<0.0001f)
	// 			{
	// 				person_list[i].idd = 0;
	// 				person_list[i].dis = 0;
	// 				person_list[i].valid = 0;
	// 				person_list[i].xl = 0.0;
	// 				person_list[i].yt = 0.0;
	// 				person_list[i].xr = 0.0;
	// 				person_list[i].yb = 0.0;
	// 				person_list[i].dec_num = 0;
	// 				person_list[i].track_num = 0;
	// 			}
	// 			else
	// 			{
	// 				person_list[i].xl = location.x;
	// 				person_list[i].yt = location.y;
	// 				person_list[i].xr = location.x + location.width;
	// 				person_list[i].yb = location.y + location.height;
	// 			}
	// 		}
	// 	}
	// #endif
	staple_track_for_person(in_dst_list, person_list, MAX_ID_PERSON, img);

	//memset(res_person_list,0, sizeof(TRACK_RES)*MAX_NUM_PERSON);
	for (int j = 0; j < MAX_NUM_PERSON; j++)
	{
		if (1 == person_list[j].valid)
		{
			if (res_person_list[j].valid == 1)
			{
				res_person_list[j].idd = person_list[j].idd;
				res_person_list[j].dis = person_list[j].dis;
				res_person_list[j].valid = person_list[j].valid;
				res_person_list[j].xl = person_list[j].xl;
				res_person_list[j].yt = person_list[j].yt;
				res_person_list[j].xr = person_list[j].xr;
				res_person_list[j].yb = person_list[j].yb;

				if (res_person_list[j].track_j_num < TRACK_J_NUM)
				{
					res_person_list[j].track_j[res_person_list[j].track_j_num].x =
						(res_person_list[j].xl + res_person_list[j].xr) / 2.0;
					res_person_list[j].track_j[res_person_list[j].track_j_num].y =
						(res_person_list[j].yt + res_person_list[j].yb) / 2.0;
					res_person_list[j].track_j_num++;
				}
				else if (res_person_list[j].track_j_num == TRACK_J_NUM)
				{
					memcpy(&res_person_list[j].track_j[0], &res_person_list[j].track_j[1],
						   (TRACK_J_NUM - 1) * sizeof(POINT));
					res_person_list[j].track_j[TRACK_J_NUM - 1].x =
						(res_person_list[j].xl + res_person_list[j].xr) / 2.0;
					res_person_list[j].track_j[TRACK_J_NUM - 1].y =
						(res_person_list[j].yt + res_person_list[j].yb) / 2.0;
				}
			}
			else
			{
				res_person_list[j].idd = person_list[j].idd;
				res_person_list[j].dis = person_list[j].dis;
				res_person_list[j].valid = person_list[j].valid;
				res_person_list[j].xl = person_list[j].xl;
				res_person_list[j].yt = person_list[j].yt;
				res_person_list[j].xr = person_list[j].xr;
				res_person_list[j].yb = person_list[j].yb;

				res_person_list[j].track_j_num = 0;
				res_person_list[j].track_j[res_person_list[j].track_j_num].x =
					(res_person_list[j].xl + res_person_list[j].xr) / 2.0;
				res_person_list[j].track_j[res_person_list[j].track_j_num].y =
					(res_person_list[j].yt + res_person_list[j].yb) / 2.0;
				res_person_list[j].track_j_num++;
			}
		}
		else
		{
			if (res_person_list[j].valid == 1)
			{
				memset(&res_person_list[j], 0, sizeof(TRACK_RES));
				res_person_list[j].event_1_ed = 8;
			}
		}
	}
}

} // namespace Headline
} // namespace FLOW