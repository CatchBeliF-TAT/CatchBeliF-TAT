/*
 * @Author: your name
 * @Date: 2020-12-14 16:04:59
 * @LastEditTime: 2020-12-14 16:39:47
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /analyzer-flow/analyzer/algorithm/persontrack/bodytracker.hpp
 */
#ifndef ANALYZER_ALGORITHM_BODYTRACK_BODYTRACK_HPP_
#define ANALYZER_ALGORITHM_BODYTRACK_BODYTRACK_HPP_

#include <vector>
#include "common/type.hpp"
#include "common/tad_internal.hpp"
#include "common/log.hpp"
#include "mot.hpp"
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

// #define MAX_NUM_PERSON 50
// #define TRACK_J_NUM 32

namespace FLOW
{
namespace BodyTracker
{
        class BodyTracker {
        public:
            BodyTracker() = default;

            ~BodyTracker() = default;

            void Process(cv::Mat &image, VecBoxF &boxes,
                         const ImageObjectsInfo &vec_image_objects_info, int &code);

        private:
            int MAX_ID_PERSON = 0;
            PersonTracker::TRACK_LIST person_list[MAX_NUM_PERSON];
            PersonTracker::TRACK_RES res_person_list[MAX_NUM_PERSON];
            std::vector<int> res_uid_list;

        };
} // namespace BodyTracker
} // namespace FLOW

#endif  // ANALYZER_ALGORITHM_BODYTRACK_BODYTRACK_HPP_
