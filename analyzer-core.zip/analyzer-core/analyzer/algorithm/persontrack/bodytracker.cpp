/*
 * @Author: your name
 * @Date: 2020-12-14 16:04:52
 * @LastEditTime: 2020-12-14 16:40:01
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /analyzer-flow/analyzer/algorithm/persontrack/bodytracker.cpp
 */
#include "common/log.hpp"
#include "bodytracker.hpp"

namespace FLOW
{
namespace BodyTracker
{
  using namespace std;
  using namespace cv;

void BodyTracker::Process(cv::Mat &image, VecBoxF &boxes,
                            const ImageObjectsInfo &vec_image_objects_info, int &code)
{
  vector<PersonTracker::DST_LIST> in_dst_list;
  in_dst_list.clear();
  int count = 0;
  for (const auto &box : boxes)
  {
    if (count >= MAX_NUM_PERSON)
    {
      break;
    }
    if (box.label != OBJECT_TYPE_PERSON)
    {
      continue;
    }
    PersonTracker::DST_LIST temp = {box.xmin, box.ymin, box.xmax, box.ymax};
    in_dst_list.push_back(temp);
    count++;
  }
  int scene_change_sign = 0;
  clock_t st2 = clock();
  QN_MOT_staple_for_person(in_dst_list, image, person_list, res_person_list, &MAX_ID_PERSON, scene_change_sign);

  for (auto &box : boxes)
  {
    for (auto &res_person : res_person_list)
    {
      if (int(box.xmin) == int(res_person.xl) && int(box.ymin) == int(res_person.yt) && int(box.xmax) == int(res_person.xr) && int(box.ymax) == int(res_person.yb))
      {
        box.uid = res_person.idd;
        box.violate_type = res_person.valid;
      }
    }
  }
  code = 0;
}

} // namespace BodyTracker
} // namespace FLOW
