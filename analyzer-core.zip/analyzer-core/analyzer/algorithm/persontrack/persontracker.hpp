#ifndef ANALYZER_ALGORITHM_PERSONTRACK_PERSONTRACKER_HPP_
#define ANALYZER_ALGORITHM_PERSONTRACK_PERSONTRACKER_HPP_

#include <vector>
#include "common/type.hpp"
#include "common/tad_internal.hpp"
#include "common/log.hpp"
#include "mot.hpp"
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

// #define MAX_NUM_PERSON 50
// #define TRACK_J_NUM 32

namespace FLOW
{
namespace PersonTracker
{
        class PersonTracker {
        public:
            PersonTracker() = default;

            ~PersonTracker() = default;

            void Process(cv::Mat &image, VecBoxF &boxes,
                         const ImageObjectsInfo &vec_image_objects_info, int &code);

            // void Release();

            // void AddStreamRoiConfig(const std::string &roi_id, const std::string &rois_cfg);

            // void RemoveStreamRoiConfig(const std::string &roi_id);

            // void AddStreamTrackingType(const std::string &roi_id, const std::string &rois_cfg);

            // void DrawTrackingROI(cv::Mat &im);

        private:
            // std::shared_ptr<mot::Tracker> engine_ = nullptr;
            int MAX_ID_PERSON = 0;
            TRACK_LIST person_list[MAX_NUM_PERSON];
            TRACK_RES res_person_list[MAX_NUM_PERSON];
            std::vector<int> res_uid_list;

        };
} // namespace Headline
} // namespace FLOW

#endif  // ANALYZER_ALGORITHM_PERSONTRACK_PERSONTRACKER_HPP_
