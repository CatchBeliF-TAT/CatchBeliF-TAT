#include "common/log.hpp"
#include "persontracker.hpp"

namespace FLOW
{
namespace PersonTracker
{
  using namespace std;
  using namespace cv;

void PersonTracker::Process(cv::Mat &image, VecBoxF &boxes,
                            const ImageObjectsInfo &vec_image_objects_info, int &code)
{
  vector<DST_LIST> in_dst_list;
  in_dst_list.clear();
  int count = 0;
  for (const auto &box : boxes)
  {
    if (count >= MAX_NUM_PERSON)
    {
      break;
    }
    if (box.label != OBJECT_TYPE_HEAD)
    {
      continue;
    }
    DST_LIST temp = {box.xmin, box.ymin, box.xmax, box.ymax};
    in_dst_list.push_back(temp);
    count++;
  }
  int scene_change_sign = 0;
  clock_t st2 = clock();
  QN_MOT_staple_for_person(in_dst_list, image, person_list, res_person_list, &MAX_ID_PERSON, scene_change_sign);
  //printf("\ntime_track: %.0lfms\n", (clock() - st2) * 1000.0 / CLOCKS_PER_SEC);

  // float xl = 0.0;
  // float yt = 0.0;
  // float xr = 0.0;
  // float yb = 0.0;
  // VecBoxF trackedObjs;
  for (auto &box : boxes)
  {
    for (auto &res_person : res_person_list)
    {
      if (int(box.xmin) == int(res_person.xl) && int(box.ymin) == int(res_person.yt) && int(box.xmax) == int(res_person.xr) && int(box.ymax) == int(res_person.yb))
      {
        box.uid = res_person.idd;
      }
    }
  }
  code = 0;
}

} // namespace PersonTracker
} // namespace FLOW
