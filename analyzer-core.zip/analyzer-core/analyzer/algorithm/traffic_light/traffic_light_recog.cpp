#include "traffic_light_recog.hpp"

#include "common/io.hpp"
#include "common/log.hpp"

namespace FLOW {

namespace TrafficLight {

void TrafficLightRecog::Setup(const std::vector<char>& meta_net_data,
                              const inference::Algorithm& config, int &code) {
  LOG(INFO) << "Setup TrafficLightRecog";
  config_ = config;

  Algorithm::Argument classify_arguments;
  classify_arguments.AddSingleArgument<int>("net_id", 0);
  classify_arguments.AddSingleArgument<std::string>("method", "classify");
  classify_arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  classify_arguments.AddSingleArgument<int>("max_batch_size",
                                            config.batch_size());
  classify_arguments.AddRepeatedArgument<std::string>("categories",
                                                      {"feature"});
  classify_arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  classify_arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());

  classify_ = std::make_shared<Algorithm::Extract>(
      meta_net_data.data(), meta_net_data.size(), classify_arguments);

  Algorithm::Argument network_argument;
  classify_->Run<const std::string&, Algorithm::Argument&>("GetNetworkArgument",
                                                           network_argument);
  resize_shape_ = network_argument.GetRepeatedArgument<int>("resize", {40, 40});

  std::vector<VecInt> network_input_shapes;
  classify_->Run<const std::string&, std::vector<VecInt>&>(
      "GetNetworkInputShapes", network_input_shapes);
  in_h_ = network_input_shapes[0][2];
  in_w_ = network_input_shapes[0][3];

  code = FLOW::module_status_success;
  LOG(INFO) << "Finished setup TrafficLightRecog";
}

void TrafficLightRecog::Predict(
    const VecShellFrame& shell_frames, const VecBoxF& boxes,
    std::vector<TrafficLightColor>* colors) {
  if (boxes.empty()) return;

  std::vector<cv::Mat> areas;
  for (int n = 0; n < shell_frames.size(); ++n) {
    const auto& box = boxes[n];
    const auto border = cv::Rect(0, 0, shell_frames[n]->width(), shell_frames[n]->height());
    const auto roi =
        cv::Rect(box.xmin, box.ymin, box.xmax - box.xmin, box.ymax - box.ymin);
    const auto roi_fix = (roi & border);
    LOG_IF(WARNING, roi_fix.area() == 0)
        << "crop image error, roi:[" << roi.x << "," << roi.y << ","
        << roi.width << "," << roi.height << "]";
    const auto& im_mat = (*shell_frames[n]->getMat())(roi_fix);
    cv::Size cv_size(resize_shape_[0], resize_shape_[1]);
    cv::Mat im_resize;
    cv::resize(im_mat, im_resize, cv_size);
    if ((box.ymax - box.ymin) > (box.xmax - box.xmin)) {
      cv::transpose(im_resize, im_resize);
    }
    cv::Mat im_crop;
    int offsetW = (cv_size.width - in_w_) / 2;
    int offsetH = (cv_size.height - in_h_) / 2;
    cv::Rect crop_roi(offsetW, offsetH, in_w_, in_h_);
    im_crop = im_resize(crop_roi).clone();
    areas.push_back(im_crop);
  }

  std::vector<std::map<std::string, VecFloat>> Gvalues;
  classify_->Run<const std::vector<cv::Mat>&,
                 std::vector<std::map<std::string, VecFloat>>&>(areas, Gvalues);

  colors->clear();
  for (const auto& values : Gvalues) {
      const auto index = Util::top_k(values.at("feature"), 1)[0];
      const auto socre = values.at("feature")[index];
      const auto threshold = [&]() {
          if (config_.thresholds().empty()) {
              return 0.0f;
          } else if (config_.thresholds_size() > index) {
              return config_.thresholds(index);
          } else {
              return config_.thresholds(config_.thresholds_size() - 1);
          }
      }();
      const auto color = (socre >= threshold) ? TrafficLightColor(index + 1) : kColorEmpty;
      colors->push_back(color);
  }
}

size_t TrafficLightRecog::MaxBatchSize() const {
    return config_.batch_size(); 
}

void TrafficLightRecog::Process(const input_type& in, output_type* out) {
    std::vector<output_type*> outs{out};
    ProcessBatch({in}, &outs);
}

void TrafficLightRecog::ProcessBatch(const std::vector<input_type>& in, const std::vector<output_type*>* out) {
  LOG_IF(FATAL, in.size() != out->size()) <<"size error";

  VecShellFrame images;
  VecBoxF boxes;
  std::vector<TrafficLight::TrafficLightColor> results;
  // input
  for (int i = 0; i < in.size(); i++) {
    const auto& mat = std::get<0>(in[i]);
    Mat_Ptr p_mat = std::make_shared<cv::Mat>(mat);
    const auto& cur_boxes = std::get<1>(in[i]);
    for (int j = 0; j < cur_boxes.size(); j++) {
      images.push_back(std::make_shared<ShellFrame>(p_mat));
      boxes.push_back(cur_boxes[j]);
    }
  }

  Predict(images, boxes, &results);

  int count = 0;
  for (int i = 0; i < in.size(); i++) {
    const auto current_out = out->at(i);
    const auto& cur_boxes = std::get<1>(in[i]);
    for (int j = 0; j < cur_boxes.size(); j++) {
      current_out->push_back(results[count++]);
    }
  }
}

TrafficLightRecog::input_type TrafficLightRecog::ConvertInput(const cv::Mat& mat, const inference::PictureReq& req) 
{
    VecBoxF boxes;
    for(const auto& rect : req.rects()) {
      boxes.emplace_back(rect.x(), rect.y(), rect.x()+rect.w(), rect.y()+rect.h());
    }
    return input_type{mat, boxes};
}

inference::PictureResp TrafficLightRecog::ConvertOutput(const output_type& results) 
{
    inference::PictureResp resp;
    for(result_type one : results) {
        resp.add_label(helperGetStringTrafficLightColor(one));
    }
    return resp;
}

}  // namespace TrafficLight

}  // namespace FLOW
