#ifndef ANALYZER_ALGORITHM_TRAFFIC_LIGHT_TRAFFIC_LIGHT_RECOG_HPP_
#define ANALYZER_ALGORITHM_TRAFFIC_LIGHT_TRAFFIC_LIGHT_RECOG_HPP_

#include "common/tad_internal.hpp"
#include "common/flow/flow_process.hpp"
#include "serving/config.pb.h"
#include "serving/input_arguments.pb.h"
#include "algorithm/algorithm.hpp"

namespace FLOW {

namespace TrafficLight {

inline std::string helperGetStringTrafficLightColor(TrafficLightColor t) {
  switch (t)
  {
  case kColorEmpty:
    return "----";
  case kColorGreen:
    return "Green";
  case kColorRed:
    return "Red";
  case kColorYellow:
    return "Yellow";
  case kColorBlack:
    return "Black";
  case kColorDouble:
    return "Double";
  default:
    break;
  }
  char buf[32];
  sprintf(buf, "%d", t);
  return buf;
}

class TrafficLightRecog {
 public:
  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int &code);

  void Predict(const VecShellFrame& shell_frames,
               const VecBoxF& boxes, std::vector<TrafficLightColor>* colors);

  // add for flow_process
  public:
      typedef std::tuple<cv::Mat, VecBoxF>    input_type;
      typedef TrafficLight::TrafficLightColor result_type;
      typedef std::vector<result_type>        output_type;
  public:
      size_t MaxBatchSize() const;
      void Process(const input_type& in, output_type* out);
      void ProcessBatch(const std::vector<input_type>& in, const std::vector<output_type*>* out);
      static input_type ConvertInput(const cv::Mat& mat, const inference::PictureReq& req);
      static inference::PictureResp ConvertOutput(const output_type& results);

 private:
  int in_h_, in_w_;
  VecInt resize_shape_;
  inference::Algorithm config_;
  std::shared_ptr<Algorithm::Extract> classify_ = nullptr;
};

class sync_traffic_light
    : public flow_process_sync<TrafficLightRecog>
{
public:
    typedef flow_process_sync<TrafficLightRecog>  processer_type;
    typedef std::shared_ptr<processer_type>       sync_handle;

public:
    sync_traffic_light()
        : processer_type("fp_traffic_light")
    {}
};

}  // namespace TrafficLight

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_TRAFFIC_LIGHT_TRAFFIC_LIGHT_RECOG_HPP_
