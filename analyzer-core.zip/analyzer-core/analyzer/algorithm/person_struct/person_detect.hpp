//
// Created by yankai on 2020/5/28.
//

#ifndef ANALYZER_ALGORITHM_PERSON_STRUCT_PERSON_DETECT_HPP_
#define ANALYZER_ALGORITHM_PERSON_STRUCT_PERSON_DETECT_HPP_

#include "algorithm/algorithm.hpp"
#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace PersonStruct {

class PersonDetectModule {
 public:
  PersonDetectModule() = default;

  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

  void Predict(const VecMat& im_mats, std::vector<RectF> rois,
               std::vector<VecBoxF>& PersonInfos, int& code);

  ~PersonDetectModule();

 private:
  void Process(const VecFloat& in_data, std::vector<VecBoxF>& PersonInfos);
  inference::Algorithm config_;
  std::shared_ptr<Algorithm::Detect> person_detect_engine_;

 public:
  int batch_;
};
}  // namespace PersonStruct
}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_PERSON_STRUCT_PERSON_DETECT_HPP_
