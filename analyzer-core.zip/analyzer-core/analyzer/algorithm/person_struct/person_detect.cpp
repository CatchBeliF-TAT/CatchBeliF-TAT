//
// Created by yankai on 2020/5/28.
//

#include "person_detect.hpp"

namespace FLOW {
namespace PersonStruct {
using namespace std;

void PersonDetectModule::Setup(const std::vector<char>& meta_net_data,
                               const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Create PersonDetectModule";
  config_ = config;
  if (config_.detect_thresholds_size() == 0) {
    config_.add_detect_thresholds(config_.detect_threshold());
  }
  Algorithm::Argument arguments;
#ifdef USE_CUDA
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<bool>("use_fp16", 1);
#else
  arguments.AddSingleArgument<string>("backend_type", "Native");
#endif

  arguments.AddSingleArgument<bool>("device_input", false);

  arguments.AddSingleArgument<int>("device_id", config.gpu_id());

  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());

  person_detect_engine_ = make_shared<Algorithm::Detect>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  code = module_status_success;
  LOG(INFO) << "Finished create PersonDetectModule!";
}

void PersonDetectModule::Predict(const VecMat& im_mats, std::vector<RectF> rois,
                                 std::vector<VecBoxF>& PersonInfos, int& code) {
  vector<cv::Mat> im_crop_mats;
  vector<Algorithm::VecBoxF> Gboxes;
  CHECK_EQ(im_mats.size(), rois.size());
  CHECK_EQ(im_mats.size(), PersonInfos.size());

  for (int i = 0; i < im_mats.size(); i++) {
    cv::Rect roi = cv::Rect(int(rois[i].x), int(rois[i].y), int(rois[i].w),
                            int(rois[i].h));
    im_crop_mats.push_back((*im_mats[i])(roi));
  }

  person_detect_engine_
      ->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecBoxF>&>(
          im_crop_mats, Gboxes);

  for (int i = 0; i < Gboxes.size(); i++) {
    auto& im_person_boxes = PersonInfos[i];
    im_person_boxes.clear();
    for (int j = 0; j < Gboxes[i].size(); j++) {
      if (Gboxes[i][j].label != 1) continue;
      auto threshold =
          Gboxes[i][j].label < config_.detect_thresholds_size()
              ? config_.detect_thresholds(Gboxes[i][j].label)
              : config_.detect_thresholds(config_.detect_thresholds_size() - 1);
      if (Gboxes[i][j].score < threshold) continue;
      BoxF person_box =
          BoxF(Gboxes[i][j].xmin + rois[i].x, Gboxes[i][j].ymin + rois[i].y,
               Gboxes[i][j].xmax + rois[i].x, Gboxes[i][j].ymax + rois[i].y);
      person_box.label = Gboxes[i][j].label;
      person_box.score = Gboxes[i][j].score;
      im_person_boxes.push_back(move(person_box));
    }
  }
  code = module_status_success;
}

PersonDetectModule::~PersonDetectModule() {
  LOG(INFO) << "Deconstruct PersonDetectModule";
}
}  // namespace PersonStruct
}  // namespace FLOW
