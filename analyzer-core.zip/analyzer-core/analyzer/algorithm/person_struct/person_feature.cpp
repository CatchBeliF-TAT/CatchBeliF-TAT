//
// Created by yankai on 2020/5/27.
//

#include "person_feature.hpp"

using namespace std;

namespace FLOW {
namespace PersonStruct {

void PersonFeatureModule::Setup(const std::vector<char>& meta_net_data,
                                const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Create PersonFeatureModule";

  task_name_ = {"feature"};
  Algorithm::Argument arguments;
#ifdef USE_CUDA
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<bool>("use_fp16", 1);
#else
  arguments.AddSingleArgument<string>("backend_type", "Native");
#endif
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());

  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());

  arguments.AddRepeatedArgument<string>("categories", task_name_);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());

  person_feature_engine_ = make_shared<Algorithm::Extract>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  code = module_status_success;
  LOG(INFO) << "Finished create PersonFeatureModule!";
}

void PersonFeatureModule::Predict(const VecMat& im_mats,
                                  vector<VecBoxF>& PersonInfos, int& code) {
  vector<cv::Mat> im_crop_mats;
  CHECK_EQ(im_mats.size(), PersonInfos.size());
  for (int i = 0; i < PersonInfos.size(); i++) {
    for (int j = 0; j < PersonInfos[i].size(); j++) {
      cv::Rect roi =
          cv::Rect(int(PersonInfos[i][j].xmin), int(PersonInfos[i][j].ymin),
                   int(PersonInfos[i][j].xmax - PersonInfos[i][j].xmin + 1),
                   int(PersonInfos[i][j].ymax - PersonInfos[i][j].ymin + 1));
      im_crop_mats.push_back((*im_mats[i])(roi));
    }
  }
  vector<map<string, VecFloat>> Gvalues;
  person_feature_engine_
      ->Run<const vector<cv::Mat>&, vector<map<string, VecFloat>>&>(
          im_crop_mats, Gvalues);

  for (int i = 0, img_mat_index = 0; i < PersonInfos.size(); i++) {
    for (int j = 0; j < PersonInfos[i].size(); j++) {
      for (int k = 0; k < task_name_.size(); k++) {
        const auto& type_scores = Gvalues[img_mat_index].at(task_name_[k]);
        PersonInfos[i][j].person_feature = type_scores;
      }
      img_mat_index++;
    }
  }
}

PersonFeatureModule::~PersonFeatureModule() {
  LOG(INFO) << "Deconstruct PersonFeatureMoudle";
}
}  // namespace PersonStruct
}  // namespace FLOW
