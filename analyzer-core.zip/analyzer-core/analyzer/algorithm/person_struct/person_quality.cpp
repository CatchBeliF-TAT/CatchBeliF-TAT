//
// Created by yankai on 12/24/20.
//

#include "person_quality.hpp"

using namespace std;

namespace FLOW {
namespace PersonStruct {

void PersonQualityModule::Setup(const std::vector<char>& meta_net_data,
                                const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Create PersonQualityModule";

  task_name_ = {"clarity", "occlusion", "Integrity", "single", "center"};
  Algorithm::Argument arguments;
#ifdef USE_CUDA
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<bool>("use_fp16", 1);
#else
  arguments.AddSingleArgument<string>("backend_type", "Native");
#endif
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());

  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());

  arguments.AddRepeatedArgument<string>("categories", task_name_);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());

  person_quality_engine_ = make_shared<Algorithm::Extract>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  code = module_status_success;
  LOG(INFO) << "Finished create PersonQualityModule!";
}

void PersonQualityModule::Predict(const VecMat& im_mats,
                                  vector<VecBoxF>& PersonInfos, int& code) {
  vector<cv::Mat> im_crop_mats;
  CHECK_EQ(im_mats.size(), PersonInfos.size());
  for (int i = 0; i < PersonInfos.size(); i++) {
    for (int j = 0; j < PersonInfos[i].size(); j++) {
      cv::Rect roi =
          cv::Rect(int(PersonInfos[i][j].xmin), int(PersonInfos[i][j].ymin),
                   int(PersonInfos[i][j].xmax - PersonInfos[i][j].xmin + 1),
                   int(PersonInfos[i][j].ymax - PersonInfos[i][j].ymin + 1));
      im_crop_mats.push_back((*im_mats[i])(roi));
    }
  }
  vector<map<string, VecFloat>> Gvalues;
  person_quality_engine_
      ->Run<const vector<cv::Mat>&, vector<map<string, VecFloat>>&>(
          im_crop_mats, Gvalues);

  for (int i = 0, img_mat_index = 0; i < PersonInfos.size(); i++) {
    for (int j = 0; j < PersonInfos[i].size(); j++, img_mat_index++) {
      PersonInfos[i][j].person_attr.clear();
      for (int k = 0; k < task_name_.size(); k++) {
        const auto& type_scores = Gvalues[img_mat_index].at(task_name_[k]);
        int top_attr_index = Util::top_k(type_scores, 1)[0];
        float top_attr_score = type_scores[top_attr_index];
        Attr attr;
        attr.type = top_attr_index;
        attr.score = top_attr_score;
        PersonInfos[i][j].person_quality.push_back(attr);
      }
    }
  }
}

PersonQualityModule::~PersonQualityModule() {
  LOG(INFO) << "Deconstruct PersonQualityModule";
}
}  // namespace PersonStruct
}  // namespace FLOW
