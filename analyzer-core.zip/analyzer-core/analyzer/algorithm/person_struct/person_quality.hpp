//
// Created by yankai on 12/24/20.
//

#ifndef ANALYZER_ALGORITHM_PERSON_STRUCT_PERSON_QUALITY_HPP_
#define ANALYZER_ALGORITHM_PERSON_STRUCT_PERSON_QUALITY_HPP_

#include "algorithm/algorithm.hpp"
#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace PersonStruct {

class PersonQualityModule {
 public:
  PersonQualityModule() = default;

  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

  void Predict(const VecMat& im_mats, std::vector<VecBoxF>& PersonInfos,
               int& code);

  ~PersonQualityModule();

 private:
  VecString task_name_;
  std::shared_ptr<Algorithm::Extract> person_quality_engine_;
};

}  // namespace PersonStruct
}  // namespace FLOW
#endif  // ANALYZER_ALGORITHM_PERSON_STRUCT_PERSON_QUALITY_HPP_
