#ifndef TAD_ALGORITHM_FACTORY_HPP
#define TAD_ALGORITHM_FACTORY_HPP

#include <memory>
#include <string>
#include <map>

#include "serving/config.pb.h"
#include "common/flow/flow_process.hpp"

namespace FLOW {
    typedef std::map<std::string, sp_flow_process_base> map_process_base;
    typedef google::protobuf::RepeatedPtrField<::inference::Algorithm > algorithm_config;

    sp_flow_process_base    CreateAlgorithm(const inference::Algorithm& config);
    map_process_base        CreateAlgorithm(const algorithm_config& configs);
} // FLOW

#endif //TAD_ALGORITHM_FACTORY_HPP