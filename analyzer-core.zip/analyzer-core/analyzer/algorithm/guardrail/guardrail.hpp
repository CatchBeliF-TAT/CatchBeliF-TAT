#ifndef ANALYZER_ALGORITHM_GUARDRAIL_GUARDRAIL_HPP_
#define ANALYZER_ALGORITHM_GUARDRAIL_GUARDRAIL_HPP_

#include <memory>
#include <opencv2/opencv.hpp>
#include <opencv2/features2d.hpp>
#include "algorithm/detect/detect.hpp"
#include "common/boxes.hpp"
#include "common/tad_internal.hpp"
#include "common/type.hpp"
#include "common/util.hpp"
#include "serving/config.pb.h"

#define GUARDRAIL_MAX_BATCH_SIZE 16

namespace FLOW {

namespace Guardrail {

class Guardrail {
 public:
  void Setup_guardrail(const std::vector<char>& meta_net_data,
                         const inference::Algorithm& config, int& code);

  //#ifdef USE_MEDIA_UTILS
  //  void Process(VecMat& images, VecVframe& frames,
  //               std::vector<std::vector<RectInfo>>& images_boxes, int& code);
  //#endif

  std::vector<int> GetInputShapes() { return input_shapes_; }
  inference::Algorithm config_;

  void Process(const std::vector<std::shared_ptr<cv::Mat>> images,
               const VecBoxF& guardrail_boxes,
               const std::vector<int>& periods,
               const std::vector<std::shared_ptr<cv::Mat>>& guardrail_origin_roi_mats,
               std::vector<std::shared_ptr<cv::Mat>>& guardrail_roi_mats,
               std::vector<std::shared_ptr<cv::Mat>>& wrong_frames,
               std::vector<int>& wrong_frame_durations,
               const std::vector<float>& similar_thresholds,
               std::vector<float>& similar_max_socres,
               std::vector<VecBoxF>& events);

  float ORB_img_similarity(cv::Mat img1, cv::Mat img2);
  float hist_img_similarity(cv::Mat img1, cv::Mat img2);
  float phash_img_similarity(cv::Mat img1, cv::Mat img2);
  void bg_roi_update(float alpha, cv::Mat &img1, cv::Mat &img2, cv::Mat &img3);
    /*
  * 功能：利用 hash 法计算图像指纹
  * 输入：image cv::Mat 输入图像
  * 输出：hash uint64_t 计算得到的指纹
  */
    unsigned long long int ImageHash(cv::Mat);

/*
* 功能：利用 phash 法计算图像指纹
* 输入：image cv::Mat 输入图像
* 输出：hash uint64_t 计算得到的指纹
*/
    unsigned long long int ImagePHash(cv::Mat);

/*
* 功能：利用 dhash 法计算图像指纹
* 输入：image cv::Mat 输入图像
* 输出：hash uint64_t 计算得到的指纹
*/
    unsigned long long int ImageDHash(cv::Mat);

    unsigned long long int hammingDistance(unsigned long long int x, unsigned long long int y);
    float iou_guardrail(const BoxF &box_a, const BoxF &box_b);

private:
  std::shared_ptr<Detect::DetectModule> engine_traffic_ = nullptr;
  std::vector<int> input_shapes_;
//  std::vector<std::shared_ptr<cv::Mat>> img_rois;
//  std::vector<bool> flags_same;
//  int guardrail_detect_interval = 12;
//  const int duration_frames = 30;        // 错误图持续2分钟替换为背景图
};

}  // namespace Guardrail
}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_GUARDRAIL_GUARDRAIL_HPP_
