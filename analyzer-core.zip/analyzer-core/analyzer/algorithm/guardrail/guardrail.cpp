#include "guardrail.hpp"
#include "common/io.hpp"
#include "common/json.hpp"
#include "common/log.hpp"
#include "document.h"
#include "prettywriter.h"
#include "stringbuffer.h"
#include <bitset>

namespace FLOW {

namespace Guardrail {
/*
* 功能：利用 hash 法计算图像指纹
* 输入：image cv::Mat 输入图像
* 输出：hash unsigned long long int 计算得到的指纹
*/
unsigned long long int Guardrail::ImageHash(cv::Mat image)
{
    unsigned long long int hash = 0; // 用于保存hash值
    cv::Mat imageGray; // 转换后的灰度图像
    cv::Mat imageFinger; // 缩放后的8x8的指纹图像
    int fingerSize = 8; // 指纹图像的大小

    if (3 == image.channels()) // rgb -> gray
    {
        cv::cvtColor(image, imageGray, cv::COLOR_RGB2GRAY);
    }
    else
    {
        imageGray = image.clone();
    }

    cv::resize(imageGray, imageFinger, cv::Size(fingerSize, fingerSize)); // 图像缩放
    imageFinger.convertTo(imageFinger, CV_32F); // 转换为浮点型
    cv::Scalar imageMean = cv::mean(imageFinger); // 求均值

    /* 计算图像哈希指纹，小于等于均值为0，大于为1 */
    for (int i = 0; i < fingerSize; i++)
    {
        float* data = imageFinger.ptr<float>(i);
        for (int j = 0; j < fingerSize; j++)
        {
            if (data[j] > imageMean[0])
            {
                hash = (hash << 1) + 1;
            }
            else
            {
                hash = hash << 1;
            }
        }
    }

    return hash;
}

/*
* 功能：利用 phash 法计算图像指纹
* 输入：image cv::Mat 输入图像
* 输出：hash unsigned long long int 计算得到的指纹
*/
unsigned long long int Guardrail::ImagePHash(cv::Mat image)
{
    unsigned long long int hash = 0; // 用于保存hash值
    cv::Mat imageGray; // 转换后的灰度图像
    cv::Mat imageFinger; // 缩放后的8x8的指纹图像
    int fingerSize = 8; // 指纹图像的大小
    int dctSize = 32; // dct变换的尺寸大小

    if (3 == image.channels()) // rgb -> gray
    {
        cv::cvtColor(image, imageGray, cv::COLOR_RGB2GRAY);
    }
    else
    {
        imageGray = image.clone();
    }

    cv::resize(imageGray, imageFinger, cv::Size(dctSize, dctSize)); // 图像缩放
    imageFinger.convertTo(imageFinger, CV_32F); // 转换为浮点型
    cv::dct(imageFinger, imageFinger); // 对缩放后的图像进行dct变换
    imageFinger = imageFinger(cv::Rect(0, 0, fingerSize, fingerSize)); // 取低频区域

    /* 对dct变换后的系数取对数 */
    for (int i = 0; i < fingerSize; i++)
    {
        float* data = imageFinger.ptr<float>(i);
        for (int j = 0; j < fingerSize; j++)
        {
            data[j] = logf(abs(data[j]));
        }
    }

    cv::Scalar imageMean = cv::mean(imageFinger); // 求均值

    /* 计算图像哈希指纹，小于等于均值为0，大于为1 */
    for (int i = 0; i < fingerSize; i++)
    {
        float* data = imageFinger.ptr<float>(i);
        for (int j = 0; j < fingerSize; j++)
        {
            if (data[j] > imageMean[0])
            {
                hash = (hash << 1) + 1;
            }
            else
            {
                hash = hash << 1;
            }
        }
    }

    return hash;
}

/*
* 功能：利用 dhash 法计算图像指纹
* 输入：image cv::Mat 输入图像
* 输出：hash unsigned long long int 计算得到的指纹
*/
unsigned long long int Guardrail::ImageDHash(cv::Mat image)
{
    unsigned long long int hash = 0; // 用于保存hash值
    cv::Mat imageGray; // 转换后的灰度图像
    cv::Mat imageFinger; // 缩放后的8x8的指纹图像
    int fingerSize = 8; // 指纹图像的大小

    if (3 == image.channels()) // rgb -> gray
    {
        cv::cvtColor(image, imageGray, cv::COLOR_RGB2GRAY);
    }
    else
    {
        imageGray = image.clone();
    }

    cv::resize(imageGray, imageFinger, cv::Size(fingerSize+1, fingerSize)); // 图像缩放

    /* 计算图像哈希指纹，对于前八列的点，如果某个点大于它右侧的点，则为1，否则为0 */
    for (int i = 0; i < fingerSize; i++)
    {
        float* data = imageFinger.ptr<float>(i);
        for (int j = 0; j < fingerSize; j++)
        {
            if (data[j] > data[j+1])
            {
                hash = (hash << 1) + 1;
            }
            else
            {
                hash = hash << 1;
            }
        }
    }

    return hash;
}

unsigned long long int Guardrail::hammingDistance(unsigned long long int x, unsigned long long int y) {
    unsigned long long int z=x^y;
    unsigned long long int count=0;
    //计算二进制中1的个数
    while(z){
        ++count;
        z=(z-1)&z;
    }
    return count;
}

float Guardrail::ORB_img_similarity(cv::Mat img1, cv::Mat img2){
    // 1. 初始化
    std::vector<cv::KeyPoint> keypoints1, keypoints2;
    cv::Mat descriptors1, descriptors2;
    cv::Ptr<cv::ORB> orb = cv::ORB::create();

    // 2. 提取特征点
    orb->detect(img1, keypoints1);
    orb->detect(img2, keypoints2);
    if ((keypoints1.size() < 2) || (keypoints2.size() < 2)){
        return -2.0;
    }
    // 3. 计算特征描述符
    orb->compute(img1, keypoints1, descriptors1);
    orb->compute(img2, keypoints2, descriptors2);
    if ((descriptors1.size[0] < 2) || (descriptors2.size[0] < 2)){
        return -3.0;
    }

    // 4. 对两幅图像的BRIEF描述符进行匹配，使用BFMatch，Hamming距离作为参考
    std::vector<cv::DMatch> matches;
    cv::BFMatcher bfMatcher(cv::NORM_HAMMING);
//    bfMatcher.match(descriptors1, descriptors2, matches);

    const float minRatio = 0.75;
    const int k = 2;

    std::vector<std::vector<cv::DMatch>> knnMatches;
    bfMatcher.knnMatch(descriptors1, descriptors2, knnMatches, k);
	if (0 == knnMatches.size()){
	        return -4.0;
	}
	
    for (size_t i = 0; i < knnMatches.size(); i++) {
        const cv::DMatch& bestMatch = knnMatches[i][0];
        const cv::DMatch& betterMatch = knnMatches[i][1];
        float  distanceRatio = bestMatch.distance / (betterMatch.distance + 1e-6);
        if (distanceRatio < minRatio)
            matches.push_back(bestMatch);
    }
    return float(matches.size()) / float(knnMatches.size() + 1e-6);
}

float Guardrail::hist_img_similarity(cv::Mat img1, cv::Mat img2){
    cv::cvtColor(img1, img1, cv::COLOR_BGR2HSV);
    cv::cvtColor(img2, img2, cv::COLOR_BGR2HSV);

    int h_bins = 50, s_bins = 60;
    int histSize[] = { h_bins, s_bins };
    float h_ranges[] = { 0, 180 };
    float s_ranges[] = { 0, 256 };
    const float* ranges[] = { h_ranges, s_ranges };
    int channels[] = { 0, 1 };
    cv::MatND hist1, hist2;

    cv::calcHist(&img1, 1, channels, cv::Mat(), hist1, 2, histSize, ranges, true, false);
    cv::normalize(hist1, hist1, 0, 1, cv::NORM_MINMAX, -1, cv::Mat());

    cv::calcHist(&img2, 1, channels, cv::Mat(), hist2, 2, histSize, ranges, true, false);
    cv::normalize(hist2, hist2, 0, 1, cv::NORM_MINMAX, -1, cv::Mat());

    return cv::compareHist(hist1, hist2, cv::HISTCMP_CORREL); //,CV_COMP_CHISQR,CV_COMP_INTERSECT,CV_COMP_BHATTACHARYYA  CV_COMP_CORREL
}

float Guardrail::phash_img_similarity(cv::Mat img1, cv::Mat img2){
    unsigned long long int hash_img1, hash_img2, distance;
    hash_img1 = ImagePHash(img1);
    hash_img2 = ImagePHash(img2);
    distance  = hammingDistance(hash_img1, hash_img2);
    return 1 - distance / std::max(std::bitset<32>(hash_img1).size(), std::bitset<32>(hash_img1).size());
}

void Guardrail::bg_roi_update(float alpha, cv::Mat& img1, cv::Mat& img2, cv::Mat& img3) {
    cv::addWeighted(img1, alpha, img2, 1-alpha, 0.0, img3);
//    *guardrail_roi_mats[box_i] = im_roi_resize.clone();
}

float Guardrail::iou_guardrail(const BoxF &box_a, const BoxF &box_b) {
    return Boxes::Intersection(box_a, box_b) / (Boxes::Size(box_b) + 1e-6);
}

void Guardrail::Setup_guardrail(const std::vector<char>& meta_net_data,
                                   const inference::Algorithm& config,
                                   int& code) {
  LOG(INFO) << "Setup Guardrail Module";
  config_ = config;
  engine_traffic_ = std::make_shared<Detect::DetectModule>();
  engine_traffic_->Setup(meta_net_data, config, code);
  input_shapes_ = engine_traffic_->GetInputShapes();

  LOG(INFO) << "Finished setup Guardrail Module";
}

// Guardrail Process
void Guardrail::Process(
    const std::vector<std::shared_ptr<cv::Mat>> images,
    const VecBoxF& guardrail_boxes_,
    const std::vector<int>& periods,
    const std::vector<std::shared_ptr<cv::Mat>>& guardrail_origin_roi_mats,
    std::vector<std::shared_ptr<cv::Mat>>& guardrail_roi_mats,
    std::vector<std::shared_ptr<cv::Mat>>& wrong_frames,
    std::vector<int> &wrong_frame_durations,
    const std::vector<float>& similar_thresholds,
    std::vector<float>& similar_max_socres,
    std::vector<VecBoxF>& events) {
  events.clear();
  Profiler Guardrail_profile;
  Guardrail_profile.tic("Guardrail Process");

  std::vector<cv::Mat> im_mats;
  std::vector<cv::Rect> rois;
  std::vector<std::vector<RectInfo>> image_rects;

  VecShellFrame shell_frames;
  for (auto& image : images) {
    shell_frames.push_back(std::make_shared<ShellFrame>(image));
    im_mats.push_back(*image);
    rois.push_back(cv::Rect(0, 0, image->cols, image->rows));
  }
  int code=0;
  engine_traffic_->ProcessROIs(shell_frames, rois, image_rects, code);

  // 相似度比对
  events.resize(im_mats.size(), guardrail_boxes_);
  for (int im_i = 0; im_i < im_mats.size(); im_i++){
      cv::Mat im_mat, im_roi, im_roi_resize;
      im_mat = im_mats[im_i];
      VecBoxF& event = events[im_i];
      for (int box_i = 0; box_i < guardrail_boxes_.size(); box_i++){
          BoxF &box_t = event[box_i];
          box_t.score = -1.0f;
          // 过滤车辆
          int flag = 0;
          for(int Gbox_i = 0; Gbox_i < image_rects[im_i].size(); Gbox_i++){
              const auto& rect = image_rects[im_i][Gbox_i].rect;
              const BoxF box_detect(rect.x, rect.y, rect.x+rect.width, rect.y+rect.height);
              if(iou_guardrail(box_detect, box_t) > 0.3){
                  flag = 1;
                  break;
              }
          }

          if(flag){
              continue;
          }

          im_roi = im_mat(cv::Rect(box_t.xmin, box_t.ymin, box_t.xmax - box_t.xmin, box_t.ymax - box_t.ymin));
          cv::resize(im_roi, im_roi_resize, cv::Size(256, 256));
//          float similarity_score   = ORB_img_similarity(im_roi_resize, *guardrail_roi_mats[box_i]);

          float similarity_score_orb   = ORB_img_similarity(im_roi_resize, *guardrail_roi_mats[box_i]);
          float similarity_score_orb2  = ORB_img_similarity(im_roi_resize, *guardrail_origin_roi_mats[box_i]);
//          float similarity_score_hist  = hist_img_similarity(im_roi_resize, *guardrail_roi_mats[box_i]);
//          float similarity_score_phash = phash_img_similarity(im_roi_resize, *guardrail_roi_mats[box_i]);

          box_t.score = std::max(similarity_score_orb, similarity_score_orb2);
//          box_t.score = (similarity_score_orb + similarity_score_hist + similarity_score_phash) / 3;
//          box_t.score = (similarity_score_orb + similarity_score_phash) / 2;

//          std::cout << box_t.score << std::endl;
          if (box_t.score < 0) {
              continue;
          }
          // 背景roi动态更新
          if(box_t.score > similar_max_socres[box_i]) {
              similar_max_socres[box_i] = box_t.score;
              wrong_frames[box_i] = std::make_shared<cv::Mat>(im_roi_resize.clone());
          }
          wrong_frame_durations[box_i]++;
          if (wrong_frame_durations[box_i] > periods[box_i]) {
            if (wrong_frames[box_i]) {
                guardrail_roi_mats[box_i] = wrong_frames[box_i];
            }
            similar_max_socres[box_i] = -1;
            wrong_frame_durations[box_i] = 0;
          }
          continue;
//           float alpha = 0.0;
// //          cv::Mat bg_mat_roi;
//           if(box_t.score > similar_thresholds[box_i]) {
//               bg_roi_update(alpha, *guardrail_roi_mats[box_i], im_roi_resize, *guardrail_roi_mats[box_i]);
//           }
//           else {
// //          else if (box_t.score > 0) {
//               if(wrong_frame_durations[box_i] == 0){
//                   wrong_frames[box_i] = std::make_shared<cv::Mat>(im_roi_resize.clone());
//                   wrong_frame_durations[box_i]++;
//               }
//               else{
//                   if(ORB_img_similarity(im_roi_resize, *(wrong_frames[box_i])) > similar_thresholds[box_i]){
//                       bg_roi_update(alpha, *(wrong_frames[box_i]), im_roi_resize, *(wrong_frames[box_i]));
//                       wrong_frame_durations[box_i]++;
//                   }
//                   else{
//                       wrong_frames[box_i] = std::make_shared<cv::Mat>();
//                       *wrong_frames[box_i] = im_roi_resize.clone();
//                   }
//               }

//               if(wrong_frame_durations[box_i] >= duration_frames){
//                   *guardrail_roi_mats[box_i] = (*wrong_frames[box_i]).clone();
//                   (*wrong_frames[box_i]).release();
//                   wrong_frame_durations[box_i] = 0;
//               }
//           }
      }
  }

  // 剔除检测到的车辆

  Guardrail_profile.toc("Guardrail Process");
  LOG(DEBUG) << Guardrail_profile.get_stats_str();
}

}  // namespace Guardrail

}  // namespace FLOW
