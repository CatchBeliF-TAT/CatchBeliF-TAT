#include "duchaMar.hpp"

#include "common/log.hpp"
#include "common/util.hpp"

namespace FLOW {

namespace duchaMar {

void DuchaMarModule::Setup(const std::vector<char>& meta_net_data,
                           const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Create DuchaMarModule";

  Algorithm::Argument arguments;
//  arguments.AddSingleArgument<int>("net_id", 0);
//  arguments.AddSingleArgument<std::string>("method", "classify");
#ifdef USE_CUDA
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<bool>("use_fp16", true);
#else
  arguments.AddSingleArgument<std::string>("backend_type", "Native");
#endif
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());
  arguments.AddRepeatedArgument<std::string>("categories", {"color", "action", "sex", "mask"});
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());

  classify_ = std::make_shared<Algorithm::Extract>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  code = module_status_success;

  LOG(INFO) << "Finished setup DuchaMarModule!";
}

void DuchaMarModule::Predict(const VecMat& images,
                             std::vector<VecBoxF>* images_boxes) {
  CHECK_EQ(images.size(), images_boxes->size());

  std::vector<cv::Mat> im_mats;
  for (int n = 0; n < images.size(); ++n) {
    for (const auto& box : images_boxes->at(n)) {
      cv::Rect cv_roi(box.xmin, box.ymin, box.xmax - box.xmin + 1,
                      box.ymax - box.ymin + 1);
      im_mats.emplace_back(*images[n], cv_roi);
    }
  }

  std::vector<std::map<std::string, VecFloat>> Gvalues;
  classify_->Run<const std::vector<cv::Mat>&,
                 std::vector<std::map<std::string, VecFloat>>&>(im_mats,
                                                                Gvalues);

  int count = 0;
  for (auto& boxes : *images_boxes) {
    for (auto& box : boxes) {
      const auto& color_scores = Gvalues[count].at("color");

      // unifom_color: "people", "lightBlue", "darkBlue", "maJia", "black"
      // ?5???????????
      int type_index = Util::top_k_scope(color_scores, 0, 4, 1)[0];
      box.ducha_colour.type = type_index;
      box.ducha_colour.score = color_scores[type_index];

      // ????: "normal", "phone", "call", "smoke", "sleep"
      // ?5???????????
      const auto& action_scores = Gvalues[count].at("action");
      type_index = Util::top_k_scope(action_scores, 0, 4, 1)[0];
      box.ducha_action.type = type_index;
      box.ducha_action.score = action_scores[type_index];

      // ????: "male", "female"
      const auto& sex_scores = Gvalues[count].at("sex");
      type_index = Util::top_k_scope(sex_scores, 0, 1, 1)[0];
      box.ducha_sex.type = type_index;
      box.ducha_sex.score = sex_scores[type_index];

      const auto& mask_scores = Gvalues[count++].at("mask");
      type_index = Util::top_k_scope(mask_scores, 0, 2, 1)[0];
      box.ducha_mask.type = type_index;
      box.ducha_mask.score = mask_scores[type_index];
    }
  }
}

}  // namespace duchaMar

}  // namespace FLOW
