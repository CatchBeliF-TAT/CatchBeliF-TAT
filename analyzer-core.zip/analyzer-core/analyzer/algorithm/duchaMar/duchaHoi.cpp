//
// Created by yankai on 2021/6/21.
//
#include "duchaHoi.hpp"

#include "common/log.hpp"
#include "common/util.hpp"

namespace FLOW {

namespace duchaHoi {

void DuchaHoiModule::Setup(const std::vector<char>& meta_net_data,
                           const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Create DuchaHoiModule";

  Algorithm::Argument arguments;
//  arguments.AddSingleArgument<int>("net_id", 0);
//  arguments.AddSingleArgument<std::string>("method", "ppdm");
#ifdef USE_CUDA
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<bool>("use_fp16", true);
#else
  arguments.AddSingleArgument<std::string>("backend_type", "Native");
#endif
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
  threshold_ =  config.detect_threshold();
  hoi_ = std::make_shared<Algorithm::Hoi>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  code = module_status_success;

  LOG(INFO) << "Finished setup DuchaHoiModule!";
}

void DuchaHoiModule::Predict(const VecMat& images,
                             std::vector<VecBoxF>* images_boxes) {
  CHECK_EQ(images.size(), images_boxes->size());

  std::vector<cv::Mat> im_mats;
  for (int n = 0; n < images.size(); ++n) {
    for (const auto& box : images_boxes->at(n)) {
      cv::Rect cv_roi(box.xmin, box.ymin, box.xmax - box.xmin + 1,
                      box.ymax - box.ymin + 1);
      if(box.ducha_action.type == 1 || box.ducha_action.type == 2 || box.ducha_action.type == 3){
        im_mats.emplace_back(*images[n], cv_roi);
      }

    }
  }

  std::vector<Algorithm::VecRelF> Grels;
  hoi_->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecRelF>&>(im_mats,
                                                                           Grels);
  int Grels_num = 0;
  int update_flag = 1;
  for (int n = 0; n < images.size(); ++n) {
    for (auto& box : images_boxes->at(n)) {
      if (box.ducha_action.type == 0 || box.ducha_action.type == 4)
        continue;
      for (auto& rel:Grels[Grels_num]){
        if(((rel.label == 0 && box.ducha_action.type == 3) ||
            (rel.label == 1 && box.ducha_action.type == 2) ||
            (rel.label == 2 && box.ducha_action.type == 1)) && rel.score >= threshold_){
          update_flag = 0;
          break;
        }
      }
      if(update_flag){
        box.ducha_action.type = 0;
        box.ducha_action.score = 0;
      }
      Grels_num++;
    }
  }
}

}  // namespace duchaHoi

}  // namespace FLOW
