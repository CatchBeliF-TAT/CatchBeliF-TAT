#ifndef ANALYZER_ALGORITHM_DUCHAMAR_DUCHAMAR_HPP_
#define ANALYZER_ALGORITHM_DUCHAMAR_DUCHAMAR_HPP_

#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

#include "algorithm/algorithm.hpp"

namespace FLOW {

namespace duchaMar {

class DuchaMarModule {
 public:
  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

  void Predict(const VecMat& images, std::vector<VecBoxF>* images_boxes);

 private:
  std::shared_ptr<Algorithm::Extract> classify_ = nullptr;
};

}  // namespace duchaMar

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_DUCHAMAR_DUCHAMAR_HPP_
