//
// Created by yankai on 2021/6/21.
//

#ifndef ANALYZER_ALGORITHM_DUCHAHOI_DUCHAHOI_HPP_
#define ANALYZER_ALGORITHM_DUCHAHOI_DUCHAHOI_HPP_

#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

#include "algorithm/algorithm.hpp"

namespace FLOW {

namespace duchaHoi {

    class DuchaHoiModule {
    public:
        void Setup(const std::vector<char>& meta_net_data,
                   const inference::Algorithm& config, int& code);

        void Predict(const VecMat& images, std::vector<VecBoxF>* images_boxes);

    private:
        float threshold_;
        std::shared_ptr<Algorithm::Hoi> hoi_ = nullptr;
    };

}  // namespace duchaMar

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_DUCHAHOI_DUCHAHOI_HPP_
