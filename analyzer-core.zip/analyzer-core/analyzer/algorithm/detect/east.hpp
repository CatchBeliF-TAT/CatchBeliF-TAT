#ifndef ANALYZER_ALGORITHM_DETECT_EAST_HPP_
#define ANALYZER_ALGORITHM_DETECT_EAST_HPP_

#include "common/tad_internal.hpp"

#include "algorithm/algorithm.hpp"
#include "serving/config.pb.h"
namespace FLOW {

namespace Detect {

class EAST {
 public:
  EAST() = default;
  ~EAST();

  void Setup(const std::vector<char>& meta_net_data, const inference::Algorithm& config);

  void BatchPredict(const VecMat &images, std::vector<std::vector<PolygonF>>* gpolygons_output);

  VecInt GetInputShapes() { return in_shape_; }

 private:
  VecInt in_shape_;

  std::shared_ptr<Algorithm::Landmark> engine_ = nullptr;
};

}  // namespace Detect

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_DETECT_EAST_HPP_
