#include "east.hpp"

#include "common/log.hpp"
#include "common/util.hpp"

namespace FLOW {

namespace Detect {

EAST::~EAST() { LOG(INFO) << "Deconstruct EastDetectModule"; }

void EAST::Setup(const std::vector<char>& meta_net_data, const inference::Algorithm& config) {
  LOG(INFO) << "Setup EastDetectModule";

  Algorithm::Argument trt_arguments;
  trt_arguments.AddSingleArgument<int>("net_id", 0);
  trt_arguments.AddSingleArgument<std::string>("method", "east");
  trt_arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  trt_arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  trt_arguments.AddSingleArgument<int>("max_batch_size", config.batch_size()); //10
  trt_arguments.AddSingleArgument<bool>("use_fp16", true);
  trt_arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  trt_arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());

  engine_ = std::make_shared<Algorithm::Landmark>(meta_net_data.data(), meta_net_data.size(), trt_arguments);

  std::vector<VecInt> network_input_shapes;
  engine_->Run<const std::string &, std::vector<VecInt> &>(
      "GetNetworkInputShapes", network_input_shapes);
  in_shape_ = network_input_shapes[0];

  LOG(INFO) << "Finished setup EastDetectModule!";
}

void EAST::BatchPredict(const VecMat &images, std::vector<std::vector<PolygonF>>* gpolygons_output) {

  
  std::vector<cv::Mat> images_mat;
  for (auto i = 0; i < images.size(); i++) {
    images_mat.push_back(*images[i]);
  }


  std::vector<Algorithm::VecPolygonF> Gpolygons;
  engine_->Run<const std::vector<cv::Mat> &,
               std::vector<Algorithm::VecPolygonF> &>(images_mat, Gpolygons);

  for (int n = 0; n < images.size(); ++n) {
    std::vector<PolygonF> polygons_output;
    for (const auto &polygon : Gpolygons[n]){
      PolygonF polygon_output;
      for (const auto &point : polygon.points) {
        polygon_output.points.emplace_back(point.x, point.y);
        polygon_output.score = polygon.score;
      }
      polygons_output.push_back(polygon_output);
    }
    gpolygons_output->push_back(polygons_output);
  }
}

}  // namespace Detect

}  // namespace FLOW
