#include "detect.hpp"

#include "common/json.hpp"

namespace FLOW {

namespace Detect {

void DetectModule::Setup(const std::vector<char>& meta_net_data,
                         const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Setup DetectModule";
  config_ = config;
  if(config_.detect_thresholds_size()==0){
    config_.add_detect_thresholds(config_.detect_threshold());
  }
  Algorithm::Argument arguments;
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("device_id", config_.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config_.batch_size());
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
  if (config.use_explicit_batch()) {
    //建筑平台里面的车辆检测模型所用
    arguments.AddSingleArgument<bool>("explicit_batch", true);
  }
#ifdef USE_MEDIA_UTILS
  arguments.AddSingleArgument<bool>("device_input", config_.device_input());
#else
  arguments.AddSingleArgument<bool>("device_input", false);
#endif

  engine_ = std::make_shared<Algorithm::Detect>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  std::vector<VecInt> network_input_shapes;
  engine_->Run<const std::string&, std::vector<VecInt>&>("GetNetworkInputShapes", network_input_shapes);
  input_shapes_ = network_input_shapes[0];

  code = FLOW::module_status_success;

  LOG(INFO) << "Finished setup DetectModule";
}

#ifdef USE_MEDIA_UTILS
void DetectModule::Process(VecShellFrame& shell_frames,
                           std::vector<cv::Rect> rois,
                           std::vector<std::vector<RectInfo>>& images_boxes,
                           int& code) {
  std::vector<cv::Mat> crop_images;
  std::vector<void*> crop_data;
  for (int n = 0; n < shell_frames.size(); ++n) {
    crop_images.emplace_back(*shell_frames[n]->getMat(), rois[n]);
    crop_data.push_back(shell_frames[n]->getVframe()->data);
  }

  std::vector<Algorithm::VecBoxF> Gboxes;
  engine_->Run<const std::vector<cv::Mat>&, const std::vector<void*>&,
               std::vector<Algorithm::VecBoxF>&>(crop_images, crop_data,
                                                 Gboxes);

  for (int n = 0; n < crop_images.size(); ++n) {
    const auto& roi = rois[n];
    std::vector<RectInfo> image_boxes;
    for (const auto& box : Gboxes[n]) {
      auto threshold = box.label < config_.detect_thresholds_size()
                           ? config_.detect_thresholds(box.label)
                           : config_.detect_thresholds(config_.detect_thresholds_size()-1);
      if (box.score > threshold) {
        RectInfo image_box{};
        image_box.label = box.label;
        image_box.score = box.score;
        const auto& box_rect = box.rect<int>();
        image_box.rect = cv::Rect(box_rect.x + roi.x, box_rect.y + roi.y,
                                  box_rect.w, box_rect.h);
        image_boxes.push_back(image_box);
      }
    }
    images_boxes.push_back(image_boxes);
  }

  if (config_.detect_type_mapping_size()!=0) {
    for (auto& image_boxes : images_boxes) {
      for (auto& box : image_boxes) {
        if (box.label < config_.detect_type_mapping_size()) {
          box.label = config_.detect_type_mapping(box.label);
        }
      }
    }
  }

  code = FLOW::module_status_success;
}
#endif

void DetectModule::ProcessROIs(VecShellFrame& shell_frames, std::vector<cv::Rect> rois,
                               std::vector<std::vector<RectInfo>>& images_boxes,
                               int& code) {
  std::vector<cv::Mat> crop_images;
  for (int n = 0; n < shell_frames.size(); ++n) {
    crop_images.emplace_back(*shell_frames[n]->getMat(), rois[n]);
  }

  std::vector<Algorithm::VecBoxF> Gboxes;
  engine_->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecBoxF>&>(
      crop_images, Gboxes);

  for (int n = 0; n < crop_images.size(); ++n) {
    const auto& roi = rois[n];
    std::vector<RectInfo> image_boxes;
    for (const auto& box : Gboxes[n]) {
      auto threshold = box.label < config_.detect_thresholds_size()
                           ? config_.detect_thresholds(box.label)
                           : config_.detect_thresholds(config_.detect_thresholds_size()-1);
      if (box.score > threshold) {
        RectInfo image_box{};
        image_box.label = box.label;
        image_box.score = box.score;
        const auto& box_rect = box.rect<int>();
        image_box.rect = cv::Rect(box_rect.x + roi.x, box_rect.y + roi.y,
                                  box_rect.w, box_rect.h);
        image_boxes.push_back(image_box);
      }
    }
    images_boxes.push_back(image_boxes);
  }

  if (config_.detect_type_mapping_size()!=0) {
    for (auto& image_boxes : images_boxes) {
      for (auto& box : image_boxes) {
        if (box.label < config_.detect_type_mapping_size()) {
          box.label = config_.detect_type_mapping(box.label);
        }
      }
    }
  }

  code = FLOW::module_status_success;
}

size_t DetectModule::MaxBatchSize() {
    return config_.batch_size();
}

void DetectModule::Process(const input_type& in, output_type* out){
    std::vector<output_type*> outs{out};
    ProcessBatch({in}, &outs);
}

void DetectModule::ProcessBatch(const std::vector<input_type>& in, const std::vector<output_type*>* out) {
    LOG_IF(FATAL, in.size() != out->size()) <<"size error";
    // input
    std::vector<void*> crop_datas;
    std::vector<cv::Mat> im_mats(in.size());
    std::transform(in.begin(), in.end(), im_mats.begin(),
                    [&crop_datas](const input_type& input) {
                        const auto& mat = std::get<0>(input);
                        const auto& roi = std::get<1>(input);
                        const auto& crop= std::get<2>(input);
                        if (crop) { crop_datas.push_back(crop); }
                        return roi.empty() ? mat : mat(roi);
                    }
    );

    // run
    std::vector<Algorithm::VecBoxF> Gboxes;
    if (crop_datas.size() == im_mats.size()) {
        engine_->Run<const std::vector<cv::Mat>&,
                    const std::vector<void*>&,std::vector<Algorithm::VecBoxF>&>(
                    im_mats, crop_datas, Gboxes
        );
    } else {
        engine_->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecBoxF>&>(
                    im_mats, Gboxes
        );
    }

    // output
    size_t index = 0;
    std::for_each(Gboxes.begin(), Gboxes.end(), [&](const Algorithm::VecBoxF& boxes) {
        const auto roi   = std::get<1>(in[index]);
        const auto current_out = out->at(index);
        current_out->clear();
        std::for_each(boxes.begin(), boxes.end(), [&](const Algorithm::BoxF& box) {
            auto threshold = box.label < config_.detect_thresholds_size()
                                ? config_.detect_thresholds(box.label)
                                : config_.detect_thresholds(config_.detect_thresholds_size()-1);
            if (box.score > threshold) {
                const cv::Point p1(box.xmin+roi.x, box.ymin+roi.y);
                const cv::Point p2(box.xmax+roi.x, box.ymax+roi.y);
                const cv::Rect rect(p1, p2);
                current_out->push_back({rect, box.score, box.label, ""});
            }
        });
        index++;
    });

    // label mapping
    for (auto& pboxes : *out) {
        for (auto& box : *pboxes) {
            if (box.label < config_.detect_type_mapping_size()) {
                box.label = config_.detect_type_mapping(box.label);
            }
            if (box.label < config_.label_str_mapping_size()) {
                box.label_str = config_.label_str_mapping(box.label);
            } else {
                box.label_str = std::to_string(box.label);
            }
        }
    }
}

DetectModule::input_type DetectModule::ConvertInput(const cv::Mat& mat, const inference::PictureReq& req) {
    const auto rect = req.has_rect() 
        ? cv::Rect{(int)req.rect().x(), (int)req.rect().y(), (int)req.rect().w(), (int)req.rect().h()}
        : cv::Rect{0, 0, mat.cols, mat.rows};
    return input_type{mat, rect, nullptr};
}

inference::PictureResp DetectModule::ConvertOutput(const output_type& results) {
    inference::PictureResp resp;
    for(result_type one : results) {
        auto obj = resp.add_object();
        obj->set_x(one.rect.x);
        obj->set_y(one.rect.y);
        obj->set_w(one.rect.width);
        obj->set_h(one.rect.height);
        resp.add_label(one.label_str);
        resp.add_score(one.score);
    }
    return resp;
}

}  // namespace Detect

}  // namespace FLOW
