#ifndef ANALYZER_ALGORITHM_DETECT_DETECT_HPP_
#define ANALYZER_ALGORITHM_DETECT_DETECT_HPP_

#include "common/tad_internal.hpp"
#include "common/flow/flow_process.hpp"
#include "serving/config.pb.h"
#include "serving/input_arguments.pb.h"
#include "algorithm/algorithm.hpp"

namespace FLOW {

struct RectInfo {
  cv::Rect rect;
  float score;
  int label;
  std::string label_str;
};

namespace Detect {

class DetectModule {
 public:
  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

#ifdef USE_MEDIA_UTILS
  void Process(VecShellFrame& shell_frames, std::vector<cv::Rect> rois,
               std::vector<std::vector<RectInfo>>& images_boxes, int& code);
#endif

  void ProcessROIs(VecShellFrame& shell_frames, std::vector<cv::Rect> rois,
                   std::vector<std::vector<RectInfo>>& images_boxes, int& code);

  const std::vector<int>& GetInputShapes() const {
    return input_shapes_;
  }

  // add for flow_process
  public:
      typedef std::tuple<cv::Mat, cv::Rect, void*>    input_type;
      typedef RectInfo                                result_type;
      typedef std::vector<result_type>                output_type;
  public:
      size_t MaxBatchSize();
      void Process(const input_type& in, output_type* out);
      void ProcessBatch(const std::vector<input_type>& in, const std::vector<output_type*>* out);
      static input_type ConvertInput(const cv::Mat& mat, const inference::PictureReq& req);
      static inference::PictureResp ConvertOutput(const output_type& results);

 private:
  inference::Algorithm config_;
  std::vector<int> input_shapes_;
  std::shared_ptr<Algorithm::Detect> engine_ = nullptr;
};

class sync_detect_general
    : public flow_process_sync<DetectModule>
{
public:
    typedef flow_process_sync<DetectModule>     processer_type;
    typedef std::shared_ptr<processer_type>     sync_handle;

public:
    sync_detect_general()
        : processer_type("fp_det_general")
    {}
};

}  // namespace Detect

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_DETECT_DETECT_HPP_
