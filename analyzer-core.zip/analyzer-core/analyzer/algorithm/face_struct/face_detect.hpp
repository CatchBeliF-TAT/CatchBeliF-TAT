//
// Created by yankai on 2020/5/28.
//

#ifndef ANALYZER_ALGORITHM_FACE_STRUCT_FACE_DETECT_HPP_
#define ANALYZER_ALGORITHM_FACE_STRUCT_FACE_DETECT_HPP_
#include "common/tad_internal.hpp"

#include "core/network.hpp"
#include "proto/tron.pb.h"
#include "serving/config.pb.h"

namespace FLOW {

namespace FaceStruct {

class FaceDetectModule {
 public:
  FaceDetectModule() = default;

  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

  void Predict(const VecMat& im_mats, std::vector<RectF> rois,
               std::vector<VecBoxF>& FaceInfos, int& code);

  ~FaceDetectModule();

 private:
  void Process(const VecFloat& in_data, std::vector<VecBoxF>& FaceInfos);

  Shadow::Network net_;
  VecFloat in_data_;
  VecInt in_shape_;
  std::string in_str_, out_str_boxes_scores_, out_str_landmarks_,
      out_str_occ_landmarks_;
  int in_num_, in_c_, in_h_, in_w_, background_label_id_;
  float threshold_, nms_threshold_;
  inference::Algorithm config_;

 public:
  int batch_;
};
}  // namespace FaceStruct
}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_FACE_STRUCT_FACE_DETECT_HPP_
