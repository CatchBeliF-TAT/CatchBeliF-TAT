//
// Created by yankai on 2020/5/27.
//

#include "face_quality.hpp"

using namespace std;

namespace FLOW {
namespace FaceStruct {

void FaceQualityModule::Setup(const std::vector<char>& meta_net_data,
                              const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Create FaceQualityModule";

  task_name_ = {"quality"};
  Algorithm::Argument arguments;
  arguments.AddSingleArgument<int>("net_id", 0);
  arguments.AddSingleArgument<std::string>("method", "classify");
#ifdef USE_CUDA
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<bool>("use_fp16", 1);
#else
  arguments.AddSingleArgument<string>("backend_type", "Native");
#endif
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());

  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());

  arguments.AddRepeatedArgument<string>("categories", task_name_);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());

  face_quality_engine_ = make_shared<Algorithm::Extract>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  code = module_status_success;
  LOG(INFO) << "Finished create FaceQualityModule!";
}

void FaceQualityModule::Predict(const VecMat& im_mats,
                                vector<VecBoxF>& FaceInfos, int& code) {
  vector<cv::Mat> im_crop_mats;
  CHECK_EQ(im_mats.size(), FaceInfos.size());
  for (int i = 0; i < FaceInfos.size(); i++) {
    for (int j = 0; j < FaceInfos[i].size(); j++) {
      cv::Rect roi =
          cv::Rect(int(FaceInfos[i][j].xmin), int(FaceInfos[i][j].ymin),
                   int(FaceInfos[i][j].xmax - FaceInfos[i][j].xmin + 1),
                   int(FaceInfos[i][j].ymax - FaceInfos[i][j].ymin + 1));
      im_crop_mats.push_back((*im_mats[i])(roi));
    }
  }
  vector<map<string, VecFloat>> Gvalues;
  face_quality_engine_
      ->Run<const vector<cv::Mat>&, vector<map<string, VecFloat>>&>(
          im_crop_mats, Gvalues);

  for (int i = 0, img_mat_index = 0; i < FaceInfos.size(); i++) {
    for (int j = 0; j < FaceInfos[i].size(); j++, img_mat_index++) {
      FaceInfos[i][j].face_attr.clear();
      for (int k = 0; k < task_name_.size(); k++) {
        const auto& type_scores = Gvalues[img_mat_index].at(task_name_[k]);
        int top_attr_index = Util::top_k(type_scores, 1)[0];
        float top_attr_score = type_scores[top_attr_index];
        FaceInfos[i][j].face_quality.type = top_attr_index;
        FaceInfos[i][j].face_quality.score = top_attr_score;
      }
    }
  }
}

FaceQualityModule::~FaceQualityModule() {
  LOG(INFO) << "Deconstruct FaceQualityModule";
}
}  // namespace FaceStruct
}  // namespace FLOW
