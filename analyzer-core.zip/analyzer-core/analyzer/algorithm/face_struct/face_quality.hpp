//
// Created by yankai on 2020/5/27.
//

#ifndef ANALYZER_ALGORITHM_FACE_STRUCT_FACE_QUALITY_HPP_
#define ANALYZER_ALGORITHM_FACE_STRUCT_FACE_QUALITY_HPP_

#include "algorithm/algorithm.hpp"
#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace FaceStruct {

class FaceQualityModule {
 public:
  FaceQualityModule() = default;

  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

  void Predict(const VecMat& im_mats, std::vector<VecBoxF>& FaceInfos,
               int& code);

  ~FaceQualityModule();

 private:
  VecString task_name_;
  std::shared_ptr<Algorithm::Extract> face_quality_engine_;
};

}  // namespace FaceStruct
}  // namespace FLOW
#endif  // ANALYZER_ALGORITHM_FACE_STRUCT_FACE_QUALITY_HPP_
