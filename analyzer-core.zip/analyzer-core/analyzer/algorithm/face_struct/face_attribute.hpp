//
// Created by yankai on 2020/5/27.
//

#ifndef ANALYZER_ALGORITHM_FACE_STRUCT_FACE_ATTRIBUTE_HPP_
#define ANALYZER_ALGORITHM_FACE_STRUCT_FACE_ATTRIBUTE_HPP_

#include "algorithm/algorithm.hpp"
#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace FaceStruct {

class FaceAttributeModule {
 public:
  FaceAttributeModule() = default;

  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

  void Predict(const VecMat& im_mats, std::vector<VecBoxF>& FaceInfos,
               int& code);

  ~FaceAttributeModule();

 private:
  VecString task_name_;
  std::shared_ptr<Algorithm::Extract> face_attribute_engine_;
};

}  // namespace FaceStruct
}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_FACE_STRUCT_FACE_ATTRIBUTE_HPP_
