//
// Created by yankai on 2020/5/28.
//

#include "face_detect.hpp"

#include "common/io.hpp"

namespace FLOW {
namespace FaceStruct {
static void ConvertData(const cv::Mat& im_mat, float* data, const RectF& roi,
                        int channel, int height, int width, int flag = 1,
                        bool transpose = false) {
  CHECK(!im_mat.empty());
  CHECK_NOTNULL(data);

  int c_ = im_mat.channels(), h_ = im_mat.rows, w_ = im_mat.cols;
  int dst_spatial_dim = height * width;

  if (roi.w <= 1 && roi.h <= 1) {
    if (roi.x < 0 || roi.y < 0 || roi.x + roi.w > 1 || roi.y + roi.h > 1) {
      LOG(FATAL) << "Crop region overflow!";
    }
  } else if (roi.w > 1 && roi.h > 1) {
    if (roi.x < 0 || roi.y < 0 || roi.x + roi.w > w_ || roi.y + roi.h > h_) {
      LOG(FATAL) << "Crop region overflow!";
    }
  } else {
    LOG(FATAL) << "Crop scale must be the same!";
  }

  float *data_r = nullptr, *data_g = nullptr, *data_b = nullptr,
        *data_gray = nullptr;
  if (channel == 3 && flag == 0) {
    // Convert to RRRGGGBBB
    data_r = data;
    data_g = data + dst_spatial_dim;
    data_b = data + (dst_spatial_dim << 1);
  } else if (channel == 3 && flag == 1) {
    // Convert to BBBGGGRRR
    data_r = data + (dst_spatial_dim << 1);
    data_g = data + dst_spatial_dim;
    data_b = data;
  } else if (channel == 1) {
    // Convert to Gray
    data_gray = data;
  } else {
    LOG(FATAL) << "Unsupported flag " << flag;
  }

  auto roi_x = static_cast<int>(roi.w <= 1 ? roi.x * w_ : roi.x);
  auto roi_y = static_cast<int>(roi.h <= 1 ? roi.y * h_ : roi.y);
  auto roi_w = static_cast<int>(roi.w <= 1 ? roi.w * w_ : roi.w);
  auto roi_h = static_cast<int>(roi.h <= 1 ? roi.h * h_ : roi.h);

  cv::Rect cv_roi(roi_x, roi_y, roi_w, roi_h);
  cv::Size cv_size(width, height);

  cv::Mat im_resize;
  if (roi_x != 0 || roi_y != 0 || roi_w != w_ || roi_h != h_) {
    cv::resize(im_mat(cv_roi), im_resize, cv_size);
  } else {
    cv::resize(im_mat, im_resize, cv_size);
  }

  int dst_h = height, dst_w = width;
  if (transpose) {
    cv::transpose(im_resize, im_resize);
    dst_h = width, dst_w = height;
  }

  if (channel == 3) {
    CHECK_EQ(c_, 3);
    for (int h = 0; h < dst_h; ++h) {
      const auto* data_src = im_resize.ptr<uchar>(h);
      for (int w = 0; w < dst_w; ++w) {
        *data_b++ = static_cast<float>(*data_src++);
        *data_g++ = static_cast<float>(*data_src++);
        *data_r++ = static_cast<float>(*data_src++);
      }
    }
  } else if (channel == 1) {
    cv::Mat im_gray;
    cv::cvtColor(im_resize, im_gray, cv::COLOR_BGR2GRAY);
    for (int h = 0; h < dst_h; ++h) {
      const auto* data_src = im_gray.ptr<uchar>(h);
      for (int w = 0; w < dst_w; ++w) {
        *data_gray++ = static_cast<float>(*data_src++);
      }
    }
  } else {
    LOG(FATAL) << "Unsupported flag " << flag;
  }
}

void FaceDetectModule::Setup(const std::vector<char>& meta_net_data,
                             const inference::Algorithm& config, int& code) {
  tron::MetaNetParam meta_net_param;
  IO::ReadProtoFromArray(meta_net_data.data(), meta_net_data.size(),
                         &meta_net_param);
  LOG(INFO) << "Create FaceDetectModule";
  config_ = config;
#ifdef USE_CUDA
  Shadow::ArgumentHelper arguments;
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
  net_.LoadXModel(meta_net_param.network(0), arguments);

#else
  Shadow::ArgumentHelper arguments;
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  arguments.AddSingleArgument<std::string>("backend_type", "Native");
  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());
  net_.LoadXModel(meta_net_param.network(0), arguments);
#endif

  const auto& in_blob = net_.in_blob();
  CHECK_EQ(in_blob.size(), 1);
  in_str_ = in_blob[0];

  const auto& out_blob_face = net_.out_blob();
  CHECK_EQ(out_blob_face.size(), 3);

  std::vector<std::string> out_blob;
  if (net_.has_argument("out_blob")) {
    out_blob = net_.get_repeated_argument<std::string>("out_blob");
  } else {
    out_blob = net_.out_blob();
  }

  out_str_boxes_scores_ = out_blob[0];
  out_str_occ_landmarks_ = out_blob[1];
  out_str_landmarks_ = out_blob[2];

  in_shape_ = net_.GetBlobShapeByName<float>(in_str_);
  batch_ = in_shape_[0];
  in_c_ = in_shape_[1];
  in_h_ = in_shape_[2];
  in_w_ = in_shape_[3];

  in_num_ = in_c_ * in_h_ * in_w_;

  threshold_ = net_.get_single_argument<float>(
      "threshold", 0.9);  // Todo: score threshold for refinedet
  threshold_ = threshold_ > config_.detect_threshold()
                   ? threshold_
                   : config_.detect_threshold();
  background_label_id_ = 0;
  nms_threshold_ = net_.get_single_argument<float>("nms_threshold", 0.3);
  code = module_status_success;
  LOG(INFO) << "Finished create FaceDetectModule!";
}

void FaceDetectModule::Predict(const VecMat& im_mats, std::vector<RectF> rois,
                               std::vector<VecBoxF>& FaceInfos, int& code) {
  int num_im = static_cast<int>(im_mats.size());
  in_shape_[0] = num_im;
  in_data_.resize(num_im * in_num_, 0);
  for (int b = 0; b < num_im; ++b) {
    const auto& im_mat = *(im_mats[b]);

    ConvertData(im_mat, in_data_.data() + b * in_num_, rois[b], in_c_, in_h_,
                in_w_, 1, false);  // flag 0: RGB input for detect
  }
  Process(in_data_, FaceInfos);

  CHECK_EQ(FaceInfos.size(), num_im);
  for (int b = 0; b < num_im; ++b) {
    const auto& im_mat = *(im_mats[b]);
    for (auto& face_info : FaceInfos[b]) {
      face_info.xmin *= rois[b].w;
      face_info.xmax *= rois[b].w;
      face_info.ymin *= rois[b].h;
      face_info.ymax *= rois[b].h;
      float det_w = face_info.xmax - face_info.xmin + 1;
      float det_h = face_info.ymax - face_info.ymin + 1;

      face_info.face_point.x1 =
          (face_info.face_point.x1 + 0.3165) * det_w + face_info.xmin;
      face_info.face_point.y1 =
          (face_info.face_point.y1 + 0.3750) * det_h + face_info.ymin;
      face_info.face_point.x2 =
          (face_info.face_point.x2 + 0.7050) * det_w + face_info.xmin;
      face_info.face_point.y2 =
          (face_info.face_point.y2 + 0.3696) * det_h + face_info.ymin;
      face_info.face_point.x3 =
          (face_info.face_point.x3 + 0.5120) * det_w + face_info.xmin;
      face_info.face_point.y3 =
          (face_info.face_point.y3 + 0.5711) * det_h + face_info.ymin;
      face_info.face_point.x4 =
          (face_info.face_point.x4 + 0.3597) * det_w + face_info.xmin;
      face_info.face_point.y4 =
          (face_info.face_point.y4 + 0.7490) * det_h + face_info.ymin;
      face_info.face_point.x5 =
          (face_info.face_point.x5 + 0.6661) * det_w + face_info.xmin;
      face_info.face_point.y5 =
          (face_info.face_point.y5 + 0.7452) * det_h + face_info.ymin;

      face_info.xmin += rois[b].x;
      face_info.xmax += rois[b].x;
      face_info.ymin += rois[b].y;
      face_info.ymax += rois[b].y;

      face_info.face_point.x1 += rois[b].x;
      face_info.face_point.y1 += rois[b].y;
      face_info.face_point.x2 += rois[b].x;
      face_info.face_point.y2 += rois[b].y;
      face_info.face_point.x3 += rois[b].x;
      face_info.face_point.y3 += rois[b].y;
      face_info.face_point.x4 += rois[b].x;
      face_info.face_point.y4 += rois[b].y;
      face_info.face_point.x5 += rois[b].x;
      face_info.face_point.y5 += rois[b].y;
    }
  }
}

void FaceDetectModule::Process(const VecFloat& in_data,
                               std::vector<VecBoxF>& FaceInfos) {
  std::map<std::string, void*> data_map;
  std::map<std::string, VecInt> shape_map;

  data_map[in_str_] = (void*)(in_data_.data());
  shape_map[in_str_] = in_shape_;

  net_.Forward(data_map, shape_map);

  const auto& out_shape_boxes_scores =
      net_.GetBlobShapeByName<float>(out_str_boxes_scores_);
  const auto* out_data_boxes_scores =
      net_.GetBlobDataByName<float>(out_str_boxes_scores_);

  const auto& out_shape_landmarks =
      net_.GetBlobShapeByName<float>(out_str_landmarks_);
  const auto* out_data_landmarks =
      net_.GetBlobDataByName<float>(out_str_landmarks_);

  const auto& out_shape_occ_landmarks =
      net_.GetBlobShapeByName<float>(out_str_occ_landmarks_);
  const auto* out_data_occ_landmarks =
      net_.GetBlobDataByName<float>(out_str_occ_landmarks_);

  int batch = out_shape_boxes_scores[0], num_priors = out_shape_boxes_scores[1],
      num_data = out_shape_boxes_scores[2];

  int landmarks_batch = out_shape_landmarks[0],
      landmarks_num_priors = out_shape_landmarks[1],
      landmarks_num_data = out_shape_landmarks[2];

  int occ_landmarks_batch = out_shape_occ_landmarks[0],
      occ_landmarks_num_priors = out_shape_occ_landmarks[1],
      occ_landmarks_num_data = out_shape_occ_landmarks[2];

  FaceInfos.clear();
  for (int b = 0; b < batch; ++b) {
    VecBoxF boxes, nmsBoxes, result;
    for (int n = 0; n < num_priors; ++n, out_data_boxes_scores += num_data,
             out_data_landmarks += landmarks_num_data,
             out_data_occ_landmarks += occ_landmarks_num_data) {
      int label = static_cast<int>(out_data_boxes_scores[0]);
      float score = out_data_boxes_scores[1];
      if (label != background_label_id_) {
        BoxF box;
        box.xmin = out_data_boxes_scores[2];
        box.ymin = out_data_boxes_scores[3];
        box.xmax = out_data_boxes_scores[4];
        box.ymax = out_data_boxes_scores[5];
        box.score = score;
        box.label = label;

        box.face_point.x1 = out_data_landmarks[0];
        box.face_point.y1 = out_data_landmarks[1];
        box.face_point.x2 = out_data_landmarks[2];
        box.face_point.y2 = out_data_landmarks[3];
        box.face_point.x3 = out_data_landmarks[4];
        box.face_point.y3 = out_data_landmarks[5];
        box.face_point.x4 = out_data_landmarks[6];
        box.face_point.y4 = out_data_landmarks[7];
        box.face_point.x5 = out_data_landmarks[8];
        box.face_point.y5 = out_data_landmarks[9];
        box.face_point.occ1 = out_data_occ_landmarks[0];
        box.face_point.occ2 = out_data_occ_landmarks[1];
        box.face_point.occ3 = out_data_occ_landmarks[2];
        box.face_point.occ4 = out_data_occ_landmarks[3];
        box.face_point.occ5 = out_data_occ_landmarks[4];
        boxes.push_back(box);
      }
    }
    // nms
    nmsBoxes = Boxes::NMS(boxes, nms_threshold_);
    for (int it = 0; it < nmsBoxes.size(); it++) {
      if (nmsBoxes.at(it).score > threshold_) {
        result.push_back(nmsBoxes.at(it));
      }
    }
    FaceInfos.push_back(result);
  }
}

FaceDetectModule::~FaceDetectModule() {
  LOG(INFO) << "Deconstruct FaceDetectModule";
}
}  // namespace FaceStruct
}  // namespace FLOW
