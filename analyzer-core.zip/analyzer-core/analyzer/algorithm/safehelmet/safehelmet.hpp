#ifndef ANALYZER_ALGORITHM_SAFEHELMET_SAFEHELMET_HPP_
#define ANALYZER_ALGORITHM_SAFEHELMET_SAFEHELMET_HPP_

#include <memory>
#include <opencv2/opencv.hpp>
#include "algorithm/algorithm.hpp"
#include "common/boxes.hpp"
#include "common/tad_internal.hpp"
#include "common/type.hpp"
#include "common/util.hpp"
#include "serving/config.pb.h"

#define SAFEHELMET_MAX_BATCH_SIZE 16

namespace FLOW {

namespace Safehelmet {

class Safehelmet {
 public:
  void Setup_head_person(const std::vector<char>& meta_net_data,
                         const inference::Algorithm& config, int& code);
  void Setup_classfy(const std::vector<char>& meta_net_data,
                     const inference::Algorithm& config, int& code);
  void Setup_vehicle(const std::vector<char>& meta_net_data,
                     const inference::Algorithm& config, int& code);

  //#ifdef USE_MEDIA_UTILS
  //  void Process(VecMat& images, VecVframe& frames,
  //               std::vector<std::vector<RectInfo>>& images_boxes, int& code);
  //#endif

  std::vector<int> GetInputShapes() { return input_shapes_; }
  inference::Algorithm config_;

  void HeadPersonProcess(const std::vector<std::shared_ptr<cv::Mat>> images,
                         std::vector<SafeHelmet_Event>& events);
  void ClassfyProcess(std::vector<SafeHelmet_Event>& events);
  void VehicleProcess(const std::vector<std::shared_ptr<cv::Mat>> images,
                      std::vector<VecBoxF> Cboxes,
                      std::vector<SafeHelmet_Event>& events);

  void ResizeAndCrop(const std::vector<std::shared_ptr<cv::Mat>> images,
                      std::vector<SafeHelmet_Event>& events);

 private:
  std::shared_ptr<Algorithm::Detect> engine_head_person_ = nullptr;
  std::shared_ptr<Algorithm::Extract> engine_classfy_ = nullptr;
  std::shared_ptr<Algorithm::Detect> engine_vehicle_ = nullptr;
  std::vector<int> input_shapes_;
  float head_person_detect_threshold, vehicle_detect_threshold;
  VecFloat classfy_thresholds;
};

}  // namespace Safehelmet
}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_SAFEHELMET_SAFEHELMET_HPP_
