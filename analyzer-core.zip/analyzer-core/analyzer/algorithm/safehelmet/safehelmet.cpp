#include "safehelmet.hpp"
#include "common/io.hpp"
#include "common/json.hpp"
#include "common/log.hpp"
#include "document.h"
#include "prettywriter.h"
#include "stringbuffer.h"

namespace FLOW {

namespace Safehelmet {

#define RESIZE_SIZE 128
#define CROP_SIZE 112

bool centerpoint_interior_box(BoxF box1, BoxF box2) {
  float center_x = (box1.xmin + box1.xmax) / 2;
  float center_y = (box1.ymin + box1.ymax) / 2;

  if ((center_x > box2.xmin) && (center_x < box2.xmax) &&
      (center_y > box2.ymin) && (center_y < box2.ymax)) {
    return true;
  } else {
    return false;
  }
}

void Safehelmet::Setup_head_person(const std::vector<char>& meta_net_data,
                                   const inference::Algorithm& config,
                                   int& code) {
  LOG(INFO) << "Setup Safehelmet Head_person Detect Module";
  config_ = config;
  Algorithm::Argument arguments;
  arguments.AddSingleArgument<std::string>("backend_type", "Native");
  arguments.AddSingleArgument<int>("device_id", config_.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config_.batch_size());
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
#ifdef USE_MEDIA_UTILS
  arguments.AddSingleArgument<bool>("device_input", false);
#else
  arguments.AddSingleArgument<bool>("device_input", false);
#endif

  engine_head_person_ = std::make_shared<Algorithm::Detect>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  std::vector<VecInt> network_input_shapes;
  engine_head_person_->Run<const std::string&, std::vector<VecInt>&>(
      "GetNetworkInputShapes", network_input_shapes);
  input_shapes_ = network_input_shapes[0];

  head_person_detect_threshold = config_.detect_threshold();

  code = FLOW::module_status_success;

  LOG(INFO) << "Finished setup Safehelmet Head_person Detect Module";
}

void Safehelmet::Setup_classfy(const std::vector<char>& meta_net_data,
                               const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Setup Safehelmet Classify Module";
  config_ = config;
  Algorithm::Argument arguments;
  arguments.AddSingleArgument<std::string>("backend_type", "Native");
  arguments.AddSingleArgument<int>("device_id", config_.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config_.batch_size());
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddRepeatedArgument<std::string>("categories", {"feature"});
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
#ifdef USE_MEDIA_UTILS
  arguments.AddSingleArgument<bool>("device_input", false);
#else
  arguments.AddSingleArgument<bool>("device_input", false);
#endif

  engine_classfy_ = std::make_shared<Algorithm::Extract>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  std::vector<VecInt> network_input_shapes;
  engine_classfy_->Run<const std::string&, std::vector<VecInt>&>(
      "GetNetworkInputShapes", network_input_shapes);
  input_shapes_ = network_input_shapes[0];

  classfy_thresholds = VecFloat(config_.detect_thresholds().begin(),
                                config_.detect_thresholds().end());

  code = FLOW::module_status_success;

  LOG(INFO) << "Finished Safehelmet Classify Module";
}

void Safehelmet::Setup_vehicle(const std::vector<char>& meta_net_data,
                               const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Setup Safehelmet Vehicle Detect Module";
  config_ = config;
  Algorithm::Argument arguments;
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("device_id", config_.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config_.batch_size());
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
  arguments.AddSingleArgument<bool>("explicit_batch", true);
#ifdef USE_MEDIA_UTILS
  arguments.AddSingleArgument<bool>("device_input", false);
#else
  arguments.AddSingleArgument<bool>("device_input", false);
#endif

  engine_vehicle_ = std::make_shared<Algorithm::Detect>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  std::vector<VecInt> network_input_shapes;
  engine_vehicle_->Run<const std::string&, std::vector<VecInt>&>(
      "GetNetworkInputShapes", network_input_shapes);
  input_shapes_ = network_input_shapes[0];
  LOG(INFO) << "GetNetworkInputShapes: ";
  for (auto e: network_input_shapes[0]){
    LOG(INFO) << e;
  }
  vehicle_detect_threshold = config_.detect_threshold();

  code = FLOW::module_status_success;

  LOG(INFO) << "Finished setup Safehelmet Vehicle Detect Module";
}

// Safehelmet HeadPersonProcess
void Safehelmet::HeadPersonProcess(
    const std::vector<std::shared_ptr<cv::Mat>> images,
    std::vector<SafeHelmet_Event>& events) {
  events.clear();
  Profiler Safehelmet_profile;
  Safehelmet_profile.tic("SafehelmetHeadPerson Process");

  std::vector<cv::Mat> im_mats;
  std::vector<Algorithm::VecBoxF> Gboxes_head_person;

  for (auto& image : images) {
    im_mats.push_back(*image);
  }
  engine_head_person_
      ->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecBoxF>&>(
          im_mats, Gboxes_head_person);

  for (auto& boxes : Gboxes_head_person) {
    BoxF pbox;
    VecBoxF boxes_head;
    for (auto& box : boxes) {
      pbox.xmin = box.xmin;
      pbox.ymin = box.ymin;
      pbox.xmax = box.xmax;
      pbox.ymax = box.ymax;
      pbox.score = box.score;
      pbox.label = box.label;
      if ((pbox.label == 0) && (pbox.score > head_person_detect_threshold)) {
        boxes_head.push_back(pbox);
      }
    }
    SafeHelmet_Event event;
    event.safe_helmets = boxes_head;
    events.push_back(event);
  }

  Safehelmet_profile.toc("SafehelmetHeadPerson Process");
  LOG(DEBUG) << Safehelmet_profile.get_stats_str();
}

void Safehelmet::ResizeAndCrop(
    const std::vector<std::shared_ptr<cv::Mat>> images,
    std::vector<SafeHelmet_Event>& events) {
    
    CHECK_EQ(images.size(), events.size());

    for(int i=0; i<images.size(); i++){
      for(auto& safehelmet_box: events[i].safe_helmets){
        cv::Rect head_roi(safehelmet_box.xmin, safehelmet_box.ymin, 
                        safehelmet_box.xmax-safehelmet_box.xmin, safehelmet_box.ymax-safehelmet_box.ymin);
        cv::Mat head_img = (*images[i])(head_roi);

        //resize
        cv::Size cv_size(RESIZE_SIZE, RESIZE_SIZE);
        cv::resize(head_img, head_img, cv_size);

        //crop
        CHECK_GT(RESIZE_SIZE, CROP_SIZE);
        cv::Rect cv_roi((RESIZE_SIZE - CROP_SIZE) / 2, (RESIZE_SIZE - CROP_SIZE) / 2, 
                        CROP_SIZE, CROP_SIZE);
        head_img = head_img(cv_roi);
        std::shared_ptr<cv::Mat> crop_mg_ptr = std::make_shared<cv::Mat>(head_img);
        events[i].safehelmets_mat.push_back(crop_mg_ptr);
      }
    }
}

// Safehelmet ClassfyProcess
void Safehelmet::ClassfyProcess(std::vector<SafeHelmet_Event>& events) {
  events.clear();
  Profiler Safehelmet_profile;
  Safehelmet_profile.tic("SafehelmetClassfy Process");
  //遍历每张图片
  for (auto& event : events) {
    std::vector<cv::Mat> im_mats;
    std::vector<std::map<std::string, Algorithm::VecFloat>> Gvalues;

    CHECK_EQ(event.safehelmets_mat.size(), event.safe_helmets.size());

    //遍历每个安全帽的img
    for(auto& mat_ptr :event.safehelmets_mat){
      im_mats.push_back(*mat_ptr);
    }

    engine_classfy_->Run<const std::vector<cv::Mat>&,
                        std::vector<std::map<std::string, Algorithm::VecFloat>>&>(
                        im_mats, Gvalues);

    for (int Aboxes_i = 0; Aboxes_i < event.safe_helmets.size(); Aboxes_i++) {
      
      VecFloat ::iterator biggest =
          std::max_element(std::begin(Gvalues[Aboxes_i].at("feature")),
                           std::end(Gvalues[Aboxes_i].at("feature")));
      event.safe_helmets[Aboxes_i].score = *biggest;
      event.safe_helmets[Aboxes_i].label =
          std::distance(std::begin(Gvalues[Aboxes_i].at("feature")), biggest);
    }
  }

  Safehelmet_profile.toc("SafehelmetClassfy Process");
  LOG(DEBUG) << Safehelmet_profile.get_stats_str();
}

// Safehelmet VehicleProcess
void Safehelmet::VehicleProcess(
    const std::vector<std::shared_ptr<cv::Mat>> images,
    std::vector<VecBoxF> Cboxes, std::vector<SafeHelmet_Event>& events) {
  events.clear();
  Profiler Safehelmet_profile;
  Safehelmet_profile.tic("Vehicle Process");
  VecInt head_flags;
  std::vector<cv::Mat> im_vehicle_mats;
  std::vector<Algorithm::VecBoxF> Gboxes_vehicle;

  //判断每一帧是否出现至少一个未戴安全帽的head，如果有，进行车辆的判断
  for (int i = 0; i < Cboxes.size(); i++) {
    int head_flag = 0;
    for (auto box : Cboxes[i]) {
      if ((1 == box.label) && (box.score > classfy_thresholds[1])) {
        head_flag = 1;
      }
    }
    head_flags.push_back(head_flag);
    if (head_flag) {
      im_vehicle_mats.push_back(*(images[i]));
    }
  }

  if (!im_vehicle_mats.empty()) {
    engine_vehicle_
        ->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecBoxF>&>(
            im_vehicle_mats, Gboxes_vehicle);
  }

  int vehicle_count = 0;
  for (int i = 0; i < Cboxes.size(); i++) {
    //每一帧的处理
    SafeHelmet_Event event;
    VecBoxF boxes_car;
    if (0 == head_flags[i]) {
      //这一帧没有没戴安全帽的
      for (auto box : Cboxes[i]) {
        if ((box.label == 0) && (box.score > classfy_thresholds[0])) {
          event.safe_helmets.push_back(box);//戴了安全帽的box不处理
        }
        if ((box.label == 1) && (box.score > classfy_thresholds[1])) {
          //no need for this
          event.safe_helmets.push_back(box);
        }
      }
    } else {
      //处理至少有一个未戴安全帽的帧
      for (auto box_car : Gboxes_vehicle[vehicle_count]) {
        //处理这一帧的所有车
        BoxF pbox_car;
        if (0 == box_car.label) {
          pbox_car.xmin = box_car.xmin;
          pbox_car.ymin = box_car.ymin;
          pbox_car.xmax = box_car.xmax;
          pbox_car.ymax = box_car.ymax;
          pbox_car.score = box_car.score;
          pbox_car.label = box_car.label;
          boxes_car.push_back(pbox_car);
        }
      }
      if (boxes_car.empty()) {
        //没有车
        for (auto box : Cboxes[i]) {
          if ((box.label == 0) && (box.score > classfy_thresholds[0])) {
            event.safe_helmets.push_back(box);
          }
          if ((box.label == 1) && (box.score > classfy_thresholds[1])) {
            event.safe_helmets.push_back(box);
          }
        }
      } else {
        for (auto box : Cboxes[i]) {
          //只要这个box在任意一个车中就为true，然后丢弃
          bool ifInACar = false;
          for (auto box_car : boxes_car) {
            if (centerpoint_interior_box(box, box_car)) {
              ifInACar = true;
            }
          }
          if(!ifInACar){
            if ((box.label == 0) && (box.score > classfy_thresholds[0])) {
              event.safe_helmets.push_back(box);
            }
            if ((box.label == 1) && (box.score > classfy_thresholds[1])) {
              event.safe_helmets.push_back(box);
            }
          }
        }
      }
      vehicle_count++;
    }
    events.push_back(event);
  }

  Safehelmet_profile.toc("Vehicle Process");
  LOG(DEBUG) << Safehelmet_profile.get_stats_str();
}
}  // namespace Safehelmet

}  // namespace FLOW
