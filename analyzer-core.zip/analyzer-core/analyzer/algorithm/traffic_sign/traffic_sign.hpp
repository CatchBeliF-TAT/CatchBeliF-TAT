#ifndef ANALYZER_ALGORITHM_TRAFFIC_SIGN_TRAFFIC_SIGN_HPP_
#define ANALYZER_ALGORITHM_TRAFFIC_SIGN_TRAFFIC_SIGN_HPP_

#include "common/tad_internal.hpp"

#include "algorithm/algorithm.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace TrafficSign {

class TrafficSign {
 public:
  void Setup(const std::vector<char>& meta_net_data, const inference::Algorithm& config);

  void Process(const std::vector<std::shared_ptr<cv::Mat>>& images,
               std::vector<TrafficSign_Event>& events);

 private:
  std::shared_ptr<Algorithm::Detect> engine_ = nullptr;
};

}  // namespace TrafficSign

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_TRAFFIC_SIGN_TRAFFIC_SIGN_HPP_
