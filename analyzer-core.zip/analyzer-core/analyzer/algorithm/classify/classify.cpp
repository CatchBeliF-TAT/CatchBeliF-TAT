#include "classify.hpp"
#include "common/log.hpp"
#include "common/util.hpp"

namespace FLOW {

namespace classify {

void ClassifyModule::Setup(const std::vector<char>& meta_net_data,
                           const inference::Algorithm& config, int& code) {

  Algorithm::Argument arguments;
  arguments.AddSingleArgument<int>("net_id", 0);
  arguments.AddSingleArgument<std::string>("method", "classify");
#ifdef USE_CUDA
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
#else
  arguments.AddSingleArgument<std::string>("backend_type", "Native");
#endif
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());
  arguments.AddRepeatedArgument<std::string>("categories", {"feature"});


  classify_ = std::make_shared<Algorithm::Extract>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  code = module_status_success;
}

/*
void ClassifyModule::Predict(const VecMat& images,
                             std::vector<VecBoxF>* images_boxes) {
  LOG(INFO)<<"predit begin, image size: "<<images.size();
  std::vector<cv::Mat> im_mats;
  for (int n = 0; n < images.size(); ++n) {
    for (const auto& box : images_boxes->at(n)) {
      cv::Rect cv_roi(box.xmin, box.ymin, box.xmax - box.xmin + 1,
                      box.ymax - box.ymin + 1);
      im_mats.emplace_back(*images[n], cv_roi);
    }
  }  
  LOG(INFO)<<"im_mats size: "<<im_mats.size();
  std::vector<std::map<std::string, Algorithm::VecFloat>> Gvalues;

  classify_->Run<const std::vector<cv::Mat>&,
                 std::vector<std::map<std::string, VecFloat>>&>(im_mats,
                                                                Gvalues);

  LOG(INFO)<<"Gvalues size: "<<Gvalues.size();
  //todo
  int count = 0;
  for (auto& boxes : *images_boxes) {
    for (auto& box : boxes) {
      const auto& scores = Gvalues[count++].at("feature");
      LOG(INFO)<<"attr: begin"<<scores.size();
      for(auto& score: scores){
        Attr tmp;
        tmp.score = score;
        box.attr.push_back(tmp);
      }
      LOG(INFO)<<"attr: end";
    }
  }
}
*/


void ClassifyModule::Predict(const VecMat& images,
                             std::vector<VecBoxF>* images_boxes) {
  std::vector<cv::Mat> im_mats;
  for (auto& image : images) {
    im_mats.push_back(*image);
  }

  for (int n = 0; n < im_mats.size(); n++) {
      Algorithm::BoxF Abox;
      Algorithm::VecBoxF Aboxes;
      std::vector<std::map<std::string, Algorithm::VecFloat>> Gvalues;

      for (auto& box : (*images_boxes)[n]) {
        Abox.xmin = box.xmin;
        Abox.ymin = box.ymin;
        Abox.xmax = box.xmax;
        Abox.ymax = box.ymax;
        Aboxes.push_back(Abox);
      }
      
      classify_->Run<const cv::Mat&, const Algorithm::VecBoxF&,
                    std::vector<std::map<std::string, Algorithm::VecFloat>>&>(
                im_mats[n], Aboxes, Gvalues);
      if((*images_boxes)[n].size()!=Gvalues.size()){
        LOG(WARNING)<<"error! box size not equal to the gvalues size.";
      }
      int count = 0;
      for (auto& box : (*images_boxes)[n]){
          const auto& scores = Gvalues[count++].at("feature");
          //LOG(WARNING)<<"print obj score begin, size: "<<scores.size();
          for(auto& score: scores){
            //LOG(WARNING)<<score;
            Attr tmp;
            tmp.score = score;
            box.attr.push_back(tmp);
          }
          //LOG(WARNING)<<"print obj score end";
      }
  }
}


}  // namespace classify

}  // namespace FLOW
