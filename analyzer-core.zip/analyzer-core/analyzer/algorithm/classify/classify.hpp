#ifndef ANALYZER_ALGORITHM_CLASSIFY_HPP_
#define ANALYZER_ALGORITHM_CLASSIFY_HPP_

#include "common/tad_internal.hpp"
#include "serving/config.pb.h"
#include "algorithm/algorithm.hpp"

namespace FLOW {

namespace classify {

class ClassifyModule {
 public:
  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

  void Predict(const VecMat& images, std::vector<VecBoxF>* images_boxes);

 private:
  std::shared_ptr<Algorithm::Extract> classify_ = nullptr;
};

}

}

#endif