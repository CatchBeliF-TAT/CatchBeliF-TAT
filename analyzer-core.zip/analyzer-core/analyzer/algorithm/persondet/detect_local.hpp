#ifndef ANALYZER_ALGORITHM_PERSONDET_DETECT_LOCAL_HPP_
#define ANALYZER_ALGORITHM_PERSONDET_DETECT_LOCAL_HPP_

#include "common/tad_internal.hpp"
#include "algorithm/algorithm.hpp"
#include "serving/config.pb.h"

namespace FLOW {

namespace BreakIn {

struct RectInfo {
  cv::Rect rect;
  float score=0.0f;
  int label=0;
};

class DetectModule {
 public:
  DetectModule()=default;
  ~DetectModule();

  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config,
             int &code);

#ifdef USE_MEDIA_UTILS
  void Process(VecMat &images, VecVframe &frames,
               std::vector<std::vector<RectInfo>> &images_boxes, int &code);
#endif

  void ProcessMutilROIs(const std::vector<std::shared_ptr<cv::Mat>> &images,
                        std::vector<std::vector<cv::Rect>> rois,
                        std::vector<std::vector<RectInfo>> &images_boxes, int &code);

  std::vector<int> GetInputShapes() { return input_shapes_; }

  inference::Algorithm config_;

 private:
  std::vector<int> input_shapes_;
  std::shared_ptr<Algorithm::Detect> engine_ = nullptr;
};

}  // namespace BreakInDetection

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_PERSONDET_DETECT_LOCAL_HPP_
