#ifndef ANALYZER_ALGORITHM_PERSONDET_PERSONDET_HPP_
#define ANALYZER_ALGORITHM_PERSONDET_PERSONDET_HPP_

#include <memory>
#include <opencv2/opencv.hpp>
#include "common/type.hpp"
#include "common/util.hpp"
#include "common/boxes.hpp"
#include "detect_local.hpp"
#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

#define PERSONDET_MAX_BATCH_SIZE 16

namespace FLOW {

namespace BreakIn {

class BreakInDetector {
 public:
  void Setup(const std::vector<char>& meta_net_data, const inference::Algorithm config, int &code);

  void Predict(const cv::Mat &im_mat, Algorithm::VecFloat &vecScore);

  void Process(const std::vector<std::shared_ptr<cv::Mat>> images,
               std::vector<BreakIn_Event> &events);

 private:
  std::shared_ptr<DetectModule> detector_ = nullptr;
  inference::Algorithm config_;
};

}  // namespace PersonDet
}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_PERSONDET_PERSONDET_HPP_
