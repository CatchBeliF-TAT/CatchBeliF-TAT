#include "common/log.hpp"
#include "common/util.hpp"
#include "common/type.hpp"
#include "document.h"
#include "prettywriter.h"
#include "detect_local.hpp"
#include "common/tad_internal.hpp"


namespace FLOW {

namespace BreakIn {

using namespace std;

DetectModule::~DetectModule() { LOG(INFO) << "Deconstruct DetectModule"; }

void DetectModule::Setup(const std::vector<char>& meta_net_data,
                         const inference::Algorithm& config, int &code) {
  LOG(INFO) << "Setup DetectModule";
  config_ = config;
  Algorithm::Argument arguments;
  arguments.AddSingleArgument<std::string>("backend_type", "Native");
  arguments.AddSingleArgument<int>("device_id", config_.gpu_id());
  //arguments.AddSingleArgument<int>("max_batch_size", detect_batch_size);
  arguments.AddSingleArgument<bool>("use_fp16", true);
#ifdef USE_MEDIA_UTILS
  arguments.AddSingleArgument<bool>("device_input", config_.device_input());
#else
  arguments.AddSingleArgument<bool>("device_input", false);
#endif

  engine_ = std::make_shared<Algorithm::Detect>(meta_net_data.data(), meta_net_data.size(), arguments);

  std::vector<VecInt> network_input_shapes;
  engine_->Run<const std::string &, std::vector<VecInt> &>(
      "GetNetworkInputShapes", network_input_shapes);
  input_shapes_ = network_input_shapes[0];

  code = FLOW::module_status_success;

  LOG(INFO) << "Finished setup DetectModule";
}

#ifdef USE_MEDIA_UTILS
void DetectModule::Process(VecMat &images, VecVframe &frames,
                           std::vector<std::vector<RectInfo>> &images_boxes,
                           int &code) {
  int batch_size = config_.batch_size();
  int num_batch = images.size() / batch_size;
  if (images.size() % batch_size != 0) {
    num_batch++;
  }

  for (int i = 0; i < num_batch; i++) {
    int start_idx = i * batch_size;
    int end_idx = (i + 1) * batch_size;
    if (end_idx > images.size()) {
      end_idx = images.size();
    }
    std::vector<cv::Mat> images_batch;
    std::vector<void *> data_batch;
    for (int j = start_idx; j < end_idx; j++) {
      images_batch.push_back((*images[j]));
      //data_batch.push_back(frames[j]->data);
      data_batch.push_back(frames[j]->data);
    }

    std::vector<Algorithm::VecBoxF> Gboxes;
    engine_->Run<const std::vector<cv::Mat> &, const std::vector<void *> &,
                 std::vector<Algorithm::VecBoxF> &>(images_batch, data_batch,
                                                    Gboxes);

    vector<std::vector<RectInfo>> tmp_images_boxes;
    for (int n = 0; n < images_batch.size(); ++n) {
      std::vector<RectInfo> tmp_image_boxes;
      for (const auto &box : Gboxes[n]) {
        if (box.score > config_.detect_threshold()) {
          RectInfo tmp_image_box{};
          tmp_image_box.label = box.label;
          tmp_image_box.score = box.score;
          const auto &box_rect = box.rect<int>();
          tmp_image_box.rect =
              cv::Rect(box_rect.x, box_rect.y, box_rect.w, box_rect.h);
          tmp_image_boxes.push_back(tmp_image_box);
        }
      }
      tmp_images_boxes.push_back(tmp_image_boxes);
    }

    if (config_.detect_type_mapping_size()!=0) {
      for (int j = 0; j < tmp_images_boxes.size(); j++) {
        for (int k = 0; k < tmp_images_boxes[j].size(); k++) {
          int temp_flag = tmp_images_boxes[j][k].label;
          if (temp_flag < config_.detect_type_mapping_size()) {
            temp_flag = config_.detect_type_mapping(temp_flag);
          }
          tmp_images_boxes[j][k].label = temp_flag;
        }
      }
    }

    images_boxes.insert(images_boxes.end(), tmp_images_boxes.begin(),
                        tmp_images_boxes.end());
  }

  code = FLOW::module_status_success;
}
#endif

void DetectModule::ProcessMutilROIs(const std::vector<std::shared_ptr<cv::Mat>> &images,
                                    std::vector<std::vector<cv::Rect>> rois,
                                    vector<std::vector<RectInfo>> &images_boxes,
                                    int &code) {
  int batch_size = config_.batch_size();
  int total_rois_num = 0;
  VecMat total_images;
  std::vector<int> total_images_index;
  std::vector<cv::Rect> total_rois;
  for (int i =0;i<rois.size();i++){
    total_rois_num += rois[i].size();
    for (int j = 0;j< rois[i].size();j++){
      total_images.push_back(images[i]);
      total_rois.push_back(rois[i][j]);
      total_images_index.push_back(i);
    }
  }
  int num_batch = total_rois_num / batch_size;
  if (images.size() % batch_size != 0) {
    num_batch++;
  }
  vector<std::vector<RectInfo>> tmp_images_boxes;
  tmp_images_boxes.resize(images.size());

  for (int i = 0; i < num_batch; i++) {
    int start_idx = i * batch_size;
    int end_idx = (i + 1) * batch_size;
    if (end_idx > total_images.size()) {
      end_idx = total_images.size();
    }
    std::vector<cv::Mat> images_batch;
    std::vector<cv::Rect> images_roi;
    for (int j = start_idx; j < end_idx; j++) {
      images_batch.push_back((*total_images[j])(total_rois[j]));
      images_roi.push_back(total_rois[j]);
    }

    std::vector<Algorithm::VecBoxF> Gboxes;
    engine_
        ->Run<const std::vector<cv::Mat> &, std::vector<Algorithm::VecBoxF> &>(
            images_batch, Gboxes);

    for (int n = 0; n < images_batch.size(); ++n) {
      const auto &image_roi = images_roi[n];
      // std::vector<RectInfo> tmp_image_boxes;
      for (const auto &box : Gboxes[n]) {
        if (box.score > config_.detect_threshold()) {
          RectInfo tmp_image_box{};
          tmp_image_box.label = box.label;
          tmp_image_box.score = box.score;
          const auto &box_rect = box.rect<int>();
          tmp_image_box.rect =
              cv::Rect(box_rect.x + image_roi.x, box_rect.y + image_roi.y,
                       box_rect.w, box_rect.h);
          tmp_images_boxes[total_images_index[start_idx+n]].push_back(tmp_image_box);
        }
      }
      //tmp_images_boxes.push_back(tmp_image_boxes);
    }

    if (config_.detect_type_mapping_size()!=0) {
      for (int j = 0; j < tmp_images_boxes.size(); j++) {
        for (int k = 0; k < tmp_images_boxes[j].size(); k++) {
          int temp_flag = tmp_images_boxes[j][k].label;
          if (temp_flag < config_.detect_type_mapping_size()) {
            temp_flag = config_.detect_type_mapping(temp_flag);
          }
          tmp_images_boxes[j][k].label = temp_flag;
        }
      }
    }

  }
  images_boxes.insert(images_boxes.end(), tmp_images_boxes.begin(),
                      tmp_images_boxes.end());

  code = FLOW::module_status_success;
}

}  // namespace BreakInDetection

}  // namespace FLOW
