#include "persondet.hpp"
#include "common/log.hpp"

namespace FLOW {

namespace BreakIn {

struct rect_node {
  RectInfo info;
  rect_node *parent;
  int index;
};

inline float size_rectInfo(RectInfo info) {
  return info.rect.width * info.rect.height;
}

inline bool is_match(RectInfo info1, RectInfo info2, float thresh_old) {
  if (info1.label == info2.label) {
    int startx = std::max(info1.rect.x, info2.rect.x);
    int endx = std::min(info1.rect.x + info1.rect.width,
                        info2.rect.x + info2.rect.width);
    int starty = std::max(info1.rect.y, info2.rect.y);
    int endy = std::min(info1.rect.y + info1.rect.height,
                        info2.rect.y + info2.rect.height);

    if ((endx > startx) && (endy > starty) &&
        (endy - starty) * (endx - startx) /
                (size_rectInfo(info1) + size_rectInfo(info2) -
                 (endy - starty) * (endx - startx)) >
            thresh_old) {
      //LOG(INFO) << "IOU = "
      //          << (endy - starty) * (endx - startx) /
      //                 (size_rectInfo(info1) + size_rectInfo(info2) -
      //                  (endy - starty) * (endx - startx));
      return true;
    }
  }
  return false;
}

inline double IOU(const BoxF& r1, const BoxF& r2) {
    int x1 = std::max(r1.xmin, r2.xmin);
    int y1 = std::max(r1.ymin, r2.ymin);
    int x2 = std::min(r1.xmax, r2.xmax);
    int y2 = std::min(r1.ymax, r2.ymax);
    int w = std::max(0, (x2-x1+1));
    int h = std::max(0, (y2-y1+1));
    double inter = w * h;
    double r1_area = (r1.xmax - r1.xmin) * (r1.ymax - r1.ymin);
    double r2_area = (r2.xmax - r2.xmin) * (r2.ymax - r2.ymin);
    double o = inter / (r1_area + r2_area - inter);
    return (o >= 0) ? o : 0;
}

bool check_person_box(const BoxF& box, const VecBoxF& vec_boxs, const float iou_threthod) {
  int if_duplicate = false;
  for (auto &filter_box : vec_boxs) {
    if (IOU(box, filter_box) > iou_threthod) {
      if_duplicate = true;
      break;
    }
  }
  return if_duplicate;
}

static std::vector<std::vector<RectInfo>> merge_boxes(
    std::vector<std::vector<RectInfo>> images_boxes) {
  std::vector<std::vector<RectInfo>> merged_boxes;
  for (auto boxes : images_boxes) {
    std::vector<rect_node> out_boxes;
    std::vector<RectInfo> merge_out;
    out_boxes.resize(boxes.size());
    int index = 0;
    for (auto box : boxes) {
      out_boxes[index].info = box;
      out_boxes[index].parent = nullptr;
      out_boxes[index].index = index;
      index++;
    }
    index = 0;
    for (auto box : boxes) {
      bool is_merge = false;
      for (auto out_box : out_boxes) {
        if (is_match(box, out_box.info, 0.3)) {
          rect_node temp = out_box;
          while (temp.parent) {
            temp = *temp.parent;
          }
          out_boxes[index].index = temp.index;
          is_merge = true;
        }
        if (is_merge) break;
      }
      index++;
    }

    for (int i = 0; i < index; i++) {
      RectInfo info;
      int n_num = 0;
      for (auto box : out_boxes) {
        rect_node temp = box;
        while (temp.parent) {
          temp = *temp.parent;
        }
        if (temp.index == i) {
          n_num++;
          info.rect.x += temp.info.rect.x;
          info.rect.y += temp.info.rect.y;
          info.rect.width += temp.info.rect.width;
          info.rect.height += temp.info.rect.height;
          info.label += temp.info.label;
          info.score += temp.info.score;
        }
      }
      if (n_num > 0) {
        RectInfo info_out;
        info_out.label = info.label;
        info_out.score = info.score / n_num;
        info_out.rect.x = info.rect.x / n_num;
        info_out.rect.y = info.rect.y / n_num;
        info_out.rect.width = info.rect.width / n_num;
        info_out.rect.height = info.rect.height / n_num;
        merge_out.push_back(info_out);
      }
    }
    merged_boxes.push_back(merge_out);
    out_boxes.clear();
  }
  return merged_boxes;
}

void BreakInDetector::Setup(const std::vector<char>& meta_net_data,
                           const inference::Algorithm config, int &code) {
  config_ = config;
  detector_ = std::make_shared<DetectModule>();
  detector_->Setup(meta_net_data, config_, code);
}

// fight process
void BreakInDetector::Process(const std::vector<std::shared_ptr<cv::Mat>> images,
                             std::vector<BreakIn_Event> &events) {
  Profiler PersonDet_profile;
  PersonDet_profile.tic("BreakIn Process");
  events.clear();
  std::vector<std::shared_ptr<cv::Mat>> image_process;
  std::vector<cv::Rect> rois;
  rois.push_back(
      cv::Rect{0, 0, images[0]->cols / 3 * 2, images[0]->rows / 3 * 2});
  rois.push_back(cv::Rect{images[0]->cols / 3 - 1, 0, images[0]->cols / 3 * 2,
                          images[0]->rows / 3 * 2});
  rois.push_back(cv::Rect{0, images[0]->rows / 3 - 1, images[0]->cols / 3 * 2,
                          images[0]->rows / 3 * 2});
  rois.push_back(cv::Rect{images[0]->cols / 3 - 1, images[0]->rows / 3 - 1,
                          images[0]->cols / 3 * 2, images[0]->rows / 3 * 2});
  std::vector<std::vector<cv::Rect>> repeat_rois;
  for (int i = 0; i < images.size(); i++) {
    repeat_rois.push_back(rois);
  }
  std::vector<std::vector<RectInfo>> images_boxes;
  int code;
  detector_->ProcessMutilROIs(images, repeat_rois, images_boxes, code);
  auto merged_boxes = merge_boxes(images_boxes);
  //{
  //  for (int i = 0; i < merged_boxes.size(); i++) {
  //    auto im_show = images[i]->clone();
  //    for (int index = 0; index < rois.size(); ++index) {
  //      cv::imwrite("ori_" + std::to_string(index) + ".bmp",
  //                  im_show(rois[index]));
  //    }
  //
  //    for (auto box : merged_boxes[i]) {
  //      cv::rectangle(
  //          im_show, cvPoint(box.rect.x, box.rect.y),
  //          cvPoint(box.rect.x + box.rect.width, box.rect.y + box.rect.height),
  //          cvScalar(255, 0, 0, 0), 2, 8, 0);
  //    }
  //    cv::imwrite("test.jpg", im_show);
  //  }
  //}
  for (auto &boxes : images_boxes) {
    std::vector<float> scores;
    BreakIn_Event event;
    VecBoxF temp_persons;
    for (auto box : boxes) {
      if (box.label == 0) {
        BoxF boxF;
        boxF.score = box.score;
        boxF.label = box.label;
        boxF.xmin = box.rect.x;
        boxF.ymin = box.rect.y;
        boxF.xmax = box.rect.x + box.rect.width;
        boxF.ymax = box.rect.y + box.rect.height;
        temp_persons.push_back(boxF);
      }
      if (box.label == 1) {
        BoxF boxF;
        boxF.score = box.score;
        boxF.label = box.label;
        boxF.xmin = box.rect.x;
        boxF.ymin = box.rect.y;
        boxF.xmax = box.rect.x + box.rect.width;
        boxF.ymax = box.rect.y + box.rect.height;
        event.non_motors.push_back(boxF);
      }
    }
    for (auto &person_box : temp_persons) {
      if (!check_person_box(person_box, event.non_motors, 0.7)) {
        event.persons.push_back(person_box);
      }
    }
    events.push_back(event);
  }

  PersonDet_profile.toc("BreakIn Process");
  LOG(INFO) << PersonDet_profile.get_stats_str();
}

}  // namespace PersonDet

}  // namespace FLOW
