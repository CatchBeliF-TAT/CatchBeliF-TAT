#include "waimai_plate.hpp"

#include "common/helper.hpp"
#include "common/log.hpp"

namespace FLOW {

namespace Plate {

void WaiMaiPlate::Setup(const std::vector<char>& meta_net_data,
                        const inference::Algorithm& config) {
  LOG(INFO) << "Setup WaiMaiPlateModule";
  config_ = config;

  Algorithm::Argument east_arguments;
  east_arguments.AddSingleArgument<int>("net_id", 0);
  east_arguments.AddSingleArgument<std::string>("method", "east");
  east_arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  east_arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  east_arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());
  east_arguments.AddSingleArgument<bool>("use_fp16", true);
  east_arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  east_arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
  east_ = std::make_shared<Algorithm::Landmark>(
      meta_net_data.data(), meta_net_data.size(), east_arguments);

  Algorithm::Argument crnn_arguments;
  crnn_arguments.AddSingleArgument<int>("net_id", 1);
  crnn_arguments.AddSingleArgument<std::string>("method", "crnn");
  crnn_arguments.AddSingleArgument<std::string>("backend_type", "Native");
  crnn_arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  crnn_arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());
  crnn_arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  crnn_arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());
  crnn_arguments.AddRepeatedArgument<std::string>("categories",{"feature"});
  crnn_ = std::make_shared<Algorithm::OCR>(
      meta_net_data.data(), meta_net_data.size(), crnn_arguments);

  LOG(INFO) << "Finished setup WaiMaiPlateModule";
}

void WaiMaiPlate::Predict(const cv::Mat& im_mat, VecBoxF* boxes) {
  if (boxes->empty()) return;

  std::vector<cv::Mat> persons;
  for (const auto& box : *boxes) {
    cv::Rect cv_roi(box.xmin, box.ymin, box.xmax - box.xmin,
                    box.ymax - box.ymin);
    persons.emplace_back(im_mat, cv_roi);
  }

  std::vector<Algorithm::VecPolygonF> Gpolygons;
  east_->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecPolygonF>&>(
      persons, Gpolygons);

  std::vector<cv::Mat> plates;
  for (int n = 0; n < persons.size(); ++n) {
    const auto& person = persons[n];
    auto& box = boxes->at(n);
    box.plates.clear();
    for (const auto& polygon : Gpolygons[n]) {
      VecPointF points;
      std::vector<cv::Point2f> cv_points;
      for (const auto& point : polygon.points) {
        points.emplace_back(point.x + box.xmin, point.y + box.ymin);
        cv_points.emplace_back(point.x, point.y);
      }
      box.plates.emplace_back(points);
      plates.push_back(
          std::move(Helper::PerspectiveAlignment(person, cv_points, 48, 100)));
    }
  }

  VecString contents;
  std::vector<VecFloat> scores;
  std::vector<std::map<std::string, VecFloat>> clsValues;
  crnn_->Run<const std::vector<cv::Mat>&, VecString&, std::vector<VecFloat>&, 
      std::vector<std::map<std::string, VecFloat>>&>(
      plates, contents, scores, clsValues);

  VecInt types;
  for (const auto& clsValue : clsValues) {
    const auto& features = clsValue.at("feature");
    const auto max_iter = std::max_element(features.begin(), features.end());
    types.push_back(max_iter - features.begin() + PlateTypeNonmotorStart + 1);
  }

  for(int i=0,k=0; i<boxes->size(); i++){
    auto& box = boxes->at(i);
    for(int j=0; j<box.plates.size(); j++,k++){
      auto& plate = box.plates.at(j);
      plate.label = types[k];
      plate.content = config_.plate_prefix_value() + contents[k];
      plate.score = scores[k].empty()
                        ? 0
                        : *std::min_element(scores[k].begin(), scores[k].end());
    }
  }
}

}  // namespace Plate

}  // namespace FLOW
