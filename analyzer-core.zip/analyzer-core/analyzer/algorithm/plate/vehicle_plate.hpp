#ifndef ANALYZER_ALGORITHM_PLATE_VEHICLE_PLATE_HPP_
#define ANALYZER_ALGORITHM_PLATE_VEHICLE_PLATE_HPP_

#include "common/flow/flow_process.hpp"
#include "common/tad_internal.hpp"
#include "serving/config.pb.h"
#include "serving/input_arguments.pb.h"

#include "algorithm/algorithm.hpp"

#include "helper.hpp"

namespace FLOW {

namespace Plate {

class VehiclePlate {
 public:
  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config,
             int& code);

  void Predict(const cv::Mat& im_mat, VecBoxF* boxes);
  void Predict(const VecShellFrame& shell_frames, std::vector<VecBoxF>* vec_boxes);

 private:
  inference::Algorithm config_;
  std::shared_ptr<Algorithm::Landmark> east_ = nullptr;
  std::shared_ptr<Algorithm::OCR> satrn_ = nullptr;
  std::vector<int> input_shapes_;
  std::map<std::string, float> plate_first_character_min_score_map_;

 public:
  typedef std::tuple<cv::Mat, BoxF> input_type;
  typedef BoxF result_type;
  typedef result_type output_type;

 public:
  size_t MaxBatchSize() const;
  void Process(const input_type& in, output_type* out);
  void ProcessBatch(const std::vector<input_type>& in,
                    const std::vector<output_type*>* out);
  static input_type ConvertInput(const cv::Mat& mat,
                                 const inference::PictureReq& req);
  static inference::PictureResp ConvertOutput(const output_type& results);
};

class sync_vehicle_plate : public flow_process_sync<VehiclePlate> {
 public:
  typedef flow_process_sync<VehiclePlate> processer_type;
  typedef std::shared_ptr<processer_type> sync_handle;

 public:
  sync_vehicle_plate() : processer_type("fp_vehicle_plate") {}
};

}  // namespace Plate

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_PLATE_VEHICLE_PLATE_HPP_
