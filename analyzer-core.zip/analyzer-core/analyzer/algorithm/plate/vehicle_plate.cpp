#include "vehicle_plate.hpp"

#include "common/helper.hpp"
#include "common/log.hpp"
#include "common/io.hpp"

#include "proto/tron.pb.h"

namespace FLOW {

namespace Plate {

float get_blurness_score(const cv::Mat& im_mat, const BoxF& box,
                         int block_size = 8) {
  cv::Mat image;
  cv::resize(im_mat(cv::Rect2f(box.xmin, (box.ymin + box.ymax) / 2,
                               box.xmax - box.xmin, (box.ymax - box.ymin) / 2)),
             image, cv::Size(256, 128));

  if (image.channels() == 3) {
    cv::cvtColor(image, image, cv::COLOR_BGR2GRAY);
  }

  int bin_h = image.rows / block_size, bin_w = image.cols / block_size;

  double total_rate = 0;
  for (int h = 0; h < bin_h; ++h) {
    for (int w = 0; w < bin_w; ++w) {
      int h_start = h * block_size, w_start = w * block_size;
      cv::Mat image_patch, image_spectrum;
      image(cv::Rect(w_start, h_start, block_size, block_size))
          .convertTo(image_patch, CV_32FC1);
      cv::dct(image_patch, image_spectrum);
      total_rate += image_spectrum.at<float>(0, 0) /
                    (cv::sum(cv::abs(image_spectrum.diag())).val[0] + 1e-10);
    }
  }

  auto blur_ratio_1 = static_cast<float>(total_rate / bin_w / bin_h);

  cv::Mat image_blur_1, image_blur_2, image_f, image_blur_1_f, image_blur_2_f;
  cv::GaussianBlur(image, image_blur_1, cv::Size(5, 5), 0);
  cv::GaussianBlur(image_blur_1, image_blur_2, cv::Size(5, 5), 0);

  image.convertTo(image_f, CV_32FC1);
  image_blur_1.convertTo(image_blur_1_f, CV_32FC1);
  image_blur_2.convertTo(image_blur_2_f, CV_32FC1);

  static auto g_mask = cv::Mat(128, 256, CV_32FC1, cv::Scalar(0.2));
  g_mask(cv::Rect(64, 32, 128, 64)) =
      cv::Mat(64, 128, CV_32FC1, cv::Scalar(0.8));

  auto img_1 = (image_f - image_blur_1_f).mul(g_mask);
  auto img_2 = (image_blur_1_f - image_blur_2_f).mul(g_mask);

  auto mean_1 = cv::mean(img_1.mul(img_1)), mean_2 = cv::mean(img_2.mul(img_2));

  auto blur_ratio_2 = static_cast<float>(mean_2.val[0] / mean_1.val[0]);

  return blur_ratio_1 * 0.2f + blur_ratio_2 * 0.8f;
}

void VehiclePlate::Setup(const std::vector<char>& meta_net_data,
                         const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Setup VehiclePlateModule";

  config_ = config;

  Algorithm::Argument dbnet_arguments;
  dbnet_arguments.AddSingleArgument<int>("net_id", 0);
  dbnet_arguments.AddSingleArgument<std::string>("method", "dbnet");
  dbnet_arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  dbnet_arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  dbnet_arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());
  dbnet_arguments.AddSingleArgument<bool>("use_fp16", true);
  dbnet_arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  dbnet_arguments.AddSingleArgument<std::string>("cache_engine_dir",
                                                config.cache_engine_dir());
  east_ = std::make_shared<Algorithm::Landmark>(
      meta_net_data.data(), meta_net_data.size(), dbnet_arguments);
  
  tron::MetaNetParam meta_net_param;
  IO::ReadProtoFromArray(meta_net_data.data(), meta_net_data.size(),
                         &meta_net_param);

  Algorithm::Argument satrn_arguments;
  std::vector<VecInt> crnn_input_shapes;

  satrn_arguments.AddSingleArgument<int>("net_id", 1);
  satrn_arguments.AddRepeatedArgument<std::string>("categories",
                                                    {"feature", "feature_blurness"});
  satrn_arguments.AddSingleArgument<std::string>("method", "satrn");
  satrn_arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  satrn_arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  satrn_arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());
  satrn_arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  satrn_arguments.AddSingleArgument<std::string>("cache_engine_dir",
                                                config.cache_engine_dir());
  satrn_ = std::make_shared<Algorithm::OCR>(
      meta_net_data.data(), meta_net_data.size(), satrn_arguments);

  satrn_->Run<const std::string&, std::vector<VecInt>&>("GetNetworkInputShapes",
                                                       crnn_input_shapes);
  
  for (int d = 0; d < crnn_input_shapes[0].size(); ++d) {
      input_shapes_.push_back(crnn_input_shapes[0][d]);
  }

  // init plate_first_character_min_score_map_
  for (auto &&kv : config_.plate_first_character_min_score_list()) {
    plate_first_character_min_score_map_[kv.key()] = kv.value();
  }

  code = FLOW::module_status_success;
  LOG(INFO) << "Finished setup VehiclePlateModule";
}

void VehiclePlate::Predict(const cv::Mat &im_mat, VecBoxF *boxes) {
  const VecShellFrame vec_mat{std::make_shared<ShellFrame>(std::make_shared<cv::Mat>(im_mat))};
  std::vector<VecBoxF> vec_boxes{*boxes};
  Predict(vec_mat, &vec_boxes);
  boxes->swap(vec_boxes.at(0));
}

void VehiclePlate::Predict(const VecShellFrame& shell_frames, std::vector<VecBoxF>* vec_boxes) {
  CHECK_EQ(shell_frames.size(), vec_boxes->size());

  if (shell_frames.empty()) return;

  std::vector<cv::Mat> vehicles;
  std::vector<cv::Mat> all_mats;
  std::vector<BoxF*> boxes_addr;
  for (int n = 0; n < shell_frames.size(); ++n) {
    auto& im_mat = *shell_frames[n]->getMat();
    auto& boxes = vec_boxes->at(n);
    for (auto& box : boxes) {
      cv::Rect cv_roi(box.xmin, box.ymin, box.xmax - box.xmin,
                      box.ymax - box.ymin);
      vehicles.emplace_back(im_mat, cv_roi);
      all_mats.push_back(im_mat);
      boxes_addr.push_back(&box);
    }
  }

  std::vector<Algorithm::VecPolygonF> Gpolygons;
  east_->Run<const std::vector<cv::Mat>&, std::vector<Algorithm::VecPolygonF>&>(
      vehicles, Gpolygons);

  std::vector<cv::Mat> plates;
  for (int n = 0; n < vehicles.size(); ++n) {
    const auto& vehicle = vehicles[n];
    auto& box = *boxes_addr[n];
    box.plates.clear();
    for (const auto& polygon : Gpolygons[n]) {
      VecPointF points;
      std::vector<cv::Point2f> cv_points;
      for (const auto& point : polygon.points) {
        points.emplace_back(point.x + box.xmin, point.y + box.ymin);
        cv_points.emplace_back(point.x, point.y);
      }
      auto plate_mat = Helper::PerspectiveAlignment(vehicle, cv_points, input_shapes_[2], input_shapes_[3]);
      auto boundingRect = cv::boundingRect(cv_points);
      if ((!config_.has_plate_min_w() || boundingRect.width >= config_.plate_min_w()) &&
          (!config_.has_plate_min_h() || boundingRect.height >= config_.plate_min_h()) ) {
        box.plates.emplace_back(points);
        plates.push_back(std::move(plate_mat));
      }
    }
  }

  VecString contents;
  std::vector<VecFloat> scores;
  std::vector<std::map<std::string, VecFloat>> Gvalues;
  satrn_->Run<const std::vector<cv::Mat>&, VecString&, std::vector<VecFloat>&, 
      std::vector<std::map<std::string, VecFloat>>&>(
      plates, contents, scores, Gvalues);
  
  VecFloat blurnessScores;
  for (const auto& values : Gvalues) {
    const auto& feature_blurness = values.at("feature_blurness");
    blurnessScores.push_back(feature_blurness[0]);
  }

  VecInt types;
  for (const auto& values : Gvalues) {
    const auto& feature = values.at("feature");
    const auto max_iter = std::max_element(feature.begin(), feature.end());
    types.push_back(max_iter - feature.begin() + PlateTypeVehicleStart + 1);
  }

  for(int i=0,k=0; i<boxes_addr.size(); i++){
    auto& box = *boxes_addr[i];
    auto& im_mat = all_mats[i];
    for(int j=0; j<box.plates.size(); j++,k++){
      auto& plate = box.plates.at(j);
      plate.label = types[k];
      plate.content = contents[k];
      const auto t_scores = scores[k];
      float blurness_score = 0.0f;
      if (blurnessScores.size() > k) {
        blurness_score = blurnessScores[k];
      } else {
        blurness_score = (1.0f - std::max(std::min(get_blurness_score(im_mat, box), 1.0f), 0.0f));
      }
      plate.score = t_scores.empty() ? 0 : blurness_score;
      plate.score_by_character = t_scores;
      size_t plate_length = Helper::utf8_length(plate.content.c_str(), plate.content.size());
      const size_t plate_length_min =
          config_.plate_character_min_count() <= 0 ? plate_length : config_.plate_character_min_count();
      const size_t plate_length_max =
          config_.plate_character_max_count() <= 0 ? plate_length : config_.plate_character_max_count();
      if (plate_length < plate_length_min || plate_length > plate_length_max) {
        plate.content.clear();
        plate.score = 0;
      } else if (!t_scores.empty()) {
        const auto plate_first_character_length = Helper::utf8_first_length(plate.content.c_str(), plate.content.size());
        const auto plate_first_character = plate.content.substr(0, plate_first_character_length);
        bool need_replace = false;
        if (plate_first_character_min_score_map_.count(plate_first_character) > 0 &&
            t_scores[0] < plate_first_character_min_score_map_[plate_first_character]) {
          need_replace = true;
        } else if (config_.has_plate_first_character_min_score() &&
                 t_scores[0] < config_.plate_first_character_min_score()) {
          need_replace = true;
        } else {
          // nop
        }
        if (need_replace) {
          plate.content.replace(0, plate_first_character_length, config_.plate_first_character_default_value());
        }
      } else {
        // nop
      }
    }
  }
}

size_t VehiclePlate::MaxBatchSize() const { return config_.batch_size(); }

void VehiclePlate::Process(const input_type& in, output_type* out) {
  std::vector<output_type*> outs{out};
  ProcessBatch({in}, &outs);
}

void VehiclePlate::ProcessBatch(const std::vector<input_type>& in,
                                const std::vector<output_type*>* out) {
  LOG_IF(FATAL, in.size() != out->size()) << "size error";

  VecShellFrame images;
  std::vector<VecBoxF> boxes;
  // input
  for (int i = 0; i < in.size(); i++) {
    const auto& mat = std::get<0>(in[i]);
    const auto& box = std::get<1>(in[i]);
    images.push_back(std::make_shared<ShellFrame>(std::make_shared<cv::Mat>(mat)));
    boxes.push_back(VecBoxF{box});
  }

  Predict(images, &boxes);

  for (int i = 0; i < boxes.size(); i++) {
    *(out->at(i)) = boxes[i].front();
  }
}

VehiclePlate::input_type VehiclePlate::ConvertInput(
    const cv::Mat& mat, const inference::PictureReq& req) {
  BoxF box = req.has_rect() ? BoxF(req.rect().x(), req.rect().y(),
                                   req.rect().x() + req.rect().w() - 1,
                                   req.rect().y() + req.rect().h() - 1)
                            : BoxF(0, 0, mat.cols - 1, mat.rows - 1);
  return input_type{mat, box};
}

inference::PictureResp VehiclePlate::ConvertOutput(const output_type& results) {
  inference::PictureResp resp;
  for( auto& plate : results.plates ) {
    auto x_pair = std::minmax_element(plate.points.begin(), plate.points.end(),
                  [](const PlateInfo<float>::PointT& p1, const PlateInfo<float>::PointT& p2) { return p1.x < p2.x; });
    auto y_pair = std::minmax_element(plate.points.begin(), plate.points.end(),
                  [](const PlateInfo<float>::PointT& p1, const PlateInfo<float>::PointT& p2) { return p1.y < p2.y; });
    resp.add_label(helperGetStringPlateType(plate.label));
    resp.add_content(plate.content);
    resp.add_score(plate.score);
    std::copy(plate.score_by_character.begin(), plate.score_by_character.end(), 
                google::protobuf::RepeatedFieldBackInserter(resp.add_plate_score_by_character()->mutable_data()));
    auto rect = resp.add_object();
    rect->set_x(x_pair.first->x);
    rect->set_y(y_pair.first->y);
    rect->set_w(x_pair.second->x - x_pair.first->x + 1);
    rect->set_h(y_pair.second->y - y_pair.first->y + 1);
  }
  return resp;
}

}  // namespace Plate

}  // namespace FLOW
