#ifndef ANALYZER_ALGORITHM_PLATE_HELPER_HPP_
#define ANALYZER_ALGORITHM_PLATE_HELPER_HPP_
#include <string>

namespace FLOW {

namespace Plate {

enum PlateType {
    PlateTypeVehicleStart = 0,
    PlateTypeNonmotorStart = 0xf0,
};

inline std::string helperGetStringPlateType(int plate_type) {
  switch (plate_type) {
    // vehicle
    case PlateTypeVehicleStart:
         return "";
    case (PlateTypeVehicleStart+1):
      return "s_blue";
    case (PlateTypeVehicleStart+2):
      return "s_yellow";
    case (PlateTypeVehicleStart+3):
      return "s_green";
    case (PlateTypeVehicleStart+4):
      return "d_yellow";
    case (PlateTypeVehicleStart+5):
      return "s_white";
    case (PlateTypeVehicleStart+6):
      return "d_white";
    case (PlateTypeVehicleStart+7):
      return "d_blue";
    // nonmotor
    case PlateTypeNonmotorStart:
         return "";
    case (PlateTypeNonmotorStart+1):
      return "d_yellow";
    case (PlateTypeNonmotorStart+2):
      return "d_blue";
    case (PlateTypeNonmotorStart+3):
      return "d_white";
    case (PlateTypeNonmotorStart+4):
      return "d_green";
    default:
      break;
  }
  char buf[32];
  sprintf(buf, "%d", plate_type);
  return buf;
}

} // namespace Plate
} // namespace FLOW

#endif // ANALYZER_ALGORITHM_PLATE_HELPER_HPP_