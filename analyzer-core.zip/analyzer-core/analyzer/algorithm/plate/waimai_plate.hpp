#ifndef ANALYZER_ALGORITHM_PLATE_WAIMAI_PLATE_HPP_
#define ANALYZER_ALGORITHM_PLATE_WAIMAI_PLATE_HPP_

#include "common/tad_internal.hpp"

#include "algorithm/algorithm.hpp"
#include "serving/config.pb.h"

#include "helper.hpp"
namespace FLOW {

namespace Plate {

class WaiMaiPlate {
 public:
  void Setup(const std::vector<char>& meta_net_data, const inference::Algorithm& config);

  void Predict(const cv::Mat& im_mat, VecBoxF* boxes);

 private:
  inference::Algorithm config_;
  std::shared_ptr<Algorithm::Landmark> east_ = nullptr;
  std::shared_ptr<Algorithm::OCR> crnn_ = nullptr;
};

}  // namespace Plate

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_PLATE_WAIMAI_PLATE_HPP_
