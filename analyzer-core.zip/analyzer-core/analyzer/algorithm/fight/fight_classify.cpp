#include "fight_classify.hpp"

#include "common/util.hpp"

namespace FLOW {

namespace FightClassify {

inline void softmax(float* input, int input_len) {
  assert(input != NULL);
  assert(input_len != 0);
  int i;
  float m;

  m = input[0];
  for (i = 1; i < input_len; i++) {
    if (input[i] > m) {
      m = input[i];
    }
  }

  float sum = 0;
  for (i = 0; i < input_len; i++) {
    sum += expf(input[i] - m);
  }

  for (i = 0; i < input_len; i++) {
    input[i] = expf(input[i] - m - log(sum));
  }
}

void FightClassify::Setup(const std::vector<char>& meta_net_data,
                          const inference::Algorithm& config, int& code) {
  LOG(INFO) << "Create FightClassifyModule";

  config_ = config;

  Algorithm::Argument arguments;
  arguments.AddSingleArgument<int>("net_id", 0);
  arguments.AddSingleArgument<std::string>("method", "classify");
  arguments.AddSingleArgument<std::string>("backend_type", "TensorRT");
  arguments.AddSingleArgument<int>("device_id", config.gpu_id());
  arguments.AddSingleArgument<int>("max_batch_size", config.batch_size());
  arguments.AddSingleArgument<bool>("use_fp16", true);
  arguments.AddRepeatedArgument<std::string>("categories", {"feature"});
  arguments.AddSingleArgument<bool>("cache_engine", config.cache_engine());
  arguments.AddSingleArgument<std::string>("cache_engine_dir", config.cache_engine_dir());

  classify_ = std::make_shared<Algorithm::Extract>(
      meta_net_data.data(), meta_net_data.size(), arguments);

  code = FLOW::module_status_success;

  LOG(INFO) << "Finished create FightClassifyModule!";
}

void FightClassify::Predict(VecMat& images, std::vector<Fight_Event>& events,
                            int& code) {
  std::vector<cv::Mat> im_mats;
  for (const auto& image : images) {
    im_mats.push_back(*image);
  }

  std::vector<std::map<std::string, Algorithm::VecFloat>> Gvalues;
  classify_->Run<const std::vector<cv::Mat>&,
                 std::vector<std::map<std::string, Algorithm::VecFloat>>&>(
      im_mats, Gvalues);

  for (const auto& values : Gvalues) {
    std::vector<float> per_img_scores = values.at("feature");
    softmax(per_img_scores.data(), per_img_scores.size());

    Fight_Event event;
    event.predict_score = per_img_scores[config_.class_index_fighting()];
    event.if_predicted = true;
    events.push_back(event);
  }

  code = FLOW::module_status_success;
}

}  // namespace FightClassify

}  // namespace FLOW
