#ifndef ANALYZER_ALGORITHM_FIGHT_FIGHT_CLASSIFY_HPP_
#define ANALYZER_ALGORITHM_FIGHT_FIGHT_CLASSIFY_HPP_

#include "common/tad_internal.hpp"
#include "serving/config.pb.h"

#include "algorithm/algorithm.hpp"

namespace FLOW {

namespace FightClassify {

class FightClassify {
 public:
  void Setup(const std::vector<char>& meta_net_data,
             const inference::Algorithm& config, int& code);

  void Predict(VecMat& images, std::vector<Fight_Event>& events, int& code);

 private:
  inference::Algorithm config_;
  std::shared_ptr<Algorithm::Extract> classify_ = nullptr;
};

}  // namespace FightClassify

}  // namespace FLOW

#endif  // ANALYZER_ALGORITHM_FIGHT_FIGHT_CLASSIFY_HPP_
